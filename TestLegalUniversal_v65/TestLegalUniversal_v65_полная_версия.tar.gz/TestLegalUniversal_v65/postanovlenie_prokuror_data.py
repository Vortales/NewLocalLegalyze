"""postanovlenie_prokuror_data.py — постановления Прокурора (v36).

Прокурор выносит постановления по обращениям, поступившим в Офис
Генерального прокурора. Состав и формулировки взяты из примеров
(`Постановление Прокурора/1–6.txt`) и Регламента подачи обращений:

* шапка «STATE OF SAN-ANDREAS / OFFICE OF THE ATTORNEY GENERAL»;
* «ПОСТАНОВЛЕНИЕ № …» + заголовок вида решения;
* «Я, Прокурор штата Сан-Андреас ФИО, удостоверение № …, руководствуясь
  частью 2 статьи 36 Конституции штата, частями 1, 2 и 6 статьи 8 Закона
  «О деятельности офиса Генерального прокурора», статьями 11–14 Регламента
  подачи обращений, рассмотрев обращение гражданина … от …»;
* «УСТАНОВИЛ:» — фактические обстоятельства и правовая оценка;
* «ПОСТАНОВИЛ:» — резолюция (принять / отказать / привлечь / передать в суд).

Порядок работы такой же, как у IAD: форма → «Сформировать» → .txt в чат →
ответ ИИ → PNG собирается ТОЛЬКО из ответа ИИ.
"""

from __future__ import annotations

import re
import datetime
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import postanovlenie_data as base
from postanovlenie_data import (
    _clean, act_genitive, clause_genitive, clean_document_text, diag_event,
    extract_document_block, has_answer_end, initials_signature, is_own_request,
    is_section_heading, is_ui_noise, is_vague_clause, normalize_clause,
    scrub_chat_text, split_subject, strip_markdown, today_ru, _BULLET,
    _NUMBERED,
)

#: Значения-заглушки: ИИ подставляет их, когда данных нет (v37).
_GOV_PLACEHOLDER = re.compile(
    r"(по\s+обстоятельствам,?\s+указанным\s+в\s+заявке|"
    r"согласно\s+обстоятельствам,?\s+указанным\s+в\s+заявке|"
    r"по\s+указанным\s+обстоятельствам|"
    r"на\s+основании\s+обстоятельств,?\s+указанных\s+в\s+заявке|"
    r"в\s+ходе\s+служебной\s+деятельности|"
    r"в\s+процессе\s+служебной\s+деятельности|"
    r"не\s+установлен[оаы]?|нет\s+данных|"
    r"информация\s+отсутствует|данные\s+отсутствуют)",
    re.IGNORECASE,
)


#: v51 (выгрузка AG-2): «Доказательства: представлены» — это НЕ доказательство.
#: ИИ отвечает одним словом «представлены», и в PNG появлялось «В подтверждение
#: представлено: представлены.» (замечание: «лишний абзац»).
_GOV_EVIDENCE_STUB = re.compile(
    r"^(?:представлен[оаы]?|приложен[оаы]?|прилагает\w*|имеются|есть|да|"
    r"не\s+представлен\w*|отсутству\w*|не\s+указан\w*|нет)$",
    re.IGNORECASE,
)

#: «В подтверждение представлено: …» — только для НАСТОЯЩИХ доказательств
#: (ссылка, видео, тайм-код). Слово-заглушка туда попадать не должно (v51).
_GOV_EVIDENCE_REAL = re.compile(
    r"(https?://|www\.|видео|запис|тайм[- ]?код|\d{1,2}:\d{2}|"
    r"скрин|фото|ссылк|youtube|yapx|imgur|рапорт|протокол)",
    re.IGNORECASE,
)


def is_evidence_stub(value: str) -> bool:
    """Ответ ИИ в поле «Доказательства» — заглушка, а не доказательство (v51)."""
    text = _clean(value)
    if not text or is_placeholder(text):
        return True
    if _GOV_EVIDENCE_REAL.search(text):
        return False
    return bool(_GOV_EVIDENCE_STUB.match(text.strip(" .;,")))


#: Предложение-заглушка про доказательства, которое ИИ ПИШЕТ САМ в
#: «УСТАНОВИЛ»: «В подтверждение представлено: представлены.» (выгрузка AG-2).
#: Поле «Доказательства» тут ни при чём — чистить надо сам текст.
_GOV_EVIDENCE_SENTENCE = re.compile(
    r"(?:в\s+подтверждение\s+(?:представлено|представлены|приложено)\s*:?\s*"
    r"[^.!?]{0,40}[.!?]?|"
    r"доказательства\s*(?:правонарушения)?\s*:?\s*"
    r"(?:представлены|приложены|имеются)[.!?]?)",
    re.IGNORECASE,
)


def strip_evidence_stub_sentences(text: str) -> str:
    """Убирает из текста «В подтверждение представлено: представлены.» (v51).

    Выгрузка AG-2: эту фразу ИИ написал сам в «УСТАНОВИЛ». Собственное поле
    «Доказательства» было пустым, поэтому проверка поля её не ловила, а в PNG
    абзац печатался как есть (замечание: «лишний абзац»).

    Настоящие доказательства (ссылка, видео, тайм-код) не трогаем: если в
    предложении есть ссылка или тайм-код, оно остаётся.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw

    def _drop(match) -> str:
        fragment = match.group(0)
        if _GOV_EVIDENCE_REAL.search(fragment):
            return fragment           # это настоящее доказательство
        return " "

    cleaned = _GOV_EVIDENCE_SENTENCE.sub(_drop, raw)
    return " ".join(cleaned.split())


# --------------------------------------------------------------------------- #
#  «В подтверждение представлено» — только доказательства (v54)
# --------------------------------------------------------------------------- #
#
# Выгрузка AG-2: в «УСТАНОВИЛ» печаталось
#
#   «В подтверждение представлено: материалы приложены к обращению (от 0 сек до
#    13 сек еду просто видно мегафонов нету. 00:13 секунда пробивают колёса,
#    0:40 Дм без причины, 0:45 предъявили не правильную статью. 1:10 едем на
#    сломанном авто. …)».
#
# Это сырые наблюдения заявителя из пункта 8 заявки (что видно на записи), а не
# доказательство: в бланке они читаются как обрывки чужой речи, а вместе с ними
# в официальный документ попадает внеигровой оборот «Дм без причины».
#
# Доказательством остаётся САМ материал: «видеозапись обращения (приложена к
# обращению)». Если после адреса в скобках идёт перечень наблюдений — скобки
# с ним выбрасываются, а упоминание материала и тайм-коды сохраняются.

#: Перечень наблюдений в скобках после материала: «(от 0 сек до 13 сек …)».
#: Признак — тайм-код или «от N сек» внутри скобок.
_EVIDENCE_NOTES = re.compile(
    r"\s*\((?:[^()]{0,600}?)(?:\d{1,2}\s*:\s*\d{2}|от\s+\d{1,2}\s*сек)"
    r"[^()]{0,600}\)",
    re.IGNORECASE,
)

#: Та же скобка, но НЕ ЗАКРЫТАЯ: в выгрузке AG-2 заявитель открыл скобку и не
#: закрыл её — «https://youtu.be/… ( от 0 сек до 13 сек … для сотрудника.».
#: Режем такую скобку до конца строки.
_EVIDENCE_NOTES_OPEN = re.compile(
    r"\s*\([^()]{0,80}?(?:\d{1,2}\s*:\s*\d{2}|от\s+\d{1,2}\s*сек)[^()]*$",
    re.IGNORECASE | re.MULTILINE,
)


def _drop_observation_brackets(text: str) -> str:
    """Выбрасывает скобки с перечнем наблюдений (закрытые и незакрытые)."""
    cleaned = _EVIDENCE_NOTES.sub("", text)
    return _EVIDENCE_NOTES_OPEN.sub("", cleaned)

#: Тайм-код в начале оборота: «0:40», «00:13».
_TIMECODE = re.compile(r"(?<![\d:])\d{1,2}\s*:\s*\d{2}(?![\d:])")

#: Оборот заявителя ПОСЛЕ тайм-кода: «0:40 Дм без причины, 0:45 предъявили
#: не правильную статью».
#:
#: v54: время СОБЫТИЯ («07.11.2026 18:15», «примерно в 18:15») — НЕ тайм-код
#: записи. Тайм-кодом список наблюдений делает перечисление: два и более
#: отметок подряд («0:00», «0:13», «0:40», «1:10»). Одиночное время в тексте
#: не трогается — иначе из «УСТАНОВИЛ» выпадало «примерно в 18:15 сотрудники
#: LSPD … открыли огонь».
_TIMECODE = re.compile(
    r"(?<![\d:.,/])(?:\d{1,2}\s*:\s*[0-5]\d)(?![\d:])",
    re.IGNORECASE,
)

#: Оборот наблюдения: от тайм-кода до запятой/точки с запятой/конца фразы.
_RAW_NOTE = re.compile(
    r"(?<![\d:.,/])(?:\d{1,2}\s*:\s*[0-5]\d)(?![\d:])"
    r"(?:[^,;.!?\n]{0,120})",
    re.IGNORECASE,
)

#: Сколько тайм-кодов должно идти подряд, чтобы это был перечень наблюдений.
_TIMECODE_LIST_MIN = 2

#: Внеигровые сокращения, которые заявитель пишет вместо правовой формулы
#: (v54: «0:40 Дм без причины»). Заменяются официальным оборотом.
_OOC_SPOKEN = (
    (r"(?<![A-Za-zА-Яа-яЁё])дм(?![A-Za-zА-Яа-яЁё])", "должностное лицо"),
    (r"\bбез\s+(?:каких[-\s]либо\s+)?причин\w*",
     "в отсутствие законных и фактических оснований"),
)


#: Разговорные обороты ЗАЯВИТЕЛЯ, по которым перечень тайм-кодов — это его
#: собственные наблюдения, а не изложенные прокурором факты (v54). Тайм-коды
#: сами по себе трогать нельзя: «00:14 — сотрудник надевает наручники» — как
#: раз то, что в «УСТАНОВИЛ» и должно быть.
_RAW_MARKERS = re.compile(
    r"(?<![A-Za-zА-Яа-яЁё])(?:еду|едем|нету|просто|пробивают|зачитана|"
    r"неадекватн\w*|не\s+правильн\w*|предъявили|поднимают|растреливают|"
    r"дм|миранда\s+зачитана)(?![A-Za-zА-Яа-яЁё])",
    re.IGNORECASE,
)


def is_timecode_list(text: str) -> bool:
    """В тексте перечень тайм-кодов записи, а не одно время события."""
    return len(_TIMECODE.findall(str(text or ""))) >= _TIMECODE_LIST_MIN


def has_raw_observations(text: str) -> bool:
    """Текст — расшифровка записи словами заявителя (v54)."""
    raw = str(text or "")
    return is_timecode_list(raw) and bool(_RAW_MARKERS.search(raw))


def is_raw_observation(text: str) -> bool:
    """Текст — сырые наблюдения заявителя по тайм-кодам, а не доказательство."""
    raw = _clean(text)
    if not raw:
        return False
    if re.search(r"(https?://|www\.)", raw, re.IGNORECASE):
        return True                  # это ссылка/материал — доказательство
    return is_timecode_list(raw)


def _scrub_spoken_ooc(text: str) -> str:
    """Переписывает разговорные внеигровые обороты официально (v54)."""
    result = str(text or "")
    for pattern, replacement in _OOC_SPOKEN:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    return result


def evidence_mention(value: str) -> str:
    """Доказательство без перечня сырых наблюдений (v54).

    «материалы приложены к обращению (от 0 сек до 13 сек … 0:40 Дм без
    причины …)» → «материалы приложены к обращению»: раскладка записи словами
    заявителя доказательством не является.
    """
    raw = _clean(value)
    if not raw:
        return ""
    cleaned = _drop_observation_brackets(raw)
    if has_raw_observations(cleaned):
        cleaned = _RAW_NOTE.sub("", cleaned)
    # Адрес — технический реквизит вложения (v53): остаётся название материала
    # и «приложено к обращению».
    cleaned = strip_urls(cleaned) if has_url(cleaned) else cleaned
    cleaned = _scrub_spoken_ooc(cleaned)
    cleaned = base.sanitize_ooc(cleaned)
    cleaned = re.sub(r"\(\s*[,;]?\s*\)", "", cleaned)      # пустые скобки
    cleaned = re.sub(r"\s+([,.;:])", r"\1", cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = cleaned.strip(" .;,()")
    # «В подтверждение представлено: материалы приложены к обращению» — так
    # не говорят. Остаётся «материалы обращения» / имя материала.
    if re.fullmatch(r"(?:материалы|материал)\w*\s*(?:,\s*)?(?:приложен\w*|"
                    r"представлен\w*)?\s*к\s*обращению[.,;]?", cleaned,
                    re.IGNORECASE):
        return "материалы обращения"
    return cleaned


def strip_raw_observations(text: str) -> str:
    """Убирает из текста документа сырые наблюдения заявителя (v54).

    Замечание к выгрузке AG-2: в «УСТАНОВИЛ» попал перечень «00:13 секунда
    пробивают колёса, 0:40 Дм без причины, 0:45 предъявили не правильную
    статью». Это не установленный факт, а расшифровка записи словами
    заявителя — в официальном документе её быть не должно.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    result = _drop_observation_brackets(raw)
    if has_raw_observations(result):
        lines: list = []
        for line in result.splitlines():
            kept: list = []
            last = 0
            for match in _RAW_NOTE.finditer(line):
                kept.append(line[last:match.start()])
                last = match.end()
            kept.append(line[last:])
            lines.append("".join(kept))
        result = "\n".join(lines)
    result = _scrub_spoken_ooc(result)
    result = re.sub(r"\s+([,.;:!?])", r"\1", result)
    result = re.sub(r"([,;:])(?:\s*[,;:])+", r"\1", result)
    result = re.sub(r"[ \t]{2,}", " ", result)
    return result.strip()


#: Ссылка в тексте документа (v53). Замечание по выгрузке «Постановление для
#: 53 версии»: в «УСТАНОВИЛ» печатались сами адреса — «Запись заседания Сената
#: от 09.11.2026: https://www.youtube.com/watch?v=…», «docs.google.com/…»,
#: «imageban.ru/…». Адрес — технический реквизит вложения, а не норма и не
#: факт дела; в официальном документе его не должно быть.
_URL_IN_TEXT = re.compile(r"(?:https?://|www\.)[^\s<>\"'«»]+", re.IGNORECASE)

#: Обрывки, после которых слово перед адресом — не название материала, а
#: служебный оборот («в подтверждение представлено», «доступно по адресу»).
_URL_NOT_A_LABEL = re.compile(
    r"(?:представлен|приложен|прикреплен|находит|содержит|имеет|указан|"
    r"доступн|ссыла|ссылк|адрес|url|источник|материал|доказательств)",
    re.IGNORECASE,
)

#: Два упоминания материалов подряд через запятую/«и» — это перечень адресов
#: одного и того же приложения; схлопываем в одно (v53).
_URL_REPEAT = re.compile(
    r"(\(?[^().;]{0,120}?приложен\w* к обращению\)?)"
    r"(?:[\s,;.]+|\s+(?:и|или)\s+)"
    r"\1",
    re.IGNORECASE,
)


def has_url(text: str) -> bool:
    """В тексте есть интернет-адрес."""
    return bool(_URL_IN_TEXT.search(str(text or "")))


def _material_label(segment: str) -> str:
    """Название материала из оборота перед адресом (v53).

    «Запись заседания Сената от 09.11.2026: https://…» → «Запись заседания
    Сената от 09.11.2026». Служебные обороты («представлено:», «ссылка:»)
    названием не считаются — для них возвращается пустая строка.
    """
    text = _clean(segment or "").strip(" .;,—-«»\"'")
    if not text or len(text) > 120:
        return ""
    # Служебный оборот («представлено:», «ссылка:») — не название материала.
    # Смотрим последние слова: «Документ, подтверждающий полномочия» —
    # название, а «в подтверждение представлено» — нет.
    words = text.split()
    for chunk in (" ".join(words[-2:]), " ".join(words[-1:])):
        if _URL_NOT_A_LABEL.search(chunk):
            return ""
    text = re.sub(r"^(?:а\s+также|и|или|либо)\s+", "", text, flags=re.IGNORECASE)
    if not text:
        return ""
    # Название материала — с заглавной буквы, как в обращении.
    return text


def _url_label(head: str):
    """Название материала перед адресом и остаток текста без него (v53).

    «… Сената от 09.11.2026: <адрес>» → («Запись заседания Сената от
    09.11.2026», «…»). Служебные обороты («представлено:», «ссылка:»)
    названием не считаются.
    """
    stripped = head.rstrip()
    marker = ""
    for candidate in (":", "—", "–", "-"):
        if stripped.endswith(candidate):
            marker = candidate
            break
    if not marker:
        return "", head
    body = stripped[:-len(marker)]
    # Название — последний оборот перед маркером (после точки, «;» или «:»).
    cut = max(body.rfind(". "), body.rfind("; "), body.rfind(": "),
              body.rfind("! "), body.rfind("? "))
    prefix, tail = (body[:cut + 2], body[cut + 2:]) if cut >= 0 else ("", body)
    name = _material_label(tail)
    if not name:
        return "", head
    return name, prefix + " "


def strip_urls(text: str) -> str:
    """Убирает интернет-адреса из текста документа (v53).

    Замечание пользователя: «ссылки типа https://… пишутся полностью в тексте
    постановления, что не является корректным — не пиши такие полные ссылки,
    просто ссылайся на то, что они есть в представленном обращении».

    Правила:
      * «Запись заседания от 09.11.2026: https://…» → «Запись заседания от
        09.11.2026 (приложена к обращению)» — название материала остаётся;
      * адрес без названия → «материалы приложены к обращению»;
      * адрес в скобках заменяется внутри тех же скобок;
      * подряд идущие адреса схлопываются в одно упоминание материалов;
      * тайм-коды, номера статей и прочие числа не трогаются.
    """
    raw = str(text or "")
    if not raw.strip() or not has_url(raw):
        return raw

    out: list = []
    position = 0
    last_replacement = ""
    for match in _URL_IN_TEXT.finditer(raw):
        head = raw[position:match.start()]
        position = match.end()
        # Адрес в скобках: «Копия ID (https://…) приложена».
        bracket = head.rstrip().endswith(("(", "«"))
        label = ""
        if not bracket:
            label, shortened = _url_label(head)
            if label:
                head = shortened
        if bracket:
            head = head.rstrip()[:-1]
            replacement = ("(" + (f"{label} " if label else "")
                           + "приложено к обращению)")
        else:
            replacement = (f"{label} (приложено к обращению)" if label
                           else "материалы приложены к обращению")
        # Перечисление адресов подряд — одно упоминание, а не три подряд.
        between = head if out else ""
        if last_replacement and replacement == last_replacement and \
                not re.sub(r"[\s,;]|\bи\b|\bили\b", "", between):
            out.append(re.sub(r"[\s,;]+$", " ", head))
            continue
        out.append(head)
        out.append(replacement)
        if not bracket:
            last_replacement = replacement
        else:
            last_replacement = ""
    out.append(raw[position:])
    cleaned = "".join(out)
    previous = None
    while previous != cleaned:
        previous = cleaned
        cleaned = _URL_REPEAT.sub(lambda m: m.group(1), cleaned)
    # Перечень адресов схлопнулся — висящие союзы и запятые убираем.
    cleaned = re.sub(r"[\s,;]+(?:и|или)\s*(?=[.,;:!?]|$)", "", cleaned)
    cleaned = re.sub(r"\s+(?:и|или)\s*(?=[.,;:!?])", "", cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,;:!?])", r"\1", cleaned)
    cleaned = re.sub(r"\(\s+", "(", cleaned)
    cleaned = re.sub(r"\s+\)", ")", cleaned)
    cleaned = re.sub(r"([,;:])(?:\s*[,;:])+", r"\1", cleaned)
    cleaned = re.sub(r"[ \t]+\n", "\n", cleaned)
    return cleaned.strip(" \n")


def is_procedural_norm(act: str) -> bool:
    """«Нарушенный акт» — процедурный регламент, а не состав нарушения (v51).

    Выгрузка AG-1: постановление о ПРИНЯТИИ обращения, а в «УСТАНОВИЛ» стояло
    «Указанные обстоятельства образуют нарушение: статьи 14 Регламента подачи
    обращений…». Статья 14 Регламента — норма о принятии, а не нарушенная.
    """
    low = _clean(act).lower()
    if not low:
        return False
    return bool(re.search(r"регламент|порядок\s+подачи|инструкц|делопроизводств",
                          low))


def offence_is_stated(value: str) -> bool:
    """ИИ в «УСТАНОВИЛ» сам ВМЕНЯЕТ нарушение (v51).

    Выгрузка AG-1: в `established` встречается «Оснований для отказа … не
    выявлено», и по слову «нарушение» финальный абзац «Указанные
    обстоятельства образуют нарушение:» считался уже напечатанным и терялся.
    """
    low = _clean(value).lower()
    if not low:
        return False
    return bool(re.search(r"образуют\s+нарушени|образует\s+нарушени|"
                          r"квалифицир\w*\s+как|призна(?:[её]т|ет)ся\s+нарушени|"
                          r"допустил\w*\s+нарушени|совершил\w*\s+нарушени|"
                          r"нарушил\w*\s+(?:требовани|положени|норм)", low))


def norm_lower_initial(text: str) -> str:
    """«Статья 14» → «статья 14» (v51, замечание п.1).

    В выгрузке AG-1 «Основание» начиналось с «Статья 14; Регламент …» —
    заглавная буква посреди фразы «на основании», да ещё и акт дважды.
    Регистр выравниваем по остальным строкам «Основания» (v46: «пункт 14 части
    1 статьи 16 …»), сам падеж нормы не трогаем: его пишет ИИ.
    """
    raw = str(text or "").strip()
    if not raw:
        return raw
    match = re.match(r"([А-ЯЁ]{2,}|[А-ЯЁ][а-яё]+)(\b.*)$", raw, re.DOTALL)
    if not match:
        return raw
    word, tail = match.group(1), match.group(2)
    # Аббревиатуры («УК», «ОГП») пишутся заглавными — их не трогаем.
    if word.isupper():
        return raw
    return word.lower() + tail


def _stem(word: str) -> str:
    """Грубая основа слова: «Регламент»/«Регламента» → «регла» (v51)."""
    raw = re.sub(r"[^А-Яа-яЁёA-Za-z]", "", str(word or "")).lower()
    return raw[:5]


def _merge_adjacent_act(parts: list, act: str) -> list:
    """Схлопывает «статьи 14; Регламента …» → «статьи 14 Регламента …» (v51).

    Замечание п.1: «Основание» повторяло акт дважды подряд — норму и название
    того же акта отдельным куском через точку с запятой.
    """
    if len(parts) < 2 or not act:
        return parts
    first_word = _stem(_clean(act).split(" ")[0]) if _clean(act) else ""
    if not first_word:
        return parts
    merged = [parts[0]]
    for part in parts[1:]:
        head = _stem(_clean(part).split(" ")[0])
        if head and head == first_word:
            merged[-1] = f"{merged[-1]} {part}"
        else:
            merged.append(part)
    return merged


def _act_pattern(act: str):
    """Регэксп ПОЛНОГО названия акта с падежным окончанием первого слова (v51)."""
    words = [w for w in re.split(r"\s+", _clean(act)) if w]
    if not words:
        return None
    # «Регламент» / «Регламента», «Устав» / «Устава»: первое слово — по основе,
    # остальные — как есть (в названии они в том же падеже).
    pattern = re.escape(_stem(words[0])) + r"[А-Яа-яЁёA-Za-z]*"
    for word in words[1:]:
        pattern += r"\s+" + re.escape(word)
    return re.compile(pattern, re.IGNORECASE)


def _norm_inside(needle: str, haystack: str) -> bool:
    """Уже напечатано ли это упоминание нормы (v49/v51).

    Сравниваем не только текст, но и ссылки на нормы: «часть 1 статьи 16»
    внутри «пункт 14 части 1 статьи 16» — это та же статья и та же часть, и
    второй раз печатать её не нужно.
    """
    def norm(value: str) -> str:
        return re.sub(r"\s+", " ", str(value or "")).strip(" ;,.").lower()

    small, big = norm(needle), norm(haystack)
    if not small:
        return True
    if small in big:
        return True
    try:
        refs = _norm_refs(needle)
        if refs and refs <= _norm_refs(haystack):
            return True
    except Exception:
        pass
    return False


def _merge_same_act_norms(parts: list, act: str) -> list:
    """Один акт — одно название, сколько бы норм по нему ни было (v51).

    Выгрузка AG-1: «статья 14 Регламента …; Статьи 5, 6, 7, 11, 12, 14
    Регламента …» — название акта повторялось. Первое упоминание оставляем,
    нормы из следующих кусков дописываем к нему, а само название убираем:
    «статья 14, статьи 5, 6, 7, 11, 12, 14 Регламента …».
    """
    pattern = _act_pattern(act)
    if pattern is None or len(parts) < 2:
        return parts
    base_index = None
    for index in range(len(parts)):
        part = parts[index]
        match = pattern.search(part)
        if match is None:
            continue                      # акта в этом куске нет — не трогаем
        if base_index is None:
            base_index = index            # первое упоминание оставляем как есть
            continue
        # Второе упоминание: убираем название акта, нормы дописываем к первому.
        trimmed = (part[:match.start()] + part[match.end():]).strip(" ;,.")
        # Кусок мог содержать несколько норм («…; часть 1 статьи 16»): каждую
        # проверяем отдельно и печатаем только новое.
        fresh = []
        for piece in trimmed.split(";"):
            piece = re.sub(r"\s{2,}", " ", piece).strip(" ;,.")
            if not piece or _norm_inside(piece, parts[base_index]):
                continue
            fresh.append(norm_lower_initial(piece))
        if not fresh:
            parts[index] = ""
            continue
        parts[base_index] = (f"{parts[base_index].rstrip(' ;,.')}, "
                             f"{'; '.join(fresh)}")
        parts[index] = ""
    return [p for p in parts if p]


def subject_requisites(doc) -> str:
    """«В отношении / Удостоверение / Отдел сотрудника» одним предложением (v51).

    Замечание п.1: «отсутствуют в PNG при наличии в заявке — „В отношении /
    Удостоверение / Отдел сотрудника“». Реквизиты нарушителя есть в полях и в
    заявке, но ИИ пересказывает обращение своими словами и не всегда их
    повторяет — тогда в бланке их нет вовсе.

    Поэтому, если «УСТАНОВИЛ» этих данных не содержит, добавляем ОДНО
    предложение (без ярлыков бланка: замечание v41 — «не вставляй названия
    полей»). Уже упомянутое не дублируется.
    """
    name = _clean(doc.get("subject_name")) if hasattr(doc, "get") else ""
    if not name or is_placeholder(name):
        return ""
    ident = _clean(doc.get("subject_id")) if hasattr(doc, "get") else ""
    ident = "" if is_placeholder(ident) else ident
    rank = _clean(doc.get("subject_rank")) if hasattr(doc, "get") else ""
    rank = "" if is_placeholder(rank) else rank
    department = _clean(doc.get("subject_department")) if hasattr(doc, "get") else ""
    department = "" if is_placeholder(department) else department
    parts = []
    if department:
        parts.append(department)
    if rank:
        parts.append(rank)
    who = " ".join(parts) if parts else "сотрудник"
    phrase = f"Установлено, что {who} {name}"
    if ident:
        phrase += f", удостоверение № {ident}"
    return phrase + "."


def append_subject_requisites(text: str, doc) -> str:
    """Дописывает реквизиты нарушителя, если их нет в тексте (v51)."""
    raw = str(text or "").strip()
    phrase = subject_requisites(doc)
    if not phrase:
        return raw
    low = raw.lower()
    name = _clean(doc.get("subject_name")).lower()
    ident = _clean(doc.get("subject_id"))
    if name and name in low and (not ident or ident in raw):
        return raw                       # ФИО и удостоверение уже названы
    if not raw:
        return phrase
    # Ставим перед выводом о составе: «…образуют нарушение: части 1 статьи
    # 15.1…» должно оставаться последним выводом, а не разрываться справкой.
    marker = "образуют нарушение"
    index = raw.lower().find(marker)
    if index > 0:
        start = max(raw.rfind(". ", 0, index), raw.rfind(".\n", 0, index))
        start = start + 2 if start >= 0 else 0
        head, tail = raw[:start], raw[start:]
        return _end_sentence(head.strip()) + " " + phrase + " " + tail.strip()
    return _end_sentence(raw) + " " + phrase


#: «Место события»-заглушки: это описание процесса, а не адрес.
_NOT_A_PLACE = re.compile(
    r"(в\s+ходе|в\s+процессе|в\s+результате|при\s+исполнении|"
    r"служебн\w*\s+деятельност|служебн\w*\s+обязанност"
    # v46: ИИ пишет «в месте проведения процессуальных действий» — это не
    # адрес, а описание процедуры. В бланке такая строка лишняя.
    r"|в\s+месте\s+проведения|проведения\s+процессуальн"
    r"|в\s+месте\s+совершения|на\s+месте\s+события)",
    re.IGNORECASE,
)


#: Ответы-заглушки, которые ИИ ставит в поля вместо данных (v40).
#: Выгрузка AG-1: «Пункт нарушения: отсутствует», «Удостоверение: не указано»
#: — из-за них в «УСТАНОВИЛ» появлялось «Указанные обстоятельства образуют
#: нарушение: Регламента подачи обращений …».
_GOV_EMPTY_ANSWERS = re.compile(
    r"^(?:отсутству\w*|не\s+указан\w*|не\s+установлен\w*|не\s+имеется|"
    r"нет\s+данных|нет|неизвестн\w*|не\s+применимо|нет\s+информации|"
    r"не\s+представлен\w*|-+|—+|\.+)$",
    re.IGNORECASE,
)


def is_placeholder(value: str) -> bool:
    """Значение — заглушка ИИ («по обстоятельствам, указанным в заявке»)."""
    text = _clean(value)
    if not text:
        return True
    text = text.strip(" .,;")
    if _GOV_EMPTY_ANSWERS.match(text):
        return True
    return bool(_GOV_PLACEHOLDER.match(text))


#: Значения «места события», которые местом дела не являются.
_NOT_A_PLACE_CITY = re.compile(
    r"^(?:г\.?\s*)?(?:лос[-\s]?сантос|los\s*santos)\s*\.?$", re.IGNORECASE)


def is_place_placeholder(value: str) -> bool:
    """«Место события: в ходе служебной деятельности» — заглушка, не адрес."""
    text = _clean(value)
    if not text or is_placeholder(text):
        return True
    # v38: ИИ подставлял в «Место события» город бланка («г. Лос-Сантос») —
    # это не место происшествия, печатать его в «УСТАНОВИЛ» нельзя.
    if _NOT_A_PLACE_CITY.match(text.strip()):
        return True
    return bool(_NOT_A_PLACE.search(text))


def strip_doc_type_tail(text: str) -> str:
    """Убирает из конца абзаца заголовок вида решения (выгрузка v38).

    Реальный случай AG-1: пересказ заявителя заканчивался строкой «О принятии
    обращения к собственному производству» — заголовок бланка попал в
    «УСТАНОВИЛ» как ещё одно предложение.
    """
    raw = str(text or "")
    lines = [line for line in raw.splitlines() if line.strip()]
    while lines and _clean(lines[-1]).lower().strip(" .") in {
            kind.lower() for kind in GOV_DOC_TYPES}:
        lines.pop()
    result = "\n".join(lines).strip()
    # Заголовок мог приклеиться к концу абзаца через точку/перенос:
    # «… ч. 2 ст. 1 гл. 15 УК. О принятии обращения к собственному производству»
    for kind in GOV_DOC_TYPES:
        pattern = r"[\s.,;:—–-]*" + re.escape(kind) + r"\s*[.,]?\s*$"
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)
    return result.strip()


def strip_placeholder_clauses(text: str) -> str:
    """Выбрасывает из абзаца фразы-заглушки (v37).

    Реальная выгрузка AG-2: «УСТАНОВИЛ» начинался со строки «Место события:
    в ходе служебной деятельности на территории штата Сан-Андреас», хотя
    место события в деле не установлено. Такие фразы — не факт, а заполнитель.
    """
    raw = str(text or "")
    if not raw.strip():
        return ""
    cleaned: list = []
    for chunk in re.split(r"(?<=[.!?])\s+|\n+", raw):
        body = chunk.strip()
        if not body:
            continue
        if re.match(r"^место события\s*:", body, re.IGNORECASE) and is_place_placeholder(
                re.sub(r"^место события\s*:\s*", "", body, flags=re.IGNORECASE)):
            continue
        if is_chat_junk(body):
            continue
        cleaned.append(body)
    return " ".join(cleaned).strip()


#: Названия полей бланка, которые ИИ приклеивает к своему тексту (v41).
#: Выгрузка «Постановление_4»: «Обстоятельства» = «Видео длится 46 секунд …
#: сотрудник FIB 301 просто стоит спиной и никак не реагирует\nОтдел
#: сотрудника:», а «Прокурор» получал «Место события: здание EMS…» внутри
#: текста. В PDF это печаталось как лишние строки «Место события: …»,
#: «Отдел сотрудника: …» посреди «УСТАНОВИЛ».
_GOV_FIELD_LABELS_TEXT = (
    "место события", "дата и время события", "отдел сотрудника",
    "звание сотрудника", "нарушенный акт", "пункт нарушения",
    "нормативное основание", "взыскание", "доказательства", "удостоверение",
    "id заявителя", "дата обращения", "предмет обращения", "в отношении",
    "постановление вынес", "удостоверение прокурора", "вид документа",
    "заявитель", "город", "номер", "дата", "должность", "этап",
)

#: «Отдел сотрудника:» / «Место события — …» на границе строки или предложения.
_GOV_LABEL_LEAK = re.compile(
    r"(?:^|(?<=[.!?;:])\s+)(" + "|".join(
        re.escape(label) for label in _GOV_FIELD_LABELS_TEXT) + r")\s*:\s*",
    re.IGNORECASE,
)

#: Хвост «…\nОтдел сотрудника:» без значения — поле осталось пустым.
_GOV_LABEL_TAIL = re.compile(
    r"(?:^|\n|\s)(" + "|".join(
        re.escape(label) for label in _GOV_FIELD_LABELS_TEXT) + r")\s*:\s*$",
    re.IGNORECASE,
)


def _mention_place(parts: list, place: str) -> list:
    """Дописывает место события внутрь первого абзаца (v52).

    Раньше место печаталось отдельной служебной строкой «Событие имело место:
    <дата>, место — <адрес>». Такой строки в «УСТАНОВИЛ» быть не должно
    (выгрузка `Постановление_52_для_версии`), но и терять адрес нельзя:
    дописываем его в скобках к первому предложению об обстоятельствах.
    """
    if not parts:
        return [f"Обстоятельства дела: место — {place}."]
    head = parts[0].rstrip()
    tail = "" if head.endswith(".") else "."
    if head.endswith(tail or "."):
        head = head.rstrip(".")
    parts[0] = f"{head} (место — {place}){tail or '.'}"
    return parts


def strip_appeal_form_items(text: str) -> str:
    """Убирает из абзаца строки-реквизиты бланка обращения (v52).

    В «УСТАНОВИЛ» попадали служебные подписи формы обращения — «5. Подробное
    описание ситуации: все описано в подробно и верно.» Такая строка — не факт
    дела, а название пункта анкеты вместе с его значением: в постановлении её
    быть не должно, даже если она приклеена к тексту по существу
    («… верно. 10 ноября 2026 года …»).

    Поэтому удаляем ярлык и его значение до конца предложения, но только в
    пределах строки: сам факт, идущий следом, остаётся.
    """
    raw = str(text or "")
    if not raw.strip():
        return ""
    kept_lines: list = []
    for line in raw.splitlines():
        body = line
        while True:
            match = _APPEAL_ITEM_LABEL.search(body)
            if match is None:
                break
            rest = body[match.end():]
            # Значение ярлыка кончается точкой/!/? или концом строки.
            stop = re.search(r"[.!?](?=\s|$)", rest)
            end = match.end() + (stop.end() if stop else len(rest))
            diag_event("gov.appeal_form_item_dropped",
                       value=body[match.start():end][:80])
            body = body[:match.start()] + body[end:]
        body = body.strip()
        if body:
            kept_lines.append(body)
    return "\n".join(kept_lines).strip()


def strip_field_label_leaks(text: str) -> str:
    """Убирает из текста приклеенные названия полей бланка (v41).

    ИИ дописывал в конец «Обстоятельств» строку «Отдел сотрудника:» (поле
    осталось пустым), а в «УСТАНОВИЛ» попадало «Место события: здание EMS».
    Название поля — это реквизит, его место в шапке бланка, а не в тексте.
    """
    raw = str(text or "")
    if not raw.strip():
        return ""
    # 1) Хвосты «<Поле>:» без значения (в том числе после перевода строки).
    previous = None
    while previous != raw:
        previous = raw
        raw = _GOV_LABEL_TAIL.sub("", raw, count=1).rstrip()
    if not raw.strip():
        return ""
    # 2) Само название поля в начале фразы: оставляем значение, убираем ярлык.
    #    Пробел после «.» сохраняем, иначе склеиваются соседние предложения.
    raw = _GOV_LABEL_LEAK.sub(lambda m: " " if m.group(0).startswith(" ") else "", raw)
    # 3) Пустые строки и повисшие разделители.
    raw = re.sub(r"[ \t]+\n", "\n", raw)
    raw = re.sub(r"\n{2,}", "\n", raw)
    return raw.strip(" \n:;,—-")


def drop_placeholders(doc) -> None:
    """Чистит поля постановления от заглушек, чтобы они не попали в текст."""
    # v54: «Установлено, что LSPD удо не видел (ID-Card, удостоверение № 25013,
    # 150066.» — это расшифровка ответа заявителя на анкету, а не нарушитель.
    # Такое «ФИО» печаталось в тексте и в резолюции.
    _drop_nonsense_subject(doc)
    # v40: к тем же заглушкам относятся «не указан»/«отсутствует» в реквизитах
    # заявителя и нарушителя — из-за них резолюция печатала «(ID-карта № не
    # указан)» и «в отношении сотрудника FIB (ID № не указано)».
    # v41: ИИ приклеивает названия полей к значениям («Видео … \nОтдел
    # сотрудника:»), из-за чего в PNG появлялись лишние строки. Снимаем.
    for key in ("situation", "established", "event_place", "penalty",
                "violation_clause", "violation_act", "legal_basis", "evidence",
                "extra", "subject_department", "subject_rank"):
        value = doc.get(key)
        if value:
            cleaned = strip_field_label_leaks(value)
            if cleaned != value:
                doc.set(key, cleaned)
    for key in ("violation_act", "violation_clause", "event_place",
                "event_date", "legal_basis", "penalty", "evidence", "extra",
                "applicant_id", "subject_name", "subject_id", "subject_rank",
                "subject_department", "appeal_number"):
        value = doc.get(key)
        if value and is_placeholder(value):
            diag_event("gov.placeholder_dropped", field=key, value=str(value)[:60])
            doc.set(key, "")
    # v46: «Место события» — отдельная проверка (город бланка, «в месте
    # проведения процессуальных действий» — это не адрес).
    for key in ("event_place",):
        value = doc.get(key)
        if value and is_place_placeholder(value):
            diag_event("gov.place_dropped", field=key, value=str(value)[:60])
            doc.set(key, "")
    # v46: без нарушителя его «должность» и «отдел» — лишние строки в бланке.
    if not (doc.get("subject_name") or "").strip():
        for key in ("subject_department", "subject_rank", "subject_id"):
            doc.set(key, "")


#: Признаки того, что в «В отношении» лежит НЕ имя нарушителя (v54).
#: Выгрузка AG-2: «В отношении: удо не видел (ID-Card» — заявитель писал в
#: графе нарушителя «удо не видел», и это печаталось как ФИО сотрудника
#: («Установлено, что LSPD удо не видел (ID-Card, удостоверение № 25013…»).
_NOT_A_NAME = re.compile(
    r"(удо\b|удостоверени|id[-\s]*card|не\s+видел|не\s+знаю|неизвестн|"
    r"установить\s+не|нет\s+данных|отсутству|—|-|\(|\))",
    re.IGNORECASE,
)


def is_subject_name(value: str) -> bool:
    """Значение поля «В отношении» — имя нарушителя, а не ответ на анкету."""
    text = _clean(value)
    if not text or is_placeholder(text):
        return False
    if _NOT_A_NAME.search(text):
        return False
    # Имя — 2–3 слова, каждое с заглавной буквы.
    words = text.split()
    if not 1 <= len(words) <= 4:
        return False
    return all(re.match(r"^[А-ЯЁA-Z][а-яёa-z.\-]*$", word) for word in words)


def _drop_nonsense_subject(doc) -> None:
    """Убирает из «В отношении» текст анкеты вместо имени (v54)."""
    value = doc.get("subject_name") if hasattr(doc, "get") else ""
    if value and not is_subject_name(value):
        diag_event("gov.subject_name_dropped", value=str(value)[:60])
        doc.set("subject_name", "")


#: Шапка бланка прокуратуры.
GOV_VEDOMSTVO = "STATE OF SAN-ANDREAS"
#: Город в бланке всегда один и тот же (замечание v37: «Город всегда Лос-Сантос»).
GOV_CITY = "г. Лос-Сантос"
GOV_PODRAZDELENIE = "OFFICE OF THE ATTORNEY GENERAL"

#: ── Вид решения: ДВЕ ЧАСТИ (v39, замечание пользователя) ───────────────
#: Постановление выносится либо по итогам ПРЕДВАРИТЕЛЬНОГО изучения
#: обращения (этап 1, не более 24 часов: принять / отказать / переадресовать /
#: прекратить — Регламент, ст. 11–16, 18, 25), либо по итогам рассмотрения
#: ПО СУЩЕСТВУ (этап 2, не более 72 часов: санкция — Регламент, ст. 22–23,
#: Закон об ОГП, ст. 9, 33). Это два разных документа, а не один заголовок.
GOV_STAGE_PRIMARY = "primary"
GOV_STAGE_FINAL = "final"

#: Часть 1 — первичное решение по обращению (судьба самого обращения).
GOV_PRIMARY_TYPES: tuple[str, ...] = (
    "О принятии обращения к собственному производству",
    "Об отказе в принятии обращения к рассмотрению",
    "О переадресации обращения по подведомственности",
    "О прекращении производства по обращению",
)

#: Часть 2 — итоговое решение по существу (вид санкции / меры реагирования).
GOV_FINAL_TYPES: tuple[str, ...] = (
    "О привлечении к административной ответственности",
    "О возбуждении уголовного дела по обращению",
    "О передаче материалов обращения в суд",
    "О применении мер прокурорского реагирования",
    "Об отказе в удовлетворении обращения",
    "О завершении проверки по обращению и передаче материалов в уголовное производство",
)

#: «Решение этапа 2 определяет ИИ по обстоятельствам» (санкция).
GOV_DOC_TYPE_AUTO = "Определит ИИ по обстоятельствам"

#: «Решение этапа 1 определяет ИИ по обращению» (v41).
#: Замечание: «в первом этапе идёт первичное решение до 24 часов — там ещё
#: нет обстоятельств, ИИ решает по обращению: принято или не принято и
#: соответствует ли регламенту; во втором этапе — уже по обстоятельствам,
#: видеофиксация и тайм-коды прокурора». Два разных значения, а не одно:
#: на этапе 2 ИИ обязан опираться на «Обстоятельства», на этапе 1 их нет.
GOV_DOC_TYPE_AUTO_APPEAL = "Определит ИИ по обращению"

#: Значения «вид решения определит ИИ» — вне GOV_DOC_TYPES.
GOV_AUTO_TYPES: tuple[str, ...] = (GOV_DOC_TYPE_AUTO_APPEAL, GOV_DOC_TYPE_AUTO)

#: Маркеры служебного блока проверки обращения (v42): по ним клиент понимает,
#: что ИИ ответил на «Проверку ИИ», а не написал свободный разбор.
INTAKE_START = "===ПРОВЕРКА ОБРАЩЕНИЯ==="
INTAKE_END = "===КОНЕЦ ПРОВЕРКИ==="

#: Состояния обращения по итогам проверки ИИ (v42). Это не вид постановления,
#: а судьба самого обращения: от неё зависит, открывается ли этап санкции.
INTAKE_ACCEPTED = "Принято"
INTAKE_REFUSED = "Отказано"
INTAKE_REDIRECTED = "Переадресовано"
INTAKE_TERMINATED = "Прекращено"
#: v62 (замечание пользователя: «на 1 этапе только 3 состояния: принятие,
#: отказ и переадресация»). Состояния «Недостатки» и «Прекращено» остались
#: только для разбора старых ответов ИИ и старых дел: они сводятся к отказу
#: (обращение не идёт в работу), поэтому в списке рабочих состояний их нет.
INTAKE_DEFECTS = "Недостатки"
GOV_INTAKE_STATES: tuple[str, ...] = (INTAKE_ACCEPTED, INTAKE_REFUSED,
                                      INTAKE_REDIRECTED)
#: Все состояния, которые умеет распознать разбор (включая устаревшие).
GOV_INTAKE_LEGACY_STATES: tuple[str, ...] = (INTAKE_ACCEPTED, INTAKE_DEFECTS,
                                             INTAKE_REFUSED, INTAKE_REDIRECTED,
                                             INTAKE_TERMINATED)

#: Все конкретные виды решений (без значения «определит ИИ»).
GOV_DOC_TYPES: tuple[str, ...] = GOV_PRIMARY_TYPES + GOV_FINAL_TYPES

#: Подписи этапов для заявки в чат (полные, с нормами).
GOV_STAGE_TITLES: dict = {
    GOV_STAGE_PRIMARY: "1. Первичное решение по обращению (до 24 часов, ст. 12 Регламента)",
    GOV_STAGE_FINAL: "2. Итоговое решение по существу — санкция (до 72 часов, ст. 23 Регламента)",
}

#: Короткие подписи для выпадающего списка формы (v39.1).
#: Замечание: полная подпись не помещалась в поле и обрывалась на «(до 72 час».
GOV_STAGE_SHORT: dict = {
    GOV_STAGE_PRIMARY: "1. Первичное решение (до 24 ч)",
    GOV_STAGE_FINAL: "2. Итоговое решение — санкция (до 72 ч)",
}

#: Что именно проверяет прокурор на каждом этапе. Уходит в заявку для ИИ:
#: на этапе 1 достаточно текста обращения (форма и ст. 16), на этапе 2 —
#: обращения вместе с «Обстоятельствами» прокурора.
GOV_STAGE_GUIDE: dict = {
    GOV_STAGE_PRIMARY: (
        "ЭТАП 1 — ПЕРВИЧНОЕ РЕШЕНИЕ (принятие, отказ, переадресация). Оцени ТОЛЬКО само обращение и его форму, санкцию не "
        "назначай и уголовное дело не возбуждай. Проверь по Регламенту: "
        "установима ли личность заявителя (ст. 7); указан ли предмет обращения "
        "по части 1 статьи 5; есть ли описание события, дата и время, "
        "нарушитель (ОПЗ и организация); есть ли доказательства со ссылками; "
        "подписано ли обращение и есть ли расшифровка. Если обращение "
        "соответствует форме и статье 14 — прими его к собственному "
        "производству. Если есть основание из части 1 статьи 16 — откажи, "
        "указав НОМЕР конкретного основания (например: пункт 13 части 1 "
        "статьи 16 — отсутствует описание события). Если первичное разрешение "
        "относится к иному органу (статьи 18–19) — переадресуй. Если "
        "обращение отозвано, утратило предмет либо подано не по форме "
        "неустранимо (статья 25) — прекрати производство. Если в заявке вид "
        "решения — «Определит ИИ по обстоятельствам», сам определи, какое "
        "первичное решение вытекает из обращения, и укажи его в поле «Вид "
        "документа» ровно одной из формулировок: «О принятии обращения к "
        "собственному производству», «Об отказе в принятии обращения к "
        "рассмотрению», «О переадресации обращения по подведомственности», "
        "«О прекращении производства по обращению». Санкцию на этом этапе всё "
        "равно не назначай."
    ),
    GOV_STAGE_FINAL: (
        "ЭТАП 2 — ИТОГОВОЕ РЕШЕНИЕ (санкция). Оцени обращение ВМЕСТЕ с "
        "разделом «Обстоятельства» (видеофиксация прокурора с тайм-кодами) и "
        "выбери одну санкцию по статье 23 Регламента: привлечение к "
        "административной ответственности (пункт «а» части 1 статьи 23; норма "
        "об ответственности — например статья 28 Этического кодекса, штраф от "
        "10 000 до 50 000 $); возбуждение уголовного дела (Закон об ОГП, статья "
        "33; нормы Уголовного кодекса); передача материалов в суд (пункт «в» "
        "части 1 статьи 23); меры прокурорского реагирования — протест, "
        "представление, предостережение (Закон об ОГП, статьи 9.1–9.3); отказ "
        "в удовлетворении обращения при недостаточности доказательств (пункт "
        "«б» части 1 статьи 23); завершение проверки с передачей материалов в "
        "уголовное производство. Доказательства, которых нет в материалах, не "
        "выдумывай."
    ),
}


def gov_stage(doc_type: str) -> str:
    """Этап постановления по его виду: «primary» или «final» (v39)."""
    low = _clean(doc_type).lower().strip(" .")
    # v41: заглушки «определит ИИ» сами указывают на этап: «по обращению» —
    # первичное решение, «по обстоятельствам» — итоговое.
    if low == GOV_DOC_TYPE_AUTO_APPEAL.lower():
        return GOV_STAGE_PRIMARY
    if low == GOV_DOC_TYPE_AUTO.lower():
        return GOV_STAGE_FINAL
    for kind in GOV_PRIMARY_TYPES:
        if kind.lower() == low:
            return GOV_STAGE_PRIMARY
    for kind in GOV_FINAL_TYPES:
        if kind.lower() == low:
            return GOV_STAGE_FINAL
    # Незнакомая формулировка: смотрим на слова. «Отказ в принятии» —
    # первичный этап, «отказ в удовлетворении» — итоговый.
    if "отказ" in low and "удовлетвор" not in low:
        return GOV_STAGE_PRIMARY
    if any(word in low for word in ("приняти", "переадрес", "прекращ")):
        return GOV_STAGE_PRIMARY
    return GOV_STAGE_FINAL


def normalize_stage(value: str) -> str:
    """Приводит «Этап» из формы или ответа ИИ к primary/final (v39)."""
    text = _clean(value).lower()
    if not text:
        return ""
    if text.startswith(("primary", "1", "перв", "предитог")):
        return GOV_STAGE_PRIMARY
    if text.startswith(("final", "2", "итог", "санкц", "по существу")):
        return GOV_STAGE_FINAL
    return ""


def stage_types(stage: str) -> tuple:
    """Виды решений выбранного этапа (для выпадающего списка формы)."""
    return GOV_PRIMARY_TYPES if stage == GOV_STAGE_PRIMARY else GOV_FINAL_TYPES


def auto_type_for(stage: str) -> str:
    """Значение «вид решения определит ИИ» для этапа (v41).

    Этап 1 — по обращению (обстоятельств ещё нет), этап 2 — по обстоятельствам
    и видеофиксации с тайм-кодами.
    """
    return (GOV_DOC_TYPE_AUTO_APPEAL if stage == GOV_STAGE_PRIMARY
            else GOV_DOC_TYPE_AUTO)


def is_auto_type(value: str) -> bool:
    """Это заглушка «определит ИИ», а не конкретный вид решения (v41)."""
    return _clean(value) in GOV_AUTO_TYPES


#: Значение по умолчанию для «Вид решения» — всегда одно и то же (v43).
#: Замечание: «В Постановление → Вид решения → всегда был по умолчанию
#: "Определит ИИ по обращению"». Поэтому первым пунктом списка стоит именно
#: оно, независимо от этапа; «по обстоятельствам» остаётся дополнительным
#: пунктом на итоговом этапе.
DEFAULT_DOC_TYPE = GOV_DOC_TYPE_AUTO_APPEAL


def type_choices(stage: str) -> list:
    """Пункты списка «Вид решения»: сначала «Определит ИИ по обращению» (v43).

    Первый пункт выбран по умолчанию и всегда одинаков — так пользователь
    видит одно и то же значение, а конкретный вид выбирает как доп. опцию.
    Значение этапа («… по обстоятельствам») остаётся в списке, чтобы ИИ мог
    решать по обстоятельствам на итоговом этапе.
    """
    choices = [DEFAULT_DOC_TYPE]
    stage_auto = auto_type_for(stage)
    if stage_auto not in choices:
        choices.append(stage_auto)
    for kind in stage_types(stage):
        if kind not in choices:
            choices.append(kind)
    return choices


def normalize_gov_doc_type(value: str, stage: str = "") -> str:
    """Приводит формулировку ИИ к одному из видов решений (v39).

    ИИ отвечает то «Постановление об отказе в принятии обращения к
    рассмотрению», то «отказ в рассмотрении». В бланке нужен ровно один из
    видов GOV_DOC_TYPES — иначе заголовок и проверки «поплывут».
    """
    text = _clean(value).lower()
    # Пусто и «Определит ИИ …» — это не вид решения: пусть решение примет
    # вызывающий код (см. parse_gov_answer, v39/v41).
    if not text or text in [auto.lower() for auto in GOV_AUTO_TYPES]:
        return ""
    for kind in GOV_DOC_TYPES:
        if kind.lower() in text or text in kind.lower():
            return kind
    # Порядок важен: «отказ в удовлетворении» проверяем раньше «отказа».
    rules = (
        (r"удовлетвор", "Об отказе в удовлетворении обращения"),
        (r"отказ.*(принят|рассмотрен)", "Об отказе в принятии обращения к рассмотрению"),
        (r"отказ", "Об отказе в принятии обращения к рассмотрению"),
        (r"переадрес|подведомствен", "О переадресации обращения по подведомственности"),
        (r"прекращ", "О прекращении производства по обращению"),
        (r"привлеч.*административ|административн\w+ ответственн|штраф",
         "О привлечении к административной ответственности"),
        (r"возбужд.*уголовн|уголовн\w+ дел", "О возбуждении уголовного дела по обращению"),
        (r"суд", "О передаче материалов обращения в суд"),
        (r"протест|представлен|предостережен", "О применении мер прокурорского реагирования"),
        (r"завершен.*проверк|передач.*материалов", "О завершении проверки по обращению и "
                                                   "передаче материалов в уголовное производство"),
        (r"принят.*производств", "О принятии обращения к собственному производству"),
    )
    for pattern, kind in rules:
        if re.search(pattern, text):
            return kind
    return ""


def suggest_primary_type(doc) -> str:
    """Первичное решение по тексту обращения (v39.1).

    Замечание: «и для 1. Первичное решение … тоже предусмотреть "Определит ИИ
    по обстоятельствам"». Это корректно: все четыре первичных решения —
    процедурные и выводятся из самого обращения (форма, ст. 14, ст. 16,
    статьи 18–19, статья 25), «Обстоятельства» прокурора для них не нужны.
    """
    formal = doc.get("appeal_raw") or doc.get("situation")
    parsed = parse_appeal_text(formal) if formal else {}
    description = parsed.get("description") or ""
    low = " ".join((formal or "", description)).lower()
    # 1) Основания статьи 16, которые видны прямо в тексте обращения.
    if not parsed.get("applicant_name") and not doc.get("applicant_name"):
        return "Об отказе в принятии обращения к рассмотрению"      # п. 1
    if not description:
        return "Об отказе в принятии обращения к рассмотрению"      # п. 13
    if formal and not parsed.get("signature"):
        return "Об отказе в принятии обращения к рассмотрению"      # п. 4
    # 2) Обращение отозвано / утратило предмет — статья 25.
    if re.search(r"отзыва\w+\s+обращени|прошу\s+отозвать|обращение\s+отозвано|"
                 r"утрат\w+\s+предмет", low):
        return "О прекращении производства по обращению"
    # 3) Вопрос не нашего ведомства — переадресация (статьи 18–19).
    if re.search(r"подведомствен|переадрес|не\s+относится\s+к\s+компетенц", low):
        return "О переадресации обращения по подведомственности"
    # 4) Остальное — соответствует форме: принимаем к производству (ст. 14).
    return "О принятии обращения к собственному производству"


def suggest_doc_type(doc) -> str:
    """Вид решения, который определяет ИИ (v39, v39.1).

    Этап 1 — первичное решение по обращению (`suggest_primary_type`),
    этап 2 — санкция по обстоятельствам дела.

    Вызывается, когда в форме выбрано «Определит ИИ», а ИИ вид не прислал.
    Правило простое и осторожное: сначала уголовный состав, затем
    административная ответственность, затем суд, меры реагирования, отказ и
    только потом «проверка завершена».
    """
    if hasattr(doc, "is_final") and not doc.is_final():
        # v45: на первичном этапе вид решения должен следовать ЗА ФАКТОМ отказа.
        # Если в резолюции «в принятии обращения … отказать», а вид решения не
        # пришёл, печатался вариант «О принятии к производству» — заголовок
        # противоречил резолюции.
        text = " ".join(str(doc.get(key) or "") for key in (
            "situation", "established", "legal_basis", "penalty", "doc_type"))
        text = text + " " + " ".join(
            str(p) for p in (getattr(doc, "points", None) or []))
        low = text.lower()
        if "отказ" in low or "отказать" in low:
            for doc_type in GOV_DOC_TYPES:
                if "отказе в принятии" in doc_type.lower():
                    return doc_type
        return suggest_primary_type(doc)
    text = " ".join(doc.get(key) for key in (
        "situation", "prosecutor_facts", "established", "penalty",
        "violation_clause", "violation_act", "legal_basis")).lower()
    # Только ЯВНЫЕ пункты «ПОСТАНОВИЛ» (пришедшие от ИИ или введённые
    # вручную). Сгенерированные по виду решения пункты здесь брать нельзя:
    # они сами зависят от заголовка, который уточняется этой функцией (v41).
    raw_points = getattr(doc, "points", None) or []
    text = text + " " + " ".join(str(point) for point in raw_points).lower()
    if re.search(r"(возбудить|возбужден\w+)\s+уголовн|признаки преступления|состав преступления", text):
        return "О возбуждении уголовного дела по обращению"
    if re.search(r"привлеч\w*\s+к\s+административн|административн\w+\s+наказан|"
                 r"назначить\s+штраф|штраф\s+в\s+размере", text):
        return "О привлечении к административной ответственности"
    if re.search(r"(переда\w*|направить)\s+(все\s+)?(материал\w*|дело|обращени\w*)"
                 r"[^.]{0,60}?\bв\s+суд", text):
        return "О передаче материалов обращения в суд"
    if re.search(r"внести\s+представление|принести\s+протест|"
                 r"предостережение|мер\w*\s+прокурорского\s+реагирования", text):
        return "О применении мер прокурорского реагирования"
    if re.search(r"отказать\s+в\s+удовлетворени|недостаточн\w+\s+доказательств|"
                 r"не\s+подтвержд|не\s+установлен", text):
        return "Об отказе в удовлетворении обращения"
    if re.search(r"завершить\s+проверк|материал\w+\s+проверки", text):
        return ("О завершении проверки по обращению и передаче материалов в "
                "уголовное производство")
    # Остаток: санкцию без основания не выдумываем — по пункту «б» части 1
    # статьи 23 Регламента при недоказанности выносится отказ в удовлетворении.
    return "Об отказе в удовлетворении обращения"

#: Предметы обращения — ровно как в форме, которую подают граждане
#: (Регламент подачи обращений, ст. 5).
GOV_SUBJECTS: tuple[str, ...] = (
    "заявление о преступлении, совершённом должностным лицом при исполнении "
    "либо в связи с исполнением служебных обязанностей",
    "заявление о нарушении законодательства (не содержащем признаков "
    "преступления), совершённом должностным лицом",
    "заявление о преступлении, совершённом гражданским лицом",
    "заявление о нарушении законодательства (не содержащем признаков "
    "преступления), совершённом гражданским лицом",
    "жалоба на действия (бездействие) должностного лица",
)

#: Поля формы. Порядок = порядок в форме и в .txt заявки; третье значение —
#: подпись поля в бланке (её же понимает разбор ответа ИИ).
GOV_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("vedomstvo", "Ведомство", "Ведомство"),
    ("podrazdelenie", "Подразделение", "Подразделение"),
    ("doc_stage", "Этап", "Этап"),
    ("doc_type", "Вид решения", "Вид документа"),
    ("doc_number", "Номер постановления", "Номер"),
    ("doc_date", "Дата постановления", "Дата"),
    ("author_name", "Прокурор (И. Фамилия)", "Постановление вынес"),
    ("author_rank", "Должность", "Должность"),
    ("author_id", "Удостоверение прокурора", "Удостоверение прокурора"),
    ("city", "Город", "Город"),
    # ── заявитель ─────────────────────────────────────────────────────────
    ("applicant_name", "Заявитель (ФИО)", "Заявитель"),
    ("applicant_id", "ID-карта заявителя", "ID заявителя"),
    ("applicant_representative", "Представитель заявителя",
     "Представитель заявителя"),
    ("appeal_number", "Номер обращения", "Номер обращения"),
    ("appeal_date", "Дата обращения", "Дата обращения"),
    ("appeal_subject", "Предмет обращения", "Предмет обращения"),
    # ── нарушитель и событие ──────────────────────────────────────────────
    ("subject_name", "Нарушитель (ФИО)", "В отношении"),
    ("subject_id", "Удостоверение / ID нарушителя", "Удостоверение"),
    ("subject_rank", "Должность / звание нарушителя", "Звание сотрудника"),
    ("subject_department", "Организация нарушителя", "Отдел сотрудника"),
    ("event_date", "Дата и время события", "Дата и время события"),
    ("event_place", "Место события", "Место события"),
    ("evidence", "Доказательства (видео, тайм-коды)", "Доказательства"),
    # ── правовая часть ────────────────────────────────────────────────────
    ("violation_act", "Нарушенный акт", "Нарушенный акт"),
    ("violation_clause", "Статьи / пункты", "Пункт нарушения"),
    ("legal_basis", "Правовое основание", "Нормативное основание"),
    ("penalty", "Наказание / решение", "Взыскание"),
    ("situation", "Обстоятельства", "Обстоятельства"),
    ("extra", "Дополнительно", "Дополнительно"),
)

#: Поля, которые печатаются в заявке для чата. Пустые не печатаются вовсе:
#: «нет данных — определи сам» в заявке раздражало и подсказывало ИИ
#: заглушки вместо нормы (v37).
#: В чат уходят только реквизиты самого постановления: заявителя, нарушителя,
#: предмет и дату события ИИ берёт из текста обращения, которое печатается
#: ниже целиком (замечание v37: «пусть ИИ сам читает и ловит суть»).
GOV_CHAT_KEYS: tuple[str, ...] = (
    "vedomstvo", "podrazdelenie", "doc_type", "doc_number", "doc_date",
    "author_name", "author_rank", "author_id", "city",
)
#: «Этап» в заявку строкой «Этап: …» не уходит: он разворачивается в
#: требования GOV_STAGE_GUIDE (иначе ИИ на этапе 1 начинал назначать санкции).
GOV_CHAT_FIELDS: tuple[tuple[str, str, str], ...] = tuple(
    row for row in GOV_FIELDS if row[0] in GOV_CHAT_KEYS)

GOV_FIELD_LABELS = {key: label for key, _form, label in GOV_FIELDS}
GOV_FORM_LABELS = {key: form for key, form, _label in GOV_FIELDS}

#: Поля, которые ИИ вправе определить сам по обстоятельствам.
GOV_OPTIONAL_GUESSED = (
    "violation_act", "violation_clause", "legal_basis", "penalty",
    "subject_rank", "subject_department", "extra", "event_place",
)

#: Ссылки на Конституцию и Закон об ОГП, которые прокурор указывает в вводной
#: части (так во всех примерах 1–6).
GOV_PREAMBLE_BASIS = (
    "частью 2 статьи 36 Конституции штата Сан-Андреас",
    "частями 1, 2 и 6 статьи 8 Закона «О деятельности офиса Генерального "
    "прокурора штата San-Andreas»",
    "статьями 11, 12, 13 и 14 Регламента подачи обращений в Офис "
    "Генерального прокурора штата San-Andreas",
)

#: Алиасы ответа ИИ (то же поле может прийти разными словами).
GOV_ALIASES: dict = {
    "номер": "doc_number",
    "№": "doc_number",
    "номер постановления": "doc_number",
    "дата": "doc_date",
    "дата постановления": "doc_date",
    "вид документа": "doc_type",
    "вид решения": "doc_type",
    "этап": "doc_stage",
    "часть вида решения": "doc_stage",
    "санкция": "doc_type",
    "вид санкции": "doc_type",
    "постановление вынес": "author_name",
    "прокурор": "author_name",
    "вынес": "author_name",
    "должность": "author_rank",
    "удостоверение прокурора": "author_id",
    "номер удостоверения прокурора": "author_id",
    # «Удостоверение: 32229» в ответе ИИ — это нарушитель (как у IAD).
    # Реквизит прокурора приходит только с уточнением «прокурора».
    "удостоверение": "subject_id",
    "город": "city",
    "заявитель": "applicant_name",
    "фио заявителя": "applicant_name",
    "id заявителя": "applicant_id",
    "id-карта": "applicant_id",
    "id карта": "applicant_id",
    "представитель заявителя": "applicant_representative",
    "номер обращения": "appeal_number",
    "дата обращения": "appeal_date",
    "предмет обращения": "appeal_subject",
    "в отношении": "subject_name",
    "нарушитель": "subject_name",
    "фио нарушителя": "subject_name",
    "звание сотрудника": "subject_rank",
    "должность нарушителя": "subject_rank",
    "отдел сотрудника": "subject_department",
    "организация": "subject_department",
    "дата и время события": "event_date",
    "место события": "event_place",
    "место": "event_place",
    "доказательства": "evidence",
    "видеофиксация": "evidence",
    "нарушенный акт": "violation_act",
    "акт": "violation_act",
    "пункт нарушения": "violation_clause",
    "статьи": "violation_clause",
    "статья": "violation_clause",
    "нормативное основание": "legal_basis",
    "правовое основание": "legal_basis",
    "основание": "legal_basis",
    # v65: «решение cut_preamble» — вводную часть печатает клиент, поэтому ИИ
    # отдаёт НОРМЫ отдельным полем, а не повторяет их внутри «УСТАНОВИЛ:».
    "основание вводной части": "preamble_basis",
    "основания вводной части": "preamble_basis",
    "нормы вводной части": "preamble_basis",
    "вводная часть": "preamble_basis",
    "взыскание": "penalty",
    "наказание": "penalty",
    "решение": "penalty",
    "обстоятельства": "situation",
    "ситуация": "situation",
    "фабула": "situation",
    "дополнительно": "extra",
    "примечание": "extra",
    "ведомство": "vedomstvo",
    "подразделение": "podrazdelenie",
}


#: Ключевые слова, которые ИИ присылает по реквизитам обращения (v49).
#: Один список и для разбора ответа на «Проверку ИИ», и для подстановки
#: реквизитов в постановление — чтобы «пришло» и «подставилось» не разошлось.
INTAKE_KEYWORD_KEYS: tuple[str, ...] = (
    "applicant_name", "applicant_id", "applicant_representative",
    "subject_name", "subject_id", "subject_department", "subject_rank",
    "event_date", "event_place", "appeal_subject", "appeal_date",
    "appeal_number", "violation_act", "violation_clause", "legal_basis",
)

#: Соответствие ключевых слов ответа ИИ полям постановления (v49).
GOV_KEYWORD_FIELDS: dict = {key: key for key in INTAKE_KEYWORD_KEYS}

#: Пункты формы обращения в ОГП (Регламент подачи обращений, ст. 6–7).
APPEAL_POINTS: tuple[tuple[str, str], ...] = (
    ("данные о заявителе", "applicant_name"),
    ("данные о представителе заявителя", "applicant_representative"),
    ("предмет обращения", "appeal_subject"),
    ("сведения о нарушителе", "violator"),
    ("дата и время события", "event_date"),
    ("подробное описание ситуации", "description"),
    ("ксерокопия идентификационной карты", "id_copy"),
    ("электронную почту и номер телефона", "contacts"),
    ("доказательства правонарушения", "evidence"),
    ("копия договора о представлении интересов", "contract"),
    ("документ, подтверждающий полномочия представителя", "authority"),
    ("дата подачи заявления", "filed_date"),
    ("подпись и расшифровка заявителя", "signature"),
)


def parse_appeal_text(raw: str) -> dict:
    """Разбирает текст обращения гражданина по пунктам формы ОГП (v37).

    Реальная ситуация: пользователь вставил в «Обстоятельства» ВСЁ обращение
    целиком — с «От:», «В:», нумерацией, почтой и подписью. В постановление
    этот текст уходил дословно, а в «УСТАНОВИЛ» появлялась строка
    «Место события: в ходе служебной деятельности». Теперь обращение
    разбирается на реквизиты, а обстоятельствами становится только описание
    ситуации (п. 5).
    """
    text = str(raw or "").replace("\r\n", "\n")
    result: dict = {}
    if not text.strip():
        return result

    buffer: dict = {}
    current = ""

    def flush(key: str) -> None:
        if not key:
            return
        value = " ".join(x.strip() for x in buffer.get(key, []) if x.strip())
        value = re.sub(r"\s{2,}", " ", value).strip(" ;,")
        if value and not result.get(key):
            result[key] = value

    for line in text.splitlines():
        clean = line.strip()
        if not clean:
            if current:
                buffer.setdefault(current, []).append("")
            continue
        # «От: Kirito Gold 178393» и «1.2 …» — не пункты формы обращения, а
        # нумерация списка; «От:» вообще не реквизит и разбор не открывает.
        if re.match(r"^(от|в|кому|куда)\s*:", clean, re.IGNORECASE):
            continue
        stripped = re.sub(r"^(?:\d{1,2}\.\d{1,2}|\d{1,2})[.)]?\s*", "", clean)
        low = stripped.lower()
        matched = ""
        for prefix, key in APPEAL_POINTS:
            if low.startswith(prefix):
                matched = key
                rest = stripped[len(prefix):].lstrip(" :—-")
                # v37: «Ксерокопия идентификационной карты ИЛИ ДРУГИХ
                # документов, удостоверяющих личность…» — продолжение названия
                # пункта, а не значение поля. В поле попадал только хвост
                # «или других документов…».
                if rest.lower().startswith(("или", "либо")):
                    rest = stripped
                flush(current)
                current = key
                buffer.setdefault(key, [])
                if rest:
                    buffer[key].append(rest)
                break
        if matched:
            continue
        if current:
            buffer.setdefault(current, []).append(clean)
    flush(current)

    # «5. Подробное описание ситуации:» мог быть пуст — тогда в поле попал
    # следующий реквизит. Такой «пересказ» описанием ситуации не считается.
    # Туда же попадал заголовок вида решения («О принятии обращения к
    # собственному производству») — в выгрузке v38 он замыкал пересказ.
    description = result.get("description", "")
    if description.lower().startswith(("подпись", "дата подачи", "доказательства",
                                      "ксерокопия", "электронную почту")):
        result.pop("description", None)
    else:
        # Хвост формы («Настоящим заверяю… К заявлению прилагаю:») — это не
        # описание события, а служебные строки обращения (выгрузка v37).
        description = re.split(r"Настоящим заверяю", description)[0].strip()
        description = re.split(r"К заявлению прилагаю", description)[0].strip()
        # v38: если «Подробное описание ситуации:» пуст, в него затягивался
        # следующий реквизит — «Дата подачи заявления: 07.11.2026». Это не
        # описание события.
        description = re.split(r"\bДата подачи заявления\s*:", description)[0].strip()
        description = re.split(r"\bПодпись и расшифровка\s*:", description)[0].strip()
        description = strip_doc_type_tail(description)
        if description:
            result["description"] = description
        else:
            result.pop("description", None)

    # v38: «Подпись и расшифровка заявителя: N. Hiddens» — в этой же строке
    # оказывался хвост из инструкции клиента («Подготовь постановление
    # Прокурора строго по этим данным…»). Подпись — одна строка, без хвоста.
    signature = result.get("signature", "")
    if signature:
        signature = re.split(r"Подготовь постановление", signature)[0]
        signature = re.split(r"\n", signature)[0].strip(" ;,")
        if signature:
            result["signature"] = signature
        else:
            result.pop("signature", None)
    # Предмет обращения: буква варианта «в)» остаётся в тексте — снимаем её.
    subject_text = result.get("appeal_subject", "")
    if subject_text:
        result["appeal_subject"] = re.sub(r"^[а-яa-z]\)\s*", "", subject_text,
                                          flags=re.IGNORECASE).strip()

    # «Kirito Gold 178393» -> ФИО + ID
    applicant = result.get("applicant_name", "")
    name, ident = split_subject(applicant, "")
    if name:
        result["applicant_name"] = name
    if ident:
        result["applicant_id"] = ident

    # «Todd Spencer 181956: FIB» -> ФИО, номер, организация
    violator = result.get("violator", "")
    if violator:
        # v38: реальная форма «Lui Killua ;Номер удостоверения: 44628 ;
        # Организация : FIB ; Должность и отдел: Head of Department , HRT».
        # Раньше «отдел» получал ВСЮ строку реквизитов, а номер удостоверения
        # не извлекался вовсе.
        chunks = [c.strip(" ;,") for c in re.split(r"[;\n]", violator) if c.strip(" ;,")]
        head = re.split(r"[:;,]", chunks[0], maxsplit=1)[0].strip()
        tail = violator[len(head):]
        vname, vid = split_subject(head, "")
        result["violator"] = vname or head
        if vid:
            result["violator_id"] = vid
        for chunk in chunks[1:]:
            low_chunk = chunk.lower()
            value = re.split(r"[:—]", chunk, maxsplit=1)[-1].strip(" ;,:—-")
            if "организац" in low_chunk or "ведомств" in low_chunk or "фракц" in low_chunk:
                if value:
                    result["violator_department"] = value
            elif "отдел" in low_chunk and value and not result.get("violator_division"):
                # «Должность и отдел: Head of Department , HRT» -> отдел HRT
                result["violator_division"] = value.split(",")[-1].strip()
            elif "удостоверен" in low_chunk or "опз" in low_chunk:
                digits = re.search(r"\d{3,10}", value)
                if digits:
                    result["violator_id"] = digits.group(0)

    return result


_APPEAL_FORM_MARKS = (
    "предмет обращения", "сведения о нарушителе", "данные о заявителе",
    "подробное описание ситуации", "дата подачи заявления",
    "подпись и расшифровка заявителя",
)


#: Строка-реквизит формы обращения: «5. Подробное описание ситуации: …».
_APPEAL_FORM_LINE = re.compile(
    r"^\s*(?:\d{1,2}[.)]?\s*)?(?:"
    + "|".join(re.escape(mark) for mark in _APPEAL_FORM_MARKS)
    + r")\s*:",
    re.IGNORECASE | re.MULTILINE,
)


#: Строка-реквизит формы обращения, попавшая в текст «УСТАНОВИЛ» (v52).
#: Выгрузка `Постановление_52_для_версии`: «УСТАНОВИЛ» начинался со строк
#: «Событие имело место: 09.11.2026 19:43» и «5. Подробное описание ситуации:
#: все описано в подробно и верно», а нужное предложение («10 ноября 2026 года
#: …») шло уже после них.
_APPEAL_ITEM_LABEL = re.compile(
    r"^\s*(?:\d{1,2}\s*[.)]?\s*)?(?:"
    + "|".join(re.escape(mark) for mark in _APPEAL_FORM_MARKS)
    + r")\s*:\s*",
    re.IGNORECASE,
)


def looks_like_appeal_form(text: str) -> bool:
    """Текст — бланк обращения гражданина в ОГП, а не описание ситуации.

    Считаем не упоминания слов, а строки-реквизиты: официальный пересказ
    («предмет обращения соответствует установленным категориям») бланком
    не считается, а «1. Данные о заявителе: …» — считается.
    """
    raw = str(text or "")
    if not raw.strip():
        return False
    if len(_APPEAL_FORM_LINE.findall(raw)) >= 2:
        return True
    low = raw.lower()
    return sum(1 for mark in _APPEAL_FORM_MARKS if f"{mark}:" in low) >= 3


#: Корни названий актов: по ним видно, о каком акте идёт речь, независимо
#: от падежа («Уголовный кодекс» / «Уголовного кодекса»).
_ACT_ROOTS: tuple[tuple[str, str], ...] = (
    ("уголовн", "ук"),
    ("процессуальн", "пк"),
    ("этическ", "этический кодекс"),
    ("административн", "ак"),
    ("устав", "устав"),
    ("конституц", "конституция"),
    ("регламент", "регламент"),
    ("закон", "закон об огп"),
)


def act_roots(text: str) -> set:
    """Корни актов, упомянутых в строке (для поиска повторов)."""
    low = str(text or "").lower()
    return {key for root, key in _ACT_ROOTS if root in low}


def acts_not_named(clause: str, act: str) -> str:
    """Часть названия акта, которая ещё НЕ названа в норме (v39).

    ИИ присылает «Нарушенный акт: Уголовный Кодекс штата Сан-Андреас,
    Процессуальный кодекс штата Сан-Андреас» и «Пункт нарушения: статья 16.4
    Уголовного кодекса штата Сан-Андреас, статья 17 Процессуального кодекса
    штата Сан-Андреас». Первое название уже есть в норме, и в тексте
    получалось «… статьи 17 Процессуального кодекса … Уголовного Кодекса …,
    Процессуальный кодекс …». Добавляем только те акты, которых в норме нет.
    """
    raw_act = _clean(act)
    if not raw_act:
        return ""
    clause_roots = act_roots(clause)
    if not clause_roots:
        return act_genitive(raw_act)
    parts = [part.strip() for part in re.split(r"[,;]", raw_act) if part.strip()]
    missing = [part for part in parts if not (act_roots(part) and act_roots(part) <= clause_roots)]
    if not missing:
        return ""
    return act_genitive(", ".join(missing))


#: «часть 1 статьи 16», «части 2 и 6 статьи 8» — ссылка на статью целиком.
_ARTICLE_REF = re.compile(r"част\w*\s+([\d.,\sи]+?)\s+стать\w+\s+(\d+(?:\.\d+)*)",
                          re.IGNORECASE)


def _same_story(first: str, second: str, threshold: float = 0.34) -> bool:
    """Два абзаца рассказывают одно и то же (v46).

    «При проведении предварительного изучения обращения … отсутствуют
    доказательства» и «В Офис Генерального прокурора поступило обращение …
    не прикреплены доказательства» — один и тот же вывод, переписанный дважды.
    """
    words_first = set(re.findall(r"[а-яёa-z]{4,}", str(first or "").lower()))
    words_second = set(re.findall(r"[а-яёa-z]{4,}", str(second or "").lower()))
    if not words_first or not words_second:
        return False
    return len(words_first & words_second) / len(words_first) >= threshold


#: Ссылки на нормы в «Основании»: «пункт 14 части 1 статьи 16», «статьи 27–28»,
#: «части 1, 2 и 6 статьи 8». Нужны, чтобы сравнивать разные записи одной нормы.
_CLAUSE_PARTS = (
    ("п", re.compile(r"пункт\w*\s+([\d.,\sи\-–]+)", re.IGNORECASE)),
    ("ч", re.compile(r"част\w*\s+([\d.,\sи\-–]+?)\s+стать", re.IGNORECASE)),
    ("ст", re.compile(r"стат\w*\s+([\d.,\sи\-–]+)", re.IGNORECASE)),
)


def _norm_refs(text: str) -> set:
    """Ссылки на нормы в отрезке текста: {("ст","16"), ("ч","1"), ("п","14")}.

    v49 (замечание): «в „Основание:“ почти всегда дважды дублируются статьи и
    их содержимое». Раньше сравнивались только «часть N статьи M», поэтому
    «пункт 14 части 1 статьи 16» и «пункт 14 части 1 статьи 16 Регламента …»
    считались разными нормами и печатались дважды.
    """
    refs: set = set()
    raw = str(text or "")
    for marker, pattern in _CLAUSE_PARTS:
        for match in pattern.finditer(raw):
            body = match.group(1)
            for token in re.findall(r"\d+(?:\.\d+)*", body):
                refs.add((marker, token))
    return refs


def _dedupe_basis_segments(text: str) -> str:
    """Убирает из «Основания» повторы одной и той же нормы (v46, v49).

    ИИ присылает сразу и «Пункт нарушения: пункт 14 части 1 статьи 16», и
    «Нормативное основание: часть 1 статьи 16 Регламента …». В бланке это
    выглядело как «Основание: пункт 14 части 1 статьи 16; …; пункт 14 части 1
    статьи 16 Регламента …; часть 1 статьи 16 …; статьи 27–28 …» — одна и та
    же норма дважды или трижды.

    v49: отрезок выбрасывается, если ВСЕ его ссылки на нормы и ВСЕ названные в
    нём акты уже встречались в предыдущих (более конкретных) отрезках.
    """
    segments = [seg.strip(" .;,") for seg in str(text or "").split(";")]
    segments = [seg for seg in segments if seg]
    if len(segments) < 2:
        return "; ".join(segments)

    covered_refs: set = set()
    covered_roots: set = set()
    seen_keys: set = set()
    kept: list = []
    for seg in segments:
        key = _key(seg)
        if key and key in seen_keys:
            continue
        refs = _norm_refs(seg)
        roots = act_roots(seg)
        if (refs or roots) and refs <= covered_refs and roots <= covered_roots:
            # Полный повтор уже напечатанного: ни новой нормы, ни нового акта.
            continue
        kept.append(seg)
        seen_keys.add(key)
        covered_refs |= refs
        covered_roots |= roots
    return "; ".join(kept)


def _drop_repeated_acts(text: str) -> str:
    """Убирает повторные упоминания акта в «Основании» (выгрузка v38).

    «… статья 16.4 Уголовного кодекса …, статья 17 Процессуального кодекса …;
    Уголовный Кодекс штата Сан-Андреас, Процессуальный кодекс штата
    Сан-Андреас; часть 2 статьи 36 Конституции …» — перечисление актов после
    конкретных статей читается как ошибка: акт уже назван при норме.
    """
    raw = str(text or "")
    if not raw:
        return raw
    chunks = [chunk.strip() for chunk in raw.split(";") if chunk.strip()]
    named: set = set()
    kept: list = []
    for chunk in chunks:
        roots = act_roots(chunk)
        has_norm = bool(re.search(r"\b(стат|пункт|част|ст\.|ч\.|п\.)", chunk.lower())
                        or re.search(r"\d+\.\d+", chunk))
        if roots and not has_norm:
            # Часть состоит только из названий актов: печатаем лишь те, что
            # ещё не названы при конкретных нормах.
            unique, seen_here = [], set()
            for part in chunk.split(","):
                key = part.strip()
                if not key or key.lower() in seen_here:
                    continue
                seen_here.add(key.lower())
                part_roots = act_roots(key)
                if part_roots and part_roots <= named:
                    continue
                unique.append(key)
                named |= part_roots
            if unique:
                kept.append(", ".join(unique))
            continue
        named |= roots
        kept.append(chunk)
    return "; ".join(kept)


def _covered(fragment: str, text: str, threshold: float = 0.6) -> bool:
    """Похоже ли, что `fragment` уже упомянут в `text`.

    Нужно, чтобы «УСТАНОВИЛ» не повторял место события второй раз: в тексте
    может стоять «в здании EMS», а в поле — «здание EMS».
    """
    words = [w for w in re.findall(r"[\wА-Яа-яЁё-]{3,}", str(fragment or "").lower())]
    if not words:
        return False
    low = re.sub(r"[^\wА-Яа-яЁё]+", " ", str(text or "").lower())
    # сравниваем по началу слова: «здание» и «здании» — одно и то же место
    hits = sum(1 for w in words if w[:5] in low)
    return hits / len(words) >= threshold


def _normalize_gov_key(raw: str) -> str:
    key = _clean(raw).lower().replace("**", "").replace("__", "").replace("`", "")
    key = key.replace("«", "").replace("»", "").replace('"', "")
    key = re.sub(r"^[\s>*_`#>•·\d.)\]]+", "", key)
    key = key.replace("\u00a0", " ").rstrip(":").strip(" .")
    key = re.sub(r"\s+", " ", key)
    if key in GOV_ALIASES:
        return GOV_ALIASES[key]
    for field_key, _form, label in GOV_FIELDS:
        if key == label.lower():
            return field_key
    return ""


_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


def _key(text: str) -> str:
    """Нормализованный ключ предложения для поиска дублей."""
    return re.sub(r"[^\wА-Яа-яЁё]+", " ", str(text or "").lower()).strip()


def sentences(text: str) -> list:
    """Делит текст на законченные предложения (для склейки без повторов)."""
    parts = [p.strip() for p in _SENT_SPLIT.split(str(text or "").strip()) if p.strip()]
    return parts


#: Строки интерфейса веб-чата, которые ИИ копирует в ответ (v37).
_CHAT_JUNK = re.compile(
    r"^(pdf|file|docx?|txt|png|jpe?g|image|изображение|вложение|"
    r"файл(ы)? приложен\w*|вы отправили \d+|ответ в режиме ии.*|"
    r"чат в режиме ии:?.*)$",
    re.IGNORECASE,
)


def is_chat_junk(line: str) -> bool:
    """Строка — элемент интерфейса чата, а не текст документа."""
    text = strip_markdown(str(line or "")).strip(" .:;«»\"'")
    if not text:
        return True
    if _CHAT_JUNK.match(text):
        return True
    # «Заявка (отправлено в чат).txt», «scan_1234.pdf»
    if re.search(r"\.(pdf|docx?|txt|png|jpe?g)$", text, re.IGNORECASE):
        return True
    return False


#: Эхо собственного документа: веб-клиент вернул отправленный текст вместе
#: с ответом, и шапка/вводная часть попадали в «Обстоятельства» (v37).
_GOV_ECHO = re.compile(
    r"^(state of san-andreas|office of the attorney general|"
    r"я,\s*прокурор|г\.\s*лос-сантос|постановление\s*№)",
    re.IGNORECASE,
)

#: v65: короче этой длины строка «Я, Прокурор …» — действительно повтор
#: шапки. Длиннее — это абзац раздела «УСТАНОВИЛ», который ИИ начинает
#: вводной частью («Я, Прокурор штата Сан-Андреас Jonathan Raine,
#: удостоверение № 198632, руководствуясь …, установил, что …»). В выгрузке
#: «Обращение №1.7z» фильтр выбросил такой абзац ЦЕЛИКОМ: 2394 знака фактов
#: и тайм-кодов 01:14–02:27, а в PNG «УСТАНОВИЛ» оказался пустым.
_GOV_ECHO_MAX_LEN = 160


def is_gov_echo(line: str) -> bool:
    """Строка — повтор шапки/вводной части документа, а не факт дела."""
    plain = strip_markdown(str(line or "")).strip(" .:;")
    if not plain or len(plain) > _GOV_ECHO_MAX_LEN:
        return False
    return bool(_GOV_ECHO.match(plain))


#: Вводная часть ИИ внутри «УСТАНОВИЛ»: клиент печатает свою (`preamble()`),
#: поэтому абзац ИИ начинается сразу с фактов — «установил, что …».
_AI_PREAMBLE = re.compile(
    r"^\s*Я\s*,\s*(?:и\.?\s?о\.?\s?)?(?:заместитель\s+|старший\s+|генерального\s+)?"
    r"прокурор\w*\b.*?\b(?:установил|установила|установлено)\b\s*[,:]?\s*"
    r"(?:что\s+|следующее\s*[:—-]?\s*)?",
    re.IGNORECASE | re.DOTALL,
)
#: Запасной вариант: ИИ не написал «установил», но вводная часть узнаётся по
#: «рассмотрев обращение …».
_AI_PREAMBLE_TAIL = re.compile(
    r"^\s*Я\s*,\s*.*?\bрассмотрев\b[^.]{0,240}?[.,:]\s*",
    re.IGNORECASE | re.DOTALL,
)


def strip_ai_preamble(text: str) -> str:
    """Убирает вводную часть ИИ из начала раздела «УСТАНОВИЛ» (v65).

    Решение пользователя по выгрузке «Обращение №1.7z»: «обрезать вводную
    часть ИИ» — клиент печатает свою (`preamble()`: должность, ФИО,
    удостоверение, нормы, «рассмотрев обращение …»), и второй раз тот же текст
    в бланке не нужен. Факты и тайм-коды сохраняются целиком.
    """
    raw = str(text or "").strip()
    if not raw:
        return ""
    match = _AI_PREAMBLE.match(raw) or _AI_PREAMBLE_TAIL.match(raw)
    if not match:
        return raw
    rest = raw[match.end():].strip()
    if not rest:
        # От абзаца ничего не осталось — лучше оставить текст как был.
        return raw
    return rest[0].upper() + rest[1:]


def _end_sentence(text: str) -> str:
    """Закрывает предложение точкой, если ИИ её не поставил (v41)."""
    body = str(text or "").strip()
    if not body:
        return ""
    if body[-1] in ".!?…:;":
        return body
    return body + "."


def _drop_unfinished_tail(text: str) -> str:
    """Убирает последний фрагмент, оборванный на полуслове (v54).

    Выгрузка AG-2: правовая оценка обрывалась посреди предложения —
    «…а также главой 16 Процессуального кодекса, Офис Генерального
    прокурора», — и в PNG «УСТАНОВИЛ» заканчивался этим обрывком.

    Трогаем ТОЛЬКО конец текста: если незаконченная фраза стоит в середине
    (дальше идёт текст), она остаётся как была.
    """
    raw = str(text or "").rstrip()
    if not raw or raw[-1] in ".!?…":
        return raw
    cut = max(raw.rfind(". "), raw.rfind("! "), raw.rfind("? "))
    if cut < 0:
        return raw
    diag_event("gov.unfinished_fragment_dropped", value=raw[cut + 2:][:80])
    return raw[:cut + 1].rstrip()


def append_unique(parts: list, text: str) -> None:
    """Добавляет предложения, которых ещё нет в `parts`.

    В выгрузке AG-2 «УСТАНОВИЛ» дважды повторял место события и один и тот же
    вывод: строки-поля ИИ склеивались с абзацем обстоятельств подряд.
    """
    known = _key(" ".join(parts))
    chunks = sentences(scrub_chat_text(text))
    for index, sentence in enumerate(chunks):
        body = sentence.strip(" ;,")
        if not body or is_chat_junk(body) or is_gov_echo(body):
            continue
        # v54 (выгрузка AG-2): ИИ оборвал правовую оценку на полуслове —
        # «В соответствии со статьёй 33 Закона …, а также главой 16
        # Процессуального кодекса, Офис Генерального прокурора» — и в бланке
        # «УСТАНОВИЛ» заканчивался этим обрывком. Длинный незаконченный
        # фрагмент в самом конце текста не печатается (короткая фраза вроде
        # «…никак не реагирует» — остаётся: точку ей поставит `_end_sentence`).
        if (index == len(chunks) - 1 and body[-1] not in ".!?…"
                and len(body) > 60 and "," in body):
            diag_event("gov.unfinished_fragment_dropped", value=body[:80])
            continue
        if is_placeholder(body) or _GOV_PLACEHOLDER.match(body):
            continue
        # «…образуют нарушение: по обстоятельствам, указанным в заявке» —
        # заглушка может быть и в середине предложения
        if re.search(r"(образуют нарушение|квалификац\w+)[:;]?\s*"
                     r"(по обстоятельствам|согласно обстоятельствам)", body, re.IGNORECASE):
            continue
        # v54 (выгрузка AG-2): ИИ закончил правовую оценку на полуслове —
        # «…а также главой 16 Процессуального кодекса, Офис Генерального
        # прокурора» — и следом пошла строка про доказательства. В бланке
        # получался оборванный абзац. Выбрасываем такой хвост, только если он
        # действительно последний (а не часть фразы, за которой есть текст):
        # `_drop_unfinished_tail` вызывается уже после склейки.
        pass
        key = _key(body)
        if key and key in known:
            continue
        parts.append(body)
        known = (known + " " + key).strip()


@dataclass
class PostanovlenieProkurora:
    """Одно постановление Прокурора: поля формы + резолюция."""

    #: v56: блок «Основание:» в PNG не печатается (общее правило для обоих
    #: бланков). Нормы остаются в полях и в «ИИ-документ.txt».
    PNG_SHOW_BASIS = False

    vedomstvo: str = GOV_VEDOMSTVO
    podrazdelenie: str = GOV_PODRAZDELENIE
    #: Этап постановления (v39): «primary» — первичное решение по обращению,
    #: «final» — итоговое решение по существу (санкция). Пусто — выводится из
    #: вида решения (`stage()`).
    doc_stage: str = ""
    #: Конкретный вид решения. «Определит ИИ …» — только значение списка в
    #: форме (v41); в модель попадает уже выбранный вид, а если там всё-таки
    #: осталась заглушка, `title()` подставит решение по обращению/санкции.
    doc_type: str = GOV_DOC_TYPES[0]
    doc_number: str = ""
    doc_date: str = field(default_factory=today_ru)
    author_name: str = ""
    author_rank: str = "Прокурор"
    author_id: str = ""
    city: str = GOV_CITY
    applicant_name: str = ""
    applicant_id: str = ""
    applicant_representative: str = ""
    appeal_number: str = ""
    appeal_date: str = ""
    appeal_subject: str = ""
    subject_name: str = ""
    subject_id: str = ""
    subject_rank: str = ""
    subject_department: str = ""
    event_date: str = ""
    event_place: str = ""
    evidence: str = ""
    violation_act: str = ""
    violation_clause: str = ""
    legal_basis: str = ""
    penalty: str = ""
    situation: str = ""
    #: «Обстоятельства» — собственное описание прокурора по видеофиксации (v37).
    #: Пусто — значит «Обстоятельства» взяты из обращения (`appeal_situation`),
    #: и в «УСТАНОВИЛ» они второй раз не печатаются, если ИИ дал свой текст.
    prosecutor_facts: str = ""
    #: Пересказ заявителя из пункта 5 обращения — только запасной вариант.
    appeal_situation: str = ""
    #: Текст обращения гражданина ЦЕЛИКОМ (v37). Отдельных полей заявителя и
    #: нарушителя в форме больше нет: заявитель, нарушитель, предмет, дата
    #: события и тайм-коды достаются из этого текста (`apply_appeal`).
    appeal_raw: str = ""
    #: Текст раздела «УСТАНОВИЛ» из ответа ИИ (правовая оценка, выводы).
    established: str = ""
    extra: str = ""
    #: Пункты «ПОСТАНОВИЛ». Пусто — собираются по виду решения.
    points: list = field(default_factory=list)
    #: v42: нормы вводной части, которые ИИ указал в ответе. Раньше в бланк
    #: всегда печатался один и тот же зашитый список (ч. 2 ст. 36 Конституции,
    #: ч. 1, 2 и 6 ст. 8 Закона об ОГП, ст. 11–14 Регламента) — при изменении
    #: законодательства бланк врал бы. Пусто — подставляется базовый перечень.
    preamble_basis: str = ""
    #: Дело «Обращение №X» и этап, на котором вынесен документ (v42).
    case_number: str = ""
    case_stage_kind: str = ""
    created_at: float = field(default_factory=time.time)
    source: str = "form"

    def __post_init__(self) -> None:
        self.applicant_name, self.applicant_id = split_subject(
            self.applicant_name, self.applicant_id)
        self.doc_type = _clean(self.doc_type) or GOV_DOC_TYPES[0]
        self.doc_stage = _clean(self.doc_stage)

    # ------------------------------------------------------------------ утиль

    def get(self, key: str, default: str = "") -> str:
        return _clean(getattr(self, key, default))

    def set(self, key: str, value) -> None:
        if not hasattr(self, key):
            return
        if key in ("applicant_name", "applicant_id"):
            other = self.applicant_id if key == "applicant_name" else self.applicant_name
            name, ident = split_subject(
                value if key == "applicant_name" else self.applicant_name,
                value if key == "applicant_id" else other,
            )
            self.applicant_name, self.applicant_id = name, ident
            return
        setattr(self, key, value)

    #: Ключевые слова ответа ИИ → поля постановления (v49).
    KEYWORD_FIELDS = GOV_KEYWORD_FIELDS

    def apply_keywords(self, keywords: dict | None) -> None:
        """Подставляет реквизиты, которые ИИ назвал ключевыми словами (v49).

        Замечание пользователя: «все данные определяет ИИ — по „Проверке ИИ“ /
        „Сформировать“ ИИ отдаёт ключевые слова, парсим их из ответа и
        подставляем в программе». Локальный разбор текста обращения
        (`apply_appeal`) больше не источник реквизитов: он ломался, как только
        пользователь менял реквизиты местами.
        """
        for key, value in dict(keywords or {}).items():
            target = self.KEYWORD_FIELDS.get(str(key))
            text = _clean(value)
            if not target or not text or is_placeholder(text):
                continue
            self.set(target, text)

    def signature(self) -> str:
        return initials_signature(self.author_name)

    # ------------------------------------------------------- этап (v39)

    def stage(self) -> str:
        """Этап постановления: первичное решение или итоговое (v39).

        Пользователь: «"Вид решения" должен состоять из 2 частей: первая —
        принять или отказать в обращении по регламенту, вторая — вид санкции,
        который ИИ определяет сам по "Обстоятельствам"». Этап задаётся явно
        (`doc_stage`), а если поле пусто — выводится из вида решения.
        """
        stage = _clean(self.doc_stage)
        if stage in (GOV_STAGE_PRIMARY, GOV_STAGE_FINAL):
            return stage
        return gov_stage(self.get("doc_type"))

    def is_final(self) -> bool:
        """Итоговое постановление по существу (санкция, этап 2)."""
        return self.stage() == GOV_STAGE_FINAL

    def stage_title(self) -> str:
        """Человеческая подпись этапа (для формы и заявки)."""
        return GOV_STAGE_TITLES[self.stage()]

    def title(self) -> str:
        """Заголовок бланка. Заглушка «Определит ИИ …» в PNG не печатается.

        v41: если вид решения ещё не выбран, берём первый вид своего этапа.
        Здесь НЕ вызывается `suggest_doc_type` — он сам опирается на
        резолюцию, а резолюция зависит от заголовка (была рекурсия).
        """
        doc_type = self.get("doc_type")
        if is_auto_type(doc_type):
            doc_type = stage_types(self.stage())[0]
        return doc_type or GOV_DOC_TYPES[0]

    def document_title(self) -> str:
        """«ПОСТАНОВЛЕНИЕ № 936» + подзаголовок о чём."""
        return self.title()

    def number_line(self) -> str:
        number = self.get("doc_number")
        return f"ПОСТАНОВЛЕНИЕ № {number}" if number else "ПОСТАНОВЛЕНИЕ"

    # ------------------------------------------------------------- текст

    #: Слова, по которым видно, что в «Должности» стоит должность прокуратуры.
    GOV_RANK_MARKS = ("прокурор", "attorney", "генеральн", "юстиц")

    def person_rank(self) -> str:
        """Должность подписанта глазами бланка прокуратуры (v38).

        В шаблоне у персонажа может стоять «Куратор отдела IAD (Assistent
        sheriff), Сенатор» — в постановлении Прокурора такая подпись выглядит
        ошибкой (выгрузка AG-1). Если в должности нет слова «прокурор»,
        печатаем «Прокурор штата Сан-Андреас», а исходную должность оставляем
        в поле `author_rank` для истории.
        """
        rank = _clean(self.get("author_rank"))
        low = rank.lower()
        if rank and any(mark in low for mark in self.GOV_RANK_MARKS):
            return rank
        return "Прокурор"

    def preamble(self) -> str:
        """Вводная часть «Я, Прокурор …, рассмотрев обращение …»."""
        rank = self.person_rank()
        name = self.get("author_name")
        who = f"{rank} штата Сан-Андреас" if "штата" not in rank.lower() else rank
        if name:
            who = f"{who} {name}"
        ident = self.get("author_id")
        if ident:
            who = f"{who}, удостоверение № {ident}"
        # v42 (замечание «много захардкоженной нормативной базы»): если ИИ
        # прислал нормы вводной части — печатаем ИХ. Зашитый перечень
        # остаётся запасным вариантом, когда ИИ норм не дал.
        custom = strip_field_label_leaks(self.get("preamble_basis"))
        if custom:
            basis = custom.rstrip(" ,;")
            tail = ""
        else:
            basis = ", ".join(GOV_PREAMBLE_BASIS[:2])
            tail = GOV_PREAMBLE_BASIS[2]
        applicant = self.get("applicant_name") or "гражданина"
        appeal_date = self.get("appeal_date") or self.get("doc_date")
        if applicant.lower().startswith(("граждан", "сотрудник")):
            applicant_phrase = applicant
        else:
            applicant_phrase = f"гражданина {applicant}"
        if not tail:
            return (
                f"Я, {who}, руководствуясь {basis}, "
                f"рассмотрев обращение {applicant_phrase}"
                + (f" от {appeal_date}" if appeal_date else "")
                + ","
            )
        return (
            f"Я, {who}, руководствуясь {basis}, а также {tail}, "
            f"рассмотрев обращение {applicant_phrase}"
            + (f" от {appeal_date}" if appeal_date else "")
            + ","
        )

    def redirect_target(self) -> str:
        """Куда переадресовать обращение (Регламент, ст. 19, ч. 1).

        Возвращает «следственное подразделение <орган>» / «дисциплинарное
        подразделение <орган>» / «Intelligence Branch (IB) Федерального
        Расследовательского Бюро» — по ведомству нарушителя из обращения.
        """
        department = self.get("subject_department") or ""
        low = department.lower()
        body = ""
        for name in ("FIB", "LSPD", "LSCSD", "SANG", "USSS", "EMS", "Weazel"):
            if name.lower() in low:
                body = name
                break
        if not body:
            return ""
        if body == "FIB":
            return "Intelligence Branch (IB) Федерального Расследовательского Бюро"
        kind = "дисциплинарное" if re.search(r"(жалоб|этическ|дресс|поведен)", 
                                             self.get("situation").lower()) else "следственное"
        return f"{kind} подразделение {body}"

    def appeal_point(self) -> str:
        """Пункт о порядке обжалования (статьи 27–28 Регламента)."""
        return ("Настоящее постановление может быть обжаловано вышестоящему "
                "прокурору либо в суд в срок, не превышающий 72 часа (статьи 27–28 "
                "Регламента подачи обращений в Офис Генерального прокурора).")

    # --------------------------------------------------- обращение целиком

    def apply_appeal(self, raw: str) -> None:
        """Раскладывает текст обращения на реквизиты (v37).

        В форме осталось одно поле «Обращение»: граждане подают обращения по
        одной форме, поэтому заявитель, его ID, нарушитель, предмет, дата
        события и доказательства достаются из самого текста. Уже заполненные
        поля не перезаписываются пустыми значениями ИИ-ответа.
        """
        self.appeal_raw = str(raw or "").strip()
        if not self.appeal_raw:
            return
        parsed = parse_appeal_text(self.appeal_raw)
        mapping = {
            "applicant_name": parsed.get("applicant_name"),
            "applicant_id": parsed.get("applicant_id"),
            "applicant_representative": parsed.get("applicant_representative"),
            "appeal_subject": parsed.get("appeal_subject"),
            "subject_name": parsed.get("violator"),
            "subject_id": parsed.get("violator_id"),
            "subject_department": parsed.get("violator_department"),
            "event_date": parsed.get("event_date"),
            "filed_date": parsed.get("filed_date"),
        }
        for key, value in mapping.items():
            if value and not self.get(key):
                self.set(key, value)
            elif value and key == "subject_department" and not self.get(key):
                self.set(key, value)
        if parsed.get("filed_date") and not self.get("appeal_date"):
            self.appeal_date = parsed["filed_date"]
        evidence = parsed.get("evidence")
        if evidence and not self.get("evidence"):
            self.evidence = evidence
        if not self.get("situation") and parsed.get("description"):
            self.situation = parsed["description"]
        description = parsed.get("description")
        if description:
            self.appeal_situation = description
        if not self.get("city"):
            self.city = GOV_CITY

    def appeal_raw_text(self) -> str:
        """Восстанавливает текст обращения для истории и повторной правки."""
        if self.get("appeal_raw"):
            return self.get("appeal_raw")
        lines = []
        if self.get("applicant_name"):
            ident = f" {self.get('applicant_id')}" if self.get("applicant_id") else ""
            lines.append(f"1. Данные о заявителе: {self.get('applicant_name')}{ident}")
        if self.get("appeal_subject"):
            lines.append(f"2. Предмет обращения: {self.get('appeal_subject')}")
        if self.get("subject_name"):
            ident = f" {self.get('subject_id')}" if self.get("subject_id") else ""
            lines.append(f"3. Сведения о нарушителе: {self.get('subject_name')}{ident}")
        if self.get("event_date"):
            lines.append(f"4. Дата и время события: {self.get('event_date')}")
        if self.get("situation"):
            lines.append(f"5. Подробное описание ситуации: {self.get('situation')}")
        if self.get("evidence"):
            lines.append(f"8. Доказательства правонарушения: {self.get('evidence')}")
        return "\n".join(lines)

    def _prosecutor_own_facts(self) -> bool:
        """«Обстоятельства» заполнены прокурором по видеофиксации, а не бланком.

        v40 (выгрузка AG-1): пользователь вставил обращение в поле
        «Обстоятельства», и `prosecutor_facts` (копия этого поля) считался
        «своими фактами прокурора» — из-за этого в «УСТАНОВИЛ» подряд шли и
        пересказ ИИ, и сырой пересказ заявителя. Теперь:
        * бланк обращения в «Обстоятельствах» — это НЕ факты прокурора;
        * текст, совпадающий с описанием ситуации из обращения, — тоже нет;
        * пересказ заявителя дублируется только если прокурор действительно
          написал что-то своё (тайм-коды, видеофиксацию) и в «УСТАНОВИЛ» ещё
          нет этого описания.
        """
        situation = strip_doc_type_tail(strip_field_label_leaks(
            strip_appeal_form_items(strip_placeholder_clauses(
                scrub_chat_text(self.get("situation"))))))
        if not situation:
            return False
        # v46: текст совпадает с «УСТАНОВИЛ» — это тот же пересказ ИИ, а не
        # работа прокурора с видеофиксацией.
        if self._facts_restart_story():
            return False
        # Бланк обращения («От:», «1. Данные о заявителе» …) — не описание
        # прокурором увиденного.
        if looks_like_appeal_form(situation):
            return False
        description = self.appeal_situation
        if description:
            key_situation, key_description = _key(situation), _key(description)
            if key_situation and (key_situation == key_description
                                  or key_situation in key_description
                                  or key_description in key_situation):
                return False
        if self.prosecutor_facts:
            # В «Обстоятельства» лежит ровно то же, что в обращении → это
            # пересказ заявителя, а не работа прокурора с видеофиксацией.
            return not self._facts_repeat_appeal()
        return True

    def _facts_restart_story(self) -> bool:
        """«Обстоятельства» и «УСТАНОВИЛ» пересказывают одно и то же (v46).

        Выгрузка Постановление_46v: ИИ заполнил оба поля почти одинаково —
        «При проведении предварительного изучения обращения … отсутствуют
        доказательства» и «В Офис Генерального прокурора поступило обращение …
        не прикреплены доказательства». В бланке получались два подряд абзаца
        об одном, и это выглядело как ошибка сборки.
        """
        situation = strip_field_label_leaks(strip_placeholder_clauses(
            scrub_chat_text(self.get("situation"))))
        established = strip_field_label_leaks(strip_placeholder_clauses(
            scrub_chat_text(self.get("established"))))
        if not situation or not established:
            return False
        return _same_story(situation, established)

    def _facts_repeat_appeal(self) -> bool:
        """Текст «Обстоятельств» повторяет описание ситуации из обращения."""
        situation = _key(strip_field_label_leaks(strip_placeholder_clauses(
            scrub_chat_text(self.get("situation")))))
        description = _key(self.appeal_situation)
        if not situation or not description:
            return False
        if situation == description or situation in description:
            return True
        # Сравнение по словам: ИИ/пользователь мог слегка переписать текст.
        words_situation = set(re.findall(r"[а-яёa-z]{4,}", situation))
        words_description = set(re.findall(r"[а-яёa-z]{4,}", description))
        if not words_situation or not words_description:
            return False
        overlap = len(words_situation & words_description) / len(words_situation)
        return overlap >= 0.6

    def facts_text(self) -> str:
        """«УСТАНОВИЛ» — фактические обстоятельства дела."""
        parts: list = []
        # v37: если в «Обстоятельства» вставили бланк обращения — берём из него
        # только описание ситуации; остальные реквизиты уже в своих полях.
        situation = strip_doc_type_tail(strip_field_label_leaks(
            strip_appeal_form_items(strip_placeholder_clauses(
                scrub_chat_text(self.get("situation"))))))
        if looks_like_appeal_form(situation):
            # В «Обстоятельства» вставили бланк обращения целиком — в документ
            # идёт только пункт «Подробное описание ситуации», остальные
            # реквизиты уже разложены по полям (v37).
            situation = parse_appeal_text(situation).get("description", "")
        established = strip_field_label_leaks(strip_appeal_form_items(
            strip_placeholder_clauses(scrub_chat_text(self.get("established")))))
        # v51 (выгрузка AG-2): ИИ сам пишет «В подтверждение представлено:
        # представлены.» — эту заглушку из текста надо убрать.
        established = strip_evidence_stub_sentences(established)
        # v37 (вторая итерация): в выгрузке AG-2 «УСТАНОВИЛ» сначала шёл текст
        # ИИ по обращению, а следом целиком повторялся пересказ заявителя из
        # пункта 5. Повторяем его только тогда, когда «УСТАНОВИЛ» пуст.
        if established and situation and not self._prosecutor_own_facts():
            situation = ""
        # v40: пересказ заявителя из пункта 5 печатается только тогда, когда
        # «УСТАНОВИЛ» ИИ пуст ИЛИ прокурор дал свои факты с тайм-кодами.
        # Если ИИ уже пересказал обращение своими словами — второй абзац
        # сырого текста заявителя в бланке недопустим (выгрузка AG-1).
        if established and situation and self._facts_repeat_appeal():
            situation = ""
        # v56 (замечание п.4 по выгрузке «Постановление»): в «УСТАНОВИЛ»
        # печатается ТОЛЬКО ответ ИИ. Текст, который прокурор написал в блоки
        # «Обстоятельства» (тайм-коды для анализа), в документ не попадает —
        # в выгрузке «УСТАНОВИЛ» начинался с «01:16 — сотрудник объясняет…»
        # вместо «15 ноября 2026 года …». Если ИИ раздел не дал — ниже
        # остаётся штатная заглушка бланка.
        if established and situation:
            situation = ""
        # v46 (выгрузка Постановление_46v): ИИ дважды пересказал одно и то же —
        # в «Обстоятельствах» и в «УСТАНОВИЛ» (пересечение слов 38 %). В бланке
        # это читалось как два почти одинаковых абзаца подряд.
        if established and situation and self._facts_restart_story():
            situation = ""
        # Порядок: сначала факты прокурора по видеофиксации, затем правовая
        # оценка ИИ — иначе «УСТАНОВИЛ» заканчивался выводом и снова начинался
        # описанием записи (замечание второй итерации v37).
        append_unique(parts, situation)
        append_unique(parts, established)

        joined = " ".join(parts).lower()
        when = self.get("event_date")
        place = self.get("event_place")
        if is_place_placeholder(place):
            place = ""
        date_part = ""
        m = re.match(r"\s*(\d{1,2}\.\d{1,2}\.\d{2,4})", when or "")
        if m:
            date_part = m.group(1)
        need_when = bool(when) and when.lower() not in joined \
            and (not date_part or date_part not in joined)
        # v41: место события — часть фразы, а не ярлык бланка. «Место события:
        # здание EMS…» в тексте «УСТАНОВИЛ» — это реквизит шапки (пользователь:
        # «лишняя информация, её быть не должно»), поэтому подставляем его
        # только внутри предложения «Событие имело место».
        need_place = bool(place) and not _covered(place, joined) and need_when
        # «в ходе служебной деятельности» — не место события, а описание
        # процесса: такие заглушки выбрасываем ещё до вставки в текст.
        # v52 (выгрузка `Постановление_52_для_версии`): «УСТАНОВИЛ» начинался
        # со служебной строки «Событие имело место: 09.11.2026 19:43», а текст
        # по существу («10 ноября 2026 года …») шёл уже после неё. Дата и место
        # события — реквизиты шапки бланка, а не первый абзац установленных
        # фактов, поэтому отдельного предложения в «УСТАНОВИЛ» больше нет.
        # Место по-прежнему дописывается, но внутри первого абзаца о событии.
        if need_place:
            parts = _mention_place(parts, place)

        # «Указанные обстоятельства образуют нарушение: по обстоятельствам,
        # указанным в заявке» — заглушка, в документе её печатать нельзя.
        clause = "" if is_vague_clause(self.get("violation_clause")) \
            else self.get("violation_clause")
        if is_placeholder(clause):
            clause = ""
        act = self.get("violation_act")
        if is_placeholder(act):
            act = ""
        # v40 (выгрузка AG-1): при отказе в удовлетворении «Пункт нарушения» и
        # «Нарушенный акт» — это НЕ нарушение, а процедурная норма, по которой
        # отказано («Регламент подачи обращений»). В «УСТАНОВИЛ» появлялось
        # «Указанные обстоятельства образуют нарушение: Регламента подачи
        # обращений …». Фраза нужна только там, где нарушение действительно
        # вменяется: есть конкретная статья/пункт нарушенного акта.
        # v41 (AG-2): ИИ сам пишет «Указанные обстоятельства образуют
        # нарушение …» внутри «УСТАНОВИЛ» — второй такой фразы в конце не
        # нужно, это дубль вывода.
        # v51 (выгрузка AG-1): раньше здесь искалось слово «нарушение», и
        # фраза «Оснований для отказа … не выявлено» в «УСТАНОВИЛ» съедала
        # вывод о вменяемом нарушении. Теперь ищем именно ВМЕНЕНИЕ.
        already_offence = offence_is_stated(" ".join(parts))
        # v45: в решении БЕЗ вменяемого нарушения (отказ в принятии, отказ в
        # удовлетворении, прекращение) «Нарушенный акт» и «Пункт нарушения» —
        # процедурная норма отказа, а не состав. Фраза «образуют нарушение»
        # там недопустима вовсе, даже когда акт указан.
        if self._ends_without_offence():
            clause, act = "", ""
        # v51 (выгрузка AG-1): «Нарушенный акт: Регламент подачи обращений» —
        # ПРОЦЕДУРНАЯ норма (по ней принимают обращение), а не нарушенный акт.
        # «Указанные обстоятельства образуют нарушение: статьи 14 Регламента
        # подачи обращений…» в постановлении о принятии — ложное утверждение.
        if clause and act and is_procedural_norm(act):
            clause, act = "", ""
        if clause and not already_offence and (act or not self._ends_without_offence()):
            norm = clause_genitive(clause)
            extra = acts_not_named(clause, act) if act else ""
            phrase = " ".join(x for x in (norm, extra) if x)
            if phrase:
                parts.append(f"Указанные обстоятельства образуют нарушение: {phrase}.")

        evidence = self.get("evidence")
        # v51 (выгрузка AG-2): «Доказательства: представлены» — заглушка.
        # В PNG печаталось «В подтверждение представлено: представлены.»
        if evidence and is_evidence_stub(evidence):
            evidence = ""
        # v54: доказательство — сам материал («видеозапись обращения»), а не
        # перечень сырых наблюдений заявителя по тайм-кодам. В выгрузке AG-2 в
        # «УСТАНОВИЛ» печаталось «…(от 0 сек до 13 сек еду просто видно
        # мегафонов нету. 00:13 секунда пробивают колёса, 0:40 Дм без причины…)».
        if evidence:
            evidence = evidence_mention(evidence)
            if not evidence or is_evidence_stub(evidence):
                evidence = ""
        if evidence:
            # тайм-коды/номера сравниваем отдельно: «05:01» в тексте уже есть,
            # значит второй раз «представлено: …» печатать не нужно
            codes = re.findall(r"\d{1,2}:\d{2}", evidence)
            already = " ".join(parts).lower()
            if codes:
                shown = sum(1 for code in codes if code in already)
                if shown >= max(1, len(codes) // 2):
                    evidence = ""
            # v54: строка про доказательство ставится только там, где на неё
            # есть что сказать. «В подтверждение представлено: материалы
            # приложены к обращению» — один и тот же оборот дважды подряд,
            # поэтому достаточно «В подтверждение представлено: материалы
            # обращения».
            phrase = ("материалы обращения"
                      if evidence.lower().startswith("материалы обращения")
                      else evidence)
            if evidence and not _covered(evidence, already):
                parts.append(f"В подтверждение представлено: {phrase}.")
        # v41 (AG-2): «… никак не реагирует Гражданин Lordik Claw обратился…» —
        # части склеивались, если ИИ не поставил точку в конце «Обстоятельств».
        joined_parts = " ".join(_end_sentence(p.strip()) for p in parts if p.strip())
        # v53 (выгрузка «Постановление для 53 версии»): ИИ печатал в «УСТАНОВИЛ»
        # сами адреса — «Запись заседания Сената от 09.11.2026:
        # https://www.youtube.com/watch?v=…», «docs.google.com/…». В документе
        # адреса быть не должно: остаётся название материала и «приложено к
        # обращению».
        joined_parts = strip_urls(joined_parts)
        # v54: оборванная на полуслове правовая оценка в конце «УСТАНОВИЛ»
        # («…а также главой 16 Процессуального кодекса, Офис Генерального
        # прокурора») в бланк не печатается.
        joined_parts = _drop_unfinished_tail(joined_parts)
        # v54: сырые наблюдения заявителя по тайм-кодам («0:40 Дм без причины»)
        # и разговорные внеигровые обороты в «УСТАНОВИЛ» не печатаются.
        joined_parts = strip_raw_observations(joined_parts)
        joined_parts = base.sanitize_ooc(joined_parts)
        # v51 (п.1): реквизиты нарушителя («В отношении / Удостоверение / Отдел
        # сотрудника») в заявке есть, а ИИ их не пересказал — в PNG их не было.
        return append_subject_requisites(joined_parts, self)

    def decision_points(self) -> list:
        """Резолюция. Если ИИ не прислал пункты — собираем по виду решения.

        v53: адреса в пунктах резолюции тоже недопустимы — ИИ иногда
        прикладывает «ссылка: https://…» прямо в постановляющей части.
        """
        if self.points:
            points = [strip_urls(point) for point in self.points]
            # v51 (п.1): «штраф (penalty) теряется». Резолюция ИИ приходит
            # готовыми пунктами, и назначенное в форме наказание в неё не
            # попадало вовсе. Добавляем его отдельным пунктом, если ИИ сам
            # наказание не назвал, — иначе в PNG санкция без размера.
            penalty = _clean(self.get("penalty"))
            if penalty and not is_placeholder(penalty):
                joined = " ".join(points).lower()
                if not _covered(penalty, joined, threshold=0.8):
                    return points + [f"Назначить наказание: {penalty}."]
            return points
        applicant = self.get("applicant_name") or "заявителя"
        ident = self.get("applicant_id")
        if is_placeholder(ident):
            ident = ""
        applicant_ref = f"{applicant} (ID-карта № {ident})" if ident else applicant
        appeal = self.get("appeal_number")
        appeal_ref = f" № {appeal}" if appeal else ""
        subject = "" if is_placeholder(self.get("subject_name")) else self.get("subject_name")
        subject_ref = subject
        subject_id = "" if is_placeholder(self.get("subject_id")) else self.get("subject_id")
        if subject and subject_id:
            subject_ref = f"{subject} (ID № {subject_id})"
        low = self.title().lower()
        points: list = []
        # v39: этап 2 — «отказ в удовлетворении обращения» (п. «б» ч. 1 ст. 23
        # Регламента) отличается от первичного «отказа в принятии» (ст. 16):
        # обращение рассмотрено по существу, но доказательств не хватило.
        if "удовлетвор" in low:
            points.append(f"В удовлетворении обращения {applicant_ref} отказать "
                          "ввиду недостаточности представленных доказательств "
                          "(пункт «б» части 1 статьи 23 Регламента подачи обращений "
                          "в Офис Генерального прокурора).")
            reason = self.get("legal_basis") or self.get("violation_clause")
            if reason:
                points.append(f"Основание: {reason}.")
            points.append("Настоящее постановление вступает в законную силу с "
                          "момента подписания и публикации.")
            points.append(self.appeal_point())
            return points
        if "отказ" in low:
            points.append(f"Отказать в принятии обращения {applicant_ref} "
                          f"к рассмотрению.")
            reason = (self.get("legal_basis") or self.get("violation_clause")
                      or "обстоятельства, предусмотренные статьей 16 Регламента "
                         "подачи обращений в Офис Генерального прокурора")
            if reason:
                points.append(f"Основание отказа: {reason}.")
            points.append("Настоящее постановление вступает в законную силу с "
                          "момента подписания и публикации и может быть "
                          "обжаловано вышестоящему прокурору либо в суд в срок, "
                          "не превышающий 72 часа (статья 28 Регламента подачи "
                          "обращений в Офис Генерального прокурора).")
            return points
        if "завершен" in low:
            points.append(f"Завершить проверку по обращению {applicant_ref}.")
            points.append("Передать материалы проверки в уголовное производство "
                          "в порядке, установленном Процессуальным кодексом "
                          "штата Сан-Андреас.")
            points.append("Уведомить заявителя о результатах проверки.")
            points.append(self.appeal_point())
            return points
        if "привлеч" in low:
            # v39: без ФИО нарушителя резолюция раньше оставалась вообще без
            # санкции — только «вступает в силу» и «может быть обжаловано».
            norm = ("" if is_vague_clause(self.get("violation_clause"))
                    else self.get("violation_clause")) or "законодательства штата"
            if subject_ref:
                points.append(f"Признать {subject_ref} виновным в нарушении "
                              f"{norm}.")
            else:
                points.append("Привлечь установленное лицо к административной "
                              f"ответственности за нарушение {norm}.")
            if self.get("penalty"):
                points.append(f"Назначить наказание: {self.get('penalty')}.")
            else:
                points.append("Назначить административное наказание в пределах "
                              "санкции нормы, указанной в основании.")
            points.append("Настоящее постановление вступает в законную силу с "
                          "момента подписания и публикации.")
            points.append(self.appeal_point())
            return points
        if re.search(r"уголовн", low):
            points.append("Возбудить уголовное производство по изложенным "
                          "обстоятельствам в отношении "
                          f"{subject_ref or 'установленных лиц'}.")
            points.append("Материалы проверки направить в Окружной суд штата "
                          "Сан-Андреас для рассмотрения по существу.")
            points.append("Настоящее постановление вступает в законную силу с "
                          "момента подписания и публикации.")
            return points
        if "прокурорского реагирования" in low:
            points.append("Применить меры прокурорского реагирования по "
                          "изложенным обстоятельствам в порядке статей 9–9.3 "
                          "Закона «О деятельности офиса Генерального прокурора "
                          "штата San-Andreas».")
            if self.get("violation_clause"):
                points.append("Внести представление об устранении нарушений "
                              "закона: " + self.get("violation_clause") + ".")
            points.append("Уведомить заявителя о принятых мерах.")
            points.append(self.appeal_point())
            return points
        if "в суд" in low:
            points.append("Передать материалы обращения и проверки в Окружной "
                          "суд штата Сан-Андреас для рассмотрения по существу "
                          "(пункт «в» части 1 статьи 23 Регламента подачи "
                          "обращений).")
            points.append("Уведомить заявителя о передаче материалов в суд.")
            points.append(self.appeal_point())
            return points
        if "переадрес" in low:
            points.append(f"Переадресовать обращение {applicant_ref} по "
                          "подведомственности.")
            # v39: Регламент, ст. 19 — переадресация идёт в следственное или
            # дисциплинарное подразделение органа либо в IB FIB, а не «в воздух».
            target = self.redirect_target()
            if target:
                points.append(f"Направить обращение в {target} для проведения "
                              "служебной проверки по изложенным обстоятельствам.")
            points.append("Уведомить заявителя о переадресации обращения.")
            points.append(self.appeal_point())
            return points
        if "прекращ" in low:
            points.append(f"Прекратить производство по обращению {applicant_ref}.")
            points.append(self.appeal_point())
            return points
        # По умолчанию — принятие к рассмотрению (самый частый случай в примерах).
        points.append(f"Принять к рассмотрению обращение {applicant_ref}"
                      f"{(' от ' + self.get('appeal_date')) if self.get('appeal_date') else ''}, "
                      f"поступившее в Офис Генерального прокурора{appeal_ref}.")
        who = self.get("author_name")
        ident_author = self.get("author_id")
        points.append("Принять материалы обращения в производство "
                      + (f"Прокурора штата Сан-Андреас {who}" if who else "прокурора")
                      + (f", удостоверение № {ident_author}" if ident_author else "")
                      + ".")
        points.append("Осуществить рассмотрение обращения в срок, не превышающий "
                      "72 часов, в соответствии с частью 2 статьи 12 Регламента "
                      "подачи обращений в Офис Генерального прокурора штата "
                      "San-Andreas.")
        points.append("Уведомить заявителя о принятом решении.")
        points.append("Настоящее постановление вступает в законную силу с момента "
                      "его подписания и публикации на официальном портале штата "
                      "Сан-Андреас.")
        points.append(self.appeal_point())
        return points

    def basis_text(self) -> str:
        parts = []
        act = self.get("violation_act")
        if self.get("violation_clause"):
            clause = normalize_clause(self.get("violation_clause"), act)
            # ИИ присылает «Пункт 8.5 Устава LSCSD — нарушение дресс-кода»,
            # и к этому приклеивалось ещё «Устава Los Santos County …»
            # (выгрузка v37). Оставляем только номер пункта с пояснением:
            # название акта печатается отдельным куском ниже.
            clause = _clean(clause)
            num = re.match(r"(?:пункт[а]?\s*)?(\d+(?:\.\d+)+)", clause, re.IGNORECASE)
            if num:
                tail = clause[num.end():].lstrip(" )—-,")
                tail = re.sub(r"^устава?\s+\S+.*$", "", tail, flags=re.IGNORECASE)
                clause = f"пункт {num.group(1)}"
                if tail and len(tail) > 3:
                    clause += f" ({tail.strip(' .')})"
            parts.append(norm_lower_initial(clause))
            # «статьи 8, 10, 11» без названия акта ничего не говорит читателю,
            # но и повторять уже названный в норме акт нельзя (v39).
            if act:
                missing_acts = acts_not_named(clause, act)
                if missing_acts:
                    parts.append(missing_acts)
        elif self.get("violation_act"):
            parts.append(self.get("violation_act"))
        legal = self.get("legal_basis")
        if legal:
            # v51 (п.1): «Нормативное основание» из ответа ИИ — несколько
            # норм через «;». Раньше вся строка печаталась одним куском, и
            # повтор уже названной нормы («часть 1 статьи 15.1; …; часть 1
            # статьи 15.1 Уголовного Кодекса …») было не убрать. Разбираем по
            # кускам и берём только то, чего в «Основании» ещё нет.
            for piece in re.split(r"[;]", str(legal)):
                piece = piece.strip(" ;,.")
                if not piece:
                    continue
                if any(_norm_inside(piece, done) for done in parts):
                    continue
                parts.append(piece)
        parts = [p.strip(" ;,") for p in parts if p.strip(" ;,")]
        # v51 (п.1): «статьи 14» вместо «Статья 14» и без повтора того же акта.
        if parts:
            parts = _merge_adjacent_act(parts, act)
            parts = _merge_same_act_norms(parts, act)
        # v51 (п.1): повтор акта и одной и той же нормы убираем ДО сведения
        # кусков через «;» — иначе «пункт 14 части 1 статьи 16 Регламента …,
        # пункт 14 части 1 статьи 16» печаталось как две нормы.
        joined = ", ".join(parts) if len(parts) > 1 and act else "; ".join(parts)
        # v46: в «Основании» печатались две нормы про одну статью — «пункт 14
        # части 1 статьи 16; … часть 1 статьи 16 Регламента …». Оставляем то
        # упоминание, что конкретнее.
        joined = _dedupe_basis_segments(joined)
        # v38 (выгрузка AG-2): название акта повторялось в «Основании» трижды —
        # «статьи 16.4 Уголовного кодекса …, …; Уголовный Кодекс штата
        # Сан-Андреас, Процессуальный кодекс …». Оставляем первое упоминание.
        return _drop_repeated_acts(joined)

    def _ends_without_offence(self) -> bool:
        """Итоговое решение не вменяет нарушения (отказ, завершение проверки).

        В этих постановлениях «Нарушенный акт»/«Пункт нарушения» — либо
        процедурная норма отказа, либо пусто, и печатать «образуют нарушение»
        нельзя (v40, выгрузка AG-1).
        """
        low = self.title().lower()
        return any(mark in low for mark in ("отказе в удовлетворении",
                                            "завершении проверки",
                                            "прекращении производства",
                                            # v45 (AG-2): отказ в ПРИНЯТИИ
                                            # обращения — тоже решение без
                                            # вменяемого нарушения. Раньше в
                                            # таком постановлении печаталось
                                            # «Указанные обстоятельства образуют
                                            # нарушение: пункта 14 части 1
                                            # статьи 16 Регламента …», хотя
                                            # это норма отказа, а не состав.
                                            "отказе в принятии обращения"))

    def missing_fields(self) -> list:
        """Обязательные реквизиты постановления (v37).

        Заявитель больше не вводится отдельно: он берётся из обращения, и если
        в тексте его нет — это видно в подсказке формы. Обязательно само
        обращение (или обстоятельства, если прокурор пишет их сам).
        """
        required = ("doc_number", "doc_date", "author_name")
        missing = [GOV_FORM_LABELS[k] for k in required if not self.get(k)]
        if not self.get("appeal_raw") and not self.get("applicant_name") \
                and not self.get("situation"):
            missing.append("Обращение")
        return missing

    def auto_number(self, existing: list | None = None, prefix: str = "AG") -> str:
        """Номер постановления прокуратуры: AG-937 (следующий после максимума)."""
        top = 0
        for item in existing or []:
            m = re.search(r"(\d+)\s*$", _clean(item))
            if m:
                top = max(top, int(m.group(1)))
        return f"{prefix}-{top + 1}"

    # ------------------------------------------------------- сериализация

    def to_dict(self) -> dict:
        data = asdict(self)
        data["points"] = list(self.points or [])
        return data

    @classmethod
    def from_dict(cls, data: dict | None) -> "PostanovlenieProkurora":
        data = data or {}
        allowed = {key for key, _f, _l in GOV_FIELDS} | {
            "points", "created_at", "source", "established", "appeal_raw",
            "prosecutor_facts", "appeal_situation", "preamble_basis",
            "case_number", "case_stage_kind"}
        kwargs = {k: v for k, v in data.items() if k in allowed}
        doc = cls(**kwargs)
        doc.points = [_clean(p) for p in (data.get("points") or []) if _clean(p)]
        return doc

    def to_chat_txt(self) -> str:
        """Заявка в чат: реквизиты постановления + обращение ЦЕЛИКОМ (v37).

        Отдельные поля заявителя и нарушителя убраны из формы, поэтому в чат
        уходит текст обращения как есть — ИИ сам находит в нём заявителя,
        нарушителя, предмет, дату события и тайм-коды.
        """
        lines = ["ЗАЯВКА НА ПОСТАНОВЛЕНИЕ ПРОКУРОРА"]
        lines.append("Данные для подготовки документа:")
        self._ensure_derived_fields()
        # v39: вид решения — из двух частей. Этап печатаем ПЕРВОЙ строкой и
        # сразу раскрываем, что именно проверять (первичное решение по форме
        # обращения или итоговая санкция по обстоятельствам).
        stage = self.stage()
        lines.append(f"Этап: {GOV_STAGE_TITLES[stage]}")
        for key, _form, label in GOV_CHAT_FIELDS:
            value = self.get(key)
            if not value:
                continue
            if key == "appeal_raw":
                continue
            lines.append(f"{label}: {value}")
        lines.append(GOV_STAGE_GUIDE[stage])
        # v50 (замечание пользователя): «текст обращения экспортируй в файл
        # „Обращение.txt" и экспортируй его в ИИ, минимум текста в поле
        # запроса». Заявка ссылается на вложение, но самого текста обращения в
        # ней больше нет — он уходит отдельным файлом, поэтому простыня в
        # сообщении исчезает.
        appeal = self.get("appeal_raw")
        if appeal:
            lines.append("")
            lines.append("ОБРАЩЕНИЕ ГРАЖДАНИНА — во вложении «Обращение.txt» "
                         "(текст целиком, форма ОГП). Реквизиты обращения "
                         "(заявитель, нарушитель, предмет, дата события, "
                         "тайм-коды) бери из этого файла.")
        if self.get("situation"):
            lines.append("")
            lines.append("ОБСТОЯТЕЛЬСТВА, УСТАНОВЛЕННЫЕ ПРОКУРОРОМ:")
            lines.append(self.get("situation"))
        if self.points:
            lines.append("")
            lines.append("Предлагаемые пункты (перепиши официально):")
            for i, point in enumerate(self.points, 1):
                lines.append(f"{i}. {point}")
        lines.append("")
        lines.append("Подготовь постановление Прокурора строго по этим данным, "
                     "в формате промта: один структурированный блок от начала "
                     "документа до конца ответа, без описания вложений.")
        return "\n".join(lines) + "\n"

    def _ensure_derived_fields(self) -> None:
        """Достаёт из обращения то, чего ещё нет в полях (v37)."""
        if self.get("appeal_raw"):
            self.apply_appeal(self.get("appeal_raw"))
        elif self.get("situation"):
            parsed = parse_appeal_text(self.get("situation"))
            if parsed.get("applicant_name") and not self.get("applicant_name"):
                self.set("applicant_name", parsed["applicant_name"])
                if parsed.get("applicant_id"):
                    self.set("applicant_id", parsed["applicant_id"])
            if parsed.get("violator") and not self.get("subject_name"):
                self.set("subject_name", parsed["violator"])
                if parsed.get("violator_id"):
                    self.set("subject_id", parsed["violator_id"])
            if parsed.get("event_date") and not self.get("event_date"):
                self.set("event_date", parsed["event_date"])
        if not self.get("city"):
            self.city = GOV_CITY

    def to_document_txt(self) -> str:
        """Бланк словами — ровно то, что печатает PNG."""
        lines = [
            self.get("vedomstvo").upper() or GOV_VEDOMSTVO,
            self.get("podrazdelenie").upper() or GOV_PODRAZDELENIE,
            "",
            self.number_line(),
            self.document_title(),
            "",
        ]
        if self.get("city") or self.get("doc_date"):
            lines.append(", ".join(x for x in (self.get("city"), self.get("doc_date")) if x))
        lines += ["", self.preamble(), "", "УСТАНОВИЛ:", "", self.facts_text(), "",
                  "ПОСТАНОВИЛ:", ""]
        for i, point in enumerate(self.decision_points(), 1):
            lines.append(f"{i}. {point}")
        basis = self.basis_text()
        if basis:
            lines += ["", "Основание: " + basis]
        if self.get("extra"):
            lines.append("Дополнительно: " + self.get("extra"))
        lines.append("")
        if self.get("author_name"):
            lines.append(f"Подпись: {self.get('author_name')}")
            if self.get("author_rank"):
                lines.append(f"Должность: {self.get('author_rank')}")
        return "\n".join(lines).strip() + "\n"

    def chat_txt_name(self) -> str:
        num = self.get("doc_number") or "б-н"
        return f"Постановление Прокурора {num}{base.DOC_MARKER_SUFFIX}"

    def history_payload(self) -> dict:
        """Снимок для истории (v51, п.4).

        Раньше `created_at` переписывался на `time.time()` при КАЖДОМ
        сохранении. Из-за этого два снимка одного документа (заявка и ответ
        ИИ) отличались всегда, ключ дедупликации в `DocumentHistory.items()`
        (полный JSON) никогда не совпадал, и в «Истории» висели две одинаковые
        строки. Теперь время берётся из документа: повторное сохранение того же
        документа даёт тот же снимок.
        """
        data = self.to_dict()
        data["created_at"] = float(self.created_at or time.time())
        return data


class GovHistory(base.DocumentHistory):
    """История постановлений Прокурора — своя папка и свой загрузчик (v41).

    Ошибка из логов (`AttributeError` в `set_document`): история была общей на
    два вида документов, и запись Прокурора грузилась моделью IAD — у неё нет
    ни `stage()`, ни `facts_text()`, поэтому «Загрузить в форму» падал.
    Теперь загрузчик — `PostanovlenieProkurora`, а сами записи лежат в
    `postanovleniya/history/gov/`.
    """

    KIND = base.HISTORY_KIND_GOV

    def _parse(self, data: dict):
        return PostanovlenieProkurora.from_dict(data)

    def _belongs(self, data: dict) -> bool:
        """Запись — постановление Прокурора, а не IAD.

        Признаки: поле `doc_stage`/`prosecutor_facts`/`appeal_raw` (их пишет
        только модель Прокурора) либо номер с префиксом «AG».
        """
        if not isinstance(data, dict):
            return False
        if any(key in data for key in ("doc_stage", "prosecutor_facts",
                                       "appeal_raw", "prosecutor_rank")):
            return True
        number = str(data.get("doc_number") or "").strip().upper()
        if number.startswith("AG"):
            return True
        # Совсем старые записи без служебных полей: у IAD-бланка есть
        # «взыскание»/«пункт нарушения» и нет «вида решения» Прокурора.
        return False


def gov_history(folder) -> GovHistory:
    """Готовая история постановлений Прокурора для формы и main.py."""
    return GovHistory(folder, kind=base.HISTORY_KIND_GOV)


# --------------------------------------------------------------------------- #
#  Разбор ответа ИИ
# --------------------------------------------------------------------------- #

#: Строки подписи в конце резолюции. ИИ нумерует их как пункты
#: («6. Прокурор штата…», «7. J. Raine»), и они попадали в резолюцию.
_GOV_SIGNATURE = re.compile(
    r"^(прокурор(\s+штата)?|подпись|должность|удостоверение|"
    r"[А-ЯЁA-Z]\.\s?[А-ЯЁA-Z][а-яёa-z]+$|"
    r"[А-ЯЁ][а-яё]+\s+[А-ЯЁ][а-яё]+$|"
    r"(?:г\.\s*)?[А-ЯЁ][а-яё-]+(?:-[А-ЯЁ][а-яё-]+)?,\s*\d{2}\.\d{2}\.\d{4})",
)


def is_signature_line(line: str) -> bool:
    """Строка — элемент подписи (должность, ФИО, удостоверение), не пункт."""
    text = strip_markdown(str(line or "")).strip(" .;,")
    if not text:
        return False
    low = text.lower()
    # v38: «Принять обращение … (удостоверение № 171034) к собственному
    # производству …» — это ПУНКТ резолюции, а не строка подписи. Раньше
    # проверка на слово «удостоверение» съедала первый пункт (выгрузка AG-1).
    short = len(text) <= 90 and len(text.split()) <= 8
    if short and (low.startswith(("удостоверение", "подпись", "должность"))
                  or "удостоверение №" in low and len(text.split()) <= 5):
        return True
    if short and low.startswith("прокурор") and "постановил" not in low:
        return True
    # «И. Рейн», «Jonathan Raine» — ФИО из 2–3 слов без глаголов приказа.
    words = text.split()
    if len(words) <= 3 and not re.search(r"\b(назначить|принять|возбудить|обязать|"
                                         r"отказать|направить|уведомить|прекратить)\b",
                                         low):
        return bool(re.fullmatch(r"(?:[А-ЯЁA-Z]\.?\s?)?(?:[А-ЯЁA-Z][а-яёa-z-]+\.?"
                                 r"(?:\s+[А-ЯЁA-Z][а-яёa-z-]+\.?){0,2}|"
                                 r"[А-ЯЁA-Z]\.\s?[А-ЯЁA-Z]\.(?:\s?[А-ЯЁA-Z]\.)?)", text))
    return False


#: Опечатки, которые ИИ повторяет из раза в раз (выгрузка v38:
#: «Возбудить прокуроровское производство»).
_GOV_TYPOS: tuple[tuple[str, str], ...] = (
    (r"\bпрокуроровск([а-яё]*)\b", r"прокурорск\1"),
)


#: Опечатки ИИ в ЗАГОЛОВКАХ разделов (встречаются в реальных ответах):
#: «УСТАВНОРИЛ» вместо «УСТАНОВИЛ», «ПОСТОНОВИЛ» вместо «ПОСТАНОВИЛ».
_HEADING_TYPOS = (
    (r"^уставн\w*", "установил"),
    (r"^устонов\w*", "установил"),
    (r"^постонов\w*", "постановил"),
    (r"^пстановил\w*", "постановил"),
)


def _normalize_heading(heading: str) -> str:
    """Приводит заголовок раздела к «установил» / «постановил» (v45.1).

    Нужно только для распознавания раздела: сам текст остаётся как у ИИ.
    """
    low = str(heading or "").strip(" .:")
    for pattern, replacement in _HEADING_TYPOS:
        if re.match(pattern, low):
            return replacement + low[re.match(pattern, low).end():]
    return low


def fix_gov_typos(text: str) -> str:
    """Убирает повторяющиеся опечатки ИИ («прокуроровское производство»)."""
    result = str(text or "")
    for pattern, replacement in _GOV_TYPOS:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    return result


def _is_basis_echo(line: str, doc) -> bool:
    """Строка «Основание: …» в конце документа повторяет блок «Основание» (v45.1).

    В ответе из лога 20261109-161442 после пунктов «ПОСТАНОВИЛ» шла строка
    «Основание: пункт 14 части 1 статьи 16; Регламента подачи обращений …».
    Она попадала в резолюцию как ещё один пункт постановления.
    """
    if ":" not in line:
        return False
    key, value = line.split(":", 1)
    if str(key).strip().lower() not in ("основание", "правовое основание",
                                        "нормативное основание"):
        return False
    value = str(value or "").strip().lower()
    if not value:
        return False
    known = (doc.get("legal_basis") or "") + " " + (doc.get("violation_clause") or "")
    known = " ".join(known.split()).lower()
    if not known.strip():
        return True                     # основание уже есть в шапке документа
    first = " ".join(value.split()[:6])
    return first in known or known[:40] in value


#: С каких слов начинается самостоятельный пункт резолюции (v46).
_POINT_START = (
    "отказать", "отказано", "принять", "принято", "прекратить",
    "переадресовать", "направить", "разъяснить", "возбудить", "привлечь",
    "внести", "объявить", "назначить", "взыскать", "уведомить",
    "настоящее постановление", "копию", "обращение",
    # v65 (выгрузка «Обращение №1.7z»): ИИ перечислил решения без номеров —
    # «Принять…», «Инициировать…», «Обязать…», «Уведомить…». Двух средних
    # глаголов в перечне не было, и они приклеились к первому пункту: в PNG
    # один пункт на 830 знаков вместо четырёх.
    "инициировать", "обязать", "истребовать", "запросить", "поручить",
    "вызвать", "отстранить", "передать", "признать", "провести",
    "обеспечить", "рекомендовать", "рассмотреть", "подготовить",
    "вынести", "установить", "запретить", "приостановить", "возобновить",
    "отменить", "изменить", "дополнить", "изъять", "вернуть", "возвратить",
    "возложить", "предоставить", "потребовать", "предложить",
    "предупредить", "сообщить", "вручить", "восстановить", "заключить",
    "организовать", "продлить", "контроль", "срок",
)


def _point_is_complete(point: str) -> bool:
    """Предыдущий пункт закончен — значит, новая строка не его продолжение."""
    return str(point or "").rstrip()[-1:] in (".", "!", "?", "…", ";")


def _starts_new_point(plain: str) -> bool:
    """Строка похожа на НОВОЕ решение, а не на перенос предыдущего (v65)."""
    text = str(plain or "").strip()
    if not text or is_signature_line(text):
        return False
    if _looks_like_point(text):
        return True
    return len(text) >= 15 and bool(re.match(r"^[A-ZА-ЯЁ][a-zа-яёA-Za-z]", text))


def _looks_like_point(plain: str) -> bool:
    """Строка — отдельный пункт резолюции, даже без номера (v46).

    Ответ ИИ на отказ в принятии приходит так:

        ПОСТАНОВИЛ:
        Отказать в принятии обращения …
        Прекратить прокурорское производство …
        Разъяснить заявителю …

    Без номеров все три строки склеивались в один пункт.
    """
    low = str(plain or "").strip().lower()
    if len(low) < 15:
        return False          # «Основание:» и подпись сюда не попадают
    return low.startswith(_POINT_START)


#: Пункты ФОРМЫ ОБРАЩЕНИЯ, которые ИИ копирует в резолюцию (v46).
#: Выгрузка Постановление_46v: «ПОСТАНОВИЛ: 1. Данные о заявителе: … 2. Сведения
#: о нарушителе: … 3. Подробное описание ситуации: …» — это не решения, а
#: реквизиты заявления, и в постановлении их быть не может.
_APPEAL_FORM_POINT = re.compile(
    r"^(?:данные\s+о\s+заявителе|сведения\s+о\s+нарушителе|"
    r"предмет\s+обращения|дата\s+и\s+время\s+события|"
    r"подробное\s+описание\s+ситуации|ксерокопи\w+|"
    r"электронн\w+\s+почт\w+|доказательства\s+правонарушения|"
    r"дата\s+подачи\s+заявления|подпись\s+и\s+расшифровка)",
    re.IGNORECASE,
)


def is_appeal_form_point(text: str) -> bool:
    """Строка — пункт формы обращения, а не решение прокурора (v46)."""
    plain = str(text or "").strip()
    if not plain:
        return False
    return bool(_APPEAL_FORM_POINT.match(plain))


def strip_signature_points(points: list) -> list:
    """Убирает пункты-подписи из резолюции (v37, v46)."""
    kept = []
    for point in points or []:
        if not point or is_signature_line(point):
            continue
        # v46: «1. Данные о заявителе: …» — пункт формы обращения, а не
        # решение прокурора (выгрузка Постановление_46v).
        if is_appeal_form_point(point):
            diag_event("gov.appeal_form_point_dropped", value=str(point)[:60])
            continue
        kept.append(point)
    return kept


#: Ключи служебного блока проверки обращения (v42) и их синонимы.
_INTAKE_KEY_ALIASES: dict = {
    "состояние": "state", "решение": "state", "итог": "state",
    "принято": "state", "статус": "state",
    "основание": "basis", "основание отказа": "basis",
    "норма": "basis", "пункт": "basis",
    "вид решения": "doc_type", "вид документа": "doc_type",
    "что проверить": "todo", "рекомендация": "todo",
    "уверенность": "confidence",
    # v43: ИИ называет строку по-разному.
    "состояние обращения": "state", "статус обращения": "state",
    "решение по обращению": "state", "итоговое состояние": "state",
    "основание решения": "basis", "правовое основание": "basis",
    "норма регламента": "basis", "статья": "basis",
    "вид постановления": "doc_type", "тип решения": "doc_type",
    # v49: реквизиты обращения определяет ИИ — он присылает их ключевыми
    # словами в том же служебном блоке. Локальные регулярки больше не
    # «угадывают» заявителя и нарушителя: пользователь может переставить
    # реквизиты местами, и порядок строк ломает любые фильтры.
    "заявитель": "applicant_name", "фио заявителя": "applicant_name",
    "заявитель фио": "applicant_name",
    "id заявителя": "applicant_id", "id-карта": "applicant_id",
    "id карта заявителя": "applicant_id", "номер id заявителя": "applicant_id",
    "паспорт заявителя": "applicant_id",
    "представитель заявителя": "applicant_representative",
    "нарушитель": "subject_name", "фио нарушителя": "subject_name",
    "в отношении": "subject_name",
    "id нарушителя": "subject_id", "удостоверение нарушителя": "subject_id",
    "опз нарушителя": "subject_id", "удостоверение": "subject_id",
    "организация нарушителя": "subject_department",
    "отдел нарушителя": "subject_department",
    "должность нарушителя": "subject_rank", "звание нарушителя": "subject_rank",
    "дата и время события": "event_date", "дата события": "event_date",
    "место события": "event_place",
    "предмет обращения": "appeal_subject",
    "дата обращения": "appeal_date",
    "номер обращения": "appeal_number",
    "нарушенный акт": "violation_act",
    "пункт нарушения": "violation_clause", "статьи нарушения": "violation_clause",
    "нормативное основание": "legal_basis",
}

_INTAKE_MARKERS = ("ПРОВЕРКАОБРАЩЕНИЯ", "ПРОВЕРКА ОБРАЩЕНИЯ")


def has_intake_block(text: str) -> bool:
    """В ответе ИИ есть служебный блок проверки обращения (v42, v43).

    v43: кроме самого блока признаём ответом проверку, где ИИ написал
    «Состояние: Отказать / Принято» без маркеров — иначе такое решение
    терялось и обращение оставалось «В процессе».
    """
    # v44.2: ответ ИИ приходит одним контейнером с цитатой заявки, поэтому в
    # тексте есть и «ПРОВЕРКА ОБРАЩЕНИЯ», и «ЗАЯВКА НА ПРОВЕРКУ ОБРАЩЕНИЯ».
    # Признаком ответа считаем м а р к е р проверки или её служебные строки —
    # примету заявки («ЗАЯВКА НА ПРОВЕРКУ ОБРАЩЕНИЯ») отбрасываем.
    compact = re.sub(r"[\s=*_\-—]+", "", str(text or "")).upper()
    compact = compact.replace("ЗАЯВКАНАПРОВЕРКУОБРАЩЕНИЯ", " ")
    if "ПРОВЕРКАОБРАЩЕНИЯ" in compact:
        return True
    plain = str(text or "").lower()
    return bool(re.search(
        r"состояни\w*\s*[:\-–—]\s*(принят|отказ|переадрес|прекращ)", plain))


def parse_intake_answer(answer_text: str) -> dict:
    """Разбирает ответ ИИ на «Проверку ИИ»: принято или отказано (v42, v43).

    Клиент не должен «угадывать» состояние обращения по свободному тексту,
    но и терять ответ из-за оформления нельзя: v43 понимает блок, написанный
    одной строкой, с «===», с «**», и состояние без маркеров
    («Состояние: Отказать»). Если состояния нет вовсе — `ok=False`, дело не
    меняется.
    """
    raw = str(answer_text or "")
    fields = _intake_fields(raw)
    state = normalize_intake_state(fields.get("state", ""))
    if not state:
        state = _intake_state_from_text(raw)
    result = {
        "state": state,
        "basis": fields.get("basis", ""),
        "doc_type": normalize_gov_doc_type(fields.get("doc_type", "")),
        "doc_type_raw": fields.get("doc_type", ""),
        "todo": fields.get("todo", ""),
        "confidence": fields.get("confidence", ""),
        # v49: реквизиты обращения, которые ИИ прислал ключевыми словами.
        "keywords": intake_keywords(fields),
        "raw": raw,
        "ok": bool(state),
    }
    return result


def intake_keywords(fields: dict) -> dict:
    """Реквизиты обращения из ключевых слов ответа ИИ (v49).

    Замечание пользователя: «все данные определяет ИИ — по „Проверке ИИ“ /
    „Сформировать“ ИИ отдаёт ключевые слова, парсим их из ответа и подставляем
    в программе; пользователь может менять реквизиты местами, что ломает
    фильтры». Поэтому источник реквизитов — только строки ответа ИИ вида
    «Заявитель: …», «ID заявителя: …», «В отношении: …», «Дата и время
    события: …». Пустые значения в результат не попадают.
    """
    result: dict = {}
    for key in INTAKE_KEYWORD_KEYS:
        value = _clean((fields or {}).get(key, ""))
        if not value:
            continue
        if key in ("event_place",) and is_placeholder(value):
            continue
        result[key] = value
    return result


#: Служебные обрывки чата и собственных заявок, которые ИИ копирует в
#: «УСТАНОВИЛ» (v63). Выгрузка `Постановление.7z`: ИИ начал раздел с нашей же
#: реплики «Проверь обращение. Текст обращения — во вложении „Обращение.txt“,
#: порядок проверки и формат ответа — в файле заявки…», затем пересказал наш
#: блок «ПРОВЕРКА ОБРАЩЕНИЯ» целиком. Печатать это в постановлении нельзя.
_INSTRUCTION_SENTENCE = re.compile(
    r"(?:^|(?<=[.!?\s]))("
    r"проверь\s+обращение"
    r"|текст\s+обращения\s+—\s+во\s+вложении"
    r"|порядок\s+проверки\s+и\s+формат\s+ответа"
    r"|ответь\s+(?:только\s+)?служебным\s+блоком"
    r"|служебным\s+блоком\s+проверки\s+обращения"
    r"|нажми\s+«?(?:этап|проверка)"
    r"|сформируй\s+постановление"
    r"|работай\s+только\s+с\s+(?:этими\s+файлами|текстом\s+заявки)"
    r"|исходные\s+данные\s+—\s+во\s+вложениях"
    r"|не\s+пересказывай\s+вложения"
    r"|не\s+описывай\s+(?:изображения\s+и\s+)?вложения"
    r"|ответ\s+в\s+режиме\s+ии"
    r"|вы\s+отправили\s+\d+\s+файл"
    r")(.*?)(?=[.!?](?:\s|$)|$)",
    re.IGNORECASE,
)

#: Строки служебного блока проверки, которые ИИ может пересказать в тексте:
#: «Состояние: Принято», «Что проверить: …», «Вид решения: …». Это не факты
#: дела, а служебные поля; в «УСТАНОВИЛ» им места нет (v63).
_SERVICE_BLOCK_LINE = re.compile(
    r"^(?:состояние|вид\s+решения|что\s+проверить|основание|"
    r"представитель\s+заявителя|удостоверение\s+нарушителя|"
    r"организация\s+нарушителя|id\s+заявителя|заявитель|нарушитель|"
    r"предмет\s+обращения|дата\s+обращения)\s*:",
    re.IGNORECASE,
)

#: Маркеры служебного блока проверки: от них и до них — не текст документа.
_INTAKE_BLOCK_START = re.compile(r"=*\s*ПРОВЕРКА\s+ОБРАЩЕНИЯ\s*=*", re.IGNORECASE)
_INTAKE_BLOCK_END = re.compile(r"=*\s*КОНЕЦ\s+ПРОВЕРКИ\s*=*", re.IGNORECASE)
_CHAINS_BLOCK_START = re.compile(r"=*\s*ЦЕПОЧКИ\s+ЭТАПА\s*2\s*=*", re.IGNORECASE)
_CHAINS_BLOCK_END = re.compile(r"=*\s*КОНЕЦ\s+ЦЕПОЧЕК\s*=*", re.IGNORECASE)
_PLAN_BLOCK_START = re.compile(r"=*\s*ПЛАН\s+ЭТАПА\s*2\s*=*", re.IGNORECASE)
_PLAN_BLOCK_END = re.compile(r"=*\s*КОНЕЦ\s+ПЛАНА\s*=*", re.IGNORECASE)
#: v64: блок «РЕКОМЕНДАЦИИ … КОНЕЦ РЕКОМЕНДАЦИЙ» требует промт (1.34, п.8.1.3),
#: а клиент его не вырезал — в выгрузке `этап-1 — принятие.7z` рекомендации
#: целиком уехали в «УСТАНОВИЛ» печатаемого постановления.
_RECO_BLOCK_START = re.compile(r"=*\s*РЕКОМЕНДАЦИИ\s*=*", re.IGNORECASE)
_RECO_BLOCK_END = re.compile(r"=*\s*КОНЕЦ\s+РЕКОМЕНДАЦИЙ\s*=*", re.IGNORECASE)


def strip_service_blocks(text: str) -> str:
    """Вырезает из ответа ИИ блоки, которые не являются текстом документа (v63).

    В одном ответе этапа 1 приходят сразу три вещи:

    * служебный блок «ПРОВЕРКА ОБРАЩЕНИЯ … КОНЕЦ ПРОВЕРКИ»;
    * блок вариантов цепочки «ЦЕПОЧКИ ЭТАПА 2 … КОНЕЦ ЦЕПОЧЕК»;
    * старый одиночный план «ПЛАН ЭТАПА 2 … КОНЕЦ ПЛАНА».

    Раньше они оставались в тексте и попадали в «УСТАНОВИЛ» печатаемого
    постановления: в выгрузке `Постановление.7z` раздел «УСТАНОВИЛ» оказался
    пересказом нашей же заявки и всех цепочек. Клиент строит из этих блоков
    цепочку этапов и решение этапа 1 — печатать их в бланке нельзя.
    """
    result = str(text or "")
    if not result.strip():
        return result
    for start_rx, end_rx in ((_INTAKE_BLOCK_START, _INTAKE_BLOCK_END),
                            (_CHAINS_BLOCK_START, _CHAINS_BLOCK_END),
                            (_PLAN_BLOCK_START, _PLAN_BLOCK_END),
                            (_RECO_BLOCK_START, _RECO_BLOCK_END)):
        result = _cut_block(result, start_rx, end_rx)
    return result


def _cut_block(text: str, start_rx, end_rx) -> str:
    """Убирает один блок от маркера до маркера (без маркеров).

    v64: границы блока соединяются ПЕРЕВОДОМ СТРОКИ, а не пробелом. Раньше
    склейка пробелом ставила в одну строку чип вложения и следующий за блоком
    текст — «File РЕКОМЕНДАЦИИ» — и строковые фильтры мусора (`is_chat_junk`,
    `is_ui_noise`) такую строку уже не распознавала: она уезжала в «УСТАНОВИЛ»
    постановления (выгрузка `этап-1 — принятие.7z`).
    """
    result = text
    while True:
        start = start_rx.search(result)
        if start is None:
            return result
        tail = result[start.end():]
        end = end_rx.search(tail)
        cut_to = start.end() + (end.end() if end else len(tail))
        result = (result[:start.start()] + "\n" + result[cut_to:]).strip()
        if not result:
            return ""


def strip_instruction_sentences(text: str) -> str:
    """Убирает из текста документа предложения-инструкции чата (v63).

    ИИ копирует в «УСТАНОВИЛ» нашу реплику из чата: «Проверь обращение…»,
    «Текст обращения — во вложении…», «Порядок проверки и формат ответа — в
    файле заявки». Это не факты дела. Режем по предложениям, а не по строкам:
    ИИ склеивает их в один абзац с настоящими фактами.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    cleaned = _INSTRUCTION_SENTENCE.sub(" ", raw)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,;:])", r"\1", cleaned)
    return cleaned.strip()


def drop_service_lines(text: str) -> str:
    """Убирает строки служебных полей («Состояние: …», «Что проверить: …»)."""
    kept = [line for line in str(text or "").splitlines()
            if not _SERVICE_BLOCK_LINE.match(line.strip())]
    return "\n".join(kept).strip()


def clean_established(text: str) -> str:
    """Готовит раздел «УСТАНОВИЛ» к печати: только факты и правовая оценка.

    Порядок важен: сначала вырезаются служебные блоки целиком (они могут
    содержать точки и «предложения»), затем — отдельные предложения-инструкции
    и строки служебных полей, затем обрезка оборванного хвоста (v54).
    """
    raw = str(text or "")
    if not raw.strip():
        return ""
    cleaned = strip_service_blocks(raw)
    cleaned = strip_instruction_sentences(cleaned)
    cleaned = drop_service_lines(cleaned)
    cleaned = strip_markdown(cleaned)
    # v65: вводная часть ИИ («Я, Прокурор …, установил, что …») в бланке
    # дублировала бы вводную часть клиента — оставляем только факты.
    cleaned = strip_ai_preamble(cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,;:])", r"\1", cleaned)
    cleaned = _drop_unfinished_tail(cleaned)
    return cleaned.strip()


# --------------------------------------------------------------------------- #
#  v64: чистый ответ ИИ из текста страницы чата
# --------------------------------------------------------------------------- #

#: Якоря, с которых начинается НАСТОЯЩИЙ ответ ИИ. Всё, что на странице чата
#: стоит раньше, — это эхо нашей заявки, чипы вложений и элементы интерфейса
#: (выгрузка `этап-1 — принятие.7z`: в поле «Ответ ИИ (только чтение)» лежала
#: вся страница, включая «Вы отправили 4 файлов…» и «Memphis.pdf / PDF»).
#: Все якоря ПРИВЯЗАНЫ К СТРОКЕ: непривязанный «ПРОВЕРКА ОБРАЩЕНИЯ» ловился
#: внутри имени вложения «Проверка обращения (заявка).txt», и голова ответа
#: обрезалась по чипу файла, а не по началу блока ИИ.
_ANCHOR_LINE = re.compile(
    r"^\s*=*\s*(?:"
    r"ПРОВЕРКА\s+ОБРАЩЕНИЯ"
    r"|ЦЕПОЧКИ\s+ЭТАПА\s*2"
    r"|ПЛАН\s+ЭТАПА\s*2"
    r"|РЕКОМЕНДАЦИИ"
    r"|ПОСТАНОВЛЕНИЕ\s*(?:№.*)?"
    r"|УСТАНОВИЛ\s*:*"
    r"|(?:Состояние|Вид\s+документа|Вид\s+решения)\s*:.*"
    r")\s*=*\s*$",
    re.IGNORECASE | re.MULTILINE,
)
_ANSWER_ANCHORS: tuple = (_ANCHOR_LINE,)

#: Маркер конца ответа: всё, что после него, — уже не текст ИИ.
_ANSWER_END = re.compile(r"=*\s*КОНЕЦ\s+ОТВЕТА\s*=*", re.IGNORECASE)

#: v65: страница чата хранит ВСЕ ответы диалога. Выгрузка «Обращение №1.7z»
#: (`AG-1/ИИ-ответ.txt`): в файле лежали ДВА ответа — проверка обращения
#: (строки 13–52) и постановление (строки 72–101), — а `extract_ai_answer`
#: обрезал голову по ПЕРВОМУ якорю, то есть по проверке обращения.
#: `parse_gov_answer` на ней возвращал None, и окно писало «В ответе ИИ нет
#: полей постановления», хотя постановление в файле было. Ответы отделяются
#: эхом нашей заявки и заголовком ответа ИИ — по ним страница режется на
#: участки, и берётся участок с ответом на ПОСЛЕДНЮЮ заявку.
_REQUEST_ECHO_LINE = re.compile(
    r"^ *(?:"
    r"Ответ\s+в\s+режиме\s+ИИ\b"
    r"|Вы\s+отправили\s+\d+\s+файл\w*\s+и\s+сделали\s+запрос"
    r"|Чат\s+в\s+режиме\s+ИИ\s*:"
    r")",
    re.IGNORECASE | re.MULTILINE,
)

#: Якоря ответов — ОБА ПРИВЯЗАНЫ К СТРОКЕ ЦЕЛИКОМ. Непривязанный якорь
#: ловил имя нашего вложения «Проверка обращения (заявка).txt» в эхе заявки:
#: участок с чипами файлов получал высшую оценку, и `extract_ai_answer`
#: возвращал пустоту вместо ответа (найдено на выгрузке «Обращение №1.7z»).
_INTAKE_ANCHOR = re.compile(r"^ *=* *ПРОВЕРКА\s+ОБРАЩЕНИЯ\s*=*\s*$",
                            re.IGNORECASE | re.MULTILINE)
_DOCUMENT_ANCHOR = re.compile(r"^ *=* *ПОСТАНОВЛЕНИЕ\s*(?:№.*)? *=*\s*$",
                              re.IGNORECASE | re.MULTILINE)

#: Предупреждение сайта под ответом («ИИ может ошибаться…») — не текст ИИ.
_PAGE_DISCLAIMER = re.compile(r"^ИИ\s+может\s+ошибаться", re.IGNORECASE)

#: Короткие строки, которые нельзя считать мусором: «1.», «б)» — списки ИИ.
_MEANINGFUL_SHORT = re.compile(r"^(?:\d{1,2}[.)]|[а-яa-z][.)])$", re.IGNORECASE)


def _norm_line(value) -> str:
    return " ".join(str(value or "").split()).strip().lower()


def _request_echo(request: str) -> set:
    """Строки нашей заявки: их ИИ цитирует обратно, в ответе им места нет."""
    return {_norm_line(line) for line in str(request or "").splitlines()
            if len(_norm_line(line)) > 20}


def _is_request_echo_line(stripped: str, echo: set) -> bool:
    """Строка дословно из нашей заявки и НЕ является полем документа (v65).

    Выгрузка «Обращение №1.7z»: заявка несёт память дела, включая блок
    проверки обращения с полями «Заявитель: Lorenzo Shroud», «Дата обращения:
    25.11.2026», «Предмет обращения: …». ИИ повторяет эти поля в постановлении
    — это его ответ, а не эхо заявки. Раньше фильтр выбрасывал их по
    совпадению с текстом заявки, и в бланке пропадали заявитель, предмет и
    дата обращения: вводная часть печатала дату ПОСТАНОВЛЕНИЯ вместо даты
    обращения («рассмотрев обращение … от 27.11.2026»).
    """
    if _norm_line(stripped) not in echo:
        return False
    if ":" in stripped:
        key = _normalize_gov_key(stripped.split(":", 1)[0])
        if key:
            return False        # поле документа — оставляем, это ответ ИИ
    return True


def _is_page_junk(line: str) -> bool:
    """Строка — элемент страницы чата, а не текст ответа ИИ (v64)."""
    text = str(line or "").strip()
    if not text:
        return False
    if _MEANINGFUL_SHORT.match(text):
        return False
    # v65: «ИИ может ошибаться. Проверяйте его ответы.» — подпись сайта под
    # ответом, в выгрузке «Обращение №1.7z» она шла сразу за постановлением.
    if _PAGE_DISCLAIMER.match(text):
        return True
    if base.is_chat_instruction(text):
        return True
    if is_chat_junk(text):
        return True
    # Наша собственная реплика из поля запроса («Проверь обращение. Текст
    # обращения — во вложении…») — ИИ цитирует её обратно вместе с ответом.
    if _INSTRUCTION_SENTENCE.search(text):
        return True
    return bool(base.is_ui_noise(text))


def _answer_regions(raw: str) -> list:
    """Участки страницы между эхами заявок и заголовками ответов (v65)."""
    bounds = [match.end() for match in _REQUEST_ECHO_LINE.finditer(raw)]
    if not bounds:
        return [raw]
    starts = [0] + bounds
    ends = bounds + [len(raw)]
    return [raw[start:end] for start, end in zip(starts, ends)
            if raw[start:end].strip()]


def _region_score(chunk: str, want: str) -> int:
    """Насколько участок похож на нужный ответ: 2 — он, 1 — ответ, 0 — эхо."""
    if want == "document":
        if _DOCUMENT_ANCHOR.search(chunk) and base.has_document_trigger(chunk):
            return 2
    elif want == "intake":
        if _INTAKE_ANCHOR.search(chunk):
            return 2
    return 1 if _ANCHOR_LINE.search(chunk) else 0


def _pick_answer_region(raw: str, want: str = "") -> str:
    """Участок страницы с ответом на ПОСЛЕДНЮЮ заявку (v65).

    Чат между шагами не очищался, поэтому на странице лежат все ответы
    подряд: брать первый — значит разбирать прошлый шаг вместо текущего.
    """
    regions = _answer_regions(raw)
    if len(regions) < 2:
        return raw
    best = 0
    picked = ""
    for chunk in regions:
        score = _region_score(chunk, want)
        # `>=`: при равной оценке побеждает ПОСЛЕДНИЙ участок.
        if score and score >= best:
            best, picked = score, chunk
    return picked or raw


def extract_ai_answer(text: str, request: str = "", want: str = "") -> str:
    """Ответ ИИ без мусора страницы чата (v64).

    Замечание пользователя по выгрузке `этап-1 — принятие.7z`: в поле
    «Ответ ИИ (только чтение)» — «каша», всё вперемешку. Так и было: в узел
    цепочки писался ВЕСЬ текст страницы (`main.py` → `set_work_node("1",
    answer=str(text))`), а страница отдаёт ответ вместе с цитатой нашей
    заявки, чипами вложений («Memphis.pdf / PDF», «Шаблон.txt / File») и
    элементами интерфейса («Перейти к предыдущему запросу», рваные
    «Mem / phis.pdf»).

    Порядок простой и проверяемый:

    1. выбираем участок страницы с ответом на ПОСЛЕДНЮЮ заявку (`want`:
       "document" — постановление, "intake" — проверка обращения, пусто —
       любой ответ): v65, иначе на странице с историей разбирается прошлый шаг;
    2. обрезаем голову до первого якоря ответа (блок проверки, цепочки,
       рекомендации, «ПОСТАНОВЛЕНИЕ», «УСТАНОВИЛ», «Состояние:»);
    3. обрезаем хвост после «КОНЕЦ ОТВЕТА»;
    4. построчно убираем мусор страницы и строки, дословно взятые из нашей
       заявки (ИИ их цитирует);
    5. схлопываем пустые строки.

    Сырой текст страницы при этом не теряется: он остаётся в файле
    «ИИ-ответ.txt» в папке дела — для разбора спорных ситуаций.
    """
    raw = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    if not raw.strip():
        return ""
    raw = _pick_answer_region(raw, str(want or ""))
    start = None
    for rx in _ANSWER_ANCHORS:
        match = rx.search(raw)
        if match and (start is None or match.start() < start):
            start = match.start()
    body = raw[start:] if start is not None else raw
    end = _ANSWER_END.search(body)
    if end is not None:
        body = body[:end.end()]
    echo = _request_echo(request)
    kept: list = []
    for line in body.splitlines():
        stripped = line.strip()
        if not stripped:
            kept.append("")
            continue
        if _is_page_junk(stripped):
            continue
        if _is_request_echo_line(stripped, echo):
            continue
        kept.append(line.rstrip())
    cleaned = re.sub(r"\n{3,}", "\n\n", "\n".join(kept))
    return cleaned.strip()


def _intake_body(answer_text: str) -> str:
    """Тело служебного блока (или весь текст, если маркеров нет) — v43.

    ИИ иногда пишет блок одной строкой, иногда с «===» в начале и в конце
    одной строки, иногда с пробелами (`=== ПРОВЕРКА ОБРАЩЕНИЯ ===`). Поэтому
    маркеры не разбираем по строкам, а вырезаем регулярным выражением.
    """
    raw = str(answer_text or "")
    start = re.search(r"=*\s*ПРОВЕРКА\s+ОБРАЩЕНИЯ\s*=*", raw, re.IGNORECASE)
    if start is None:
        return raw
    tail = raw[start.end():]
    end = re.search(r"=*\s*КОНЕЦ\s+ПРОВЕРКИ\s*=*", tail, re.IGNORECASE)
    if end is not None:
        tail = tail[:end.start()]
    return tail


def _intake_fields(answer_text: str) -> dict:
    """Поля блока «ПРОВЕРКА ОБРАЩЕНИЯ»: ключ → значение (v43)."""
    body = _intake_body(answer_text)
    fields: dict = {}
    for raw_line in body.splitlines():
        line = strip_markdown(raw_line.strip()).strip("*").strip()
        if not line:
            continue
        # В одной строке может оказаться несколько пар «ключ: значение».
        for chunk in re.split(r"\s*[;|]\s*(?=[А-ЯЁA-Za-z][^:]{0,30}:)", line):
            if ":" not in chunk:
                continue
            key, value = chunk.split(":", 1)
            key = re.sub(r"^[\d.)\-\s]+", "", key).strip().lower()
            key = re.sub(r"[*`_]", "", key).strip()
            target = _INTAKE_KEY_ALIASES.get(key)
            value = strip_markdown(value).strip().strip("*").strip()
            if target and value and target not in fields:
                fields[target] = value
    return fields


def _intake_state_from_text(answer_text: str) -> str:
    """Состояние из свободного текста, если ключа не было (v43).

    Смотрим строки «Состояние …» / «Решение …» в любом месте ответа, затем —
    явные формулировки в начале строки, затем первые 400 символов.
    """
    text = str(answer_text or "")
    for pattern in (
            r"состояни\w*\s*[:\-–—]\s*([^\n;|]{2,60})",
            r"решение\s+по\s+обращени\w*\s*[:\-–—]\s*([^\n;|]{2,60})",
            r"итог\w*\s*[:\-–—]\s*([^\n;|]{2,60})"):
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            state = normalize_intake_state(match.group(1))
            if state:
                return state
    for line in text.splitlines():
        state = normalize_intake_state(strip_markdown(line))
        if state and not _is_state_menu(line):
            return state
    head = strip_markdown(text)[:400]
    state = normalize_intake_state(head)
    return "" if _is_state_menu(head) else state


#: Перечисление вариантов решения — это описание формата, а не решение ИИ
#: (v44). Пример строки из заявки: «В служебной строке состояния укажи ровно
#: одно слово-решение: Принято, Отказано, Переадресовано или Прекращено».
_MENU_MARKERS = ("или", "либо", " / ", "укажи", "укажите", "выбери",
                 "выберите", "вариант", "слово-решение", "одно из",
                 # описание полей формата: «(для отказа обязательно; для
                 # принятия — что именно проверено)»
                 "(для ", "обязательно;", "что именно проверено",
                 # v60: заявка перечисляет ПЯТЬ исходов и «плюс» блоки плана
                 # этапа 2. Слова «если плана нет (отказ, переадресация…)» и
                 # «(5 этап)» сами по себе ничего не решают — без этих
                 # маркеров собственная заявка снова читалась как ответ.
                 "если ", "этап ", "шагов", "или ", "либо ")


def _is_state_menu(line: str) -> bool:
    """Строка перечисляет ВАРИАНТЫ решения, а не выносит одно (v44).

    Без этой проверки клиент принимал свою же заявку за ответ ИИ: в заявке
    перечислены все состояния, и разбор брал первое упоминание «Отказано».
    """
    text = str(line or "").lower()
    if not text.strip():
        return False
    return any(marker in text for marker in _MENU_MARKERS)


def normalize_intake_state(value: str) -> str:
    """Приводит состояние обращения к «Принято» / «Отказано» / … (v42, v43).

    v43: ИИ отвечает не только «Отказано», но и «Отказать», «отказ»,
    «в принятии отказать», «не подлежит принятию», «принимается» — все такие
    формулировки должны давать одно состояние, иначе программа не видит
    решение и дело остаётся «В процессе».
    """
    text = _clean(value).lower().strip(" .:;,!")
    text = re.sub(r"[*`«»\"]", "", text).strip()
    if not text:
        return ""
    # Отказ в принятии — раньше остальных проверок: «в принятии отказать»
    # содержит и «принят», и «отказ».
    if re.search(r"в\s+принятии\s+(обращения\s+)?отказ", text):
        return INTAKE_REFUSED
    if re.search(r"отказ\w*\s+в\s+приняти", text):
        return INTAKE_REFUSED
    if re.search(r"не\s+(подлежит\s+принят|принимает|принят)", text):
        return INTAKE_REFUSED
    if re.match(r"^(отказ|отказан|отказать|отказыва)", text):
        return INTAKE_REFUSED
    if re.search(r"\bотказ\w*\b", text) and not re.search(r"отказ\w*\s+в\s+удовлетвор", text):
        return INTAKE_REFUSED
    # v60: пятый исход — «оставить без движения на 24 часа». Проверяется
    # раньше отказа: «устранить недостатки» — не отказ, а шанс исправить.
    if re.search(r"недостат|без\s+движения|устрани", text):
        return INTAKE_DEFECTS
    if re.search(r"переадрес", text):
        return INTAKE_REDIRECTED
    if re.search(r"прекращ|прекрати", text):
        return INTAKE_TERMINATED
    if re.match(r"^(принят|принима|принять|принято)", text):
        return INTAKE_ACCEPTED
    if re.search(r"принят\w*\s+(к|в)\s+(собственн\w+\s+)?производств", text):
        return INTAKE_ACCEPTED
    if re.search(r"\bпринято\b", text) and not re.search(r"не\s+принято", text):
        return INTAKE_ACCEPTED
    return ""


def parse_gov_answer(answer_text: str, base_doc: PostanovlenieProkurora | None = None, base=None):
    """Достаёт постановление Прокурора из ответа ИИ.

    Понимает тот же формат, что и IAD: строки «Ключ: значение», нумерованные
    пункты, заголовки «УСТАНОВИЛ»/«ПОСТАНОВИЛ». Возвращает None, если ответ
    не похож на документ.
    """
    base_doc = base_doc or base
    text = str(answer_text or "")
    if not text.strip():
        return None
    if is_own_request(text):
        diag_event("gov.answer_is_own_request")
        return None
    block = extract_document_block(text)
    if block.strip():
        text = block
    # v54: «[cite: 2]», хвост чата после «===КОНЕЦ ОТВЕТА===» и реплики ИИ
    # «Я могу продолжить работу по этому делу…» — не текст постановления.
    # Чистим ДО разбора: иначе они уезжают в «УСТАНОВИЛ» и в пункты резолюции.
    text = clean_document_text(text)
    # v63: в ответе этапа 1 приходят ещё три служебных блока — решение по
    # обращению, варианты цепочки и старый план. В бланк они попадать не
    # должны: в выгрузке `Постановление.7z` «УСТАНОВИЛ» оказался их
    # пересказом вместе с нашей собственной репликой из чата.
    text = strip_service_blocks(text)

    doc = PostanovlenieProkurora.from_dict((base_doc or PostanovlenieProkurora()).to_dict())
    doc.source = "ai"
    doc.created_at = time.time()

    saw_marker = False
    saw_content = False
    points: list = []
    free_lines: list = []
    facts_lines: list = []
    in_facts = False
    in_points = False

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or is_ui_noise(line) or is_section_heading(line):
            continue
        if is_chat_junk(line) or is_gov_echo(line):
            continue
        compact = re.sub(r"[\s=*/\-_]+", "", line.upper())
        if "ПОСТАНОВЛЕНИЕ" in compact and compact.startswith("ПОСТАНОВЛЕНИЕ"):
            # v45.1: строка «Постановление вынес: Jonathan Raine» — это ПОЛЕ,
            # а не заголовок документа. Клиент принимал её за маркер и терял
            # автора: проверка писала «не указано, кто вынес постановление».
            raw_key = line.split(":", 1)[0]
            if ":" in line and _normalize_gov_key(raw_key):
                marker_row = False
            else:
                saw_marker = True
                continue
        if "КОНЕЦПОСТАНОВЛЕНИЯ" in compact or "КОНЕЦОТВЕТА" in compact:
            continue
        plain = strip_markdown(line)
        heading = plain.lower().strip(" .:")
        # v45.1: ИИ пишет заголовки с опечатками («УСТАВНОРИЛ» вместо
        # «УСТАНОВИЛ»). Из-за этого весь раздел фактов не попадал в документ.
        heading = _normalize_heading(heading)
        if heading.startswith(("установил", "у с т а н о в и л")):
            in_facts, in_points = True, False
            rest = re.sub(r"^[^:]*:\s*", "", plain).strip()
            if rest and rest.lower() != heading:
                facts_lines.append(rest)
                saw_content = True
            continue
        if heading.startswith(("постановил", "постановляющая", "резолютивная")):
            in_facts, in_points = False, True
            rest = re.sub(r"^[^:]*:\s*", "", plain).strip()
            if rest and rest.lower() != heading:
                for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", rest):
                    body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                    if body:
                        points.append(body)
                        saw_content = True
            continue

        if ":" in line:
            raw_key, raw_value = line.split(":", 1)
            key = _normalize_gov_key(raw_key)
            value = strip_markdown(raw_value)
            if key and value:
                doc.set(key, value)
                if key not in ("doc_number", "doc_date"):
                    saw_content = True
                continue

        numbered = _NUMBERED.match(line)
        if numbered:
            body = strip_markdown(numbered.group(2))
            if body:
                if in_facts and not in_points:
                    facts_lines.append(body)
                else:
                    points.append(body)
                saw_content = True
                continue
        bullet = _BULLET.match(line)
        if bullet and strip_markdown(bullet.group(1)):
            (facts_lines if in_facts and not in_points else points).append(
                strip_markdown(bullet.group(1)))
            saw_content = True
            continue
        # v46: в резолюции ИИ перечисляет решения БЕЗ номеров, каждое с новой
        # строки («Отказать …», «Прекратить …», «Разъяснить …»). Раньше все они
        # склеивались в ОДИН пункт постановления.
        if in_points and not in_facts and _looks_like_point(plain):
            points.append(plain)
            saw_content = True
            continue
        if plain:
            if in_points:
                # v45.1: ИИ переносит пункт на следующую строку. Без склейки
                # «1. Отказать гражданину …» и его продолжение «на основании
                # пункта 14 …» становились ДВУМЯ пунктами постановления.
                numbered_line = bool(_NUMBERED.match(line))
                # Подпись прокурора (должность, ФИО, удостоверение) — не
                # продолжение последнего пункта: она уходит в реквизиты.
                # v65: склейка — только для НЕЗАКОНЧЕННОГО пункта. Если
                # предыдущий пункт закрыт точкой, а строка похожа на новое
                # решение, это ОТДЕЛЬНЫЙ пункт (выгрузка «Обращение №1.7z»).
                brand_new = (points and not numbered_line
                             and _point_is_complete(points[-1])
                             and _starts_new_point(plain))
                if brand_new:
                    points.append(plain)
                    saw_content = True
                elif points and not numbered_line and not is_signature_line(plain):
                    points[-1] = (points[-1] + " " + plain).strip()
                else:
                    for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", plain):
                        body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                        if body:
                            points.append(body)
                            saw_content = True
            elif in_facts:
                facts_lines.append(plain)
                saw_content = True
            else:
                free_lines.append(plain)
                saw_content = True

    if points:
        clean_points = [p for p in strip_signature_points(points)
                        if not _is_basis_echo(p, doc)]
        doc.points = [fix_gov_typos(p) for p in clean_points]
    if facts_lines:
        # Раздел «УСТАНОВИЛ» — это выводы прокурора, а не «Обстоятельства»:
        # раньше он приклеивался к обстоятельствам и печатался дважды.
        # v63: вычищаем из него реплики чата и служебные поля («Проверь
        # обращение…», «Текст обращения — во вложении…», «Состояние: …»).
        established = clean_established(
            " ".join(f.strip() for f in facts_lines if f.strip()))
        doc.established = fix_gov_typos(established)
    if free_lines:
        joined = "\n".join(free_lines).strip()
        if not doc.get("situation"):
            doc.situation = joined
        elif joined and joined not in doc.get("situation"):
            doc.situation = (doc.get("situation") + "\n" + joined).strip()

    # v37: заявителя и нарушителя в форме больше нет — их достаём из текста
    # ответа. «…обращение гражданина Mark Skywalker от 27.10.2026…»,
    # «…сотрудника Los Santos County Sheriff Department Kyria Suspectzx с
    # номером опознавательного знака 8332…».
    if not doc.get("applicant_name"):
        found = re.search(r"обращени\w+\s+(?:гражданина|гражданки|заявителя)\s+"
                          r"([А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Z][а-яёa-z]+)?)",
                          text)
        if found:
            doc.set("applicant_name", found.group(1))
    if not doc.get("subject_name"):
        found = re.search(r"(?:сотрудник\w*|в\s+отношении)\s+(?:[^,.]{0,80}?)\s?"
                          r"([А-ЯЁA-Z][а-яёa-z]+\s+[А-ЯЁA-Z][а-яёa-z]+)\s*"
                          r"(?:с\s+номером\s+опознавательного|,|\.)",
                          text)
        if found:
            doc.set("subject_name", found.group(1))
    if not doc.get("subject_id"):
        found = re.search(r"опознавательн\w+\s+знак\w*\s*(?:№\s*)?(\d{3,10})", text)
        if found:
            doc.set("subject_id", found.group(1))

    # v37: ответ ИИ не содержит поля «Постановление вынес …» — имя прокурора
    # есть только в преамбуле «Я, Прокурор штата Сан-Андреас Jonathan Raine,
    # удостоверение № 198632». Без этого проверка считала, что автор не указан.
    if not doc.get("author_name"):
        found = re.search(
            r"Я,\s*(?:заместитель\s+)?(?:генерального\s+)?прокурор\w*[^,]{0,40}?"
            r"\s([А-ЯЁA-Z][а-яёa-z]+(?:\s+[А-ЯЁA-Z][а-яёa-z]+){1,2})\s*,",
            text, re.IGNORECASE)
        if found:
            doc.author_name = found.group(1).strip()
    if not doc.get("author_id"):
        found_id = re.search(r"удостоверен\w*\s*№\s*(\d{3,10})", text, re.IGNORECASE)
        if found_id:
            doc.author_id = found_id.group(1)

    drop_placeholders(doc)
    if not saw_marker and not (doc.get("applicant_name") or doc.points):
        return None
    if not saw_content:
        diag_event("gov.answer_without_content", chars=len(text))
        return None
    if not doc.get("doc_date"):
        doc.doc_date = today_ru()
    # v39: вид решения — всегда один из GOV_DOC_TYPES. ИИ отвечает свободной
    # формулировкой («Постановление об отказе в рассмотрении обращения»), а
    # заголовок бланка и проверки ждут каноническое название.
    stage = normalize_stage(doc.get("doc_stage"))
    if not stage and base_doc is not None:
        stage = normalize_stage(base_doc.get("doc_stage"))
    if not stage and base_doc is not None:
        stage = gov_stage(base_doc.get("doc_type"))
    normalized = normalize_gov_doc_type(doc.get("doc_type"), stage)
    auto = (base_doc is not None and is_auto_type(base_doc.get("doc_type")))
    if auto and (not normalized or gov_stage(normalized) != stage):
        # В форме выбрано «Определит ИИ …» (этап 1 — по обращению, этап 2 — по
        # обстоятельствам). Если ИИ прислал вид решения ЧУЖОГО этапа (на этапе
        # санкции — «О принятии обращения к производству»), доверяем
        # обстоятельствам и резолюции, а не полю.
        normalized = suggest_doc_type(doc)
    if normalized:
        doc.doc_type = normalized
    elif not doc.get("doc_type"):
        doc.doc_type = stage_types(stage)[0]
    # Этап: выбор пользователя в форме неприкосновенен. Если он не задан —
    # выводим из вида решения. Когда ИИ «съехал» на другой этап (на итоговом
    # этапе прислал «О принятии обращения к производству»), этап НЕ
    # переписываем — расхождение поймает check_gov_document и покажет
    # пользователю, что санкции в ответе нет.
    doc.doc_stage = stage or gov_stage(doc.get("doc_type"))
    return doc


# --------------------------------------------------------------------------- #
#  Проверка по праву
# --------------------------------------------------------------------------- #

def _law_text(name_fragment: str, data_dir: Path | str | None = None) -> str:
    """Читает текст акта из законодательной базы (data/reestr/*.json)."""
    folder = Path(data_dir or Path(__file__).resolve().parent / "data") / "reestr"
    if not folder.is_dir():
        return ""
    for path in sorted(folder.glob("*.json")):
        if name_fragment.lower() in path.name.lower():
            try:
                import json
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                return ""
            chunks = [str(p.get("text") or "") for p in data.get("posts") or []]
            chunks += [str(s.get("text") or "") for s in data.get("sections") or []]
            return "\n".join(chunks)
    return ""


#: Основания отказа по Регламенту (ст. 16, ч. 1) — для проверки «отказных».
GOV_REFUSAL_GROUNDS: tuple[tuple[str, str], ...] = (
    ("заявител", "невозможно установить личность заявителя"),
    ("предмет", "отсутствует предмет обращения"),
    ("описан", "отсутствует описание события правонарушения"),
    ("подпис", "отсутствует подпись заявителя"),
    ("форме", "обращение составлено не по установленной форме"),
    ("электронной почт", "не указаны электронная почта / телефон заявителя"),
)


def _parse_ru_date(value: str):
    """Дата «25.11.2026» → datetime.date (None — если не разобрать)."""
    text = str(value or "").strip()
    match = re.search(r"(\d{1,2})\s*[.\-/]\s*(\d{1,2})\s*[.\-/]\s*(\d{4})", text)
    if not match:
        return None
    day, month, year = (int(part) for part in match.groups())
    try:
        return datetime.date(year, month, day)
    except ValueError:
        return None


def check_gov_dates(doc_date: str, appeal_date: str) -> str:
    """Замечание, если постановление датировано раньше обращения (v63).

    Выгрузка `Постановление.7z`: документ этапа 1 — «16.11.2026», обращение —
    «25.11.2026». ИИ подставил дату из примеров промта, и в бланке получилось
    решение, вынесенное за девять дней до обращения. Пустая дата замечанием не
    считается: её подставляет клиент.
    """
    made = _parse_ru_date(doc_date)
    appeal = _parse_ru_date(appeal_date)
    if not made or not appeal or made >= appeal:
        return ""
    return ("Дата постановления (" + str(doc_date).strip() +
            ") раньше даты обращения (" + str(appeal_date).strip() +
            "): решение не может быть вынесено до поступления обращения. "
            "Возьмите дату из обращения или дату вынесения решения.")


def check_gov_document(doc: PostanovlenieProkurora) -> list:
    """Замечания по постановлению Прокурора. Пустой список = всё в порядке."""
    issues: list = []

    # 1. Внеигровая лексика (промт 1.19 п. 19) — та же проверка, что у IAD.
    issues.extend(base.check_ooc(doc))

    # 2. Сроки из Регламента: первичное рассмотрение 24 ч, по существу 72 ч.
    text = " ".join(doc.decision_points()).lower()
    for match in re.finditer(r"(\d+)\s*(час|ч\.|часов|сут)", text):
        hours = int(match.group(1))
        if "сут" in match.group(2):
            hours *= 24
        if hours > 72:
            issues.append(
                f"В постановлении указан срок {hours} ч, а Регламент (ст. 12) "
                "допускает не более 24 часов на принятие к рассмотрению и не "
                "более 72 часов на рассмотрение по существу.")

    # 3. Отказ без основания (ст. 16 Регламента). Вид — без заглушки
    #    «Определит ИИ …»: иначе проверки не видят, что это отказ (v41).
    low_type = doc.title().lower()
    if "отказ" in low_type:
        # основание отказа может быть указано и в самой резолюции («Основание
        # отказа: пункт 1 статьи 16 Регламента»), поэтому её тоже учитываем
        basis = (doc.get("legal_basis") + " " + doc.get("violation_clause") + " "
                 + doc.facts_text() + " " + " ".join(doc.decision_points())).lower()
        if not any(word in basis for word, _reason in GOV_REFUSAL_GROUNDS) \
                and "регламент" not in basis:
            issues.append(
                "Постановление об отказе должно содержать конкретное основание "
                "из статьи 16 Регламента подачи обращений (нет описания события, "
                "невозможно установить заявителя, обращение не по форме и т. п.).")

    # 4. Обжалование: 72 часа (ст. 27–28 Регламента). Статья 27 требует
    # указывать порядок обжалования для отказа, переадресации и прекращения.
    appeal_needed = any(word in low_type for word in ("отказ", "переадрес", "прекращ"))
    if appeal_needed and not re.search(r"обжалов",
                                       " ".join(doc.decision_points()).lower()):
        issues.append(
            "В резолютивной части нет порядка обжалования. По статьям 27–28 "
            "Регламента решение обжалуется вышестоящему прокурору или в суд в "
            "срок, не превышающий 72 часа.")

    # 5. Полномочия: постановление подписывает прокурор.
    if not doc.get("author_name"):
        issues.append("Не указано, кто вынес постановление (Прокурор).")

    # 6. Реквизиты обращения: без них постановление «по обращению» повисает.
    if not doc.get("applicant_name"):
        issues.append("Не указан заявитель — из постановления нельзя понять, "
                      "по чьему обращению оно вынесено.")
    if not doc.get("appeal_date") and not doc.get("doc_date"):
        issues.append("Не указана дата обращения — нарушается вводная часть.")

    # 6.1. Дата документа раньше даты обращения (v63). В выгрузке
    #    `Постановление.7z` постановление датировалось 16.11.2026, а обращение —
    #    25.11.2026: ИИ подставил дату из примеров промта. Решение не может быть
    #    вынесено раньше самого обращения.
    issue = check_gov_dates(doc.get("doc_date"), doc.get("appeal_date"))
    if issue:
        issues.append(issue)

    # 7. Ссылка на материалы, которых в обращении нет (v37).
    #    В выгрузке AG-2 «УСТАНОВИЛ» утверждал: «Изложенные факты и
    #    прикрепленные к кадровым и юридическим договорам сведения
    #    достаточны…», хотя таких документов в деле не было.
    facts_low = doc.facts_text().lower()
    sources_low = " ".join([doc.get("evidence"), doc.get("situation"),
                            doc.get("extra")]).lower()
    invented = [phrase for phrase in (
        "кадровым и юридическим договорам", "кадровым договорам",
        "юридическим договорам", "прикрепленные к договорам",
        "материалами дела подтверждается", "согласно материалам дела")
        if phrase in facts_low and not any(
            word in sources_low for word in ("договор", "материал", "доказательств"))]
    if invented:
        issues.append(
            "В «УСТАНОВИЛ» есть ссылка на документы, которых нет в обращении ("
            + "; ".join(invented) + "). Опишите только те факты и материалы, "
            "которые заявитель действительно приложил.")

    # 8. Обжалование без ссылки на норму (ст. 27–28 Регламента).
    resolution = " ".join(doc.decision_points()).lower()
    has_norm = ("регламент" in resolution or "регламента" in resolution
                or "статьи 27" in resolution or "статьями 27" in resolution
                or "ст. 27" in resolution or "статей 27" in resolution)
    if "обжалов" in resolution and not has_norm:
        issues.append(
            "Порядок обжалования указан без правовой нормы. По статьям 27–28 "
            "Регламента подачи обращений решение обжалуется вышестоящему "
            "прокурору или в суд в срок, не превышающий 72 часа, — сошлитесь "
            "на эти статьи.")

    # 9. Обращение без описания ситуации (v37). В выгрузке AG-2 пункт 5
    #    «Подробное описание ситуации» был пуст, и ИИ дописал факты от себя
    #    («прикрепленные к кадровым и юридическим договорам сведения»).
    situation = doc.get("situation")
    if looks_like_appeal_form(situation):
        description = parse_appeal_text(situation).get("description", "")
        if not description or description.lower().startswith("настоящим заверяю"):
            issues.append(
                "В обращении не заполнен пункт «Подробное описание ситуации» — "
                "постановление опирается на факты, которых в обращении нет. "
                "Попросите заявителя описать событие или укажите это как "
                "основание для запроса дополнительных материалов.")

    # 9.1. v39: этап и вид решения должны быть согласованы. Если выбран
    #      итоговый этап, а в резолюции «принять обращение к производству» —
    #      документ противоречит сам себе.
    resolution_all = " ".join(doc.decision_points()).lower()
    sanction_marks = ("признать", "привлечь", "назначить", "возбудить", "передать", "передаче",
                      "применить меры", "в удовлетворении", "отказать в удовлетворении",
                      "завершить проверку", "внести представление")
    if doc.is_final() and not any(mark in resolution_all for mark in sanction_marks):
        issues.append(
            "Вид решения — итоговое (этап 2), а резолюция только принимает "
            "обращение к рассмотрению. Итоговое постановление должно содержать "
            "санкцию по статье 23 Регламента: привлечение к ответственности, "
            "возбуждение уголовного дела, передача материалов в суд, меры "
            "прокурорского реагирования или отказ в удовлетворении обращения.")
    if not doc.is_final() and re.search(r"возбудить\s+уголовн|назначить\s+(наказание|"
                                        r"административн|штраф)", resolution_all):
        issues.append(
            "Вид решения — первичный (этап 1: принятие, отказ, переадресация, "
            "прекращение), но в резолюции назначается санкция. На этапе "
            "первичного рассмотрения санкция не назначается — она выносится "
            "отдельным постановлением по существу (статья 23 Регламента).")

    # 9.2. v39: санкция без нормы ответственности. «Признать виновным» и
    #      «назначить штраф» без статьи — это резолюция без права.
    if doc.is_final() and doc.get("doc_type") in (
            "О привлечении к административной ответственности",
            "О возбуждении уголовного дела по обращению"):
        qualification = " ".join((
            doc.get("violation_clause"), doc.get("violation_act"),
            doc.get("legal_basis"), doc.get("penalty"))).lower()
        if not re.search(r"(стат|пункт|част|ст\.)", qualification):
            issues.append(
                "Итоговое постановление о привлечении к ответственности не "
                "содержит нормы, устанавливающей ответственность (статья "
                "кодекса / пункт устава). Без неё санкция не имеет правового "
                "основания.")

    # 10. Заглушки вместо правовой оценки (v37).
    if is_placeholder(doc.get("violation_clause")) and doc.get("violation_clause"):
        issues.append(
            "Нарушенная норма указана заглушкой («по обстоятельствам, указанным "
            "в заявке»). Нужен конкретный пункт устава или статья закона — "
            "иначе правовая оценка в постановлении отсутствует.")

    return issues


# --------------------------------------------------------------------------- #
#  Ассеты бланка прокуратуры
# --------------------------------------------------------------------------- #

def gov_assets(base_dir: Path | str | None = None):
    """Герб/печать/шрифты для бланка прокуратуры.

    Отличается от IAD только картинками: `data/gerb_gov.png` (герб Офиса
    Генерального прокурора) и `data/stamp_gov.png` (печать DEPARTMENT OF
    JUSTICE). Если их нет — используются штатные, чтобы бланк не остался пустым.
    """
    import doc_render as render

    root = Path(base_dir) if base_dir else Path(__file__).resolve().parent
    assets = render.DocAssets(root)
    for folder in [root / "data", root] + list(render._resource_dirs()):
        coat = folder / "gerb_gov.png"
        stamp = folder / "stamp_gov.png"
        if coat.is_file():
            assets.coat = coat
        if stamp.is_file():
            assets.stamp = stamp
        if coat.is_file() and stamp.is_file():
            break
    return assets
