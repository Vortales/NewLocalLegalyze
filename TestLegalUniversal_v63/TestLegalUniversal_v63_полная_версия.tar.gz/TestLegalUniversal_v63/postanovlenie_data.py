"""postanovlenie_data.py — данные постановления и разбор ответа ИИ (v27).

Задача новой версии: пользователь заполняет форму, программа формирует
структурированный .txt, прикрепляет его в чат, ИИ отвечает строго в рамках
постановления и помечает ответ триггером. Этот модуль отвечает за три вещи:

1. Модель данных постановления (`Postanovlenie`) — единый словарь полей,
   который понимают и форма, и .txt, и рендер в PNG.
2. Сериализация в .txt «как документ» и обратно (для истории и правок).
3. Разбор ответа ИИ по триггерам: `===ПОСТАНОВЛЕНИЕ===`, `===КОНЕЦ ОТВЕТА===`,
   поля `Ключ: значение`, нумерованные пункты постановляющей части.

Модуль намеренно не зависит от PyQt: его можно проверять автотестами и
переиспользовать в консольных инструментах.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

# --------------------------------------------------------------------------- #
#  Триггеры. Их имена — часть контракта с промтом (см. ПРОМТ_ПОСТАНОВЛЕНИЯ.md)
# --------------------------------------------------------------------------- #

TRIGGER_DOC_START = "===ПОСТАНОВЛЕНИЕ==="
TRIGGER_DOC_END = "===КОНЕЦ ПОСТАНОВЛЕНИЯ==="
TRIGGER_ANSWER_END = "===КОНЕЦ ОТВЕТА==="
#: Имя вложенного файла, по которому промт понимает «это заявка на постановление».
DOC_MARKER_NAME = "ПОСТАНОВЛЕНИЕ"
DOC_MARKER_SUFFIX = ".txt"

#: Поля шаблона (Шаблон.txt) — используются для автозаполнения формы.
TEMPLATE_FIELDS = ("Name", "ID", "Fraction", "Rang", "Department", "JobTitle")

#: Единый список полей постановления: (ключ, подпись в форме, подпись в .txt).
DOC_FIELDS: tuple[tuple[str, str, str], ...] = (
    ("vedomstvo", "Ведомство", "Ведомство"),
    ("podrazdelenie", "Подразделение", "Подразделение"),
    ("doc_type", "Вид документа", "Вид документа"),
    ("doc_title", "Заголовок документа", "Заголовок"),
    ("doc_number", "Номер документа", "Номер"),
    ("doc_date", "Дата документа", "Дата"),
    ("author_name", "Кто выносит (И. Фамилия)", "Постановление вынес"),
    ("author_rank", "Звание / должность", "Должность"),
    ("subject_name", "Кому (И. Фамилия)", "В отношении"),
    ("subject_id", "Удостоверение №", "Удостоверение"),
    ("subject_rank", "Звание сотрудника", "Звание сотрудника"),
    ("subject_department", "Отдел сотрудника", "Отдел сотрудника"),
    ("violation_act", "Нарушенный акт", "Нарушенный акт"),
    ("violation_clause", "Пункт / статья / часть", "Пункт нарушения"),
    # v33: нормативное основание шире одного устава — процессуальные нормы,
    # УК, иные акты «в части касающейся».
    ("legal_basis", "Нормативное основание", "Нормативное основание"),
    ("penalty", "Взыскание", "Взыскание"),
    ("situation", "Обстоятельства", "Обстоятельства"),
    # v33 (замечание): строки «Доказательства» в бланке больше нет.
    ("extra", "Дополнительно", "Дополнительно"),
)

FIELD_LABELS = {key: label for key, _form, label in DOC_FIELDS}
FORM_LABELS = {key: form for key, form, _label in DOC_FIELDS}

#: Виды постановлений, которые форма умеет собирать уже сейчас.
#: Универсальность на будущее: сюда добавляются жалобы/иски/обращения.
DOC_TYPES = (
    "Постановление о выдаче дисциплинарного взыскания",
    "Постановление о снятии дисциплинарного взыскания",
    "Постановление о проведении внутренней проверки",
    "Постановление об отстранении от службы",
)

#: Взыскания по Уставу LSCSD, гл. IV, п. 4.1 (см. data/reestr).
PENALTIES = (
    "предупреждение",
    "устный выговор",
    "строгий выговор",
    "переаттестация",
    "понижение",
    "увольнение",
)

#: Родительный падеж для формулировки «в виде …» (документ пишется по-русски,
#: поэтому «в виде строгого выговора», а не «в виде строгий выговор»).
PENALTY_GENITIVE = {
    "предупреждение": "предупреждения",
    "устный выговор": "устного выговора",
    "строгий выговор": "строгого выговора",
    "переаттестация": "переаттестации",
    "понижение": "понижения",
    "увольнение": "увольнения",
}

#: Начала формулировок нарушения, которые в постановлении идут в родительном
#: падеже: «в связи с нарушением пункта 19) части 1 статьи «а»».
_CLAUSE_GENITIVE = (
    ("пункт ", "пункта "),
    ("часть ", "части "),
    ("статья ", "статьи "),
    ("статьи ", "статьи "),
    ("подпункт ", "подпункта "),
    ("раздел ", "раздела "),
)


def penalty_instrumental(penalty: str) -> str:
    """«строгий выговор» -> «строгого выговора» (для фразы «в виде …»).

    Возвращает "" для пустых значений и для «заглушек» вида «дисциплинарное
    взыскание»: в документе нельзя писать «взыскание в виде дисциплинарного
    взыскания» — нужен конкретный вид из перечня п. 4.1 Устава LSCSD.
    """
    text = _clean(penalty).lower().strip(" .")
    if not text:
        return ""
    if text in PENALTY_GENITIVE:
        return PENALTY_GENITIVE[text]
    for nominative, genitive in PENALTY_GENITIVE.items():
        if text.startswith(nominative):
            return genitive + text[len(nominative):]
    # «дисциплинарное взыскание», «взыскание», «наказание» — не вид взыскания
    if "взыскани" in text or "наказани" in text:
        return ""
    return _clean(penalty)


#: v33: ориентиры тяжести (Устав LSCSD, гл. III–IV). Нужны, чтобы взыскание
#: не сводилось к «строгому выговору» там, где проступок легче или тяжелее.
#: Ключ — вид взыскания, значение — слова-признаки проступка.
PENALTY_HINTS = (
    ("предупреждение",
     ("опоздал", "опоздание", "незначительн", "впервые", "мелк", "небрежн",
      "незначительный", "устное замечание", "формальн")),
    ("устный выговор",
     ("нарушил форму одежды", "дресс-код", "дресс код", "не выполнил приказ",
      "пререкани", "грубость", "халатн")),
    ("строгий выговор",
     ("систематическ", "повторн", "грубое нарушение", "оскорбл", "неуважени",
      "субординац", "отказ выполнять приказ")),
    ("переаттестация",
     ("несоответств", "квалификац", "профпригодн", "не сдал", "аттестац")),
    ("понижение",
     ("превышение полномочий", "халатность", "сокрытие", "фальсификац",
      "злоупотребл")),
    ("увольнение",
     ("тяжк", "особо тяжк", "преступлен", "коррупц", "взятк", "применение силы",
      "незаконное задержание", "угроз")),
)


def suggest_penalty(situation: str) -> str:
    """Подсказывает вид взыскания по описанию проступка (v33).

    Пользователь просил не ограничиваться выговорами: если обстоятельства
    описывают тяжёлый проступок — ориентир на увольнение/понижение, если
    незначительный — предупреждение. Это лишь ОРИЕНТИР для ИИ и для формы:
    окончательное решение всё равно за ИИ (он видит устав), а пользователь
    может выбрать любое взыскание из перечня п. 4.1.
    """
    text = _clean(situation).lower()
    if not text:
        return ""
    best, best_score = "", 0
    for penalty, markers in PENALTY_HINTS:
        score = sum(1 for marker in markers if marker in text)
        if score > best_score:
            best, best_score = penalty, score
    return best


#: Слова, которыми в уставе обозначены виды взысканий (для разбора перечня
#: «[ Строгий выговор / Понижение / Увольнение ]»).
_PENALTY_CANON = (
    ("строгий выговор", "строгий выговор"),
    ("устный выговор", "устный выговор"),
    ("переаттестац", "переаттестация"),
    ("предупрежд", "предупреждение"),
    ("понижен", "понижение"),
    ("увольнен", "увольнение"),
)


def parse_allowed_penalties(text: str) -> list:
    """Перечень допустимых взысканий из пункта устава: «… [ A / B / C ]».

    Устав LSCSD у каждого пункта главы VIII прямо указывает вилку наказаний,
    например «8.1 … [ Строгий выговор / Понижение / Увольнение ]». Именно по
    этой вилке и нужно проверять применимость взыскания (замечание анализа).
    """
    raw = str(text or "")
    if "[" not in raw or "]" not in raw:
        return []
    inside = raw[raw.index("[") + 1: raw.rindex("]")].lower()
    allowed = []
    for marker, canon in _PENALTY_CANON:
        if marker in inside and canon not in allowed:
            allowed.append(canon)
    return allowed


def _clause_numbers(clause: str) -> list:
    """Номера пунктов устава из строки: «пункты 8.1 и 8.24» -> [8.1, 8.24]."""
    return re.findall(r"\b(\d{1,2}\.\d{1,2})\b", str(clause or ""))


def allowed_penalties_for(clause: str, regulation) -> list:
    """Какие взыскания допускает устав за указанные пункты (пересечение)."""
    if regulation is None:
        return []
    numbers = _clause_numbers(clause)
    if not numbers:
        return []
    allowed_per_clause = []
    for number in numbers:
        for text in getattr(regulation, "articles", {}).values():
            if str(text).strip().startswith(number):
                allowed = parse_allowed_penalties(text)
                if allowed:
                    allowed_per_clause.append(set(allowed))
                break
    if not allowed_per_clause:
        return []
    common = set.intersection(*allowed_per_clause)
    # Порядок — как в уставе (п. 4.1): от мягкого к строгому.
    return [name for name in ("предупреждение", "устный выговор", "строгий выговор",
                              "переаттестация", "понижение", "увольнение")
            if name in common]


def normalize_penalty(penalty: str) -> str:
    """Приводит взыскание к виду из перечня п. 4.1 Устава LSCSD.

    Понимает падежи и вольные формулировки: «строгого выговора» -> «строгий
    выговор», «устный» -> «устный выговор». Неизвестное значение не
    выдумывает — возвращает пустую строку, и тогда пункт строится без него.
    """
    text = _clean(penalty).lower().strip(" .")
    if not text or "взыскани" in text or "наказани" in text:
        return ""
    for nominative, genitive in PENALTY_GENITIVE.items():
        if text in (nominative, genitive) or text.startswith(nominative):
            return nominative
    if text.startswith("строг"):
        return "строгий выговор"
    if text.startswith("устн"):
        return "устный выговор"
    if text.startswith("выговор"):
        return "строгий выговор"
    if text.startswith("уволь"):
        return "увольнение"
    if text.startswith("пониж"):
        return "понижение"
    if text.startswith("переаттест"):
        return "переаттестация"
    if text.startswith("предупрежд"):
        return "предупреждение"
    return ""


def clean_position(rank: str) -> str:
    """Оставляет только должность внутри фракции.

    Замечание: «Куратор отдела IAD (Assistent sheriff), Сенатор» — в документе
    должна быть только должность во фракции, без внешних статусов (Сенатор,
    Губернатор, Адвокат и т. п.).
    """
    text = _clean(rank)
    if not text:
        return ""
    # Отрезаем «, Сенатор», «; Губернатор» и т. п. после запятой, если это
    # не часть названия должности в скобках.
    depth = 0
    cut = len(text)
    for index, char in enumerate(text):
        if char == "(":
            depth += 1
        elif char == ")":
            depth = max(0, depth - 1)
        elif char in ",;" and depth == 0:
            cut = index
            break
    head = text[:cut].strip()
    if not head:
        return text
    return head


def normalize_clause(clause: str, act: str = "") -> str:
    """Убирает дублирование слова «устав», когда акт назван отдельно.

    Пользователь может написать в пункте «пункт 3.1 устава», а в акте —
    «Внутреннего устава Los Santos County Sheriff Department». В документе
    это давало «…нарушением пункта 3.1 устава Внутреннего устава …».
    """
    text = _clean(clause)
    if not text:
        return ""
    if "устав" in _clean(act).lower():
        text = re.sub(r"\s*,?\s*устава?\s*$", "", text, flags=re.IGNORECASE)
    return text.strip(" ,")


_VAGUE_CLAUSE = re.compile(
    r"^(по обстоятельствам|согласно обстоятельствам|по уставу|по заявке|"
    r"по указанным обстоятельствам|не указан|не установлен)",
    re.IGNORECASE,
)


#: Прилагательные перед названием акта: «Уголовный кодекс» -> «Уголовного кодекса».
_ADJ_GENITIVE = (
    ("ый ", "ого "), ("ий ", "его "), ("ой ", "ого "), ("ый", "ого"),
)


def act_genitive(act: str) -> str:
    """«Устав Los Santos» -> «Устава Los Santos» (после «нарушением …»)."""
    text = _clean(act)
    if not text:
        return ""
    low = text.lower()
    for nominative, genitive in (("устав ", "Устава "), ("кодекс ", "Кодекса "),
                                 ("закон ", "Закона "), ("регламент ", "Регламента ")):
        if low.startswith(nominative):
            return genitive + text[len(nominative):]
    # v38: ИИ присылает «Уголовный кодекс штата Сан-Андреас» — после
    # «образуют нарушение …» нужен родительный падеж («Уголовного кодекса»).
    words = text.split()
    if len(words) > 1:
        for index, word in enumerate(words[:-1]):
            if word.lower() in ("кодекс", "устав", "закон", "регламент"):
                head = words[index].lower()
                genitive = {"кодекс": "кодекса", "устав": "устава",
                            "закон": "закона", "регламент": "регламента"}[head]
                if words[index][:1].isupper():
                    genitive = genitive[:1].upper() + genitive[1:]
                before = words[:index]
                if before:
                    adjective = before[-1]
                    for nominative, ending in _ADJ_GENITIVE:
                        if adjective.lower().endswith(nominative):
                            before[-1] = adjective[:-len(nominative)] + ending
                            break
                words[index] = genitive
                return " ".join(before + words[index:])
    return text


def shorten_clause(clause: str) -> str:
    """«Пункт 8.5 Устава LSCSD — нарушение дресс-кода» -> «пункт 8.5».

    В выгрузке v37 ИИ прислал пункт вместе с расшифровкой и сокращением
    устава («Устава LSCSD»), а рядом печаталось полное название акта —
    получалось «… своего отдела Устава Los Santos County Sheriff Department».
    Пояснение сохраняем в скобках, название акта оставляем отдельному полю.
    """
    text = _clean(clause)
    if not text:
        return ""
    # «пункт 19) части 1 статьи а» — это не «пункт 19.», а ссылка на статью:
    # такие формулировки оставляем как есть.
    if re.search(r"\d\s*\)", text) or "части" in text.lower() or "стать" in text.lower():
        return text
    found = re.match(r"(?:пункт[аы]?\s*|ст\.?\s*|стать[яи]\s*)?(\d+(?:\.\d+)+)",
                     text, re.IGNORECASE)
    if not found:
        return text
    tail = text[found.end():].lstrip(" )—-,")
    # Расшифровку оставляем, только если она поясняет суть пункта, а не
    # повторяет название устава или акта.
    tail = re.sub(r"^(устава?|закона?|кодекса?)\b[^-—]*", "", tail,
                  flags=re.IGNORECASE).strip(" —-,")
    if len(tail) < 4 or re.fullmatch(r"(устава?|закона?|кодекса?)", tail, re.IGNORECASE):
        return f"пункт {found.group(1)}"
    return f"пункт {found.group(1)} ({tail.strip(' .')})"


def is_vague_clause(clause: str) -> bool:
    """Пункт/статья — заглушка вида «по обстоятельствам, указанным в заявке»."""
    return bool(_VAGUE_CLAUSE.match(_clean(clause)))


#: Разделители перечисления норм в поле «Пункт нарушения».
_CLAUSE_SPLIT = re.compile(r"\s*;\s*|,\s*(?=(?:часть|част[аи]|статья|статьи|"
                           r"пункт|пункта|ст\.|ч\.|п\.)\s)", re.IGNORECASE)


def clause_genitive(clause: str) -> str:
    """«пункт 19) части 1 статьи а» -> «пункта 19) части 1 статьи а»."""
    text = _clean(clause)
    # v38: ИИ перечисляет нормы через запятую — «части 2 статьи 12.8, часть 2
    # статьи 15.1». Падеж нужен КАЖДОЙ части, иначе в документе остаётся
    # «образуют нарушение: части 2 статьи 12.8, часть 2 статьи 15.1».
    pieces = [piece for piece in _CLAUSE_SPLIT.split(text) if piece.strip()]
    if len(pieces) > 1:
        return ", ".join(clause_genitive(piece) for piece in pieces)
    low = text.lower()
    for nominative, genitive in _CLAUSE_GENITIVE:
        if low.startswith(nominative):
            return genitive + text[len(nominative):]
    # v37: ИИ прислал «нарушением 8.5 Устав …» — без слова «пункт» фраза
    # читается как ошибка. Голый номер устава получает нужный падеж.
    if re.match(r"^\d+(\.\d+)+", text):
        return f"пункта {text}"
    return text

#: Поля, которые разрешено оставлять пустыми: их подбирает ИИ по обстоятельствам
#: (замечание v27: «вся информация будет браться из Обстоятельств»).
OPTIONAL_GUESSED_FIELDS = (
    "violation_act", "violation_clause", "legal_basis", "penalty",
    "subject_rank", "subject_department", "extra",
)

#: Ведомство по умолчанию — то, для которого в папке лежат герб и печать.
DEFAULT_VEDOMSTVO = "LOS SANTOS COUNTY SHERIFF'S DEPARTMENT"
DEFAULT_PODRAZDELENIE = "INTERNAL AFFAIRS DIVISION"
DEFAULT_STATE = "STATE OF SAN ANDREAS"


#: Номер удостоверения внутри ФИО: «#131485», «№ 131485», а также отдельное
#: число из 4+ цифр в конце («Marcus Nomad 85028»). Двузначные ранги и т. п.
#: не трогаем, чтобы не испортить имя.
_ID_IN_NAME = re.compile(r"(?:#|№)?\s*\b\d{4,}\b")


def split_subject(name: str, ident: str) -> tuple:
    """Разделяет «ФИО» и «удостоверение», если ИИ перепутал их местами.

    Реальный случай: в поле «В отношении» пришло «Aliya», а в «Удостоверение»
    — «Nomad». В документе это давало «сотруднику Aliya с номером удостоверения
    #Nomad». Правило: номер удостоверения — только цифры; всё буквенное,
    попавшее в это поле, — часть фамилии.
    """
    name = _clean(name)
    ident = _clean(ident).lstrip("#").strip()
    letters_in_id = re.findall(r"[^\d#\s][^#]*", ident)
    if letters_in_id and not re.search(r"\d{3,}", ident):
        tail = " ".join(part.strip() for part in letters_in_id if part.strip())
        if tail and tail.lower() not in name.lower():
            name = f"{name} {tail}".strip()
        ident = ""
    elif ident and not re.fullmatch(r"\d+", ident):
        # «№123456», «уд. 123456» и прочее — оставляем только цифры
        digits = re.sub(r"\D", "", ident)
        ident = digits
    found = _ID_IN_NAME.search(name)
    if found and not ident:
        ident = re.sub(r"\D", "", found.group(0))
    name = _ID_IN_NAME.sub("", name).strip(" ,;-")
    return name, ident


def initials_signature(full_name: str) -> str:
    """«Kirill Goldens» -> «K. Goldens» (подпись как в примерах IAD)."""
    parts = [p for p in str(full_name or "").replace(".", " ").split() if p]
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0][:1].upper() + parts[0][1:]
    surname = parts[-1]
    return f"{parts[0][0].upper()}. {surname[:1].upper() + surname[1:]}"


def today_ru() -> str:
    return datetime.now().strftime("%d.%m.%Y")


#: Значения-заглушки, которые ИИ пишет вместо данных.
_PLACEHOLDERS = {
    "не указано", "не указан", "не указана", "не указаны", "нет данных",
    "неизвестно", "n/a", "нет", "-", "—", "отсутствует", "не установлено",
}


def _clean(value) -> str:
    text = str(value if value is not None else "").strip()
    if text.lower().strip(" .") in _PLACEHOLDERS:
        return ""
    return text


@dataclass
class Postanovlenie:
    """Одно постановление: поля формы + служебная история."""

    #: v56: печатать ли в PNG строку «Основание: …». Сами нормы остаются в
    #: полях документа и в «ИИ-документ.txt»; в бланк их больше не выводят
    #: (замечание п.2 по выгрузке «Постановление»).
    PNG_SHOW_BASIS = False

    vedomstvo: str = DEFAULT_VEDOMSTVO
    podrazdelenie: str = DEFAULT_PODRAZDELENIE
    doc_type: str = DOC_TYPES[0]
    doc_title: str = ""
    doc_number: str = ""
    doc_date: str = field(default_factory=today_ru)
    author_name: str = ""
    author_rank: str = ""
    subject_name: str = ""
    subject_id: str = ""
    subject_rank: str = ""
    subject_department: str = ""
    violation_act: str = ""
    violation_clause: str = ""
    legal_basis: str = ""       # v33: УК / процессуальный кодекс / иные акты
    penalty: str = ""
    situation: str = ""
    #: v56: что в «Обстоятельства» записал сам ИИ после «Сформировать».
    #: Блок обстоятельств — вход для ИИ (пользователь: «всё, что я пишу в
    #: Обстоятельства сам и исправляю, попасть не должно»), поэтому при
    #: повторной отправке в чат уходит только правка человека, а не текст ИИ
    #: повторно.
    ai_facts: dict = field(default_factory=dict)
    #: Оставлено для чтения старых файлов; в бланк не печатается (v33).
    evidence: str = ""
    extra: str = ""
    #: Пункты постановляющей части. Если пусто — собираются автоматически.
    points: list = field(default_factory=list)
    #: Служебное: откуда взято (форма / ответ ИИ), когда создано.
    created_at: float = field(default_factory=time.time)
    source: str = "form"

    def __post_init__(self) -> None:
        """Единые правила применяются сразу при создании, а не «где-то потом».

        Иначе объект, собранный из формы/истории/ответа ИИ напрямую через
        конструктор, обходил бы чистку ФИО, должности и взыскания — именно так
        в v28 в документ попадали «Aliya» / «#Nomad», «Сенатор» и «взыскание в
        виде дисциплинарного взыскания».
        """
        self.subject_name, self.subject_id = split_subject(self.subject_name, self.subject_id)
        self.author_rank = clean_position(self.author_rank)
        cleaned_penalty = normalize_penalty(self.penalty)
        if cleaned_penalty:
            self.penalty = cleaned_penalty
        elif _clean(self.penalty).lower().strip(" .") in ("взыскание", "дисциплинарное взыскание",
                                                          "наказание"):
            self.penalty = ""
        self.doc_type = _clean(self.doc_type) or DOC_TYPES[0]

    # ------------------------------------------------------------------ утиль

    def get(self, key: str, default: str = "") -> str:
        value = _clean(getattr(self, key, default))
        if key == "author_rank":
            return clean_position(value)
        if key == "penalty":
            return normalize_penalty(value)
        return value

    def set(self, key: str, value) -> None:
        if not hasattr(self, key):
            return
        if key in ("subject_name", "subject_id"):
            # Правило одно на весь документ: ФИО — буквы, удостоверение — цифры.
            other = self.subject_id if key == "subject_name" else self.subject_name
            name, ident = split_subject(
                value if key == "subject_name" else self.subject_name,
                value if key == "subject_id" else other,
            )
            self.subject_name, self.subject_id = name, ident
            return
        if key == "author_rank":
            value = clean_position(value)
        elif key == "penalty":
            value = normalize_penalty(value)
        setattr(self, key, value)

    def clean_copy(self) -> "Postanovlenie":
        """Копия с уже применёнными правилами ФИО/должности/взыскания."""
        clone = Postanovlenie.from_dict(self.to_dict())
        clone.subject_name, clone.subject_id = split_subject(self.subject_name, self.subject_id)
        clone.author_rank = clean_position(self.author_rank)
        clone.penalty = normalize_penalty(self.penalty) or self.penalty
        return clone

    def signature(self) -> str:
        """Подпись «И. Фамилия» из поля «кто выносит»."""
        return initials_signature(self.author_name)

    def title(self) -> str:
        return self.doc_title or self.doc_type

    def document_title(self) -> str:
        """Полный заголовок для бланка.

        ИИ часто присылает «Заголовок: о выдаче дисциплинарного взыскания»
        (без слова «Постановление»), и на бланке получалось просто
        «о выдаче дисциплинарного взыскания». Если вида документа нет в
        заголовке — подставляем его.
        """
        title = self.title().strip()
        doc_type = self.get("doc_type").strip()
        if not title:
            return doc_type
        low_title = title.lower()
        prefix = doc_type.split()[0] if doc_type else "Постановление"
        if prefix.lower() not in low_title:
            # «Снятие дисциплинарного взыскания» -> «Постановление о снятии…»
            head = title[:1].lower() + title[1:]
            if head.startswith(("о ", "об ")):
                return f"{prefix} {head}"
            # Падеж меняем у ПЕРВОГО слова: «Снятие …» -> «о снятии …»,
            # «Проведение …» -> «о проведении …», «Отстранение …» -> «об отстранении …».
            first, _, rest = head.partition(" ")
            for ending, replacement in (("ание", "ании"), ("ение", "ении"),
                                        ("тие", "тии"), ("ие", "ии")):
                if first.endswith(ending):
                    first = first[: -len(ending)] + replacement
                    break
            joiner = "об " if first[:1] in "аоэиуыеёюя" else "о "
            return f"{prefix} {joiner}{first}{(' ' + rest) if rest else ''}"
        if title[:1].islower():
            return title[:1].upper() + title[1:]
        return title

    def missing_fields(self) -> list:
        """Обязательные поля, без которых документ не имеет смысла."""
        # v28: нарушение/взыскание определяет ИИ («по желанию для уточнения»),
        # поэтому обязательными остались только реквизиты и предмет документа.
        required = (
            "doc_number", "doc_date", "author_name", "author_rank",
            "subject_name", "subject_id",
        )
        return [FORM_LABELS[k] for k in required if not self.get(k)]

    def auto_number(self, existing: list | None = None, prefix: str = "LSCSD-IAD") -> str:
        """Номер вида LSCSD-IAD-140: следующий после максимального в истории."""
        top = 0
        for item in existing or []:
            m = re.search(r"(\d+)\s*$", _clean(item))
            if m:
                top = max(top, int(m.group(1)))
        return f"{prefix}-{top + 1}"

    def kind(self) -> str:
        """Класс документа по заголовку: выдача / снятие / проверка / отстранение."""
        text = f"{self.get('doc_type')} {self.get('doc_title')}".lower()
        if "снят" in text:
            return "removal"
        if "проверк" in text:
            return "inspection"
        if "отстран" in text:
            return "suspension"
        return "penalty"

    def _violation_phrase(self) -> str:
        """«нарушением пункта 8.5 Устава …» без заглушек «по обстоятельствам»."""
        clause = self.get("violation_clause")
        act = self.get("violation_act")
        clean_clause = "" if is_vague_clause(clause) else clause
        if clean_clause and act:
            return f"{clause_genitive(clean_clause)} {act_genitive(act)}"
        if clean_clause:
            return clause_genitive(clean_clause)
        if act:
            return f"требований {act_genitive(act)}"
        return ""

    def decision_points(self) -> list:
        """Постановляющая часть. Если ИИ не дал пунктов — собираем по Уставу."""
        points = [p for p in (self.points or []) if _clean(p)]
        if points:
            fixed = [_clean(p) for p in points]
            return self._align_points(fixed)
        subject = self.get("subject_name") or "сотруднику"
        subject_id = self.get("subject_id")
        who = f"{subject} с номером удостоверения #{subject_id}" if subject_id else subject
        if self.kind() == "removal":
            # Снятие: и первый пункт, и весь документ говорят одно и то же.
            penalty_gen = penalty_instrumental(self.get("penalty"))
            done = (f"Снять с сотрудника {who} ранее наложенное дисциплинарное "
                    f"взыскание в виде {penalty_gen}."
                    if penalty_gen else
                    f"Снять с сотрудника {who} ранее наложенное дисциплинарное взыскание.")
            return [
                done,
                "Настоящее постановление вступает в силу с момента его подписания.",
                "Ответственность за доведение настоящего постановления до сотрудника, а также "
                "контроль за исполнением настоящего документа оставляю за собой.",
            ]
        reference = self._violation_phrase()
        because = f", в связи с нарушением {reference}" if reference else ""
        penalty = penalty_instrumental(self.get("penalty"))
        # Конкретный вид взыскания обязателен: «в виде дисциплинарного
        # взыскания» — это не наказание, а его отсутствие (замечание v28).
        measure = f"дисциплинарное взыскание в виде {penalty}" if penalty \
            else "дисциплинарное взыскание"
        result = [
            f"Назначить сотруднику {who} {measure}{because}.",
            "Настоящее постановление вступает в силу с момента его подписания и подлежит "
            "исполнению в течение 24 часов с момента назначения.",
            "Ответственность за доведение настоящего постановления до сотрудника, а также "
            "контроль за исполнением настоящего документа оставляю за собой.",
        ]
        return result

    def _align_points(self, points: list) -> list:
        """Согласует пункты с видом документа.

        Реальный случай из замечаний: документ называется «о снятии
        дисциплинарного взыскания», а первый пункт — «Назначить … взыскание».
        Правим только противоречие первого пункта, остальные не трогаем.
        """
        kind = self.kind()
        penalty = self.get("penalty")
        penalty_gen = penalty_instrumental(penalty)
        first = points[0]
        low = first.lower()
        if kind == "removal" and ("назначить" in low or "наложить" in low):
            subject = self.get("subject_name")
            who = f"{subject} с номером удостоверения #{self.get('subject_id')}" \
                if self.get("subject_id") else subject
            points[0] = (f"Снять с сотрудника {who} ранее наложенное дисциплинарное "
                         f"взыскание в виде {penalty_gen}." if penalty
                         else f"Снять с сотрудника {who} ранее наложенное "
                              "дисциплинарное взыскание.")
            return points
        if kind == "penalty" and "снять" in low and penalty_gen:
            points[0] = re.sub(r"в виде [^.]+", f"в виде {penalty_gen}", first)
        if kind == "inspection" and ("назначить" in low or "снять" in low):
            points[0] = ("Назначить проведение внутренней проверки по изложенным "
                         "обстоятельствам.")
        if kind == "suspension" and ("назначить" in low or "снять" in low):
            points[0] = "Отстранить сотрудника от исполнения служебных обязанностей до окончания проверки."
        return points

    def preamble(self) -> str:
        """Вводная часть — ровно как в примерах IAD."""
        dept = self.get("vedomstvo") or DEFAULT_VEDOMSTVO
        name = self.get("author_name")
        rank = self.get("author_rank")
        podr = self.get("podrazdelenie") or DEFAULT_PODRAZDELENIE
        who = f"{dept} {name}".strip()
        # Если должность уже содержит подразделение («Начальник отдела
        # внутренних расследований»), не повторяем «отдела INTERNAL AFFAIRS
        # DIVISION» — фраза становится бессмысленной.
        low_rank = rank.lower()
        if not rank:
            position = f"отдела {podr}"
        elif "отдел" in low_rank or "division" in low_rank or "дивизион" in low_rank:
            position = ""
        else:
            position = f"отдела {podr}"
        position = f", занимающий должность {rank} {position}".rstrip() if position \
            else f", занимающий должность {rank}"
        # v56 (замечание п.1 по выгрузке «Постановление»): в PNG выходило
        # «…настоящим кодексом постановил:» и сразу под ним по центру
        # «ПОСТАНОВИЛ:» — «постановил» печаталось дважды. Теперь вводная часть
        # заканчивается словами «настоящим кодексом,», а резолюцию открывает
        # единственный заголовок «ПОСТАНОВИЛ:».
        return (
            f"Я, сотрудник {who}{position}, "
            "в рамках своих полномочий, предоставленных мне внутренним уставом и иными "
            "нормативно-правовыми актами, настоящим кодексом,"
        )

    # ------------------------------------------------------- сериализация

    def to_dict(self) -> dict:
        data = asdict(self)
        data["points"] = list(self.points or [])
        return data

    @classmethod
    def from_dict(cls, data: dict | None) -> "Postanovlenie":
        data = data or {}
        allowed = {key for key, _f, _l in DOC_FIELDS} | {
            "points", "created_at", "source", "ai_facts",
        }
        kwargs = {k: v for k, v in data.items() if k in allowed}
        doc = cls(**kwargs)
        doc.points = [_clean(p) for p in (data.get("points") or []) if _clean(p)]
        # v56: память «что в обстоятельства записал ИИ» (старые файлы её не
        # имеют — тогда считается, что ИИ туда ничего не писал).
        stored = data.get("ai_facts")
        doc.ai_facts = ({str(k): str(v) for k, v in stored.items()}
                        if isinstance(stored, dict) else {})
        return doc

    #: .txt, который прикрепляется в чат: машиночитаемый блок + читаемый вид.
    def to_chat_txt(self) -> str:
        """Текст заявки, который уходит в чат.

        v30.3 (причина замечания «в PNG данные конструктора»): раньше заявка
        начиналась словом «ПОСТАНОВЛЕНИЕ» и заканчивалась «===КОНЕЦ ОТВЕТА===».
        Для клиента это выглядело как готовый ответ ИИ: он читал из чата СВОЁ
        же сообщение и печатал из него PNG. Теперь заявка — обычная просьба,
        без триггеров и без служебных пометок («сырые слова пользователя»,
        «определить по обстоятельствам»).
        """
        lines = ["ЗАЯВКА НА ПОСТАНОВЛЕНИЕ"]
        lines.append("Данные для подготовки документа:")
        # v56: обстоятельства — вход для ИИ. В заявку уходит только то, что
        # написал человек: текст, записанный сюда ИИ после прошлого
        # «Сформировать», повторно не отправляется.
        own_situation = self.own_situation()
        for key, _form, label in DOC_FIELDS:
            value = own_situation if key == "situation" else self.get(key)
            if key == "situation" and value:
                lines.append(f"{label}: {value}")
            elif value:
                lines.append(f"{label}: {value}")
            elif key in OPTIONAL_GUESSED_FIELDS:
                # v28: если пользователь не заполнил нарушение/взыскание/звание,
                # ИИ должен определить их сам по обстоятельствам (промт 1.12).
                lines.append(f"{label}: нет данных — определи сам")
        if self.get("penalty") or self.get("violation_clause"):
            # Подсказка для ИИ: он всё равно перепишет пункты официально.
            lines.append("")
            lines.append("Предлагаемые пункты (перепиши официально):")
            for i, point in enumerate(self.decision_points(), 1):
                lines.append(f"{i}. {point}")
        lines.append("")
        # v30.3: буквальных триггеров в заявке НЕТ намеренно — иначе заявку
        # можно принять за готовый ответ ИИ (именно это и происходило).
        lines.append("Подготовь постановление строго по этим данным, в формате "
                     "промта: один структурированный блок от начала документа до "
                     "конца ответа, без описания вложений.")
        return "\n".join(lines) + "\n"

    def basis_text(self) -> str:
        """«Основание: …» — все применимые нормы, а не только устав (v33).

        Замечание: в бланке был только Устав LSCSD. Теперь сюда попадают и
        нормы Уголовного кодекса, процессуального кодекса и других актов
        («в части касающейся»), если ИИ их указал в «Нормативном основании».
        """
        parts = []
        raw_clause = self.get("violation_clause")
        clause = ("" if is_vague_clause(raw_clause)
                  else normalize_clause(raw_clause, self.get("violation_act")))
        clause = shorten_clause(clause)
        if clause and self.get("violation_act"):
            parts.append(f"{clause} {act_genitive(self.get('violation_act'))}".strip())
        elif clause:
            parts.append(clause)
        elif self.get("violation_act"):
            parts.append(self.get("violation_act"))
        basis = _clean(self.get("legal_basis"))
        if basis and basis.lower() not in " ".join(parts).lower():
            parts.append(basis)
        # Убираем дубли, сохраняя порядок: устав мог быть назван дважды.
        unique = []
        for part in parts:
            part = part.strip(" ;,")
            if part and part.lower() not in [u.lower() for u in unique]:
                unique.append(part)
        return "; ".join(unique)

    # ----------------------------------------------- v56: обстоятельства

    def own_situation(self) -> str:
        """Только то, что в «Обстоятельства» написал человек (v56)."""
        current = _clean(self.get("situation"))
        written = _clean((self.ai_facts or {}).get("situation", ""))
        if not current:
            return ""
        if not written:
            return current
        if current == written:
            return ""
        rest = current.replace(written, " ").lstrip(" \n\t;,.—")
        return _clean(rest.rstrip())

    def remember_ai_facts(self, values: dict) -> None:
        """Запоминает текст, который в «Обстоятельства» записал ИИ (v56)."""
        self.ai_facts = {str(key): _clean(value)
                         for key, value in (values or {}).items() if _clean(value)}

    def clear_facts(self) -> None:
        """Очищает «Обстоятельства» и память о тексте ИИ (v56)."""
        self.situation = ""
        self.ai_facts = {}

    def to_document_txt(self) -> str:
        """Готовый бланк словами — ровно то, что печатается в PNG.

        Порядок блоков повторяет `doc_render.render_document()`: шапка,
        заголовок, вводная часть, ПОСТАНОВИЛ, основания. Нужен, чтобы можно
        было проверить документ до печати: `ИИ-документ.txt` == PNG.
        """
        lines = [
            (self.get("vedomstvo") or "LOS SANTOS COUNTY SHERIFF DEPARTMENT").upper(),
            (self.get("podrazdelenie") or "").upper(),
            "",
            self.document_title(),
            "",
        ]
        if self.get("doc_date"):
            lines.append(f"Дата: {self.get('doc_date')}")
        if self.get("doc_number"):
            lines.append(f"№ {self.get('doc_number')}")
        lines.append("")
        lines.append(self.preamble())
        lines.append("")
        lines.append("ПОСТАНОВИЛ:")
        lines.append("")
        for i, point in enumerate(self.decision_points(), 1):
            lines.append(f"{i}. {point}")
        lines.append("")
        facts = []
        basis = self.basis_text()
        if basis:
            facts.append("Основание: " + basis)
        if self.get("situation"):
            facts.append("Обстоятельства: " + self.get("situation"))
        if self.get("extra"):
            facts.append("Дополнительно: " + self.get("extra"))
        lines.extend(facts)
        lines.append("")
        if self.get("author_name"):
            lines.append(f"Подпись: {self.get('author_name')}")
            if self.get("author_rank"):
                lines.append(f"Должность: {self.get('author_rank')}")
        return "\n".join(lines).strip() + "\n"

    def chat_txt_name(self) -> str:
        num = self.get("doc_number") or "б-н"
        return f"{DOC_MARKER_NAME} {num}{DOC_MARKER_SUFFIX}"

    #: Снимок для истории: полный, чтобы можно было открыть и поправить.
    def history_payload(self) -> dict:
        data = self.to_dict()
        data["created_at"] = time.time()
        data["human_created"] = datetime.fromtimestamp(self.created_at).strftime(
            "%d.%m.%Y %H:%M"
        )
        return data


# --------------------------------------------------------------------------- #
#  Разбор ответа ИИ
# --------------------------------------------------------------------------- #

_ALIASES = {
    "номер": "doc_number",
    "№": "doc_number",
    "номер документа": "doc_number",
    "дата": "doc_date",
    "дата документа": "doc_date",
    "постановление вынес": "author_name",
    "вынес": "author_name",
    "должность": "author_rank",
    "звание": "author_rank",
    "в отношении": "subject_name",
    "сотрудник": "subject_name",
    "кому": "subject_name",
    "удостоверение": "subject_id",
    "удостоверение №": "subject_id",
    "id": "subject_id",
    "звание сотрудника": "subject_rank",
    "отдел сотрудника": "subject_department",
    "нарушенный акт": "violation_act",
    "акт": "violation_act",
    "пункт нарушения": "violation_clause",
    "пункт": "violation_clause",
    "статья": "violation_clause",
    "взыскание": "penalty",
    # v30: одно и то же поле в чате и в документе называется «Обстоятельства»,
    # но старые ответы ИИ («Ситуация») и вольные формулировки тоже понимаем.
    "обстоятельства": "situation",
    "обстоятельства дела": "situation",
    "ситуация": "situation",
    "ситуация / фабула": "situation",
    "фабула": "situation",
    "примечание": "extra",
    "примечания": "extra",
    # v33: нормативное основание — УК, процессуальный кодекс, иные акты.
    "нормативное основание": "legal_basis",
    "нормативное обоснование": "legal_basis",
    "правовое основание": "legal_basis",
    "правовое обоснование": "legal_basis",
    "основание": "legal_basis",
    "нормы": "legal_basis",
    "применимые нормы": "legal_basis",
    "статьи ук": "legal_basis",
    "нормы ук": "legal_basis",
    "нормы упк": "legal_basis",
    # «Доказательства» больше не печатаем, но старые ответы читаем без ошибок.
    "доказательства": "evidence",
    "дополнительно": "extra",
    "ведомство": "vedomstvo",
    "подразделение": "podrazdelenie",
    "вид документа": "doc_type",
    "заголовок": "doc_title",
}

_NUMBERED = re.compile(r"^\s*(?:п(?:ункт)?\s*)?(\d{1,2})[.)]\s+(.*)$")
_BULLET = re.compile(r"^\s*[-•*—]\s+(.*)$")

#: Строки интерфейса сервиса, которые попадают в текст вместе с ответом
#: (чипы вложений, кнопки «перейти», статусы «Режим ИИ обрабатывает…»).
#: Без этой чистки они уезжали в «Дополнительно» готового постановления —
#: ровно то, что видно в замечаниях к v27.
_UI_NOISE = re.compile(
    r"(перейти к (основному контенту|предыдущему запросу)"
    r"|справка по использованию специальных возможностей"
    r"|all items removed from input context"
    r"|режим ии обрабатывает"
    r"|^(pdf|file|файл|txt|png|docx)$"
    r"|^[^:]{1,80}\.(pdf|txt|png|jpe?g|docx|doc|json)$"
    r"|^шаблон\.txt$"
    r"|^заявка \(отправлено в$"
    r"|^ответ от режима ии"
    r"|^ответ в режиме ии"
    r"|^(mem|phis\.pdf|ша|блон\.txt)$"
    r"|^показать больше$|^копировать$|^поделиться$|^нравится$)",
    re.IGNORECASE,
)


#: Служебные фразы нашего же сообщения в чате (v37).
#:
#: Реальная ситуация: веб-клиент ИИ отдал в ответе ВЕСЬ текст чата, включая
#: наше сообщение «Сформировано постановление… НИ В КАКОМ РАЗДЕЛЕ не
#: используй внеигровые термины: «IC», «OOC»…». Этот текст ушёл в
#: «Обстоятельства» документа и в PNG, а проверка справедливо нашла там «IC».
#: Теперь строки-инструкции не считаются содержанием документа.
_CHAT_INSTRUCTION = re.compile(
    r"(сформировано постановление, файл заявки приложен"
    r"|работай только с текстом заявки"
    r"|не описывай изображения и вложения"
    r"|ответь строго по формату промта"
    r"|ни в каком разделе .{0,40}не используй внеигровые"
    r"|вместо «?без весомых ic причин»?"
    r"|вы отправили \d+ файл"
    r"|ответ в режиме ии, исходные файлы"
    r"|исходный запрос:"
    r"|прикрепил|приложен файл заявки"
    # v46 (выгрузка Постановление_46v): ИИ вставил в «УСТАНОВИЛ» наш промт
    # целиком — от «Обращение уже рассмотрено…» до «ЭТАП 1 — ПЕРВИЧНОЕ
    # РЕШЕНИЕ…» и цитаты заявки. Это не текст документа.
    r"|обращение уже рассмотрено"
    r"|оформи это решение постановлением"
    r"|основание отказа \(по проверке обращения\)"
    r"|ответ ии по проверке обращения"
    r"|заявка на постановление прокурора"
    r"|данные для подготовки документа"
    r"|этап 1 — первичное решение"
    r"|обращение гражданина \(текст целиком"
    r"|оценивай только само обращение"
    r"|санкцию не назначай"
    r"|не назначай санкцию|не возбуждай уголовное дело"
    r"|определит ии по обстоятельствам)",
    re.IGNORECASE,
)

#: Строка целиком — служебная инструкция (начинается с повелительного глагола).
_CHAT_INSTRUCTION_START = re.compile(
    r"^(работай|ответь|не описывай|не разбирай|не пиши|используй|укажи|"
    r"перепиши|сформируй|подготовь|выбери|составь|выведи)\b",
    re.IGNORECASE,
)


def is_chat_instruction(line: str) -> bool:
    """Строка — инструкция из нашего сообщения в чате, а не текст документа."""
    text = _clean(line)
    if not text:
        return False
    if _CHAT_INSTRUCTION.search(text):
        return True
    return bool(_CHAT_INSTRUCTION_START.match(text))


def scrub_chat_text(text: str) -> str:
    """Убирает из ответа ИИ служебные строки чата (v37)."""
    kept = []
    for line in str(text or "").splitlines():
        if is_chat_instruction(line):
            continue
        kept.append(line)
    return "\n".join(kept)


def is_ui_noise(line: str) -> bool:
    """Строка — мусор интерфейса, а не часть постановления."""
    text = _clean(line)
    if not text:
        return True
    if len(text) <= 2:
        return True
    if is_chat_instruction(text):
        return True
    # v37: сначала явные признаки интерфейса («PDF», «File», «Заявка.txt») —
    # раньше проверка обрывков имени вложения срабатывала раньше и отвечала
    # «не мусор», из-за чего эти строки попадали в «Обстоятельства».
    if _UI_NOISE.search(text):
        return True
    # «Ша / блон.txt» — перенос имени вложения, «Мем / фис.pdf» и т. п.
    if re.fullmatch(r"[А-Яа-яЁёA-Za-z]{1,6}", text) and len(text) <= 6:
        return bool(re.search(r"[а-яё]{2,}", text)) and _looks_like_fragment(text)
    return False


def _looks_like_fragment(text: str) -> bool:
    """Короткий обрывок без пробелов рядом с именем файла — мусор чата."""
    return text.lower() in {"ша", "мем", "блон", "фи", "фис", "чат", "заяв", "заявк"}


_MD_WRAP = re.compile(r"^[\s>*_`#>\-•·\d.)\]]+")


def diag_event(name: str, **fields) -> None:
    """Событие в лог, если диагностика доступна (рендер работает и без неё)."""
    try:
        import diagnostics as _diag
        _diag.event(name, **fields)
    except Exception:
        pass


def strip_markdown(value: str) -> str:
    """Убирает markdown-разметку из значения, сохраняя текст.

    ИИ любит отвечать «- **Обстоятельства:** текст», «`#131485`», «*важно*».
    В документе звёздочки и обратные кавычки не нужны.
    """
    text = str(value or "")
    text = text.replace("**", "").replace("__", "").replace("`", "")
    text = re.sub(r"(?<![\w])[*_](?=\S)|(?<=\S)[*_](?![\w])", "", text)
    # Срезаем только «маркеры списка» и кавычки, НЕ трогая цифры и «#»:
    # «#131485» — это номер удостоверения, «3.1» — пункт устава.
    text = re.sub(r"^[\s>*_`•·\-—]+", "", text)
    text = text.replace("\u00a0", " ")
    return re.sub(r"[ \t]+", " ", text).strip()


def _normalize_key(raw: str) -> str:
    """Ключ поля из строки ответа, устойчивый к markdown.

    Реальный случай: ИИ прислал «- **Обстоятельства:** текст» — звёздочки не
    давали распознать поле, строка уходила в «свободный текст», и в документе
    появлялась подпись рендера вместо значения поля. Теперь разметка снимается
    до сравнения с алиасами.
    """
    key = _clean(raw).lower()
    key = key.replace("**", "").replace("__", "").replace("`", "")
    key = key.replace("«", "").replace("»", "").replace('"', "")
    key = re.sub(r"^[\s>*_`#>\-•·\d.)\]]+", "", key)
    key = key.replace("\u00a0", " ").rstrip(":").strip(" .")
    key = re.sub(r"\s+", " ", key)
    if key in _ALIASES:
        return _ALIASES[key]
    for label_key, form_label in FORM_LABELS.items():
        if key == form_label.lower():
            return label_key
    for field_key, _f, label in DOC_FIELDS:
        if key == label.lower():
            return field_key
    return ""


#: Признаки того, что ИИ вместо документа описывает изображение.
#: Реальный случай: клиент приложил .png постановления, ИИ ответил «На
#: изображении представлен официальный бланк…», и этот разбор уезжал в
#: «Обстоятельства» готового документа. Такой текст документом не считается.
_DESCRIPTION_MARKERS = (
    "на изображении", "на картинке", "на скриншоте", "на предоставленном изображении",
    "изображении представлен", "представлен официальный бланк", "вот подробный разбор",
    "разбор всего, что находится", "шапка документа", "основной текст постановления",
    "подпись и водяные знаки", "нижний левый угол", "нижний правый угол",
    "вероятно, для ролевого", "gta v rp", "samp", "водяной знак (герб",
)
#: Строки-«рубрики» описания: «📑 Шапка документа», «**✍️ Основной текст**».
_SECTION_HEADING = re.compile(
    r"^[\s>*_`#•·📑✍️🖋️📄🔹▪✅❌\-]*(шапка|основной текст|постановляющая часть|"
    r"подпись|водяные знаки|фотер|подвал|реквизиты|логотип|примечание|"
    r"исходящие данные|вводная часть)[^\n]{0,40}$",
    re.IGNORECASE,
)


def is_section_heading(line: str) -> bool:
    """Строка-рубрика описания картинки («📑 Шапка документа»), а не поле.

    Проверяем до ключей: если слева от двоеточия стоит известное имя поля
    («Примечание», «Обстоятельства»), это поле, а не заголовок раздела.
    """
    text = _clean(line)
    if not text:
        return False
    if ":" in text:
        head = _normalize_key(text.split(":", 1)[0])
        if head:
            return False
    return bool(_SECTION_HEADING.match(text)) and len(text) <= 60


def looks_like_image_description(text: str) -> bool:
    """Ответ ИИ — описание бланка на картинке, а не сам документ."""
    raw = str(text or "").lower()
    if not raw.strip():
        return False
    hits = sum(1 for marker in _DESCRIPTION_MARKERS if marker in raw)
    if hits >= 2:
        return True
    # одиночный сильный признак + отсутствие полей документа
    if hits >= 1 and not re.search(r"^\s*[*_`>-]*\s*(номер|дата|в отношении)\s*[:：]",
                                   raw, re.MULTILINE):
        return True
    return False


def count_document_fields(text: str) -> int:
    """Сколько НАСТОЯЩИХ полей постановления распознаёт парсер.

    v32: главный признак документа. Наше собственное сообщение в чате
    («…ответь одним блоком от ===ПОСТАНОВЛЕНИЕ=== до ===КОНЕЦ
    ПОСТАНОВЛЕНИЯ===…») содержит маркеры, но НИ ОДНОГО поля — именно на этом
    клиент ошибался: находил «блок», решал, что ответ готов, и выдавал
    «Бланк не сформирован», так и не дождавшись настоящего ответа ИИ.

    Считаем теми же ключами, что и разбор, — лишней логики не добавляем.
    """
    found = {key for key, _form, _label in DOC_FIELDS}
    count = 0
    for raw_line in str(text or "").splitlines():
        line = strip_markdown(raw_line.strip())
        if ":" not in line:
            continue
        key = _normalize_key(line.split(":", 1)[0])
        if key in found and strip_markdown(line.split(":", 1)[1]).strip():
            count += 1
    return count


def looks_like_document(text: str) -> bool:
    """Текст — постановление ИИ, а не служебная фраза про маркеры."""
    return count_document_fields(text) >= 2


def has_document_trigger(text: str) -> bool:
    """Есть ли в тексте НАСТОЯЩИЙ маркер постановления.

    v30.3: раньше проверялось вхождение слова «ПОСТАНОВЛЕНИЕ» в любом месте
    текста — под это подходила и сама заявка («ЗАЯВКА НА ПОСТАНОВЛЕНИЕ»,
    «Вид документа: Постановление …»), и обычная правовая формулировка.
    Поэтому заявка принималась за ответ ИИ, и PNG собирался из конструктора.

    Теперь нужен явный маркер: `===ПОСТАНОВЛЕНИЕ===` / `===КОНЕЦ
    ПОСТАНОВЛЕНИЯ===` — либо строка, начинающаяся с `ПОСТАНОВЛЕНИЕ` И
    содержащая двоеточие-поля. Просто слово в тексте не считается.
    """
    raw = str(text or "")
    # Пробелы, `*` и обратные кавычки вокруг маркера не важны:
    # «=== ПОСТАНОВЛЕНИЕ ===», «**===ПОСТАНОВЛЕНИЕ===**».
    compact = re.sub(r"[\s`*]+", "", raw.upper())
    if "===ПОСТАНОВЛЕНИЕ===" in compact or "КОНЕЦПОСТАНОВЛЕНИЯ" in compact:
        return True
    # Строка-маркер: «ПОСТАНОВЛЕНИЕ» как ЗАГОЛОВОК, а не «Постановление вынес: …».
    # Поэтому смотрим только на первое слово строки и не берём «вынес/вступает».
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Только когда «ПОСТАНОВЛЕНИЕ» стоит отдельным заголовком:
        # «ПОСТАНОВЛЕНИЕ», «ПОСТАНОВЛЕНИЕ: …», но НЕ «Постановление вынес: …».
        if re.match(r"^ПОСТАНОВЛЕНИЕ(\s*[:.]|\s*$)", line.upper()):
            return True
    return False


def has_answer_end(text: str) -> bool:
    compact = re.sub(r"[\s=*/\-_]+", "", str(text or "").upper())
    return "КОНЕЦОТВЕТА" in compact


def strip_triggers(text: str) -> str:
    out = str(text or "")
    for trigger in (TRIGGER_ANSWER_END, TRIGGER_DOC_START, TRIGGER_DOC_END):
        out = out.replace(trigger, "")
    return out.strip()


#: Служебные фразы, которые есть ТОЛЬКО в нашей заявке (ИИ их не пишет).
#:
#: v45.1: «заявка на постановление» отсюда УБРАНА. Ответ ИИ часто начинается с
#: цитаты заявки («… ЗАЯВКА НА ПОСТАНОВЛЕНИЕ ПРОКУРОРА … Данные для подготовки
#: документа …»), и такая примета отбрасывала настоящий ответ целиком: в чате
#: документ есть, а PNG не печатается. Теперь для заявки на постановление
#: работает _DOC_REQUEST_HEAD ниже.
_REQUEST_ONLY_MARKS = (
    "нет данных — определи сам",
    "предлагаемые пункты (перепиши официально)",
)

#: Начало заявки на проверку обращения. Это НЕ признак «свой текст»: ответ
#: ИИ часто цитирует постановку задачи (в чате он виден вместе с вложениями —
#: `**Memphis.pdf** … ЗАЯВКА НА ПРОВЕРКУ ОБРАЩЕНИЯ (этап 1) … ПРОВЕРКА
#: ОБРАЩЕНИЯ Состояние: Отказано`), и в v44.1 такой ответ целиком отбрасывался.
#: Поэтому фраза используется только как «наша заявка начинается здесь»:
#: заявкой считается текст, который НАЧИНАЕТСЯ с неё и почти сразу кончается.
_INTAKE_REQUEST_HEAD = "заявка на проверку обращения (этап"

#: Начало заявки на постановление. Тоже НЕ признак «свой текст»: ответ ИИ
#: начинается с цитаты заявки, а документ идёт после неё.
_DOC_REQUEST_HEAD = "заявка на постановление прокурора"

#: Настоящий заголовок заявки на постановление (в файле заявки и в цитате
#: ответа): «ЗАЯВКА НА ПОСТАНОВЛЕНИЕ ПРОКУРОРА / Данные для подготовки
#: документа:». Второй строки в ответе ИИ нет — по ней и различаем.
_DOC_REQUEST_BODY = "данные для подготовки документа"


#: Служебная строка состояния в ответе на проверку обращения. ИИ пишет её
#: и как «Состояние: Отказано», и как «**Состояние:** Отказать».
_INTAKE_STATE_RE = re.compile(
    r"состояни\w*\s*[:\-–—]\s*(принят|отказ|переадрес|прекращ)")


def _flat(text: str) -> str:
    return " ".join(str(text or "").split())


def is_own_request(text: str, request_text: str = "") -> bool:
    """Текст — это НАША ЖЕ заявка в чате, а не ответ ИИ.

    v30.3 (главная причина замечания): заявка начинается словом
    «ПОСТАНОВЛЕНИЕ» и заканчивается «===КОНЕЦ ОТВЕТА===», поэтому она
    выглядит для клиента как готовый ответ ИИ. Клиент опрашивал страницу и на
    первых опросах читал СВОЁ сообщение — из него собирался PNG (данные
    конструктора), а настоящий ответ ИИ приходил позже и только перезаписывал
    `ИИ-ответ.txt`. Отсюда и расхождение: файл верный, PNG — нет.

    v45.1: ответ ИИ обычно ЦИТИРУЕТ заявку (в чате он виден вместе с ней), а
    иногда ещё и содержит строку «Состояние: Отказано» из прошлой проверки.
    Поэтому порядок проверок — от самых надёжных признаков к слабым:

    1. текст совпадает с заявкой — это заявка;
    2. в тексте есть готовый документ («УСТАНОВИЛ», «ПОСТАНОВИЛ», «КОНЕЦ
       ПОСТАНОВЛЕНИЯ») — это ОТВЕТ, даже если он цитирует заявку;
    3. заявка целиком внутри текста — решает остаток: есть документ → ответ,
       остались только имена вложений → заявка;
    4. текст начинается как заявка на постановление (заголовок + «Данные для
       подготовки документа») — заявка;
    5. блок проверки обращения — ответ;
    6. служебные пометки заявки — заявка.
    """
    flat = _flat(text)
    if not flat:
        return False
    low = flat.lower()
    request = _flat(request_text)
    if request and flat == request:
        return True
    # 2. Готовый документ в тексте — это ответ ИИ.
    if _has_document_body(low):
        return False
    # 3. Заявка внутри текста.
    if request and request in flat:
        rest = flat.replace(request, " ", 1).strip().lower()
        if _has_document_body(rest):
            return False
        if len(rest) <= 600 or len(request) * 100 >= len(flat) * 80:
            return True
        return False
    # 4. Текст начинается как наша заявка на постановление.
    if _DOC_REQUEST_HEAD in low and _DOC_REQUEST_BODY in low:
        return True
    # v60: заявка этапа 1 подросла (пять исходов + требование плана шагов
    # этапа 2), поэтому прежний лимит в 2000 символов её больше не покрывал —
    # и собственная заявка принималась за ответ ИИ. Лимит поднят до 4000:
    # ответ ИИ с документом всё равно отсекается раньше (пункт 2), а текст
    # короче 4000 символов документом быть не может.
    if _INTAKE_REQUEST_HEAD in low and len(low) <= len(_INTAKE_REQUEST_HEAD) + 4000:
        return True
    # 5. Блок проверки обращения или её служебная строка — ответ.
    if _has_ai_answer_inside(low):
        return False
    # 6. Служебные пометки заявки.
    if sum(1 for mark in _REQUEST_ONLY_MARKS if mark in low) >= 1:
        return True
    return False


#: Приметы ГОТОВОГО документа в ответе ИИ. Их нет в нашей заявке: она просит
#: «оформи постановлением», но самого документа не содержит.
_DOC_BODY_MARKS = ("установил", "постановил", "конец постановления",
                   "===конец ответа===", "===постановление===")


def _has_document_body(low: str) -> bool:
    """В тексте есть САМ документ, а не просьба его оформить (v45.1).

    Наша заявка просит «оформи это решение постановлением», но слов
    «УСТАНОВИЛ» / «ПОСТАНОВИЛ» / «КОНЕЦ ПОСТАНОВЛЕНИЯ» не содержит — они есть
    только в ответе ИИ.
    """
    for mark in _DOC_BODY_MARKS:
        if mark in low:
            return True
    return False


def _has_ai_answer_inside(low: str) -> bool:
    """В тексте есть признаки ОТВЕТА ИИ (а не только наша заявка).

    Нужно, чтобы отличить наше сообщение от ответа, который цитирует заявку.
    """
    if _INTAKE_STATE_RE.search(low):
        return True
    # Блок проверки обращения в ответе — это строка-заголовок и маркеры.
    if re.search(r"(===+\s*)?проверка\s+обращения\s*(===+)?", low):
        return True
    for trigger in (TRIGGER_DOC_START, "===ПОСТАНОВЛЕНИЕ==", TRIGGER_DOC_END,
                    "===КОНЕЦ ПОСТАНОВЛЕНИЯ"):
        if trigger.lower().replace(" ", "") in low.replace(" ", ""):
            return True
    # v45.1: ответ содержит сам документ («УСТАНОВИЛ», «ПОСТАНОВИЛ», «КОНЕЦ
    # ПОСТАНОВЛЕНИЯ»). Наша заявка эти слова не печатает — только просит
    # оформить постановление. Без этой проверки ответ, который цитирует
    # заявку, считался «своей заявкой» (в чате документ есть, PNG нет).
    if any(mark in low for mark in _DOC_BODY_MARKS):
        return True
    if re.search(r"(===+\s*)?постановление\s*(===+)?\s*\n", low):
        return True
    return False


#: Заголовок документа в ответе: «ПОСТАНОВЛЕНИЕ» отдельной строкой, за которым
#: идут его реквизиты. Именно с него начинается документ, если ответ сначала
#: цитирует заявку.
#: Реквизиты, которые идут сразу после заголовка документа. Порядок у ИИ
#: бывает любой, поэтому проверяем весь набор.
_DOC_HEADING_FIELDS = ("ведомство:", "подразделение:", "номер:", "дата:",
                       "вид документа:", "вид решения:", "заявитель:")

_DOC_HEADING_RE = re.compile(
    r"^[\s>*_#`•·]*(?:===+\s*)?ПОСТАНОВЛЕНИЕ\s*(?:===+)?[\s*_`]*$", re.MULTILINE)


def _document_body_start(raw: str) -> int:
    """Позиция начала документа в ответе ИИ (0 — не нашли).

    Нужна, когда ответ начинается с цитаты нашей заявки: «ЗАЯВКА НА
    ПОСТАНОВЛЕНИЕ ПРОКУРОРА … Данные для подготовки документа …» и только
    потом идёт сам документ. Без этого цитата попадала в разбор как поля
    документа (в «ПОСТАНОВИЛ» оказывались пункты обращения).
    """
    best = 0
    for match in _DOC_HEADING_RE.finditer(raw):
        pos = match.start()
        tail = raw[pos:pos + 400].lower()
        # v46: реквизиты документа идут в разном порядке. В ответе из
        # Постановление_46v после заголовка сразу «Номер:», «Дата:»,
        # «Вид документа:» — без «Ведомство:», и документ не находился вовсе:
        # в разбор уходила цитата заявки (в «УСТАНОВИЛ» — инструкции ИИ).
        if any(mark in tail for mark in _DOC_HEADING_FIELDS):
            if pos > best:
                best = pos
    return best


def extract_document_block(text: str) -> str:
    """Вырезает из ответа ИИ только блок постановления.

    Реальная ситуация: ИИ пишет «На изображении представлен официальный
    документ…» и уже ПОСЛЕ этого выдаёт `===ПОСТАНОВЛЕНИЕ=== …`. Раньше
    детектор описания срабатывал на весь текст и документ отбрасывался —
    в PNG уходили данные формы, а не то, что ответил ИИ. Теперь описание до
    блока и после него просто не участвует в разборе.
    """
    raw = str(text or "")
    # v32: маркер маркером, но если настоящих полей в тексте нет — это не
    # документ, а служебная фраза («…ответь одним блоком от ===ПОСТАНОВЛЕНИЕ===
    # до ===КОНЕЦ ПОСТАНОВЛЕНИЯ===…»). Такой текст блоком не считается.
    if not looks_like_document(raw):
        return ""
    # v37: в ответ может попасть весь чат вместе с нашими инструкциями
    raw = scrub_chat_text(raw)
    upper = raw.upper()
    start = -1
    for marker in (TRIGGER_DOC_START, "===ПОСТАНОВЛЕНИЕ=="):
        pos = upper.find(marker.upper())
        if pos >= 0:
            start = pos
            break
    if start < 0:
        if not has_document_trigger(raw):
            return ""
        start = 0
        # v45.1: ответ ИИ иногда цитирует заявку ЦЕЛИКОМ, а сам документ идёт
        # ПОСЛЕ. Тогда блоком считаем не цитату, а документ: режем по
        # заголовку «ПОСТАНОВЛЕНИЕ», за которым идут реквизиты.
        body = _document_body_start(raw)
        if body > 0:
            start = body
    block = raw[start:]
    for end_marker in (TRIGGER_DOC_END, "===КОНЕЦ ПОСТАНОВЛЕНИЯ==="):
        end = block.find(end_marker)
        if end >= 0:
            return block[:end + len(end_marker)]
    # конец блока мог не прийти (обрезанный ответ) — режем по «КОНЕЦ ОТВЕТА»
    end = block.find(TRIGGER_ANSWER_END)
    return block[:end] if end >= 0 else block


def parse_ai_answer(answer_text: str, base: Postanovlenie | None = None) -> Postanovlenie | None:
    """Достаёт поля постановления из ответа ИИ (триггерная логика).

    Понимает оба вида ответа, которые допускает промт:
    * структурированный — строки «Ключ: значение» и нумерованные пункты;
    * свободный — тогда просто сохраняется как обстоятельства.

    Возвращает `None`, если ответ не похож на постановление.
    """
    text = str(answer_text or "")
    if not text.strip():
        return None

    # v30.3: наша собственная заявка — не документ. Её служебные пометки
    # однозначно указывают на конструктор, а не на ответ ИИ.
    if is_own_request(text):
        diag_event("postanovlenie.answer_is_own_request")
        return None

    # v30.1: работаем только с блоком постановления, если он есть в ответе.
    block = extract_document_block(text)
    if block.strip("= \n\tПОСТАНОВЛЕНИЕКОНЕЦ"):
        text = block
    elif looks_like_image_description(text):
        # Блока нет, а пришло описание картинки — это не документ: базовый
        # вариант (данные формы) остаётся как есть, чтобы в PNG не попал пересказ.
        diag_event("postanovlenie.answer_is_image_description")
        return None

    text = scrub_chat_text(text)
    # v54: ссылки сервиса «[cite: 2]», хвост чата после «===КОНЕЦ ОТВЕТА===»
    # («Ваш файл», «Page 18», «Показать все») и реплики ИИ «Я могу составить…»
    # — не текст постановления. Чистим ДО разбора, иначе они уезжают в поля,
    # а оттуда в PNG (выгрузка «Постановление 54 версия»).
    text = clean_document_text(text)

    doc = Postanovlenie.from_dict((base or Postanovlenie()).to_dict())
    doc.source = "ai"
    doc.created_at = time.time()

    inside = False
    saw_marker = False
    saw_content = False          # ИИ дал что-то кроме номера и даты
    points: list = []
    free_lines: list = []
    # v36 (замечание): ИИ присылал строку «Постановляющая часть: 1. … 2. …»
    # ОДНОЙ строкой. Ключ не совпадал ни с одним полем, и вся резолюция уезжала
    # в «Обстоятельства» — поэтому в бланке не было приказа, а обстоятельства
    # дублировали сами себя. Теперь такая строка разбирается на пункты.
    in_points = False

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        # v37: «Постановляющая часть:» — это рубрика резолюции, но
        # is_section_heading() принимала её за заголовок описания картинки и
        # выбрасывала строку. Из-за этого in_points не включался, и все пункты
        # приказа уезжали в «Обстоятельства» (выгрузка LSCSD-IAD-1).
        heading_plain = strip_markdown(line)
        heading_key = heading_plain.split(":", 1)[0].strip(" .").lower()
        if heading_key.startswith(("постановляющая", "резолютивная", "постановил",
                                   "решил")):
            in_points = True
            rest = heading_plain.split(":", 1)[1].strip() if ":" in heading_plain else ""
            for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", rest):
                body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                if body:
                    points.append(body)
                    saw_content = True
            continue
        if is_ui_noise(line) or is_section_heading(line):
            continue
        compact = re.sub(r"[\s=*/\-_]+", "", line.upper())
        # v37: маркер — это строка «ПОСТАНОВЛЕНИЕ» целиком. Раньше под условие
        # попадало любое начало с этого слова, и поле «Постановление вынес:
        # Marcus Nomad» съедалось как маркер — в документе не было подписанта.
        if (compact.startswith("ПОСТАНОВЛЕНИЕ") and ":" not in line
                and len(compact) <= len("ПОСТАНОВЛЕНИЕ") + 6):
            inside = True
            saw_marker = True
            continue
        if "КОНЕЦПОСТАНОВЛЕНИЯ" in compact:
            inside = False
            continue
        if "КОНЕЦОТВЕТА" in compact:
            continue

        if ":" in line:
            raw_key, raw_value = line.split(":", 1)
            key = _normalize_key(raw_key)
            value = strip_markdown(raw_value)
            heading = _clean(raw_key).lower().replace("**", "").strip(" .")
            # «Постановляющая часть: …» / «Резолютивная часть: …»
            if not key and heading.startswith(("постановляющая", "резолютивная",
                                               "постановил", "решил")):
                in_points = True
                value = value.strip()
                if value:
                    # внутри строки может быть сразу несколько пунктов «1. … 2. …»
                    for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", value):
                        body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                        if body:
                            points.append(body)
                            saw_content = True
                continue
            if key and value:
                # v37: в значение мог попасть весь чат вместе с инструкцией.
                # Чистим ТОЛЬКО инструкции: значение поля («Примечание: Mem»)
                # трогать нельзя, даже если оно похоже на обрывок имени файла.
                value = "\n".join(
                    chunk for chunk in scrub_chat_text(value).splitlines()
                    if not is_chat_instruction(chunk)).strip()
                if not value:
                    continue
                doc.set(key, value)
                if key not in ("doc_number", "doc_date"):
                    saw_content = True
                    in_points = False
                continue

        numbered = _NUMBERED.match(line)
        if numbered:
            body = strip_markdown(numbered.group(2))
            if body:
                points.append(body)
                saw_content = True
                continue
        bullet = _BULLET.match(line)
        if bullet and strip_markdown(bullet.group(1)):
            points.append(strip_markdown(bullet.group(1)))
            saw_content = True
            continue
        plain = strip_markdown(line)
        if plain:
            low_plain = plain.lower().strip(" .:")
            if low_plain.startswith(("постановляющая часть", "резолютивная часть")):
                in_points = True
                rest = re.sub(r"^[^:]*:\s*", "", plain).strip()
                if rest:
                    for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", rest):
                        body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                        if body:
                            points.append(body)
                            saw_content = True
                continue
            if in_points:
                for chunk in re.split(r"(?:^|\s)(?=\d{1,2}[.)]\s)", plain):
                    body = strip_markdown(re.sub(r"^\d{1,2}[.)]\s*", "", chunk.strip()))
                    if body:
                        points.append(body)
                        saw_content = True
                continue
            free_lines.append(plain)
            saw_content = True

    if points:
        doc.points = [p for p in (clean_document_text(point) for point in points)
                      if p.strip()]
    # Неразобранный текст — это содержание документа (обстоятельства), а не
    # «дополнительно»: в v27 мусор интерфейса попадал именно в «Дополнительно».
    if free_lines:
        joined = clean_document_text("\n".join(free_lines)).strip()
        if not doc.get("situation"):
            doc.situation = joined
        elif joined and joined not in doc.get("situation"):
            doc.situation = (doc.get("situation") + "\n" + joined).strip()
    # v54: «ПОСТАНОВЛЕНИЕ INTERNAL AFFAIRS DIVISION / УСТАНОВИЛ:» и сырая
    # фраза заявителя перед официальным текстом — это не обстоятельства.
    if doc.get("situation"):
        doc.situation = strip_inner_headings(doc.get("situation"))
        doc.situation = strip_raw_before_ustanovil(doc.situation).strip()
    if doc.get("extra"):
        doc.extra = clean_document_text(doc.get("extra"))

    if not saw_marker and not (doc.get("subject_name") or doc.get("penalty") or doc.points):
        return None
    # v31: документ считается разобранным, только если ИИ дал СОДЕРЖАНИЕ.
    # Одного «Номер:» (или «Номер» + «Дата») мало: раньше этого хватало, и
    # печатался бланк из конструктора, хотя ИИ фактически ничего не прислал.
    if not saw_content:
        diag_event("postanovlenie.answer_without_content", chars=len(text))
        return None
    if not doc.get("doc_date"):
        doc.doc_date = today_ru()
    if not doc.get("doc_type"):
        doc.doc_type = DOC_TYPES[0]
    return doc


# --------------------------------------------------------------------------- #
#  Сохранение результатов в папку postanovleniya
# --------------------------------------------------------------------------- #

#: Имена файлов одной выдачи (по номеру документа).
#: Префикс папки обращения (v53). Замечание пользователя: «при создании
#: обращения необходимо создавать папку „Обращение №_номер_обращения“ и в неё
#: уже класть папки AG-1, AG-2 и т.д. Чтобы было понятно».
APPEAL_FOLDER_PREFIX = "Обращение №"


def appeal_folder_name(case_number) -> str:
    """Имя папки обращения по номеру дела: «Обращение №1» (v53)."""
    number = _clean(case_number) or "без-номера"
    safe = re.sub(r"[^\w\-. №]", "_", number)[:60].strip()
    if safe.startswith(APPEAL_FOLDER_PREFIX) or safe.startswith("Обращение"):
        return safe
    return f"{APPEAL_FOLDER_PREFIX}{safe}"


def appeal_folder(root, case_number) -> Path:
    """Папка обращения: `postanovleniya/Обращение №1/` (v53).

    Внутри неё лежат папки этапов («AG-1», «AG-2» — см.
    `gov_case.stage_folder`), чтобы было видно, к какому обращению относится
    постановление.
    """
    folder = Path(root) / appeal_folder_name(case_number)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


#: Префикс папки постановления IAD (v54). Замечание пользователя: «Имеется
#: папка „Обращение №“ под постановления прокурора, нужно сделать аналогично,
#: но теперь под IAD, под названием „Постановление №“, и внутри уже будут,
#: например, „LSCSD-IAD-1“».
IAD_FOLDER_PREFIX = "Постановление №"

#: Номер постановления IAD: «LSCSD-IAD-1», «LSPD-IAD-14», «IAD-7».
_IAD_NUMBER = re.compile(r"^(?:[A-Z]{2,6}[-\s]*)?IAD[-\s]*(\d{1,4})$", re.IGNORECASE)


def is_iad_number(number) -> bool:
    """Номер документа — постановление IAD («LSCSD-IAD-1»)."""
    return bool(_IAD_NUMBER.match(_clean(number)))


def iad_folder_number(number) -> str:
    """Номер папки-обёртки из номера документа (v54).

    «LSCSD-IAD-1» → «1», «LSPD-IAD-14» → «14». Если номер не распознан,
    возвращается пустая строка: папка тогда остаётся плоской.
    """
    found = _IAD_NUMBER.match(_clean(number))
    return found.group(1) if found else ""


def iad_folder_name(number) -> str:
    """Имя папки постановления IAD: «Постановление №1» (v54)."""
    index = iad_folder_number(number)
    return f"{IAD_FOLDER_PREFIX}{index or 'без-номера'}"


def iad_folder(root, number) -> Path:
    """Папка постановления IAD: `postanovleniya/Постановление №1/` (v54).

    Внутри лежит папка самого документа («LSCSD-IAD-1») с заявкой, ответом
    ИИ и PNG — так же, как у Прокурора документы лежат внутри «Обращение №N».
    """
    folder = Path(root) / iad_folder_name(number)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def doc_folder(root, number: str = "", case_number=None) -> Path:
    """Папка одной выдачи ПОСТАНОВЛЕНИЯ: `postanovleniya/Обращение №1/AG-1/` (v53).

    v53: раньше папка с номером постановления (`AG-1`) лежала прямо в корне, и
    по ней нельзя было понять, к какому обращению относится документ. Теперь
    она вложена в папку обращения «Обращение №N».

    v54: у постановления IAD своя папка-обёртка «Постановление №N» — по аналогии
    с «Обращение №N» у Прокурора: «Постановление №1/LSCSD-IAD-1/». Номер
    обёртки берётся из номера документа (`_iad_folder_number`).

    Если номер обращения не передан и номер документа не вида «LSCSD-IAD-N»,
    папка остаётся плоской — так работают старые вызовы.
    """
    parent = Path(root)
    if case_number:
        parent = appeal_folder(root, case_number)
    elif is_iad_number(number):
        parent = iad_folder(root, number)
    safe = re.sub(r"[^\w\-. №]", "_", _clean(number) or "без-номера")[:60]
    folder = parent / safe.strip()
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def copy_pngs_into(folder, paths) -> list:
    """Кладёт копии готовых PNG в папку выдачи (рядом с заявкой и ответом ИИ)."""
    import shutil
    folder = Path(folder)
    copied = []
    for path in paths or []:
        try:
            target = folder / Path(path).name
            if Path(path).resolve() != target.resolve():
                shutil.copy2(path, target)
            copied.append(target)
        except Exception:
            continue
    return copied


def save_ai_answer(root, doc: Postanovlenie, answer_text: str) -> list:
    """Складывает в папку выдачи то, что ответил ИИ.

    * `ИИ-ответ.txt` — ровно тот текст, который пришёл в чат (as is, с
      markdown) — чтобы всегда можно было понять, откуда взялся документ;
    * `ИИ-поля.json` — разобранные поля (что именно клиент принял к сведению);
    * `ИИ-документ.txt` — РОВНО тот бланк, который печатается в PNG.
    """
    folder = doc_folder(root, doc.get("doc_number"))
    written = []
    raw = str(answer_text or "")
    if raw.strip():
        path = folder / "ИИ-ответ.txt"
        path.write_text(raw.replace("\r\n", "\n"), encoding="utf-8")
        written.append(path)
    payload = {
        "когда": datetime.now().strftime("%d.%m.%Y %H:%M:%S"),
        "источник": doc.source,
        "поля": doc.to_dict(),
    }
    path = folder / "ИИ-поля.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    written.append(path)
    path = folder / "ИИ-документ.txt"
    path.write_text(doc.to_document_txt(), encoding="utf-8")
    written.append(path)
    return written



# --------------------------------------------------------------------------- #
#  Юридическая проверка постановления (v34)
# --------------------------------------------------------------------------- #

#: Процессуальные кодексы — их нормы НЕ являются материальным основанием
#: дисциплинарного взыскания (замечание анализа: «часть 1 статьи 16
#: Процессуального кодекса» регламентирует задержание, а не проступок).
_PROCEDURAL_MARKS = ("процессуальн", "упк", "проц. кодекс")

#: Материальные кодексы: ссылаться можно, обосновывать ими дисциплинарное
#: взыскание — нет (ст. 8.24 устава нарушение НПА штата — самостоятельный
#: дисциплинарный проступок сотрудника).
_MATERIAL_CODE_MARKS = ("уголовн", "ук ", "ук\u00a0", "коап", "административн")

#: Ограничение полномочий из п. 4.4 устава: понижение — только Шериф,
#: его заместители и Ассистент Шерифа.
_RANK_LIMITS = (
    ("понижение", ("шериф", "заместител", "ассистент шерифа", "ундершериф")),
)


def split_basis(basis: str) -> tuple:
    """Делит «Нормативное основание» на устав и прочие акты.

    Возвращает (`уставная часть`, `прочие акты`). Нужно, чтобы процессуальные
    нормы не попадали в обоснование взыскания.
    """
    charter, others = [], []
    for part in re.split(r"[;\n]+", str(basis or "")):
        part = part.strip(" .,")
        if not part:
            continue
        low = part.lower()
        if "устав" in low or "lscsd" in low:
            charter.append(part)
        else:
            others.append(part)
    return "; ".join(charter), "; ".join(others)


def procedural_parts(basis: str) -> list:
    """Куски основания со ссылкой на процессуальный кодекс."""
    result = []
    for part in re.split(r"[;\n]+", str(basis or "")):
        low = part.lower()
        if any(mark in low for mark in _PROCEDURAL_MARKS):
            result.append(part.strip(" .,"))
    return [p for p in result if p]


#: Признаки внеигровой (OOC) речи в официальном документе (v36, промт 1.19 п. 19).
#:
#: Замечание: в постановление попало «при отсутствии на то весомых IC причин».
#: «IC», «OOC», «РП», «отыгран», «администрация сервера» — это язык игроков, а
#: не штата Сан-Андреас. В бланке их быть не может: там официальный язык права.
OOC_MARKERS: tuple[tuple[str, str], ...] = (
    ("IC", "в отсутствие законных и фактических оснований"),
    ("OOC", ""),
    ("RP", ""),
    ("РП", ""),
    ("нон-РП", ""),
    ("non-RP", ""),
    ("отыгр", ""),
    ("не отыграл", ""),
    ("функционал", ""),
    ("по правилам сервера", ""),
    ("правила сервера", ""),
    ("администрация сервера", ""),
    ("админ", ""),
    ("бан ", ""),
    ("варн", ""),
    ("персонаж игрока", ""),
    ("игровой персонаж", ""),
)

#: Готовые формулировки для типовых внеигровых оборотов.
_OOC_REWRITES: tuple[tuple[str, str], ...] = (
    # «в соответствии с IC информацией» → «на основании материалов проверки»
    (r"в\s+соответствии\s+с\s+IC[-\s]*информаци\w*", "на основании материалов проверки"),
    (r"согласно\s+IC[-\s]*информаци\w*", "согласно материалам проверки"),
    (r"по\s+IC[-\s]*информаци\w*", "по материалам проверки"),
    (r"IC[-\s]*информаци\w*", "материалам проверки"),
    # «при отсутствии на то весомых IC причин» → официальная формула целиком
    (r"(?:при\s+отсутствии|без|не\s+имея)\s+(?:на\s+то\s+)?(?:весомых\s+|"
     r"достаточных\s+|законных\s+)?IC[-\s]*причин\w*",
     "в отсутствие законных и фактических оснований"),
    (r"(?:при\s+отсутствии|без)\s+(?:на\s+то\s+)?(?:весомых|достаточных)\s+причин\w*",
     "в отсутствие законных и фактических оснований"),
    (r"IC[-\s]*причин\w*", "законных и фактических оснований"),
    (r"IC[-\s]*основани\w*", "законных оснований"),
    # v54 (выгрузка AG-2): «законных IC-требований» — дефисный оборот, общее
    # правило подставляло в него «в рамках служебной деятельности» и получалось
    # «законных в рамках служебной деятельности-требований».
    (r"IC[-\s]*(требовани\w*|норм\w*|правил\w*|предписани\w*)", r"\1"),
    (r"IC-(?=[А-Яа-яЁё])", ""),
    # одиночные термины
    (r"(?<![A-Za-zА-Яа-яЁё])IC(?![A-Za-zА-Яа-яЁё])", "в рамках служебной деятельности"),
    (r"(?<![A-Za-zА-Яа-яЁё])OOC(?![A-Za-zА-Яа-яЁё])", ""),
    (r"(?<![A-Za-zА-Яа-яЁё])(?:RP|РП)(?![A-Za-zА-Яа-яЁё])", ""),
)

#: Русские слова, внутри которых «IC»/«RP» — не термин (латиница в кириллице
#: не встречается, поэтому проверяем только границы слова).
def ooc_terms(text: str) -> list:
    """Находит внеигровые термины в тексте. Возвращает список найденных."""
    found: list = []
    low = " " + str(text or "").lower() + " "
    for marker, _replacement in OOC_MARKERS:
        needle = marker.lower().strip()
        if not needle:
            continue
        if re.search(r"(?<![a-zа-яё0-9])" + re.escape(needle) + r"(?![a-zа-яё0-9])", low):
            label = marker.strip()
            if label.lower() not in [f.lower() for f in found]:
                found.append(label)
    return found


def sanitize_ooc(text: str) -> str:
    """Переписывает внеигровые обороты официальным языком (правка документа).

    Ничего не выдумывает: заменяет только типовые конструкции на юридические
    формулы («без весомых IC причин» → «в отсутствие законных и фактических
    оснований»). Если оборот не распознан, его надо править вручную — об этом
    сообщит `check_document`.
    """
    result = str(text or "")
    for pattern, replacement in _OOC_REWRITES:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
    result = re.sub(r"\s{2,}", " ", result)
    result = re.sub(r"\s+([,.;:])", r"\1", result)
    return result.strip()


# --------------------------------------------------------------------------- #
#  Чистка ответа ИИ (v54)
# --------------------------------------------------------------------------- #
#
# Три вещи, которые ИИ пишет «от себя» и которых в документе быть не должно:
#
# 1. `[cite: 2]`, `[cite: 2, 3]` — ссылки на приложенный .pdf. Это пометки
#    веб-сервиса, а не текст постановления: в PNG они печатались прямо посреди
#    «УСТАНОВИЛ» («…чья действия обжалуются [cite: 2].»).
# 2. Чат-хвост после `===КОНЕЦ ОТВЕТА===`: «Ваш файл · Доступно только вам»,
#    «Page 18», «Показать все», «ИИ может ошибаться. Проверяйте его ответы.»
#    Хвост уезжал в «УСТАНОВИЛ» и печатался отдельным абзацем.
# 3. Предложения помощи и вопросы к пользователю: «Я могу продолжить работу
#    по этому делу», «Я могу составить для вас исковое заявление… Напишите,
#    если вам требуется шаблон…», «Что именно мы делаем на следующем шаге?»
#    В постановлении это лишний текст, а в резолюции — целый пункт «4.».
#
# Чистка нужна на уровне РАЗБОРА (текст документа), а не только в промте:
# промт ИИ выполняет не всегда, а бланк печатается из его ответа.

#: Ссылка на приложенный файл: «[cite: 2]», «[cite: 2, 3]», «[cite:2-4]».
#: Скобка необязательна: сервис иногда отдаёт «cite: 2» без неё.
_CITE_MARK = re.compile(
    r"[ \t]*[\[(]?\s*(?<![A-Za-zА-Яа-яЁё])cite\s*:\s*\d{1,3}"
    r"(?:\s*[,;–-]\s*\d{1,3})*\s*[\])]?",
    re.IGNORECASE,
)

#: Строки интерфейса сервиса, которые приезжают вместе с ответом (v54).
#: Выгрузка: «Ваш файл», «·», «Доступно только вам», «Page 18», «Показать все».
_CHAT_UI_LINE = re.compile(
    r"^(?:"
    r"ваш файл|доступно только вам|показать все|показать больше|скрыть|"
    r"страница \d+|page \d+(?: of \d+)?|"
    r"\d+ файл(?:а|ов)?|"
    r"ии может ошибаться\.?\s*проверяйте его ответы\.?|"
    r"проверяйте (?:его )?ответы\.?|"
    r"·"
    r")$",
    re.IGNORECASE,
)

#: Начало служебной части чата: всё, что после этой строки, документом не
#: является. Режем по строке ЦЕЛИКОМ, чтобы «===КОНЕЦ ОТВЕТА===» сработал в
#: любом написании («КОНЕЦ ОТВЕТА», «===КОНЕЦ ОТВЕТА ===»). Если маркер стоит
#: последней строкой без закрывающих «===» — тоже конец ответа.
_ANSWER_END_LINE = re.compile(
    r"^[\s=*`\-—]*КОНЕЦ\s*ОТВЕТА[\s=*`\-—]*$",
    re.IGNORECASE,
)

#: Предложения помощи и вопросы к пользователю (v54). В документе их нет:
#: «они засоряют ответ» (замечание к выгрузке). Ловим по началу предложения.
_CHAT_OFFER = re.compile(
    r"(?:я\s+могу\s+(?:продолжить|составить|подготовить|сформировать|"
    r"предложить|помочь|разработать|написать|предоставить)"
    r"|могу\s+(?:продолжить|составить|подготовить|сформировать|предложить|"
    r"помочь|разработать|написать)"
    r"|напишите,?\s+если\s+(?:вам\s+)?(?:требуется|нужн|понадоб)"
    r"|если\s+(?:вам\s+)?(?:требуется|нужн|понадоб)\w*[^.!?]{0,60}"
    r"(?:шаблон|консультаци|документ|помощ)"
    r"|что\s+(?:именно\s+)?(?:мы|нам)\s+(?:делаем|делать|сделать)\s+"
    r"(?:на\s+следующем|дальше|теперь)"
    r"|какой\s+документ\s+(?:мы\s+)?(?:сформируем|составим|подготовим)"
    r"|дайте\s+знать|сообщите,?\s+если|обращайтесь)",
    re.IGNORECASE,
)

#: Обрывки предложения-предложения помощи, которые остаются, если резать по
#: глаголу: «…инциденту. Напишите, если вам требуется шаблон документа или
#: дополнительная консультация по статьям законов.»
_CHAT_OFFER_TAIL = re.compile(
    r"^(?:дополнительн\w+\s+консультаци\w*|консультаци\w+\s+по\s+статьям"
    r"[^.!?]*|по\s+статьям\s+закон\w+[^.!?]*|шаблон\w*\s+документ\w*[^.!?]*)",
    re.IGNORECASE,
)

#: Строка интерфейса сервиса, приехавшая в текст вместе с ответом: «Ваш файл
#: · Доступно только вам», «Page 18», «Показать все», «Перейти к предыдущему
#: запросу». Такая строка может стоять ПОСРЕДИ абзаца — тогда она вырезается
#: из строки, а не выбрасывает её целиком.
_UI_INSIDE = re.compile(
    r"(?:ваш\s+файл\s*[·.]?\s*(?:доступно\s+только\s+вам)?"
    r"|доступно\s+только\s+вам"
    r"|\bpage\s+\d+(?:\s+of\s+\d+)?\b"
    r"|показать\s+все"
    r"|перейти\s+к\s+(?:предыдущему\s+запросу|основному\s+контенту)"
    r"|ии\s+может\s+ошибаться\.?\s*проверяйте\s+его\s+ответы\.?)",
    re.IGNORECASE,
)


def strip_ui_noise_inside(text: str) -> str:
    """Вырезает из строки служебные обороты интерфейса (v54)."""
    raw = str(text or "")
    if not raw.strip():
        return raw
    cleaned = _UI_INSIDE.sub(" ", raw)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,;:])", r"\1", cleaned)
    return cleaned.strip()


#: Служебные обороты, которые ИИ берёт из интерфейса: «Установлено, что LSPD
#: удо не видел (ID-Card, удостоверение № 25013, 150066.» — это ответ на вопрос
#: «видели ли удо», а не факт дела.
_PLACEHOLDER_SENTENCE = re.compile(
    r"(?:удо\s+не\s+видел|не\s+видел\w*\s+удо|удостоверени\w+\s+не\s+предъяв\w*)",
    re.IGNORECASE,
)


def strip_citations(text: str) -> str:
    """Убирает из текста ссылки сервиса «[cite: 2]» (v54)."""
    raw = str(text or "")
    if "cite" not in raw.lower():
        return raw
    cleaned = _CITE_MARK.sub("", raw)
    # После вырезания остаются «двойные» пробелы и пробел перед точкой.
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    cleaned = re.sub(r"\s+([.,;:!?])", r"\1", cleaned)
    cleaned = re.sub(r"\(\s*\)", "", cleaned)
    return cleaned


def has_citations(text: str) -> bool:
    """В тексте есть ссылки сервиса «[cite: N]»."""
    return bool(_CITE_MARK.search(str(text or "")))


def cut_chat_tail(text: str) -> str:
    """Отрезает всё, что приехало в чат после «===КОНЕЦ ОТВЕТА===» (v54).

    Выгрузка AG-1: после маркера окончания ответа в тот же текст попал
    интерфейс сервиса — «ИИ может ошибаться. Проверяйте его ответы.», «Ваш
    файл · Доступно только вам», «Page 18», «Показать все». Этот хвост
    попадал в «УСТАНОВИЛ» и печатался в PNG отдельным абзацем.

    Если маркера нет, из текста всё равно выбрасываются отдельные строки
    интерфейса (`_CHAT_UI_LINE`): они не являются содержанием документа.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    kept: list = []
    for line in raw.splitlines():
        if _ANSWER_END_LINE.match(line.strip()):
            break                     # конец ответа — дальше только чат
        kept.append(line)
    body = "\n".join(kept)
    if not body.strip():
        body = raw
    lines = [line for line in body.splitlines()
             if not _CHAT_UI_LINE.match(line.strip())]
    return "\n".join(lines)


def strip_chat_offers(text: str) -> str:
    """Убирает из текста предложения помощи и вопросы к пользователю (v54).

    Замечание по выгрузке: в пункт 4 «ПОСТАНОВИЛ» попал ответ ИИ на реплику
    пользователя — «Jonathan Raine Я могу составить для вас исковое заявление
    в суд или официальное обращение по данному инциденту. Напишите, если вам
    требуется шаблон документа или дополнительная консультация по статьям
    законов.» Это не решение прокурора, а реплика чата.

    Режем по предложениям: остаются только те, где нет оборота помощи.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    out: list = []
    for line in raw.splitlines():
        if not line.strip():
            out.append(line)
            continue
        kept = []
        # Оборот интерфейса («ИИ может ошибаться. Проверяйте его ответы.»)
        # может занимать целое предложение — убираем его ДО деления на фразы.
        line = _UI_INSIDE.sub(" ", line)
        for sentence in re.split(r"(?<=[.!?…])\s+", line.strip()):
            body = sentence.strip()
            if not body:
                continue
            if _CHAT_OFFER.search(body):
                continue
            if kept and _CHAT_OFFER_TAIL.match(body):
                continue
            kept.append(body)
        if kept:
            out.append(" ".join(kept))
    return "\n".join(out)


def strip_placeholder_sentences(text: str) -> str:
    """Убирает «Установлено, что … удо не видел …» — ответ на анкету (v54).

    Выгрузка AG-2: «Установлено, что LSPD удо не видел (ID-Card,
    удостоверение № 25013, 150066.» — в «УСТАНОВИЛ» это оборванный пересказ
    ответа заявителя на вопрос «видели ли удостоверение», а не факт дела.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    out: list = []
    for line in raw.splitlines():
        if not line.strip():
            out.append(line)
            continue
        kept = [s for s in re.split(r"(?<=[.!?…])\s+", line.strip())
                if s.strip() and not _PLACEHOLDER_SENTENCE.search(s)]
        if kept:
            out.append(" ".join(kept))
    return "\n".join(out)


#: Внутренний заголовок самого документа, попавший в текст (v54).
#: Выгрузка IAD: в «Обстоятельства» приехал кусок бланка —
#: «ПОСТАНОВЛЕНИЕ INTERNAL AFFAIRS DIVISION» и «УСТАНОВИЛ:», а ниже снова
#: пошёл текст по существу. В PNG «Обстоятельства» обрывались, и внутренний
#: блок печатался отдельной строкой посреди абзаца.
_INNER_DOC_HEADER = re.compile(
    # «ПОСТАНОВЛЕНИЕ INTERNAL AFFAIRS DIVISION» — название подразделения
    # капсом, без номера: это шапка, а не маркер начала документа.
    r"^постановлени\w*\s+[a-zа-яё][a-zа-яё\s\-]{3,}$"
    r"|^(?:установил|постановил|определил|решил|обстоятельства|"
    r"постановляющая часть|резолютивная часть)\s*:?\s*$",
    re.IGNORECASE,
)


def strip_inner_headings(text: str) -> str:
    """Убирает из текста внутренние заголовки бланка (v54).

    «ПОСТАНОВЛЕНИЕ INTERNAL AFFAIRS DIVISION» и «УСТАНОВИЛ:» — это шапка и
    рубрика того самого документа, который печатается. В значении поля
    («Обстоятельства») они не нужны: строка «УСТАНОВИЛ:» посреди абзаца
    выглядит как обрыв документа.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    kept = [line for line in raw.splitlines()
            if not _INNER_DOC_HEADER.match(line.strip())]
    return "\n".join(kept)


#: Строка-рубрика «УСТАНОВИЛ:» внутри значения поля.
_INNER_USTANOVIL_LINE = re.compile(r"^\s*установил\s*:?\s*$", re.IGNORECASE)


def strip_raw_before_ustanovil(text: str) -> str:
    """Оставляет только официальный текст после рубрики «УСТАНОВИЛ:» (v54).

    Выгрузка IAD: в «Обстоятельства» попали и сырая фраза заявителя
    («Данный сотрудник открыл огонь на поражение по своим сотрудникам без
    причины»), и следом сам раздел документа («10 ноября 2026 года в
    отношении сотрудника … было инициировано дисциплинарное производство…»).
    В бланке это два почти одинаковых абзаца подряд, а сырая фраза ещё и с
    разговорным «без причины».

    Если после рубрики идёт содержательный текст — он и есть обстоятельства.
    """
    raw = str(text or "")
    if not raw.strip():
        return raw
    lines = raw.splitlines()
    for index, line in enumerate(lines):
        if _INNER_USTANOVIL_LINE.match(line):
            tail = "\n".join(lines[index + 1:]).strip()
            if len(tail.split()) > 15:      # это полноценный абзац, а не обрывок
                return tail
    return raw


def clean_document_text(text: str) -> str:
    """Полная чистка текста документа от «части чата» (v54).

    Один вход для всех полей: ссылки сервиса, хвост после конца ответа,
    предложения помощи, заглушки анкеты. Промт это тоже запрещает, но промт
    ИИ выполняет не всегда, а бланк печатается из его ответа.
    """
    result = str(text or "")
    if not result.strip():
        return result
    result = cut_chat_tail(result)
    result = strip_citations(result)
    result = strip_chat_offers(result)
    result = strip_placeholder_sentences(result)
    result = strip_ui_noise_inside(result)
    result = re.sub(r"[ \t]{2,}", " ", result)
    return result.strip()


def leaked_chat_text(doc) -> str:
    """Возвращает служебную строку чата, попавшую в текст документа (v37)."""
    for label, value in (("Обстоятельства", doc.get("situation")),
                         ("Постановляющая часть", " ".join(getattr(doc, "points", []) or [])),
                         ("Нормативное основание", doc.get("legal_basis")),
                         ("Дополнительно", doc.get("extra"))):
        for line in str(value or "").splitlines():
            if is_chat_instruction(line):
                return f"{label}: «{line.strip()[:120]}…»"
    return ""


def check_ooc(doc: "Postanovlenie") -> list:
    """Замечания «в документе внеигровая лексика» (v36)."""
    issues: list = []
    for label, value in (("Обстоятельства", doc.get("situation")),
                         ("Постановляющая часть", " ".join(doc.points or [])),
                         ("Нормативное основание", doc.get("legal_basis")),
                         ("Дополнительно", doc.get("extra"))):
        found = ooc_terms(value)
        if found:
            issues.append(
                f"{label}: внеигровые термины ({', '.join(found)}) — в официальном "
                "документе их быть не должно. Замените на правовые формулировки: "
                "«в отсутствие законных и фактических оснований», «при отсутствии "
                "надлежащих правовых оснований».")
    return issues


def check_document(doc: "Postanovlenie", regulation=None) -> list:
    """Проверяет постановление по уставу. Возвращает список замечаний.

    Каждое замечание — готовый текст для человека. Пустой список = замечаний
    нет. Именно эти замечания сохраняются в `Проверка.txt` и показываются
    в клиенте, чтобы документ не уходил с юридической ошибкой.

    Проверяется то, что реально нашлось в присланном анализе:
    * вилка взысканий из устава (п. 4.1 и перечни «[ … ]» у пунктов);
    * смешение процессуальных и материальных норм;
    * ограничения по должности (п. 4.4 — понижение только Шериф/заместители/
      Ассистент Шерифа);
    * «чёрный список» — только по п. 4.5 (3 строгих выговора или
      несдача переаттестации);
    * пункты устава, которые не удалось найти в базе.
    """
    issues: list = []
    basis = doc.get("legal_basis")
    clause = doc.get("violation_clause")

    # 1. Вилка наказаний по уставу.
    allowed = allowed_penalties_for(clause, regulation)
    penalty = normalize_penalty(doc.get("penalty")) or doc.get("penalty")
    if allowed and penalty and penalty not in allowed:
        issues.append(
            f"Взыскание «{penalty}» не предусмотрено за указанные пункты. "
            f"Устав допускает: {', '.join(allowed)}.")

    # 2. Процессуальные нормы не обосновывают дисциплинарное взыскание.
    procedural = procedural_parts(basis)
    if procedural:
        issues.append(
            "Процессуальный кодекс не может быть основанием дисциплинарного "
            "взыскания — он регулирует порядок, а не составы проступков. "
            "Уберите из основания: " + "; ".join(procedural) + ".")

    # 3. Ограничения по должности (п. 4.4 устава).
    rank = (doc.get("author_rank") or "").lower()
    if penalty in ("понижение", "увольнение") and rank:
        for limited, words in _RANK_LIMITS:
            if penalty == limited and not any(word in rank for word in words):
                issues.append(
                    f"«{penalty.capitalize()}» по п. 4.4 устава назначают только "
                    "Шериф, его заместители и Ассистент Шерифа. Укажите это "
                    "в документе или выберите взыскание в рамках полномочий.")

    # 4. Чёрный список — только по п. 4.5.
    black_list = "черн" in (str(doc.get("penalty")) + str(doc.get("extra"))).lower()
    if black_list and not re.search(r"\b4\.5\b", str(basis) + str(clause)):
        issues.append(
            "Занесение в чёрный список устав предусматривает только по п. 4.5 "
            "(3 строгих выговора или несдача переаттестации). Укажите это "
            "основание или уберите чёрный список.")

    # 5. Взыскание с «дополнительными» словами, которых нет в уставе (v37).
    #    В выгрузке было «устный выговор с занесением в личное дело» — устав
    #    такого вида взыскания не знает (п. 4.1), есть только устный выговор.
    extra_penalty = re.search(r"с\s+занесением\s+в\s+личное\s+дело",
                              " ".join([str(doc.get("penalty"))]
                                       + list(doc.decision_points())).lower())
    if extra_penalty:
        issues.append(
            "Взыскание указано с добавлением «с занесением в личное дело», "
            "а устав (п. 4.1) такого вида не предусматривает: есть только "
            "устный выговор и строгий выговор. Оставьте формулировку устава.")

    # 6. Пункт устава — заглушка вместо номера.
    if clause and is_vague_clause(clause):
        issues.append(
            "Нарушенный пункт устава не указан («по обстоятельствам, указанным "
            "в заявке»). Постановление должно ссылаться на конкретный пункт "
            "главы VIII — иначе взыскание назначено без состава проступка.")

    # 7. Кодекс этики — это п. 8.6 устава, а не отдельный акт.
    if "этическ" in basis.lower() and not re.search(r"\b8\.6\b", str(clause)):
        issues.append(
            "Кодекс этики и служебного поведения — это пункт 8.6 Устава LSCSD. "
            "Ссылку «Этический кодекс штата» замените на «пункт 8.6 "
            "Устава Los Santos County Sheriff Department».")

    # 8. Служебный текст чата попал в документ (v37).
    leaked = leaked_chat_text(doc)
    if leaked:
        issues.append(
            "В текст документа попала служебная инструкция из чата: " + leaked +
            " Её нужно удалить — в постановлении должен быть только текст решения.")

    # 9. Внеигровая лексика (IC/OOC) — промт 1.19 п. 19.
    issues.extend(check_ooc(doc))

    # 10. Пункты устава, которые не найдены в базе.
    if regulation is not None and clause:
        for number in _clause_numbers(clause):
            found = any(str(text).strip().startswith(number)
                        for text in getattr(regulation, "articles", {}).values())
            if not found:
                issues.append(f"Пункт {number} в уставе не найден — проверьте номер.")

    return issues


# --------------------------------------------------------------------------- #
#  История сформированных постановлений
# --------------------------------------------------------------------------- #

#: Виды постановлений в истории (v41). Раньше и IAD, и Прокурор писали в одну
#: папку `postanovleniya/`, из-за чего:
#: * список истории перемешивался — в форме IAD показывались постановления
#:   Прокурора, а «Загрузить в форму» падал (документ собирался моделью IAD);
#: * нумерация была общей: создав IAD-постановление, прокурор получал номер
#:   «вторым», хотя нумерация у ведомств своя (AG-1, LSCSD-IAD-1).
HISTORY_KIND_IAD = "iad"
HISTORY_KIND_GOV = "gov"


class DocumentHistory:
    """История постановлений: JSON-файлы в папке `postanovleniya`.

    Требование задачи: «вызвать старое заполнение шаблона и внести правки».
    Поэтому каждая запись — полный снимок полей, а не только имя файла.

    v41: у каждого вида постановлений СВОЯ папка и СВОЙ загрузчик:
    `postanovleniya/history/iad/*.json` и `postanovleniya/history/gov/*.json`.
    Старые записи из корня папки подхватываются только теми формами, чей
    загрузчик может их разобрать.
    """

    #: Вид истории по умолчанию. Подкласс перекрывает через `KIND` (v41).
    KIND = HISTORY_KIND_IAD

    def __init__(self, folder: Path, kind: str = ""):
        # `kind` экземпляра не должен перебивать KIND подкласса: иначе
        # GovHistory писал бы в папку IAD (ошибка ловилась тестами v41).
        self.kind = kind or type(self).KIND
        root = Path(folder)
        # Новые записи — в подпапке вида; корень читаем только как «старые».
        self.legacy_folder = root
        self.folder = root / "history" / self.kind
        self.folder.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------ загрузчик

    def _parse(self, data: dict):
        """Собирает документ из снимка истории. Переопределяется в v41."""
        return Postanovlenie.from_dict(data)

    #: Поля, которые пишет только модель Прокурора (v41). Запись с ними —
    #: постановление Прокурора, форме IAD она не показывается.
    GOV_ONLY_KEYS = ("doc_stage", "prosecutor_facts", "appeal_raw",
                     "prosecutor_rank", "appeal_subject")

    def _belongs(self, data: dict) -> bool:
        """Запись относится к этому виду истории (v41).

        История IAD принимает всё, кроме постановлений Прокурора: они лежат в
        своей папке, но старые записи могли остаться в корне. Без этой
        проверки форма IAD собирала бы из них документ IAD.
        """
        if not isinstance(data, dict):
            return False
        # Признак только по полям: номер «AG-1» может стоять и в бланке IAD
        # (так бывало в тестах и старых выгрузках), поля «вида решения» —
        # только у Прокурора.
        return not any(key in data for key in self.GOV_ONLY_KEYS)

    def _path(self, stamp: float, folder: Path | None = None) -> Path:
        name = datetime.fromtimestamp(stamp).strftime("%Y%m%d-%H%M%S")
        path = Path(folder or self.folder) / f"{name}.json"
        n = 1
        while path.exists():
            path = self.folder / f"{name}-{n}.json"
            n += 1
        return path

    #: v51: папка «черновиков» истории. Снимок формы, сделанный по кнопке
    #: «Сформировать» ДО ответа ИИ, живёт здесь. Как только приходит ответ,
    #: запись переезжает в обычную историю и черновик исчезает — в списке
    #: остаётся ровно одна строка на документ.
    DRAFT_FOLDER = "_draft"

    def save(self, doc: Postanovlenie, draft: bool = False) -> Path:
        """Пишет снимок документа в историю (v51: с черновиками).

        Замечание пользователя (п.4): «Во вкладке „История“, „Постановление
        Обращение №“ записи дублируются — всегда 2 одинаковые». Причина: на
        один этап историю писали ДВАЖДЫ — форма по «Сформировать» (вид решения
        ещё «Определит ИИ …») и разбор ответа ИИ (`main.py`). Ключ дедупликации
        в `items()` — весь снимок, а `created_at` переписывается заново, поэтому
        два файла никогда не совпадали и обе строки показывались.

        Теперь снимок формы пишется как ЧЕРНОВИК (`draft=True`), а `items()`
        его не показывает. Ответ ИИ вызывает `replace()`, который черновик
        удаляет.
        """
        folder = self.drafts_folder if draft else self.folder
        folder.mkdir(parents=True, exist_ok=True)
        path = self._path(doc.created_at or time.time(), folder)
        path.write_text(
            json.dumps(doc.history_payload(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return path

    @property
    def drafts_folder(self) -> Path:
        """Папка черновиков истории (v51)."""
        return self.folder / self.DRAFT_FOLDER

    def replace(self, doc: Postanovlenie) -> Path:
        """Ответ ИИ заменил черновик этой заявки — одна запись (v51, п.4).

        Удаляем ВСЕ черновики вида (их не должно быть больше одного, но битый
        прошлый прогон мог оставить несколько) и пишем единственный снимок в
        обычную историю.
        """
        self.clear_drafts()
        return self.save(doc)

    def clear_drafts(self) -> int:
        """Убирает черновики истории. Возвращает число удалённых файлов."""
        removed = 0
        try:
            paths = sorted(self.drafts_folder.glob("*.json"))
        except Exception:
            return 0
        for path in paths:
            try:
                path.unlink()
                removed += 1
            except Exception:
                diag_event("history.draft_delete_failed", path=str(path))
        if removed:
            diag_event("history.drafts_cleared", count=removed)
        return removed

    def items(self) -> list:
        """Свежие записи первыми: [(path, dump, документ)].

        v41: читаются своя папка вида и (для совместимости) старый корень.
        Одна и та же запись не показывается дважды: если снимок лежит и в
        старом корне, и в подпапке вида (или сохранён дважды без изменений),
        остаётся один — самый свежий файл.
        """
        seen: dict = {}
        order: list = []
        candidates = []
        for path in sorted(self.folder.glob("*.json")):
            # v51: черновики («Сформировать» без ответа ИИ) в списке не видны —
            # иначе на каждый этап было две одинаковые строки (п.4).
            if path.parent == self.drafts_folder:
                continue
            candidates.append(path)
        for path in sorted(self.legacy_folder.glob("*.json")):
            # Корень остаётся «старым» хранилищем: подхватываем только то,
            # что этот вид истории умеет разобрать.
            candidates.append(path)
        for path in candidates:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(data, dict) or not self._belongs(data):
                continue
            try:
                doc = self._parse(data)
            except Exception:
                continue
            if doc is None:
                continue
            # v51 (замечание п.4): ключ — ДОКУМЕНТ, а не путь к файлу.
            # Раньше в ключ входило имя файла и `created_at`, который
            # переписывался при каждом сохранении, поэтому один и тот же
            # документ, записанный дважды, давал две одинаковые строки.
            # Теперь сравнивается содержимое без служебного времени, а из
            # совпавших файлов остаётся самый свежий.
            key = self._record_key(data, doc)
            old_path = seen.get(key)
            if old_path is not None:
                try:
                    if old_path.stat().st_mtime >= path.stat().st_mtime:
                        continue
                    order = [(k, p, d, o) for k, p, d, o in order if k != key]
                except Exception:
                    continue
            seen[key] = path
            order.append((key, path, data, doc))
        return [(path, data, doc) for _key, path, data, doc in order]

    @staticmethod
    def _record_key(data: dict, doc) -> str:
        """Подпись записи истории: документ без служебного времени (v51)."""
        payload = {k: v for k, v in (data or {}).items()
                   if k not in ("created_at", "human_created")}
        try:
            body = json.dumps(payload, ensure_ascii=False, sort_keys=True)
        except Exception:
            body = str(payload)
        return body

    def labels(self) -> list:
        """Подписи записей истории: «дата · номер · нарушитель» (v41).

        v51 (замечание п.4) закрыт на уровне записей: на один документ в
        истории остаётся ОДНА строка (`save(draft=True)` в форме и `replace()`
        по ответу ИИ), поэтому «две одинаковые строки» больше не появляются.
        Формат подписи прежний — по нему пользователь и искал записи.
        """
        labels = []
        for _path, data, doc in self.items():
            created = _clean(data.get("human_created")) or "—"
            num = doc.get("doc_number") or "без номера"
            who = doc.get("subject_name") or "—"
            labels.append(f"{created} · {num} · {who}")
        return labels

    def used_numbers(self) -> list:
        """Номера этого вида постановлений (v41).

        Замечание: «создаю постановление для IAD, и если делаю постановление
        Прокурора следующим, то номер уже второй». Проверка идёт по своим
        номерам: у Прокурора AG-1…, у IAD LSCSD-IAD-1…, они не пересекаются.
        """
        # Повторы допустимы (две редакции одного документа): `auto_number`
        # берёт максимум, поэтому важен только состав своих номеров.
        numbers = []
        for _p, _d, doc in self.items():
            number = doc.get("doc_number")
            if number:
                numbers.append(number)
        return numbers

    def load_index(self, index: int):
        items = self.items()
        if 0 <= index < len(items):
            return items[index][2]
        return None

    # ------------------------------------------------------------ удаление (v38)
    #
    # Замечание: «в «История» добавь возможность удалять «Постановления»».
    # Удаляем ИМЕННО запись истории (json-снимок полей). Папку документа
    # (<номер>/ с PNG и текстами) не трогаем — там готовый бланк, который
    # пользователь мог уже отправить; в диалоге это прямо сказано.

    def path_at(self, index: int) -> Path | None:
        items = self.items()
        if 0 <= index < len(items):
            return items[index][0]
        return None

    def label_at(self, index: int) -> str:
        labels = self.labels()
        if 0 <= index < len(labels):
            return labels[index]
        return ""

    def delete_index(self, index: int) -> bool:
        """Удаляет запись истории по индексу в списке (свежие первыми)."""
        path = self.path_at(index)
        if path is None:
            return False
        try:
            path.unlink()
        except Exception:
            diag_event("history.delete_failed", path=str(path))
            return False
        diag_event("history.deleted", path=str(path))
        return True

    def delete_all(self) -> int:
        """Очищает историю целиком. Возвращает число удалённых записей."""
        removed = 0
        for path in sorted(self.folder.glob("*.json")):
            try:
                path.unlink()
                removed += 1
            except Exception:
                diag_event("history.delete_failed", path=str(path))
        diag_event("history.cleared", removed=removed)
        return removed


# --------------------------------------------------------------------------- #
#  Правила ведомства: подстановка реквизитов и проверка по Уставу
# --------------------------------------------------------------------------- #

class Regulation:
    """Правила конкретного ведомства (пока IAD/LSCSD, дальше — универсально).

    Читает выгруженный JSON законодательной базы (data/reestr/*.json) и умеет
    подставить реквизиты вроде «пункт 19) части 1 статьи а» и проверить,
    что такой пункт в уставе действительно есть.
    """

    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else None
        self.title = ""
        self.sections: list = []
        self.articles: dict = {}
        if self.path and self.path.exists():
            self._load(self.path)

    def _load(self, path: Path) -> None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return
        self.title = _clean(data.get("title"))
        self.sections = data.get("sections") or []
        for section in self.sections:
            text = _clean(section.get("text"))
            n = section.get("n")
            if text:
                self.articles[str(n)] = text

    def clause_text(self, clause: str, act_words: str = "") -> str:
        """Ищет пункт устава по строке вида «19) части 1 статьи а».

        Возвращает точный фрагмент текста устава, если он найден, иначе "".
        Нужно для того, чтобы в постановлении была дословная норма, а не
        пересказ ИИ.
        """
        needle = _clean(clause)
        if not needle:
            return ""

        # Формат LSCSD: пункт устава — «3.1», «4.1», «10.6». Ищем дословно по
        # началу текста раздела: в уставе нет деления на статьи и части,
        # поэтому прежний шаблон «пункт 19) части 1 статьи а» тут не работает.
        dotted = re.search(r"\b(\d{1,2}\.\d{1,2})\b", needle)
        if dotted:
            number = dotted.group(1)
            for text in self.articles.values():
                if text.strip().startswith(number):
                    return text[:600]
            return ""

        item = re.search(r"(\d+)\s*\)", needle)
        article = re.search(r"статьи?\s*([0-9A-Za-zА-Яа-я]+)", needle, re.IGNORECASE)
        if not item and not article:
            return ""
        want_item = item.group(1) if item else ""
        want_article = article.group(1).lower() if article else ""
        for text in self.articles.values():
            low = text.lower()
            if want_item and f"{want_item})" not in low:
                continue
            if want_article and f"статья {want_article}" not in low and f"статьи {want_article}" not in low:
                continue
            return text[:600]
        return ""

    def penalties(self) -> list:
        """Перечень взысканий из гл. IV (п. 4.1) устава, если он есть."""
        for text in self.articles.values():
            low = text.lower()
            if "4.1" in text and "взыскан" in low:
                inside = text.split(":", 1)[-1]
                inside = re.sub(r"нажмите.*", " ", inside, flags=re.IGNORECASE)
                inside = inside.replace("\n", " ")
                parts = re.split(r"[/,;]|\sи\s", inside)
                clean = []
                for part in parts:
                    item = _clean(part).strip(". \"'")
                    item = re.sub(r"^(цитата|перечень)[:\s]*", "", item, flags=re.IGNORECASE)
                    if item and len(item) < 40 and item.lower() not in {c.lower() for c in clean}:
                        clean.append(item)
                if clean:
                    return clean
        return list(PENALTIES)


def default_regulation_path(base_dir: Path) -> Path | None:
    folder = Path(base_dir) / "reestr"
    if not folder.is_dir():
        return None
    for path in sorted(folder.glob("*.json")):
        return path
    return None
