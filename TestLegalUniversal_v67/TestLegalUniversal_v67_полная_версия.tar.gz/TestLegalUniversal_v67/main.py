"""Legalyze Win10/Win11 diagnostic client.
See README.md for isolation, known causes, logging and Windows validation steps.
The production client directory is deliberately untouched.
"""
import sys
import ctypes

def suppress_console():
    """Скрывает и отсоединяет любое консольное окно на Windows при старте (v25)."""
    if sys.platform == "win32":
        try:
            hwnd = ctypes.windll.kernel32.GetConsoleWindow()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 0)  # SW_HIDE
            ctypes.windll.kernel32.FreeConsole()
        except Exception:
            pass

suppress_console()

import diagnostics as diag
diag.setup()
from diagnostics import stage


def _fatal_missing_dependency(exc):
    """Понятное сообщение вместо молчаливого выхода (v26).

    Раньше при нехватке PyQt6-WebEngine приложение умирало на импорте
    `qt_browser`, и единственным следом была строка в логе:
    `ModuleNotFoundError` + `qt_browser.py line 18` — со стороны это выглядело
    как «программа не запускается и ничего не говорит». Теперь причина
    называется прямо, с командой установки, а лог остаётся на месте.
    """
    try:
        diag.exception("main.import_qt_browser")
    except Exception:
        pass
    message = (
        "Legalyze не может запуститься: не установлен компонент PyQt6-WebEngine.\n\n"
        f"Техническая причина: {exc}\n\n"
        "Установите зависимости из папки программы:\n"
        "    pip install -r requirements.txt\n\n"
        "Если PyQt6 уже стоял, доставьте отдельно:\n"
        "    pip install PyQt6-WebEngine\n\n"
        "Логи: " + str(getattr(diag, "LOG_DIR", ""))
    )
    shown = False
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                None, message, "Legalyze — не хватает компонента", 0x10)
            shown = True
        except Exception:
            shown = False
    if not shown:
        # Консоль к этому моменту уже отсоединена — пишем в поток ошибок и в лог.
        try:
            sys.stderr.write(message + "\n")
            sys.stderr.flush()
        except Exception:
            pass


try:
    from qt_browser import BrowserPane, DEBUG_PORT, READY_SCRIPT
except ModuleNotFoundError as _qt_exc:
    _fatal_missing_dependency(_qt_exc)
    sys.exit(2)
except Exception as _qt_exc:  # noqa: BLE001 — прочее тоже не должно быть «тишиной»
    _fatal_missing_dependency(_qt_exc)
    sys.exit(2)

import storage_paths
# v20: приборная панель браузера. Импорт — сразу после `diagnostics.setup()`:
# ниже, рядом с `diag.install_http()`, модуль уже включается в работу. Собирает
# то, чего не было в логе: «куда просили поставить окно, где оно оказалось и
# почему разошлось», хронологию «съехало — вернулось» в миллисекундах и
# доказательства экспорта файлов.
import browser_trace as btrace
import machine_profile as mp
# v27: постановления (данные + рендер A4 в PNG + форма-конструктор).
import postanovlenie_data as pdoc
import doc_render as prender
from postanovlenie_ui import PostanovlenieDialog
from postanovlenie_prokuror_ui import PostanovlenieProkuroraDialog
import ogp_appeal_ui
import ogp_appeal as ogp_appeal_mod
import ogp_chain
import ogp_flow
import ogp_stages
import postanovlenie_prokuror_data as pgov
import gov_case as pcases
import doc_layout as dl
import pending_send as psend
import ai_request
import chat_ready as cread
import upload_gate as ugate

import json
import os
from datetime import datetime
import random
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import urllib.parse
import ctypes
import threading
import hashlib
import math
import base64
from ctypes import wintypes
from pathlib import Path

from websocket import create_connection
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QCheckBox, QDialog, QComboBox,
    QFormLayout, QMessageBox, QInputDialog, QGraphicsDropShadowEffect,
    QSizePolicy, QProgressDialog, QAbstractButton, QFrame, QScrollArea,
)
from PyQt6.QtCore import (QTimer, QThread, pyqtSignal, Qt, QPoint, QRectF, QLockFile, pyqtSlot,
                          QObject, QEvent)
from PyQt6.QtGui import (
    QFont, QPainter, QColor, QPen, QBrush, QPainterPath, QKeySequence, QIcon,
)

from config import (
    load_config, save_config, get_template_filled, get_hotkeys_configured,
    template_profiles, active_profile_name, active_template, add_profile,
    select_profile, rename_profile, delete_profile, DEFAULT_PROFILE_NAME,
    postanovlenie_dir,
    CHAT_URL,
    APP_DIR, DATA_DIR, PROMPTS_DIR,
    TEMPLATE_FILE, normalize_template, ICON_FILE,
    ensure_template_file, write_template_file, save_template,
)
from crypto_utils import decrypt_data_auto
from updater import restart_app

from secure_store import (
    SecureWorkspace, PromptCacheManifest,
    encrypt_blob, decrypt_blob,
    purge_plaintext_artifacts, shred_file,
    sha256_bytes, template_hash,
)

# FPDF нужен только как legacy-фолбэк для старых текстовых .enc (ТЗ 1.3).
try:
    from fpdf import FPDF
except Exception:
    diag.exception("main.py:65")
    FPDF = None


diag.install_http()
# Сбор поведения браузера: та же папка сессии, что у диагностики. Отказ сбора
# (нет прав на запись) не мешает приложению работать — он просто выключится.
BROWSER_TRACE_ON = bool(btrace.install())

#: v55: единственный адрес, который открывает приложение. Задан в `config.py`
#: (`CHAT_URL`) и больше нигде не дублируется; вторичных адресов нет.
URL = CHAT_URL
#: v51: сколько ждать мягкую перезагрузку страницы ИИ («чистый чат») прежде
#: чем гасить дерево браузера целиком. Страница и ворота готовности обычно
#: укладываются в 10–20 с; таймаут только страховка.
FRESH_CHAT_RELOAD_TIMEOUT = 30
#: v51: пауза перед очисткой чата после готового ответа ИИ, с.
FRESH_CHAT_AFTER_ANSWER_DELAY = 4
PROFILE = APP_DIR / "qtwebengine-profile"
# Профиль НАСТОЯЩЕГО браузера: отдельный и постоянный (согласие/вход — один раз).
BROWSER_PROFILE = APP_DIR / "browser-profile"






X, Y, W, H = 1426, 200, 453, 735

# ============================================================================
# НАСТРОЙКИ РАСПОЛОЖЕНИЯ ОБЪЕКТОВ — правьте числа ТОЛЬКО здесь и перезапускайте
# ============================================================================
# Значения НЕ угаданы: сдвиг окна подобран на Windows в измерительной сборке
# pre14 (режим администратора). Остальное — те же ползунки, но числами.

# --- окно браузера внутри окна программы, DIP (сдвиг и изменение размера) ---
BROWSER_DX = -10     # сдвиг окна браузера по X: -10 = влево, +10 = вправо
BROWSER_DY = -24     # сдвиг окна браузера по Y: -20 = вверх, +20 = вниз
BROWSER_DW = 0       # изменить ширину окна браузера (0 = не менять)
BROWSER_DH = 0       # изменить высоту окна браузера (0 = не менять)

# --- раскладка страницы ---
PAGE_ZOOM = 0.667    # нативный зум страницы (0.667 = 67 %)
WIDTH_DELTA = 0      # поправка ширины раскладки, CSS px
HEIGHT_DELTA = 0     # поправка высоты раскладки, CSS px

# --- сдвиг содержимого страницы, CSS px (0 = страницу не трогаем вообще) ---
PAGE_OFFSET_X = 0    # сдвинуть всю страницу вправо/влево
PAGE_OFFSET_Y = 0    # сдвинуть всю страницу вверх/вниз
PAD_BOTTOM = 0       # добавить отступ снизу страницы
SCROLL_X = 0         # прокрутка сразу после загрузки
SCROLL_Y = 0

# --- сдвиг ТОЛЬКО поля ввода, CSS px ---
INPUT_DX = 0
INPUT_DY = 0
INPUT_SELECTOR = ('textarea, div[contenteditable="true"], rich-textarea, '
                  '[role="textbox"], input[type="text"]')

# --- речевой ввод и внешний вид страницы (v18) ---
SPEECH_LANG = "ru-RU"     # язык распознавания речи. Приложение русское,
                          # поэтому русский имеет ПРИОРИТЕТ над языком Windows:
                          # у пользователя из США распознавание всё равно будет
                          # по-русски. Изменить можно и в config.json
                          # (ключ speech_lang).
ACCEPT_LANGUAGES = ""     # Accept-Language профиля. Пусто = "<язык>,<язык>,en".
FORCE_LIGHT_THEME = True  # светлая тема страницы. На Windows с тёмной темой
                          # Chrome иначе рисует чат тёмным (у разных
                          # пользователей получалось по-разному).
AUTO_INSTALL_BROWSER = True  # если настоящего Chrome нет — предложить скачать
                          # официальный Chrome for Testing (это и есть
                          # «установка речевого ввода»: в этом браузере
                          # работает ШТАТНЫЙ микрофон страницы, и никакие
                          # речевые пакеты Windows не нужны).
REVIVE_AFTER_SHOW = True  # «оживлять» браузер после сворачивания/разворачивания
                          # окна: иначе вместо страницы остаётся чёрный фон.
REVIVE_STEPS = (0, 150, 350, 600, 900, 1300, 1800, 2400)  # мс: Chromium
                          # применяет перенос окна и перерисовку не мгновенно.
                          # Последний шаг — жёсткий предел: GUI прогрузки
                          # снимается в любом случае.
REVIVE_SETTLE_N = 3       # сколько ОДИНАКОВЫХ измерений подряд считать, что
                          # браузер устоялся (innerWidth, dpr, размер окна)
REVIVE_MIN_MS = 1600      # раньше этого срока GUI прогрузки НЕ снимаем даже
                          # при совпавших измерениях: возмущение у Chromium
                          # начинается позже первых кадров (по приёмке — около
                          # двух секунд), поэтому «три одинаковых кадра на
                          # 300-й миллисекунде» ещё ни о чём не говорят.
                          # 1600 мс (v19): 1200 оказалось мало на машинах,
                          # где объекты встают на место дольше.
REVIVE_REVEAL_GATE_MS = 700  # v19: перед тем как снять GUI прогрузки, ждём
                          # `readyState == "complete"` — но не дольше этого
                          # времени, чтобы индикатор не залип навсегда.
REVIVE_FINAL_MS = 180     # пауза после финальной правки: кадр должен лечь
REVIVE_TITLE = "Подготовка страницы"      # тот же индикатор, что на старте
REVIVE_MESSAGE = "Пожалуйста, подождите…"

# --- определение и исправление поверхности страницы (v19) ---
SURFACE_READY_TIMEOUT = 90    # сколько максимум ждать настоящей готовности чата
SURFACE_STABLE_ROUNDS = 2     # сколько ОДИНАКОВЫХ замеров подряд считать
                              # страницу устоявшейся (готовность = «complete»
                              # плюс поле ввода плюс совпавший замер)
SURFACE_POLL_MS = 500         # период опроса состояния страницы
THEME_MAX_REPAIRS = 4         # сколько раз подряд приводить тему к светлой,
                              # если страница всё равно тёмная
UPLOAD_BLOCK_THRESHOLD = 6    # столько пустых попыток прикрепить файлы подряд
                              # достаточно, чтобы считать: на ЭТОЙ странице
                              # вложение не работает
UPLOAD_BLOCK_LOG_EVERY = 15.0  # и не чаще раза в столько секунд писать в лог

# --- поведение лишних окон браузера ---
CLOSE_STRAY_WINDOWS = True    # после скрытия закрывать лишнее окно приложения
TASKBAR_DELETE_TAB = False    # v22 (ОШИБКИ.md № 10): отключаем COM ITaskbarList.
                              # Стиль WS_EX_TOOLWINDOW гарантированно и чисто
                              # скрывает окно из панели задач без вызовов COM,
                              # без риска 0xc000001d (Illegal instruction) и
                              # без крашей ctypes.
# =========================== конец блока настроек ============================

# Журнал pid своего браузера: по нему добиваемся то, что осталось от прошлого
# запуска (иначе его окно висит в панели задач и мешает синглтону профиля).
BROWSER_PIDS_FILE = APP_DIR / "browser-pids.json"

PAGE_TUNE_JS = """
(function(){
  try {
    var D = document, id = 'legalyze-tune-css';
    var s = D.getElementById(id);
    var offX = %d, offY = %d, padB = %d, inX = %d, inY = %d;
    var sel = %s;
    if (!offX && !offY && !padB && !inX && !inY) {
      if (s && s.parentNode) { s.parentNode.removeChild(s); }
      return {ok: true, removed: true};
    }
    if (!s) {
      s = D.createElement('style');
      s.id = id;
      (D.head || D.documentElement).appendChild(s);
    }
    var css = '';
    if (offX || offY) {
      css += 'html, body { transform: translate(' + offX + 'px, ' + offY + 'px); }';
    }
    if (padB) {
      css += 'html, body { padding-bottom: ' + padB + 'px !important; }';
    }
    if (inX || inY) {
      css += sel + ' { transform: translate(' + inX + 'px, ' + inY + 'px) !important; }';
    }
    s.textContent = css;
    var out = {ok: true, len: css.length};
    if (%d || %d) {
      window.scrollTo(%d, %d);
      out.scrolled = true;
    }
    return out;
  } catch (e) {
    return {ok: false, error: String(e)};
  }
})()
"""


def page_tune_js(with_scroll=True):
    """Сдвиги страницы из блока настроек: один <style> + прокрутка.

    При нулевых значениях стиль СНИМАЕТСЯ — страница остаётся ровно такой,
    как в проверенной на Windows v13. `with_scroll=False` — для повторного
    применения (не мешаем пользователю прокручивать самому).
    """
    sx = int(SCROLL_X) if with_scroll else 0
    sy = int(SCROLL_Y) if with_scroll else 0
    return PAGE_TUNE_JS % (int(PAGE_OFFSET_X), int(PAGE_OFFSET_Y), int(PAD_BOTTOM),
                           int(INPUT_DX), int(INPUT_DY),
                           json.dumps(str(INPUT_SELECTOR)),
                           sx, sy, sx, sy)


def page_tuning_needed():
    """Нужно ли вообще трогать страницу (все сдвиги нулевые -> нет)."""
    return bool(PAGE_OFFSET_X or PAGE_OFFSET_Y or PAD_BOTTOM
                or INPUT_DX or INPUT_DY or SCROLL_X or SCROLL_Y)


def zoom_settings_needed():
    """Отличаются ли настройки раскладки от проверенных значений v13."""
    return bool(WIDTH_DELTA or HEIGHT_DELTA
                or abs(float(PAGE_ZOOM) - (2.0 / 3.0)) > 1e-6)

GWL_STYLE = -16
GWL_EXSTYLE = -20

WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
WS_CHILD = 0x40000000
WS_CLIPCHILDREN = 0x02000000
WS_CLIPSIBLINGS = 0x04000000
WS_CAPTION = 0x00C00000
WS_SYSMENU = 0x00080000
WS_THICKFRAME = 0x00040000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
WS_DLGFRAME = 0x00400000
WS_BORDER = 0x00800000

WS_EX_DLGMODALFRAME = 0x00000001
WS_EX_WINDOWEDGE = 0x00000100
WS_EX_CLIENTEDGE = 0x00000200
WS_EX_STATICEDGE = 0x00020000
WS_EX_APPWINDOW = 0x00040000
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_TOPMOST = 0x00000008
WS_EX_NOACTIVATE = 0x08000000

SWP_FRAMECHANGED = 0x0020
SWP_SHOWWINDOW = 0x0040
SWP_HIDEWINDOW = 0x0080
SWP_NOACTIVATE = 0x0010
SWP_NOMOVE = 0x0002
SWP_NOSIZE = 0x0001
SWP_NOZORDER = 0x0004
SW_SHOW = 5

TH32CS_SNAPPROCESS = 0x00000002
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
HWND_TOP = 0
HWND_TOPMOST = -1
WM_HOTKEY = 0x0312

user32 = ctypes.WinDLL("user32", use_last_error=True) if sys.platform == "win32" else None
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True) if sys.platform == "win32" else None

WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM) if sys.platform == "win32" else None


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", ctypes.c_wchar * 260),
    ]


if user32:
    user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
    user32.EnumWindows.restype = wintypes.BOOL

    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD

    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.restype = ctypes.c_int

    user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongW.restype = ctypes.c_long

    user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    user32.SetWindowLongW.restype = ctypes.c_long

    if hasattr(user32, "GetWindowLongPtrW"):
        user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.GetWindowLongPtrW.restype = ctypes.c_void_p

        user32.SetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
        user32.SetWindowLongPtrW.restype = ctypes.c_void_p

    user32.SetWindowPos.argtypes = [
        wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, ctypes.c_uint,
    ]
    user32.SetWindowPos.restype = wintypes.BOOL


    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.ShowWindow.restype = wintypes.BOOL

    user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
    user32.RegisterHotKey.restype = wintypes.BOOL

    user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.UnregisterHotKey.restype = wintypes.BOOL

    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL

    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.restype = wintypes.BOOL

    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL

    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int

if kernel32:
    kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE

    kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    kernel32.Process32FirstW.restype = wintypes.BOOL

    kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
    kernel32.Process32NextW.restype = wintypes.BOOL

    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL




def get_window_long(hwnd, index):
    if not user32:
        return 0
    try:
        if hasattr(user32, "GetWindowLongPtrW"):
            return int(user32.GetWindowLongPtrW(hwnd, index) or 0) & 0xFFFFFFFF
        return int(user32.GetWindowLongW(hwnd, index) or 0) & 0xFFFFFFFF
    except Exception:
        diag.exception("main.py:294")
        return 0


def set_window_long(hwnd, index, value):
    if not user32:
        return 0
    try:
        value = int(value) & 0xFFFFFFFF
        if hasattr(user32, "SetWindowLongPtrW"):
            return user32.SetWindowLongPtrW(hwnd, index, ctypes.c_void_p(value))
        return user32.SetWindowLongW(hwnd, index, value)
    except Exception:
        diag.exception("main.py:307")
        return 0


def force_topmost(hwnd):
    """Жёстко поднимает окно в слой TOPMOST (режим «картинка-в-картинке»)."""
    if not user32 or not hwnd:
        return
    try:
        user32.SetWindowPos(
            wintypes.HWND(int(hwnd)), wintypes.HWND(HWND_TOPMOST),
            0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE,
        )
    except Exception:
        diag.exception("main.py:321")
        pass


# Полный список поддерживаемых клавиш (F1..F24, буквы, цифры, numpad, спецклавиши)
VK_MAP = {
    # Функциональные клавиши (F1 - F24)
    "F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74,
    "F6": 0x75, "F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79,
    "F11": 0x7A, "F12": 0x7B, "F13": 0x7C, "F14": 0x7D, "F15": 0x7E,
    "F16": 0x7F, "F17": 0x80, "F18": 0x81, "F19": 0x82, "F20": 0x83,
    "F21": 0x84, "F22": 0x85, "F23": 0x86, "F24": 0x87,

    # Буквы (A - Z)
    "A": 0x41, "B": 0x42, "C": 0x43, "D": 0x44, "E": 0x45, "F": 0x46,
    "G": 0x47, "H": 0x48, "I": 0x49, "J": 0x4A, "K": 0x4B, "L": 0x4C,
    "M": 0x4D, "N": 0x4E, "O": 0x4F, "P": 0x50, "Q": 0x51, "R": 0x52,
    "S": 0x53, "T": 0x54, "U": 0x55, "V": 0x56, "W": 0x57, "X": 0x58,
    "Y": 0x59, "Z": 0x5A,

    # Цифры основного блока
    "0": 0x30, "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34,
    "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39,

    # Цифровая клавиатура (Numpad)
    "Num0": 0x60, "Num1": 0x61, "Num2": 0x62, "Num3": 0x63,
    "Num4": 0x64, "Num5": 0x65, "Num6": 0x66, "Num7": 0x67,
    "Num8": 0x68, "Num9": 0x69,
    "Num*": 0x6A, "Num+": 0x6B, "Num-": 0x6D, "Num.": 0x6E, "Num/": 0x6F,

    # Управление и навигация
    "Space": 0x20, "Enter": 0x0D, "Tab": 0x09, "Esc": 0x1B,
    "Backspace": 0x08, "CapsLock": 0x14, "ScrollLock": 0x91,
    "Pause": 0x13, "PrintScreen": 0x2C,
    "Insert": 0x2D, "Delete": 0x2E, "Home": 0x24, "End": 0x23,
    "PageUp": 0x21, "PageDown": 0x22,
    "Up": 0x26, "Down": 0x28, "Left": 0x25, "Right": 0x27,

    # Символьные и пунктуационные клавиши
    "-": 0xBD, "=": 0xBB, "[": 0xDB, "]": 0xDD, "\\": 0xDC,
    ";": 0xBA, "'": 0xDE, ",": 0xBC, ".": 0xBE, "/": 0xBF,
    "`": 0xC0,
}

QT_KEY_TO_NAME = {}
for _i in range(1, 25):
    if hasattr(Qt.Key, f"Key_F{_i}"):
        QT_KEY_TO_NAME[getattr(Qt.Key, f"Key_F{_i}")] = f"F{_i}"
for _c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
    if hasattr(Qt.Key, f"Key_{_c}"):
        QT_KEY_TO_NAME[getattr(Qt.Key, f"Key_{_c}")] = _c
for _d in "0123456789":
    if hasattr(Qt.Key, f"Key_{_d}"):
        QT_KEY_TO_NAME[getattr(Qt.Key, f"Key_{_d}")] = _d

QT_KEY_TO_NAME.update({
    Qt.Key.Key_Space: "Space", Qt.Key.Key_Return: "Enter", Qt.Key.Key_Enter: "Enter",
    Qt.Key.Key_Tab: "Tab", Qt.Key.Key_Escape: "Esc", Qt.Key.Key_Backspace: "Backspace",
    Qt.Key.Key_CapsLock: "CapsLock", Qt.Key.Key_ScrollLock: "ScrollLock",
    Qt.Key.Key_Pause: "Pause", Qt.Key.Key_Print: "PrintScreen",
    Qt.Key.Key_Insert: "Insert", Qt.Key.Key_Delete: "Delete",
    Qt.Key.Key_Home: "Home", Qt.Key.Key_End: "End",
    Qt.Key.Key_PageUp: "PageUp", Qt.Key.Key_PageDown: "PageDown",
    Qt.Key.Key_Up: "Up", Qt.Key.Key_Down: "Down",
    Qt.Key.Key_Left: "Left", Qt.Key.Key_Right: "Right",
    Qt.Key.Key_Minus: "-", Qt.Key.Key_Equal: "=",
    Qt.Key.Key_BracketLeft: "[", Qt.Key.Key_BracketRight: "]",
    Qt.Key.Key_Backslash: "\\", Qt.Key.Key_Semicolon: ";",
    Qt.Key.Key_Apostrophe: "'", Qt.Key.Key_Comma: ",",
    Qt.Key.Key_Period: ".", Qt.Key.Key_Slash: "/",
    Qt.Key.Key_QuoteLeft: "`",
})

RU_TO_EN_KEY = {
    'Й': 'Q', 'Ц': 'W', 'У': 'E', 'К': 'R', 'Е': 'T', 'Н': 'Y', 'Г': 'U', 'Ш': 'I', 'Щ': 'O', 'З': 'P', 'Х': '[', 'Ъ': ']',
    'Ф': 'A', 'Ы': 'S', 'В': 'D', 'А': 'F', 'П': 'G', 'Р': 'H', 'О': 'J', 'Л': 'K', 'Д': 'L', 'Ж': ';', 'Э': "'",
    'Я': 'Z', 'Ч': 'X', 'С': 'C', 'М': 'V', 'И': 'B', 'Т': 'N', 'Ь': 'M', 'Б': ',', 'Ю': '.', 'Ё': '`',
}

MODIFIER_MAP = {
    "Ctrl": 0x0002,
    "Alt": 0x0001,
    "Shift": 0x0004,
    "Win": 0x0008,
}


def apply_win32_icon(hwnd):
    """Принудительно устанавливает иконку окна через Win32 API для гарантированного отображения в Taskbar (v25)."""
    if sys.platform != "win32" or not ICON_FILE.exists():
        return
    try:
        import ctypes
        from ctypes import wintypes
        user32_dll = ctypes.windll.user32
        IMAGE_ICON = 1
        LR_LOADFROMFILE = 0x00000010
        LR_DEFAULTSIZE = 0x00000040
        WM_SETICON = 0x0080
        ICON_SMALL = 0
        ICON_BIG = 1

        user32_dll.LoadImageW.restype = wintypes.HANDLE
        user32_dll.LoadImageW.argtypes = [
            wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
            ctypes.c_int, ctypes.c_int, wintypes.UINT
        ]
        user32_dll.SendMessageW.restype = wintypes.LPARAM
        user32_dll.SendMessageW.argtypes = [
            wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
        ]

        hicon = user32_dll.LoadImageW(
            None, str(ICON_FILE), IMAGE_ICON, 0, 0, LR_LOADFROMFILE | LR_DEFAULTSIZE
        )
        if hicon:
            user32_dll.SendMessageW(wintypes.HWND(int(hwnd)), WM_SETICON, ICON_BIG, hicon)
            user32_dll.SendMessageW(wintypes.HWND(int(hwnd)), WM_SETICON, ICON_SMALL, hicon)
    except BaseException:
        pass


def resolve_key_event(event) -> str | None:
    """Определяет символическое имя клавиши из события Qt (раскладко-независимо, v25)."""
    if event.isAutoRepeat():
        return None

    key = Qt.Key(event.key())
    if key in (Qt.Key.Key_Escape,):
        return None

    name = None
    # 1. По аппаратному коду виртуальной клавиши Win32
    try:
        vk = event.nativeVirtualKey()
        if vk:
            for k, code in VK_MAP.items():
                if code == vk:
                    name = k
                    break
    except Exception:
        diag.exception("resolve_key_event.vk")
        pass

    # 2. Через Qt Key enum
    if not name:
        name = QT_KEY_TO_NAME.get(key)

    # 3. Через русскую раскладку
    if not name:
        ru_char = event.text().upper()
        mapped = RU_TO_EN_KEY.get(ru_char)
        if mapped and mapped in VK_MAP:
            name = mapped
        elif ru_char in VK_MAP:
            name = ru_char

    return name

from win32_hotkeys import HotkeyMonitor, HOTKEY_TOGGLE_ID, HOTKEY_MIC_ID
from web_compat import (JS_PURGE, JS_MIC_TOGGLE, JS_MIC_STOP, JS_MIC_START,
                        CONSENT_CLICK_JS, JS_LIGHT_THEME, speech_lang_js)
from native_browser import (NativeBrowser, discover_browsers, choose_target,
                            apply_zoom, apply_viewport, zoom_ok, grant_microphone,
                            speech_surface)
import native_browser
import win32_embed
import browser_focus
import browser_fetch


# v16: события, которыми Qt/Windows сообщают о смене DPI или монитора под
# окном. `DevicePixelRatioChange` есть не во всех сборках Qt6 — берём те,
# что есть.
_METRIC_CHANGE_EVENTS = tuple(
    t for t in (
        getattr(QEvent.Type, 'DevicePixelRatioChange', None),
        getattr(QEvent.Type, 'ScreenChangeInternal', None),
    ) if t is not None)


THEME = {
    "bg": "#0e1020",
    "bg1": "#151830",
    "bg2": "#151830",
    "panel": "rgba(14, 16, 32, 0.96)",
    "line": "#262a4a",
    "text": "#e6e8f5",
    "muted": "#8f96bf",
    "accent": "#7c83ff",
    "accent2": "#5b61e8",
    "danger": "#ef4444",
    "ok": "#34d399",
}

BASE_QSS = f"""
QDialog, QWidget#Card {{
    background: {THEME['bg']};
    border: 1px solid {THEME['line']};
    border-radius: 14px;
}}
QLabel {{ color: {THEME['text']}; font-size: 13px; }}
QLabel#Caption {{ color: {THEME['muted']}; font-size: 11px; }}
QLineEdit {{
    background: {THEME['bg2']};
    border: 1px solid {THEME['line']};
    border-radius: 8px;
    padding: 10px 12px;
    color: {THEME['text']};
    font-size: 14px;
    selection-background-color: {THEME['accent2']};
}}
QLineEdit:focus {{ border: 1px solid {THEME['accent']}; background: #171b38; }}
QComboBox {{
    background: {THEME['bg2']};
    border: 1px solid {THEME['line']};
    border-radius: 8px;
    padding: 8px 10px;
    color: {THEME['text']};
    font-size: 13px;
}}
QComboBox:hover {{ border: 1px solid {THEME['accent']}; }}
QComboBox QAbstractItemView {{
    background: {THEME['bg2']};
    color: {THEME['text']};
    selection-background-color: {THEME['accent2']};
    border: 1px solid {THEME['line']};
    outline: none;
}}
QCheckBox {{ color: {THEME['muted']}; font-size: 12px; }}
QPushButton {{
    background: {THEME['bg2']};
    color: {THEME['text']};
    border: 1px solid {THEME['line']};
    border-radius: 9px;
    padding: 9px 16px;
    font-size: 13px;
    font-weight: 600;
}}
QPushButton:hover {{ border-color: {THEME['accent']}; background: #1b1f40; }}
QPushButton:pressed {{ background: #222750; }}
QPushButton#Primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {THEME['accent']}, stop:1 {THEME['accent2']});
    border: none;
    color: #ffffff;
}}
QPushButton#Primary:hover {{ background: {THEME['accent2']}; }}
QPushButton#Ghost {{ background: transparent; color: {THEME['muted']}; }}
QPushButton#Ghost:hover {{ color: {THEME['text']}; border-color: {THEME['accent']}; }}
QPushButton#Danger {{
    background: rgba(239, 68, 68, 0.14);
    color: #fca5a5;
    border: 1px solid rgba(239, 68, 68, 0.55);
}}
QPushButton#Danger:hover {{ background: rgba(239, 68, 68, 0.32); color: #fff; }}
"""


class CDP:
    @stage
    def __init__(self, ws_url):
        self.ws = create_connection(ws_url, suppress_origin=True, max_size=None, timeout=5, http_no_proxy=["127.0.0.1", "localhost"])
        self._id = 0
        self._lock = threading.Lock()

    def send(self, method, params=None, timeout=60):
        started = time.monotonic()
        deadline = started + timeout
        if not self._lock.acquire(timeout=timeout):
            diag.event("cdp.lock_timeout", method=method, timeout=timeout)
            raise TimeoutError("CDP lock acquisition")
        try:
            # v19: в логе видны вызываемый метод и КЛЮЧИ параметров (не сами
            # значения — в них файлы, токены и текст промтов).
            diag.event("cdp.send", method=method, timeout=timeout,
                       params=sorted(str(k) for k in (params or {}).keys())[:16])
            self._id += 1
            mid = self._id
            payload = json.dumps({"id": mid, "method": method, "params": params or {}})
            left = deadline - time.monotonic()
            if left <= 0:
                raise TimeoutError(method)
            self.ws.settimeout(left)
            self.ws.send(payload)
            while True:
                left = deadline - time.monotonic()
                if left <= 0:
                    raise TimeoutError(method)
                self.ws.settimeout(left)
                raw = self.ws.recv()
                if not raw:
                    raise ConnectionError("CDP socket closed")
                msg = json.loads(raw)
                if msg.get("id") == mid:
                    if "error" in msg:
                        error = msg.get("error") or {}
                        diag.event("cdp.protocol_error", method=method,
                                   code=error.get('code'),
                                   text=str(error.get('message') or '')[:200],
                                   params=sorted(str(k) for k in (params or {}).keys())[:16])
                        raise RuntimeError("CDP protocol error: " + method)
                    result = msg.get("result", {}) or {}
                    diag.event("cdp.result", method=method,
                               seconds=round(time.monotonic()-started, 3),
                               keys=sorted(str(k) for k in result.keys())[:12]
                               if isinstance(result, dict) else [])
                    return result
        except Exception:
            diag.exception("CDP.send:" + method)
            raise
        finally:
            self._lock.release()

    def eval(self, expr, await_promise=False, by_value=True, timeout=60):
        r = self.send("Runtime.evaluate", {
            "expression": expr,
            "awaitPromise": await_promise,
            "returnByValue": by_value,
            "userGesture": True,
            "generatePreview": False,
        }, timeout=timeout)

        if isinstance(r, dict) and "exceptionDetails" in r:
            # v19: текст исключения страницы — главный источник «почему скрипт
            # не сработал». Раньше он терялся (в логе было только RuntimeError).
            details = r.get("exceptionDetails") or {}
            diag.event("cdp.js_exception", method="Runtime.evaluate",
                       text=str(details.get("text") or "")[:200],
                       line=int((details.get("exception") or {}).get("lineNumber", 0)
                                if isinstance(details.get("exception"), dict) else 0))
            raise RuntimeError(str(details.get("text", "JS exception")))

        if isinstance(r, dict):
            return r.get("result", {})
        return {}

    def close(self):
        try:
            self.ws.close()
        except Exception:
            diag.exception("main.py:553")
            pass








def _http_json(port, path, timeout=1.0):
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(f"http://127.0.0.1:{port}{path}", timeout=timeout) as r:
        return json.load(r)


@stage
def attach_chrome(port, timeout=30):
    deadline = time.time() + timeout

    while time.time() < deadline:
        try:
            version = _http_json(port, "/json/version")
            browser_ws = version.get("webSocketDebuggerUrl")

            targets = _http_json(port, "/json/list")
            pages = [
                t for t in targets
                if t.get("type") == "page" and t.get("webSocketDebuggerUrl")
            ]

            # NEVER a consent/account wall: `consent.google.com` used to match
            # "any google page", automation attached to the wall and waited for
            # a chat that never arrived (the "chrome starts and hangs" report).
            chosen = choose_target(targets)

            if browser_ws and chosen:
                diag.event("cdp.discovered", browser=version.get("Browser"), protocol=version.get("Protocol-Version"), pages=len(pages))
                browser = CDP(browser_ws)
                try:
                    return browser, CDP(chosen["webSocketDebuggerUrl"])
                except Exception:
                    diag.exception("main.py:686")
                    browser.close()
                    raise
        except Exception:
            diag.exception("main.py:690")
            pass

        time.sleep(0.1)

    raise TimeoutError("chrome/devtools not ready")


def grant_mic_permission(browser: CDP, page: CDP):
    origins = set()

    try:
        origin = page.eval("location.origin", timeout=5).get("value")
        if origin and origin != "null":
            origins.add(origin)
    except Exception:
        diag.exception("main.py:706")
        pass

    origins.update([
        "https://google.com",
        "https://www.google.com",
        "https://gemini.google.com",
        "https://accounts.google.com",
    ])

    browser_context_id = None
    try:
        info = browser.send("Target.getBrowserContexts", timeout=5)
        ids = info.get("browserContextIds") or []
        if ids:
            browser_context_id = ids[0]
    except Exception:
        diag.exception("main.py:723")
        pass

    for origin in origins:
        params = {"origin": origin, "permissions": ["audioCapture", "videoCapture"]}
        if browser_context_id:
            params["browserContextId"] = browser_context_id

        try:
            browser.send("Browser.grantPermissions", params, timeout=5)
        except Exception:
            diag.exception("main.py:734")
            pass



# Детект файлов в чате Google AI
JS_CHECK_FILES = r"""
(() => {
// v58: состояние КАЖДОГО чипа вложения. По дампам пользователя
// (`Загрузка.txt`, `После загрузки.txt`, `Ошибка загрузки.txt`, `Удалить.txt`):
//   идёт загрузка  — у хоста чипа класс `oacyne`;
//   ошибка загрузки — класс `bGkj2b`, значок `div.rUmyzd` и подпись
//                    `div.oIIrVc` («При загрузке произошла ошибка»);
//   готово          — ни того, ни другого.
// Крестик `div.zXgSbc` и `data-progressvalue="0"` есть во ВСЕХ состояниях,
// поэтому «готово» по ним больше НЕ определяется (раньше определялось, и
// незагруженный файл считался прикреплённым).
const all = Array.from(document.querySelectorAll('div.ArblTe'));
// v43.5: чипы вложены друг в друга — считаем только ВНЕШНИЕ узлы.
const chips = all.filter((el) => {
    try {
        const parent = el.parentElement;
        return !(parent && parent.closest && parent.closest('div.ArblTe'));
    } catch (e) { return true; }
});
const items = [];
let uploading = false;
let errors = 0;
let done = 0;
const names = [];
for (const chip of (chips.length ? chips : all)) {
    let fname = '';
    let hostClasses = '';
    try {
        const host = chip.closest('div[role="button"]');
        if (host) {
            hostClasses = String(host.className || '');
            fname = (host.getAttribute('title') || host.getAttribute('aria-label') || '').trim();
            if (!fname) {
                const label = host.querySelector('div.zrI2ad');
                const txt = (label ? label.innerText : host.innerText) || '';
                fname = txt.replace(/\s+/g, ' ').trim();
            }
        }
        if (!fname) fname = ((chip.innerText || '').replace(/\s+/g, ' ').trim());
        fname = fname.slice(0, 160);
    } catch (e) { fname = ''; }
    // классы хоста могут дублироваться внутри чипа — смотрим и на сам чип
    let classes = hostClasses;
    try { if (chip.className) classes += ' ' + String(chip.className); } catch (e) {}
    const hasError = !!(chip.querySelector('div.oIIrVc')
                       || chip.querySelector('div.rUmyzd'))
                     || classes.indexOf('bGkj2b') >= 0;
    const isUploading = !hasError && classes.indexOf('oacyne') >= 0;
    if (hasError) errors += 1;
    if (isUploading) uploading = true;
    if (!hasError && !isUploading) { done += 1; names.push(fname); }
    items.push({ name: fname, uploading: isUploading, error: hasError });
}
return { present: done, uploading: uploading, errors: errors,
         names: names, chips: items };
})()
"""

# v58: кнопка «Отправить» — главный признак «экспорт завершён».
# По дампам: пока файл грузится (или сломан), у кнопки есть `IbS5tc`/`wdK4Nc`
# и `tabindex="-1"`; когда всё принято — классы снимаются, `tabindex="0"`.
JS_SEND_BUTTON = r"""
(() => {
const selectors = [
    'button[data-xid="input-plate-send-button"]',
    'button[data-xid="input-plate-voice-send-button"]',
    'button[aria-label="Отправить"]',
    'button[aria-label="Send"]'
];
for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (!el) continue;
    return {
        found: true,
        classes: String(el.className || ''),
        tabindex: String(el.getAttribute('tabindex') || ''),
        disabled: !!el.disabled || el.hasAttribute('disabled'),
        aria_disabled: String(el.getAttribute('aria-disabled') || '')
    };
}
return { found: false };
})()
"""

# v58: удалить ОДИН сломанный чип (точечно), не трогая остальные вложения.
JS_REMOVE_CHIP = r"""
(() => {
const wanted = String(NAME || '').trim().toLowerCase();
const all = Array.from(document.querySelectorAll('div.ArblTe'));
const chips = all.filter((el) => {
    try {
        const parent = el.parentElement;
        return !(parent && parent.closest && parent.closest('div.ArblTe'));
    } catch (e) { return true; }
});
const fire = (el) => {
    try {
        const r = el.getBoundingClientRect();
        const x = r.left + r.width / 2, y = r.top + r.height / 2;
        for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
            el.dispatchEvent(new MouseEvent(t, {bubbles: true, cancelable: true, clientX: x, clientY: y}));
        }
        el.click();
        return true;
    } catch (e) { return false; }
};
for (const chip of (chips.length ? chips : all)) {
    let fname = '';
    try {
        const host = chip.closest('div[role="button"]');
        if (host) fname = (host.getAttribute('title') || host.getAttribute('aria-label') || '').trim();
        if (!fname) fname = ((chip.innerText || '').replace(/\s+/g, ' ').trim());
    } catch (e) {}
    if (wanted && fname.toLowerCase().indexOf(wanted) < 0) continue;
    const x = chip.querySelector('div.zXgSbc');
    if (x && fire(x)) return { removed: true, name: fname.slice(0, 160) };
}
return { removed: false, count: (chips.length || all.length) };
})()
"""

JS_FIND_INPUT = r"""
(() => {
    const ins = Array.from(document.querySelectorAll('input[type=file]'));
    if (!ins.length) return null;

    const suitable = ins.find((input) => {
        if (!input.accept) return true;
        const accept = String(input.accept).toLowerCase();
        return accept.includes('pdf') || accept.includes('application') || accept.includes('*');
    });

    return suitable || ins[0];
})()
"""

# v24: разрешаем контекстное меню, если пользователь выделил текст (чтобы скопировать)
JS_DISABLE_CONTEXT_MENU = r"""
(() => {
    window.addEventListener('contextmenu', (e) => {
        try {
            const sel = window.getSelection ? window.getSelection().toString() : '';
            if (sel && sel.trim().length > 0) {
                return; // текст выделен — разрешаем штатное меню браузера ("Копировать")
            }
        } catch(err) {}
        e.preventDefault();
    }, true);
})();
"""

# v24: РАЗРЕШАЕМ выделение текста во всем окне вывода ответа от ИИ
JS_DISABLE_DRAG = r"""
(() => {
    const s = document.createElement('style');
    s.id = 'legalyze-user-select-style';
    s.innerHTML = `
        /* Запрещаем перетаскивание окна за фон */
        * { -webkit-app-region: no-drag !important; }

        /* v24: разрешаем выделение текста во всем окне ответа ИИ, чата и сообщений */
        html, body, main, article, section, [role="region"], [role="article"],
        p, span, div, pre, code, blockquote, li, table, tr, td, th, h1, h2, h3, h4, h5, h6,
        .markdown, .message-content, model-response, user-query, text-bubble {
            user-select: text !important;
            -webkit-user-select: text !important;
        }

        /* Запрещаем выделение только на кнопках и служебных иконках */
        button, button *, .mat-icon, svg {
            user-select: none !important;
            -webkit-user-select: none !important;
        }
    `;
    (document.head || document.documentElement).appendChild(s);

    // v24: при клике в область ввода — гарантируем установку фокуса
    document.addEventListener('pointerdown', (e) => {
        try {
            const el = e.target && e.target.closest('textarea, div[contenteditable="true"], [role="textbox"], input');
            if (el) { el.focus(); }
        } catch(err) {}
    }, true);
})();
"""

# Микрофон: СТАРТ записи речи (ТЗ п.1)
JS_START_RECORDING = r"""
(() => {
    const findMic = () => {
        // 1. Поиск по специфичным атрибутам и классам кнопки микрофона
        const selectors = [
            'button[data-xid="input-plate-voice-button"]',
            'button[data-xid="h4gG8"]',
            'button.uMMzHc.vpw7Fc',
            'button.vpw7Fc',
            'button[aria-label="Микрофон"]',
            'button[aria-label="Использовать микрофон"]',
            'button[aria-label*="икрофон" i]',
            'button[aria-label*="дикт" i]',
            'button[aria-label*="Microphone" i]',
            'button[aria-label*="voice" i]:not([aria-label*="send" i]):not([aria-label*="тправ" i])',
            'div[role="button"][aria-label*="икрофон" i]'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el && el.offsetParent !== null) return el;
        }

        // 2. Поиск внутри контейнера ввода (input plate / footer / bottom form)
        const inputArea = document.querySelector('.esoFne, .Txyg0d, footer, [role="region"], form') || document.body;
        const buttons = Array.from(inputArea.querySelectorAll('button, div[role="button"]'));
        for (const btn of buttons) {
            const label = (btn.getAttribute('aria-label') || '').toLowerCase();
            const xid = (btn.getAttribute('data-xid') || '').toLowerCase();
            if ((label.includes('микрофон') || label.includes('mic') || xid.includes('voice')) && !xid.includes('send')) {
                return btn;
            }
        }

        // 3. Поиск по SVG path иконки микрофона
        const paths = Array.from(inputArea.querySelectorAll('svg path'));
        for (const p of paths) {
            const d = p.getAttribute('d') || '';
            if (d.includes('M480-400') || d.includes('M12 14c1.66') || d.includes('M12 2a3 3 0')) {
                const btn = p.closest('button, div[role="button"]');
                if (btn && !(btn.getAttribute('data-xid') || '').includes('send')) return btn;
            }
        }

        return null;
    };

    const el = findMic();
    if (!el) return { ok: false, reason: 'not_found' };

    try { el.focus(); } catch(e) {}
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;

    const evOpts = {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: x,
        clientY: y,
        button: 0,
        buttons: 1
    };

    try { el.dispatchEvent(new PointerEvent('pointerdown', { ...evOpts, pointerId: 1, pointerType: 'mouse', isPrimary: true, pressure: 0.5 })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('mousedown', evOpts)); } catch(e) {}
    try { el.dispatchEvent(new PointerEvent('pointerup', { ...evOpts, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 0, pressure: 0 })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { ...evOpts, buttons: 0 })); } catch(e) {}
    try { el.dispatchEvent(new MouseEvent('click', { ...evOpts, buttons: 0 })); } catch(e) {}
    try { el.click(); } catch(e) {}

    return { ok: true, x: x, y: y };
})()
"""

# Микрофон: ПРОВЕРКА активного процесса записи (ТЗ п.2)
JS_CHECK_RECORDING = r"""
(() => {
    const textEls = document.querySelectorAll('.pRjbAe, [aria-live="polite"], div');
    for (const el of textEls) {
        if (el.innerText && el.innerText.includes('Преобразование речи')) return { recording: true };
    }
    if (document.querySelector('.tFTltc, .S7I6ve, .S34Aff, .r5nqdd')) return { recording: true };
    if (document.querySelector('button[data-xid="input-plate-voice-send-button"]')) return { recording: true };
    const ta = document.querySelector('textarea.ITIRGe, textarea[aria-label="Задайте вопрос"]');
    if (ta && (ta.hidden || ta.style.display === 'none')) return { recording: true };

    return { recording: false };
})()
"""

# Микрофон: ОТПРАВКА голосовой записи в ИИ чат (ТЗ п.3)
JS_STOP_AND_SEND = r"""
(() => {
    const findSend = () => {
        // 1. Поиск точной кнопки отправки голосового ввода
        const selectors = [
            'button[data-xid="input-plate-voice-send-button"]',
            'button.wdK4Nc',
            'button[aria-label="Отправить"]',
            'button.uMMzHc.wdK4Nc',
            'button[data-xid*="voice-send"]',
            'button[data-xid*="send"]',
            'button[aria-label*="тправить" i]',
            'button[aria-label*="end" i]',
            'button[aria-label*="ubmit" i]',
            'div[role="button"][aria-label*="тправить" i]'
        ];
        for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) return el;
        }

        // 2. Поиск по иконке отправки в области ввода
        const inputArea = document.querySelector('.esoFne, .Txyg0d, footer, form') || document.body;
        const buttons = Array.from(inputArea.querySelectorAll('button, div[role="button"]'));
        for (const btn of buttons) {
            const label = (btn.getAttribute('aria-label') || '').toLowerCase();
            const xid = (btn.getAttribute('data-xid') || '').toLowerCase();
            if (label.includes('отправ') || label.includes('send') || xid.includes('send')) {
                return btn;
            }
        }
        return null;
    };

    const triggerClick = (el) => {
        if (!el) return null;
        // v58: принудительную разблокировку УБРАЛИ (решение пользователя).
        // Раньше здесь стояли `el.disabled = false`, `removeAttribute('disabled')`
        // и `aria-disabled = 'false'` — из-за этого «продавливалась» неактивная
        // кнопка, и запрос уходил раньше, чем ИИ принял файлы. Теперь клик
        // только по РЕАЛЬНО активной кнопке, иначе — отказ без клика.
        try {
            const cls = String(el.className || '');
            const aria = String(el.getAttribute('aria-disabled') || '').toLowerCase();
            if (el.disabled || el.hasAttribute('disabled') || aria === 'true'
                    || cls.indexOf('IbS5tc') >= 0 || cls.indexOf('wdK4Nc') >= 0
                    || String(el.getAttribute('tabindex') || '') === '-1') {
                return { ok: false, reason: 'disabled' };
            }
        } catch(e) {}
        try { el.focus(); } catch(e) {}

        const rect = el.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;

        const evOpts = {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: x,
            clientY: y,
            button: 0,
            buttons: 1
        };

        try { el.dispatchEvent(new PointerEvent('pointerdown', { ...evOpts, pointerId: 1, pointerType: 'mouse', isPrimary: true, pressure: 0.5 })); } catch(e) {}
        try { el.dispatchEvent(new MouseEvent('mousedown', evOpts)); } catch(e) {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { ...evOpts, pointerId: 1, pointerType: 'mouse', isPrimary: true, buttons: 0, pressure: 0 })); } catch(e) {}
        try { el.dispatchEvent(new MouseEvent('mouseup', { ...evOpts, buttons: 0 })); } catch(e) {}
        try { el.dispatchEvent(new MouseEvent('click', { ...evOpts, buttons: 0 })); } catch(e) {}
        try { el.click(); } catch(e) {}

        return { ok: true, x: x, y: y };
    };

    const el = findSend();
    if (el) {
        return triggerClick(el);
    }

    // Fallback: клик по контейнеру остановки или Enter в текстовом поле
    const waveEl = document.querySelector('.tFTltc, .pRjbAe, .S34Aff');
    if (waveEl) {
        triggerClick(waveEl);
    }

    const inputEl = document.querySelector('textarea, div[contenteditable="true"], div[role="textbox"]');
    if (inputEl) {
        try { inputEl.hidden = false; } catch(e) {}
        try { inputEl.focus(); } catch(e) {}
        const opts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
        inputEl.dispatchEvent(new KeyboardEvent('keydown', opts));
        inputEl.dispatchEvent(new KeyboardEvent('keypress', opts));
        inputEl.dispatchEvent(new KeyboardEvent('keyup', opts));
        return { ok: true, fallback: 'enter' };
    }

    return { ok: false, reason: 'not_found' };
})()
"""

# Удаление файлов из чата
JS_REMOVE_ALL_FILES = r"""
(() => {
    let clicked = 0;
    const fire = (el) => {
        try {
            const r = el.getBoundingClientRect();
            const x = r.left + r.width / 2, y = r.top + r.height / 2;
            for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
                el.dispatchEvent(new MouseEvent(t, {bubbles: true, cancelable: true, clientX: x, clientY: y}));
            }
            clicked++;
        } catch (e) {}
    };
    const chips = document.querySelectorAll('div.ArblTe');
    for (const chip of chips) {
        const x = chip.querySelector('div.zXgSbc');
        if (x) fire(x);
    }
    if (!clicked) {
        const old = document.querySelectorAll(
            'button[aria-label*="Delete"], button[aria-label*="Remove"], button[aria-label*="Удалить"]');
        for (const el of old) { try { el.click(); clicked++; } catch (e) {} }
    }
    return clicked;
})()
"""

# v44: сколько текста в чате сейчас. Нужно, чтобы отличить НОВЫЙ ответ ИИ от
# нашей собственной заявки и от предыдущих сообщений.
JS_CHAT_TEXT_LENGTH = r"""
(() => {
    const selectors = [
        'message-content', '.model-response-text', '.markdown',
        '[data-test-id="conversation-turn"]', '.response-container', 'main'
    ];
    let total = 0;
    for (const sel of selectors) {
        const nodes = document.querySelectorAll(sel);
        if (!nodes.length) continue;
        for (const node of nodes) {
            total += ((node.innerText || '') + '').length;
        }
        if (total) return total;
    }
    return total;
})()
"""

JS_CHECK_END = r"""
(() => {
    const bodyText = (document.body ? document.body.innerText : '') || '';
    const cleanText = bodyText.toUpperCase().replace(/[\s=*/\-_]+/g, '');
    const matches = cleanText.match(/КОНЕЦОТВЕТА/g);
    return matches ? matches.length : 0;
})()
"""


# v27: текст последнего ответа ИИ — из него собирается постановление по
# триггеру. Берём самый «свежий» блок ответа (последний по порядку в DOM),
# чтобы не смешать новый ответ с предыдущей перепиской.
JS_READ_ANSWER = r"""
(() => {
    // v30: берём ПОСЛЕДНИЙ ответ ИИ (а не самый длинный блок на странице —
    // из-за этого в разбор попадало предыдущее сообщение или описание картинки).
    //
    // v44: роль текста ВАЖНА. В сессии 20261109-145359-16532-54c702 в дело
    // сохранился весь текст страницы («Перейти к основному контенту … Чат в
    // режиме ИИ: ЗАЯВКА НА ПРОВЕРКУ …»), и разбор принял за ответ нашу же
    // заявку: дело получило «Отказано» с пустым основанием. Теперь текст
    // пользователя никогда не считается ответом, а `document.body` как
    // запасной источник не используется вовсе.
    //
    // v44.1: отсечение «наше сообщение внутри ответа» было слишком грубым —
    // ответ отбрасывался, если где-то в нём встречался текст запроса.
    //
    // v44.2: список блоков ответа расширен. Ответ в чате ИИ приходит одним
    // контейнером ВМЕСТЕ с цитатой заявки — «**Memphis.pdf** … ЗАЯВКА НА
    // ПРОВЕРКУ ОБРАЩЕНИЯ (этап 1) … ПРОВЕРКА ОБРАЩЕНИЯ Состояние: Отказано»,
    // — и на разных страницах (gemini, режим ИИ в поиске) блоки называются
    // по-разному. Если ни один селектор не подошёл, берём текст основной
    // области и ВЫРЕЗАЕМ из него нашу реплику: остаётся ответ ИИ.
    const ANSWER = ['message-content', 'model-response', '.model-response-text',
                    '.response-container', '.markdown', '.prose',
                    'ai-mode-response', '[data-test-id="ai-mode-response"]',
                    '[data-test-id="model-response"]', 'article'];
    const USER = ['user-query', 'user-query-content', '.query-text',
                  '[data-test-id="user-query"]', '[data-test-id="user-query-content"]',
                  '.user-message', 'user-message'];
    const clean = (node) => ((node && node.innerText) || '').trim();
    const squeeze = (text) => (text || '').replace(/\s+/g, ' ').trim();
    const inUserMessage = (node) => {
        for (const sel of USER) {
            try {
                if (node.closest && node.closest(sel)) return true;
            } catch (e) { /* селектор не поддержан — пропускаем */ }
        }
        return false;
    };
    const readLast = (selectors, skipUser) => {
        let text = '';
        for (const sel of selectors) {
            let nodes = [];
            try {
                nodes = document.querySelectorAll(sel);
            } catch (e) { continue; }
            for (let i = nodes.length - 1; i >= 0; i--) {
                const node = nodes[i];
                if (skipUser && inUserMessage(node)) continue;
                const candidate = clean(node);
                if (candidate.length > text.length) text = candidate;
                if (text) break;   // последний подходящий узел этого селектора
            }
        }
        return text;
    };
    const said = readLast(USER, false);
    let reply = readLast(ANSWER, true);
    if (!reply) {
        // Запасной путь: основная область страницы без нашей реплики.
        let area = null;
        try {
            area = document.querySelector('main') ||
                   document.querySelector('[role="main"]');
        } catch (e) { area = null; }
        if (area) {
            let rest = clean(area);
            if (said) rest = rest.split(said).join(' ');
            rest = rest.trim();
            if (rest.length > 80) reply = rest;
        }
    }
    if (!reply) return '';
    // Ответ не может БЫТЬ своей же репликой (но может её цитировать).
    if (said && squeeze(reply) === squeeze(said)) return '';
    return reply;
})()
"""


# v27: фокус в поле ввода перед автоматической отправкой заявки.
JS_FOCUS_INPUT = r"""
(() => {
    const el = document.querySelector(
        'textarea, div[contenteditable="true"], div[role="textbox"]');
    if (!el) return { ok: false, reason: 'not_found' };
    try { el.focus(); } catch (e) {}
    try {
        const r = document.createRange();
        r.selectNodeContents(el);
        r.collapse(false);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(r);
    } catch (e) {}
    return { ok: true };
})()
"""


def install_compat(browser: CDP, page: CDP, native: bool = False):
    """Согласуем User-Agent и client hints с обычным Chrome для feature-gating сайта.

    `native=True` — настоящий Chrome: UA и client hints честные, поэтому
    подменять их не нужно, а шим речи **вреден** (он подменяет рабочий
    `SpeechRecognition`, которым сайт и записывает голос). Здесь
    устанавливается только кликер согласия: в ЕС (Испания) свежий профиль
    сначала показывается страница «Aceptar todo», и пока она не принята,
    чата не будет.
    """
    if native:
        try:
            page.send("Page.enable", timeout=5)
        except Exception:
            diag.exception("main.py:compat_native_enable")
        try:
            page.send("Page.addScriptToEvaluateOnNewDocument",
                      {"source": CONSENT_CLICK_JS}, timeout=5)
            page.eval(CONSENT_CLICK_JS, timeout=5)
            diag.event("browser.consent_installed")
        except Exception:
            diag.exception("main.py:compat_native_consent")
        return

    try:
        ua = str(page.eval("navigator.userAgent", timeout=5).get("value") or "")
        full = ""
        m = re.search(r"Chrome/([\d.]+)", ua)
        if m:
            full = m.group(1)
        major = full.split(".")[0] if full else "120"
        page.send("Network.enable", timeout=5)
        params = {
            "acceptLanguage": "ru-RU,ru;q=0.9,en;q=0.8",
            "platform": "Windows",
            "userAgentMetadata": {
                "brands": [
                    {"brand": "Chromium", "version": major},
                    {"brand": "Google Chrome", "version": major},
                    {"brand": "Not;A=Brand", "version": "24"},
                ],
                "fullVersion": full or (major + ".0.0.0"),
                "platform": "Windows",
                "platformVersion": "15.0.0",
                "architecture": "x86",
                "model": "",
                "mobile": False,
                "bitness": "64",
                "wow64": False,
            },
        }
        if ua:
            params["userAgent"] = ua
        page.send("Network.setUserAgentOverride", params, timeout=5)
        diag.event("webengine.compat_installed", chrome=full or "?")
    except Exception:
        diag.exception("webengine.compat")


# v18: скрипты, которые внедряются при создании документа и работают всегда.
PAGE_SCRIPTS = (JS_DISABLE_CONTEXT_MENU, JS_DISABLE_DRAG, JS_PURGE)


def page_scripts(lang="ru-RU", light=True):
    """Полный набор скриптов страницы с подставленным языком (v18)."""
    scripts = [speech_lang_js(lang)]
    if light:
        scripts.append(JS_LIGHT_THEME)
    scripts.extend(PAGE_SCRIPTS)
    return tuple(scripts)


# v18: вернуть страницу к жизни после разворачивания окна. Chromium
# приостанавливает отрисовку, пока окно скрыто, — одного показа мало.
JS_REVIVE = r"""
(() => {
    try { window.dispatchEvent(new Event('resize')); } catch (e) {}
    try { document.documentElement && document.documentElement.style &&
          document.documentElement.style.setProperty('color-scheme', 'light', 'important'); } catch (e) {}
    try { const b = document.body; if (b) { b.offsetHeight; } } catch (e) {}
    return true;
})();
"""


# v19: отпечаток страницы. Раньше готовность определялась одним вопросом
# «есть ли текстовое поле» — он отвечал «да» уже на `readyState == "interactive"`,
# когда страница ещё грузится. Из-за этого GUI прогрузки снимали слишком рано и
# пользователь видел недогруженную страницу (жалоба «Error - 1»). Здесь одним
# вызовом снимается ВСЁ, по чему видно, что именно открыто:
#   * `verdict` — какая это поверхность (чат / режим ИИ в поиске / вход / согласие);
#   * `ready` — настоящая готовность документа;
#   * `composer`, `files`, `chips` — есть ли во что писать и куда прикреплять файл;
#   * `dark`, `bg`, `scheme` — тёмная страница или нет (жалоба «нестандартно
#     тёмного цвета»): замеряется, а не предполагается;
#   * `account` — вошёл ли пользователь в аккаунт Google;
#   * `pending` — сколько ресурсов уже запрошено (по нему видно залипание).
JS_SURFACE = r"""
(() => {
    const qsa = (s) => { try { return document.querySelectorAll(s).length } catch (e) { return 0 } };
    const host = String(location.hostname || '');
    const path = String(location.pathname || '');
    const query = String(location.search || '');
    const protocol = String(location.protocol || '');
    let verdict = 'other';
    if (protocol === 'chrome-error:') verdict = 'browser_error';
    else if (host === 'accounts.google.com') verdict = 'login';
    else if (host === 'consent.google.com') verdict = 'consent';
    else if (host === 'gemini.google.com' || host === 'aistudio.google.com') verdict = 'gemini';
    else if (host === 'about' || location.href === 'about:blank') verdict = 'blank';
    else if ((host === 'www.google.com' || host === 'google.com') &&
             (query.indexOf('udm=50') >= 0 || path === '/ai')) verdict = 'ai_mode';
    else if (host === 'www.google.com' || host === 'google.com') verdict = 'google_other';
    let bg = '';
    let scheme = '';
    try { bg = String(getComputedStyle(document.body).backgroundColor || ''); } catch (e) {}
    try { scheme = String((getComputedStyle(document.documentElement).colorScheme) || ''); } catch (e) {}
    let dark = false;
    try { dark = !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); } catch (e) {}
    let account = false;
    try {
        account = !!(document.querySelector('a[href*="accounts.google.com/ServiceLogin"]') === null &&
            (document.querySelector('img[src*="googleusercontent.com"]') ||
             document.querySelector('div[aria-label*="Google Account"]') ||
             document.querySelector('a[href*="accounts.google.com/SignOut"]')));
    } catch (e) {}
    return {
        verdict: verdict, host: host, path: path, ready: document.readyState,
        composer: qsa('div.esoFne') + qsa('rich-textarea') + qsa('textarea') +
            qsa('div[contenteditable="true"]') + qsa('[role="textbox"]'),
        files: qsa('input[type="file"]'), chips: qsa('div.ArblTe'),
        buttons: qsa('button'), frames: qsa('iframe'),
        bodyChildren: document.body ? document.body.children.length : 0,
        dark: dark, bg: bg, scheme: scheme, account: account,
        pending: (performance.getEntriesByType('resource') || []).length,
        lang: String(navigator.language || '')
    };
})()
"""

# Разрешённые значения: данные страницы — всегда недоверенный ввод.
_SURFACE_VERDICTS = ("gemini", "ai_mode", "google_other", "login", "consent",
                     "browser_error", "blank", "other")
_COLOR_RE = re.compile(r"^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*[\d.]+\s*)?\)$")


def probe_page_surface(page, timeout=3):
    """Снять отпечаток страницы: только числа, перечисления и цвет (v19)."""
    empty = {"verdict": "unknown", "ready": "unknown", "composer": 0, "files": 0,
             "chips": 0, "bodyChildren": 0, "dark": False, "bg": "", "scheme": "",
             "account": False, "pending": 0, "lang": "", "host": "", "buttons": 0,
             "frames": 0}
    if page is None:
        return empty
    try:
        raw = page.eval(JS_SURFACE, timeout=timeout).get("value")
    except Exception:
        diag.exception("main.surface_probe")
        return empty
    if not isinstance(raw, dict):
        return empty
    result = dict(empty)
    verdict = raw.get("verdict")
    result["verdict"] = verdict if verdict in _SURFACE_VERDICTS else "other"
    ready = raw.get("ready")
    result["ready"] = ready if ready in ("loading", "interactive", "complete") else "unknown"
    for key in ("composer", "files", "chips", "bodyChildren", "pending", "buttons",
                "frames"):
        value = raw.get(key)
        result[key] = int(value) if isinstance(value, int) and 0 <= value <= 1000000 else 0
    for key in ("dark", "account"):
        result[key] = raw.get(key) is True
    bg = str(raw.get("bg") or "")
    result["bg"] = bg[:32] if _COLOR_RE.match(bg.strip()) else ""
    result["scheme"] = str(raw.get("scheme") or "")[:16]
    result["lang"] = str(raw.get("lang") or "")[:16]
    host = str(raw.get("host") or "")
    result["host"] = host[:64]
    path = str(raw.get("path") or "")
    result["path"] = path[:64] if path in ("/", "/ai", "/search", "/app") else "<other>"
    return result


def _surface_signature(surface):
    return (surface.get("verdict"), surface.get("ready"), surface.get("composer"),
            surface.get("files"), surface.get("chips"), surface.get("dark"),
            surface.get("bg"), surface.get("account"))


def measure_theme(page, surface=None):
    """Замер темы страницы: тёмная или нет — по факту, а не по настройке (v19).

    Жалоба «Error - 1»: страница «нестандартно тёмного цвета», хотя приложение
    применило светлую тему. Значит применение надо ПРОВЕРЯТЬ. Тёмный фон здесь
    определяется по цвету `body` (яркость), а не по `prefers-color-scheme`:
    сервис может красить страницу своей разметкой, а системное свойство при
    этом оставаться светлым.
    """
    data = surface if isinstance(surface, dict) and surface.get("bg") \
        else probe_page_surface(page)
    bg = str(data.get("bg") or "")
    numbers = [int(n) for n in re.findall(r"\d{1,3}", bg)[:3]]
    dark = False
    if len(numbers) == 3:
        # Яркость по восприятию: тёмный фон — это серый/чёрный, а не цветной.
        luminance = 0.299 * numbers[0] + 0.587 * numbers[1] + 0.114 * numbers[2]
        dark = luminance < 110
    dark = bool(dark or data.get("dark"))
    diag.event("page.theme_probe", bg=bg, scheme=str(data.get("scheme") or ""),
               dark=dark, verdict=data.get("verdict"))
    return dark


def repair_light_theme(page, lang="ru-RU"):
    """Привести страницу к светлой теме и проверить, что получилось (v19).

    Почему это не «ещё один вызов»: в v18 светлая тема применялась ОДИН раз, на
    ещё не загруженной странице, и всё. Здесь применяется и ПРОВЕРЯЕТСЯ: если
    замер всё ещё тёмный — применяется снова (не больше `THEME_MAX_REPAIRS`),
    а в логе остаётся и цвет, и verdict.
    """
    applied = apply_language_and_theme(page, lang=lang, light=True)
    try:
        page.send("Emulation.setAutoDarkModeOverride", {"enabled": False}, timeout=4)
    except Exception:
        diag.exception("main.repair_auto_dark")
    try:
        page.eval(JS_LIGHT_THEME, timeout=5)
    except Exception:
        diag.exception("main.repair_light_js")
    return applied


def wait_for_chat_surface(page, timeout=SURFACE_READY_TIMEOUT, poll=SURFACE_POLL_MS,
                          lang="ru-RU", light=True, should_stop=None,
                          on_round=None):
    """Ждать НАСТОЯЩЕЙ готовности чата, а не первого текстового поля (v19).

    Раньше ворота (`READY_SCRIPT`) отвечали «готово» уже на
    `readyState == "interactive"`: страница в этот момент ещё грузится, поэтому
    GUI прогрузки снимали слишком рано. Теперь готовность — это:
      * `readyState == "complete"` (догрузилось, а не «почти»);
      * есть поле ввода (во что писать запрос);
      * **два одинаковых замера подряд** (страница устоялась);
      * тема приведена к светлой, если замер показал тёмную.
    Возвращает словарь: `ready`, `verdict`, `surface`, `rounds`,
    `blocked` (причина, по которой чата здесь нет и не будет).
    """
    deadline = time.monotonic() + max(1.0, float(timeout))
    result = {"ready": False, "verdict": "unknown", "surface": {}, "rounds": 0,
              "blocked": "", "stable": 0, "theme_repairs": 0}
    if page is None:
        result["blocked"] = "no_page"
        return result
    last_signature = None
    last_log = ""
    stable = 0
    while time.monotonic() < deadline:
        if callable(should_stop) and should_stop():
            result["blocked"] = "stopped"
            return result
        result["rounds"] += 1
        surface = probe_page_surface(page)
        result["surface"] = surface
        result["verdict"] = surface.get("verdict") or "unknown"
        if callable(on_round):
            try:
                on_round(result["rounds"], surface)
            except Exception:
                diag.exception("main.surface_round_hook")
        signature = _surface_signature(surface)
        previous_signature = last_signature
        # Одинаковые замеры подряд пишем один раз: лог не должен зарастать
        # сотнями одинаковых строк, а «залипла» страница или нет — видно.
        if signature != last_signature:
            diag.event("page.surface", **{k: surface[k] for k in
                       ("verdict", "ready", "composer", "files", "chips", "dark",
                        "bg", "scheme", "account", "pending", "bodyChildren",
                        "lang", "host", "path") if k in surface})
            last_signature = signature
        verdict = surface.get("verdict")
        if verdict in ("login", "consent", "browser_error"):
            # Чата здесь не будет никогда: дальше ждать бессмысленно.
            result["blocked"] = verdict
            diag.warn("surface_blocked", reason=verdict)
            return result
        if light and surface.get("ready") == "complete" \
                and result["theme_repairs"] < THEME_MAX_REPAIRS \
                and measure_theme(page, surface):
            result["theme_repairs"] += 1
            diag.warn("dark_theme_measured", repair=result["theme_repairs"],
                      bg=str(surface.get("bg") or ""))
            repair_light_theme(page, lang=lang)
            stable = 0
            last_signature = None
            continue
        ready = (surface.get("ready") == "complete" and int(surface.get("composer") or 0) > 0)
        if not ready:
            stable = 0
        elif signature == previous_signature:
            stable += 1
        else:
            stable = 1
        result["stable"] = stable
        if ready and stable >= int(SURFACE_STABLE_ROUNDS):
            result["ready"] = True
            diag.event("page.ready", rounds=result["rounds"], verdict=verdict,
                       theme_repairs=result["theme_repairs"])
            return result
        now = time.strftime("%H:%M:%S")
        if now != last_log:
            last_log = now
            diag.event("page.wait", round=result["rounds"],
                       left=round(deadline - time.monotonic(), 1),
                       verdict=verdict, ready=surface.get("ready"),
                       composer=surface.get("composer"),
                       stable=stable, pending=surface.get("pending"))
        time.sleep(max(0.05, float(poll) / 1000.0))
    result["blocked"] = result["blocked"] or "timeout"
    diag.warn("surface_timeout", **{k: result["surface"].get(k)
                                    for k in ("verdict", "ready", "composer",
                                              "files", "pending", "host")})
    return result


def apply_language_and_theme(page, lang="ru-RU", light=True):
    """Язык интерфейса и светлая тема страницы через CDP (v18).

    * `Emulation.setLocaleOverride` — язык страницы (navigator.language):
      именно по нему сервис ИИ выбирает язык ответов и распознавания;
    * `Emulation.setAutoDarkModeOverride` — выключает авто-тёмную тему Chrome;
    * `Emulation.setEmulatedMedia` — фиксирует `prefers-color-scheme: light`.
    Идемпотентно: любая ошибка только пишется в лог, страница не ломается.
    """
    applied = {}
    if page is None:
        return applied
    try:
        page.send("Emulation.setLocaleOverride", {"locale": str(lang or "ru-RU")},
                  timeout=4)
        applied["locale"] = str(lang or "ru-RU")
    except Exception:
        diag.exception("main.locale_override")
    if not light:
        return applied
    try:
        page.send("Emulation.setAutoDarkModeOverride", {"enabled": False}, timeout=4)
        applied["auto_dark"] = False
    except Exception:
        diag.exception("main.auto_dark")
    try:
        page.send("Emulation.setEmulatedMedia", {
            "features": [{"name": "prefers-color-scheme", "value": "light"}],
        }, timeout=4)
        applied["color_scheme"] = "light"
    except Exception:
        diag.exception("main.emulated_media")
    return applied


def install_purge(page: CDP, lang="ru-RU", light=True):
    for src in page_scripts(lang, light):
        try:
            page.send("Page.addScriptToEvaluateOnNewDocument", {"source": src}, timeout=5)
        except Exception:
            diag.exception("main.py:1111")
            pass

    try:
        page.send("Page.enable", timeout=5)
    except Exception:
        diag.exception("main.py:1117")
        pass

    # v18: язык и тема — сразу и по CDP (часть свойств живёт только там).
    state = apply_language_and_theme(page, lang, light)
    if state:
        diag.event("page.language_theme", **state)

    for src in page_scripts(lang, light):
        try:
            page.eval(src, timeout=5)
        except Exception:
            diag.exception("main.py:1124")
            pass


def log_page_probe(page):
    # Deliberately no URL, query, title, text, filenames or HTML in this result.
    script = """(() => {
        const h = location.hostname;
        const category = h === 'accounts.google.com' ? 'google_login' :
            h === 'consent.google.com' ? 'google_consent' :
            ['google.com', 'www.google.com', 'gemini.google.com'].includes(h) ? 'google' :
            location.protocol === 'chrome-error:' ? 'browser_error' :
            location.href === 'about:blank' ? 'blank' : 'other';
        return {category, ready: document.readyState,
            bodyChildren: document.body ? document.body.children.length : 0,
            fileInputs: document.querySelectorAll('input[type="file"]').length,
            editors: document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]').length,
            frames: document.querySelectorAll('iframe').length,
            documentFocused: document.hasFocus(),
            activeEditable: !!(document.activeElement &&
                (document.activeElement.isContentEditable || ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName))),
            activeReadOnly: !!(document.activeElement && document.activeElement.readOnly),
            activeDisabled: !!(document.activeElement && document.activeElement.disabled)};
    })()"""
    try:
        raw = page.eval(script, timeout=2).get("value")
        if isinstance(raw, dict):
            # Treat page-provided data as untrusted: permit only fixed enums and counts.
            category = raw.get("category")
            ready = raw.get("ready")
            counts = {key: raw[key] for key in ("bodyChildren", "fileInputs", "editors", "frames")
                      if type(raw.get(key)) is int and 0 <= raw[key] <= 1000000}
            flags = {key: raw[key] for key in ("documentFocused", "activeEditable", "activeReadOnly", "activeDisabled")
                     if type(raw.get(key)) is bool}
            diag.event("page.probe", category=category if category in
                       ("google_login", "google_consent", "google", "browser_error", "blank", "other") else "unknown",
                       ready=ready if ready in ("loading", "interactive", "complete") else "unknown", **counts, **flags)
    except Exception:
        diag.exception("page.probe")


def wait_send_button(page: CDP, timeout: float = ugate.SEND_BUTTON_TIMEOUT,
                     poll: float = ugate.POLL_SECONDS) -> dict:
    """Ждёт, пока кнопка «Отправить» станет активной (v58), до 20 секунд.

    Замечание пользователя: «ожидать активности кнопки отправки во всех
    случаях, когда ты что-либо экспортируешь в чат с ИИ». Пока кнопка
    неактивна, файл ещё не принят ИИ (или в чате есть файл с ошибкой) —
    отправлять рано.
    """
    deadline = time.monotonic() + float(timeout)
    last = {"found": False, "enabled": False}
    while time.monotonic() < deadline:
        try:
            last = ugate.normalize_send(page.eval(JS_SEND_BUTTON, timeout=2).get("value"))
        except Exception:
            diag.exception("main.wait_send_button")
            last = {"found": False, "enabled": False}
        if last.get("enabled"):
            return last
        time.sleep(float(poll))
    diag.event("upload.send_button_timeout", seconds=round(float(timeout), 1),
               found=bool(last.get("found")))
    return last


def check_state(page: CDP):
    """Состояние чата: готовые файлы, загрузка, ошибки и кнопка «Отправить».

    v58: раньше здесь были только `present`/`uploading`/`names`, а «готовность»
    определялась по крестику `div.zXgSbc`. По дампам пользователя крестик есть
    и при ошибке загрузки, поэтому незагруженный файл считался прикреплённым.
    Теперь дополнительно отдаём:

    * `chips` — состояние КАЖДОГО чипа (`{name, uploading, error}`);
    * `errors` — число чипов с ошибкой загрузки;
    * `send` — состояние кнопки «Отправить» (главный признак «экспорт готов»).
    """
    default = {"present": 0, "uploading": False, "names": [], "probe_ok": False,
               "chips": [], "errors": 0, "send": {"found": False, "enabled": False}}

    try:
        r = page.eval(JS_CHECK_FILES, timeout=2)
        value = r.get("value")
        if isinstance(value, dict):
            try:
                present = int(value.get("present", 0) or 0)
            except Exception:
                diag.exception("main.py:1139")
                present = 1 if value.get("present") else 0
            names = value.get("names", []) or []
            chips = ugate.normalize_chips(value.get("chips"))
            send = {"found": False, "enabled": False}
            try:
                send = ugate.normalize_send(page.eval(JS_SEND_BUTTON, timeout=2).get("value"))
            except Exception:
                diag.exception("main.check_send_button")
            return {
                "probe_ok": True,
                "present": present,
                "uploading": bool(value.get("uploading", False)),
                "names": _unique_names(names),
                "chips": chips,
                "errors": int(value.get("errors", 0) or 0),
                "send": send,
            }
    except Exception:
        diag.exception("main.py:1148")
        pass

    return default


def remove_chip(page: CDP, name: str) -> bool:
    """Удаляет ОДИН чип вложения из чата (v58).

    Замечание пользователя по «Ошибка загрузки.txt»: чат не перезагружаем,
    «используй логику из „Удалить.txt“, то есть удалить файл… логика
    автодогрузки при отсутствующих файлах уже имеется». Поэтому убираем
    только сломанный чип, остальные вложения остаются на месте.
    """
    try:
        script = "const NAME = " + json.dumps(str(name or "")) + ";\n" + JS_REMOVE_CHIP
        value = page.eval(script, timeout=3).get("value")
        ok = bool(isinstance(value, dict) and value.get("removed"))
        diag.event("upload.chip_removed", name=str(name or "")[:80], ok=ok)
        return ok
    except Exception:
        diag.exception("main.remove_chip")
        return False


def _unique_names(names) -> list:
    """Имена вложений без повторов (v43.5).

    Один файл в чате может быть представлен несколькими узлами DOM: в сессии
    20261109-143836-13424-edee58 три вложения дали `present=6` и список
    ["Memphis.pdf", "Шаблон.txt", "Проверка обращения (заявка).txt",
     "Memphis.pdf", …]. Из-за удвоения заявка считалась «лишними файлами» и
    никогда не отправлялась. Считаем файлы, а не узлы.
    """
    if not isinstance(names, list):
        return []
    result = []
    for name in names:
        text = str(name or "").strip()
        if not text:
            continue
        if text.lower() not in [item.lower() for item in result]:
            result.append(text)
    return result


def _chat_has_file(names, wanted: str) -> bool:
    """Есть ли файл wanted среди прикреплённых (поиск по подстроке имени)."""
    want = (wanted or "").strip().lower()
    if not want:
        return False
    for n in names or []:
        text = str(n or "").lower()
        if want in text or text in want:
            return True
    return False


def _mime_for_path(path) -> str:
    """MIME-тип по расширению: PDF и TXT грузятся каждый со своим типом."""
    ext = Path(path).suffix.lower()
    if ext == ".pdf":
        return "application/pdf"
    if ext in (".txt", ".json", ".md", ".csv"):
        return "text/plain"
    return "application/octet-stream"


def upload_file_advanced(page: CDP, path: Path, mime: str | None = None) -> bool:
    """
    Надежный метод загрузки файла через эмуляцию Drag & Drop с DataTransfer API и File Input.
    Работает с любыми современными SPA, так как полностью имитирует действие
    пользователя (перетаскивание файла), обходя ограничения скрытых input'ов.
    Одинаково используется и для PDF промта, и для Шаблон.txt.
    """
    try:
        if not path or not Path(path).exists():
            return False

        if page.eval(READY_SCRIPT, timeout=2).get("value") is not True:
            return False
        file_path = Path(path)
        file_name = file_path.name.replace("\\", "").replace('"', "").replace("\n", "")
        mime = mime or _mime_for_path(file_path)
        file_data = file_path.read_bytes()
        b64_data = base64.b64encode(file_data).decode('ascii')

        js_inject = f"""
        (() => {{
            try {{
                const b64 = "{b64_data}";
                const fileName = "{file_name}";

                const binary = atob(b64);
                const bytes = new Uint8Array(binary.length);
                for (let i = 0; i < binary.length; i++) {{
                    bytes[i] = binary.charCodeAt(i);
                }}

                const blob = new Blob([bytes], {{ type: '{mime}' }});
                const file = new File([blob], fileName, {{ type: '{mime}' }});
                const dt = new DataTransfer();
                dt.items.add(file);

                let matched = false;

                // 1. Устанавливаем в скрытый input
                const inputs = Array.from(document.querySelectorAll('input[type="file"]'));
                for (const input of inputs) {{
                    try {{
                        input.files = dt.files;
                        input.dispatchEvent(new Event('change', {{ bubbles: true }}));
                        input.dispatchEvent(new Event('input', {{ bubbles: true }}));
                        matched = true;
                    }} catch (e) {{}}
                }}

                // 2. Эмулируем Drag & Drop на текстовое поле (основной триггер для Google AI)
                const dropZone = document.querySelector('.esoFne') 
                              || document.querySelector('textarea') 
                              || document.querySelector('[role="textbox"]')
;

                if (dropZone) {{
                    dropZone.dispatchEvent(new DragEvent('dragenter', {{ bubbles: true, cancelable: true, dataTransfer: dt }}));
                    dropZone.dispatchEvent(new DragEvent('dragover', {{ bubbles: true, cancelable: true, dataTransfer: dt }}));
                    dropZone.dispatchEvent(new DragEvent('drop', {{
                        bubbles: true,
                        cancelable: true,
                        dataTransfer: dt
                    }}));
                    matched = true;
                }}

                return matched;
            }} catch (err) {{
                return false;
            }}
        }})()
        """

        res = page.eval(js_inject, timeout=10)
        return bool(res.get("value"))

    except Exception:
        diag.exception("main.py:1252")
        return False




_enum_callbacks = []




def text_to_pdf_bytes(text: bytes, title: str = "") -> bytes:
    if FPDF is None:
        raise RuntimeError("fpdf is not installed")

    pdf = FPDF()
    try:
        if title:
            pdf.set_title(title)
    except Exception:
        diag.exception("main.py:1318")
        pass

    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    try:
        font_path = DATA_DIR / "DejaVuSans.ttf"
        if font_path.exists():
            pdf.add_font("DejaVu", "", str(font_path))
            pdf.set_font("DejaVu", size=10)
        else:
            pdf.set_font("Helvetica", size=10)
    except Exception:
        diag.exception("main.py:1332")
        try:
            pdf.set_font("Helvetica", size=10)
        except Exception:
            diag.exception("main.py:1336")
            pass

    decoded = text.decode("utf-8", errors="replace")

    for line in decoded.splitlines():
        line = line.strip()

        if not line:
            try:
                pdf.ln(6)
            except Exception:
                diag.exception("main.py:1348")
                pass
            continue

        try:
            pdf.multi_cell(0, 6, line)
        except Exception:
            diag.exception("main.py:1355")
            try:
                safe_line = line.encode("latin-1", errors="replace").decode("latin-1")
                pdf.multi_cell(0, 6, safe_line)
            except Exception:
                diag.exception("main.py:1360")
                pass

    return bytes(pdf.output())


_ILLEGAL_FS = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


def prompt_display_name(filename: str) -> str:
    """Имя так, как оно отображается в выпадающем списке (без служебных расширений)."""
    name = (filename or "").strip()
    name = name.replace("\\", "/").split("/")[-1]
    for ext in (".enc", ".bin", ".dat", ".txt", ".json", ".prompt", ".pdf"):
        if name.lower().endswith(ext):
            name = name[: -len(ext)]
    return name or "prompt"


def pdf_file_name(filename: str) -> str:
    """Итоговое имя PDF, которое увидит ИИ-чат."""
    safe = _ILLEGAL_FS.sub("_", prompt_display_name(filename)).strip(" .")
    return f"{safe or 'prompt'}.pdf"


def cache_key(filename: str) -> str:
    return _ILLEGAL_FS.sub("_", (filename or "").strip()) or "prompt"


TEMPLATE_EXPORT_NAME = "Шаблон.txt"

# v27: третье вложение — заявка на постановление (файл из формы «Документы»).
# Имя у него своё («ПОСТАНОВЛЕНИЕ LSCSD-IAD-141.txt»), поэтому сравниваем не
# по константе, а по фактическому имени файла, пришедшего из формы.
DOCUMENT_MARKER = "ПОСТАНОВЛЕНИЕ"
SHABLON_MANIFEST_KEY = "__shablon_txt__"
REQUIRED_CHAT_FILES = 2

WORKSPACE = SecureWorkspace(prefix="legalyze_")
MANIFEST = PromptCacheManifest(DATA_DIR / "prompt_cache.json")


# --------------------------------------------------------------------------- #
#  v26: СЕРВЕРНАЯ ЧАСТЬ УДАЛЕНА.
#  Здесь были AuthWorker / HWIDWorker / BalanceWorker / DecrementWorker —
#  вход в аккаунт, привязка устройства и счётчик запросов по сети. Больше нет
#  ни авторизации, ни счётчика, ни обращений к серверу. Осталась подготовка
#  файлов из локальной папки «Промт» (PDF промта + Шаблон.txt).
# --------------------------------------------------------------------------- #


class PromptLoaderWorker(QThread):
    """Готовит файлы для экспорта в чат ЛОКАЛЬНО (v26).

    Никакой сети: промт берётся из локальной папки «Промт» рядом с
    config.json (её же читает кнопка «Промт»), PDF формируется из файла
    промта, Шаблон.txt — из окна «Шаблон».
    """

    progress = pyqtSignal(str)
    loaded = pyqtSignal(bool, object)

    @stage
    def __init__(self, cfg, force=False):
        super().__init__()
        self.cfg = cfg
        self.force = force

    def _prepare_template_file(self) -> str:
        # v35: в чат уходит Шаблон.txt АКТИВНОГО персонажа, а не «один на всех».
        tpl = normalize_template(active_template(self.cfg))
        tpl_hash = template_hash(tpl)
        entry = MANIFEST.get(SHABLON_MANIFEST_KEY)

        need_write = (
            self.force
            or not TEMPLATE_FILE.exists()
            or entry.get("template_hash") != tpl_hash
        )
        if need_write:
            self.progress.emit("Обновление Шаблон.txt…")
            write_template_file(tpl)
            try:
                file_sha = sha256_bytes(TEMPLATE_FILE.read_bytes())
            except Exception:
                diag.exception("main.template_file_sha")
                file_sha = ""
            MANIFEST.put(
                SHABLON_MANIFEST_KEY,
                template_hash=tpl_hash,
                file_sha256=file_sha,
                updated_at=int(time.time()),
            )
        else:
            self.progress.emit("Шаблон не изменился — используем готовый Шаблон.txt…")
        return str(TEMPLATE_FILE)

    def run(self):
        try:
            sel = self.cfg.get("selected_prompt", "")
            if not sel:
                self.loaded.emit(False, "Промт не выбран — нажмите «Промт» и выберите файл")
                return

            PROMPTS_DIR.mkdir(parents=True, exist_ok=True)
            key = cache_key(sel)
            enc_source = PROMPTS_DIR / key
            enc_pdf = PROMPTS_DIR / f"{key}.pdfenc"
            out_name = pdf_file_name(sel)

            entry = MANIFEST.get(key)
            if enc_source.exists() and not enc_pdf.exists() and entry.get("pdf_name") != out_name:
                pass  # кэш пуст — ниже соберём PDF из локального файла промта

            pdf_bytes = None

            if enc_pdf.exists() and not self.force and entry.get("pdf_name") == out_name:
                try:
                    self.progress.emit("Промт не изменился — мгновенный экспорт из кэша…")
                    cached = decrypt_blob(enc_pdf.read_bytes())
                    if cached[:4] == b"%PDF":
                        pdf_bytes = cached
                except Exception:
                    diag.exception("main.prompt_cache")
                    pdf_bytes = None

            if pdf_bytes is None:
                if not enc_source.exists():
                    self.loaded.emit(
                        False,
                        f"Файл промта не найден в папке «Промт»: {PROMPTS_DIR}",
                    )
                    return

                raw = enc_source.read_bytes()

                self.progress.emit("Подготовка PDF промта…")
                try:
                    decrypted = decrypt_data_auto(raw)
                except Exception:
                    # Локальный промт может лежать и «как есть» (без шифрования):
                    # .pdf или .txt, положенный в папку вручную.
                    decrypted = raw
                if isinstance(decrypted, str):
                    decrypted = decrypted.encode("utf-8")

                if decrypted[:4] == b"%PDF":
                    pdf_bytes = bytes(decrypted)
                else:
                    if FPDF is None:
                        self.loaded.emit(False, "Промт не PDF — установите fpdf2 или положите .pdf в папку «Промт»")
                        return
                    self.progress.emit("Текстовый промт — формирование PDF…")
                    pdf_bytes = text_to_pdf_bytes(decrypted, title=prompt_display_name(sel))

                decrypted = b""

                try:
                    enc_pdf.write_bytes(encrypt_blob(pdf_bytes))
                except Exception:
                    diag.exception("main.prompt_cache_write")
                    pass

                MANIFEST.put(
                    key,
                    source_sha256=sha256_bytes(raw),
                    pdf_name=out_name,
                    pdf_sha256=sha256_bytes(pdf_bytes),
                    updated_at=int(time.time()),
                )

            pdf_path = WORKSPACE.write(out_name, pdf_bytes)
            template_path = self._prepare_template_file()

            self.progress.emit("Экспорт в чат…")
            self.loaded.emit(True, {"pdf": str(pdf_path), "template": template_path})

        except Exception as e:
            diag.exception("main.prompt_loader")
            self.loaded.emit(False, f"Ошибка подготовки промта: {e}")


class DraggableDialog(QDialog):
    """Базовый диалог с поддержкой свободного перемещения мышью за любую область (v25)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._drag_pos = None
        if ICON_FILE.exists():
            self.setWindowIcon(QIcon(str(ICON_FILE)))

    def showEvent(self, event):
        super().showEvent(event)
        try:
            apply_win32_icon(int(self.winId()))
        except Exception:
            pass

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            child = self.childAt(event.position().toPoint())
            # Не перехватываем клик, если пользователь кликнул по интерактивным элементам ввода
            if not isinstance(child, (QAbstractButton, QLineEdit, QComboBox)):
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos is not None:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
        super().mouseReleaseEvent(event)


def prompts_dir() -> Path:
    """Локальная папка с промтами (v26): рядом с config.json.

    Именно её показывает кнопка «Промт»: никакого списка с сервера больше нет.
    Поддерживаются .pdf, .txt и .enc — всё, что пользователь положил сам.
    """
    return PROMPTS_DIR


def list_local_prompts() -> list:
    """Файлы промтов из локальной папки (без служебных .pdfenc и кэшей)."""
    result = []
    try:
        folder = prompts_dir()
        folder.mkdir(parents=True, exist_ok=True)
        for path in sorted(folder.iterdir()):
            try:
                if not path.is_file():
                    continue
                if path.name.startswith(".") or path.name.endswith((".pdfenc", ".tmp")):
                    continue
                result.append(path.name)
            except Exception:
                diag.exception("main.list_local_prompts")
        return result
    except Exception:
        diag.exception("main.list_local_prompts_root")
        return result


class TemplateWindow(DraggableDialog):
    """Вкладка «Шаблон» — выровненная форма (ТЗ п.3, v25 draggable)."""

    FIELDS = [
        ("Name", "Имя и фамилия", "Mike Macmillan"),
        ("ID", "ID", "85028"),
        ("Fraction", "Фракция", "SANG"),
        ("Rang", "Ранг", "11"),
        ("Department", "Отдел", "MP"),
        ("JobTitle", "Должность", "Заместитель командующего MP, сенатор NG"),
    ]

    # v37: отдельных «полей для бланка» больше нет.
    #
    # Замечание: «Убери лишние строки ввода. Звание соответствует Должности,
    # Должность полностью и Должность одинаковы, Ведомство в бланке — это
    # Фракция, город всегда Лос-Сантос, Должность прокурора — это Должность,
    # Удостоверение — это ID, а реквизиты Прокурора должны вводиться в
    # конструкторе, а не в шаблоне».
    #
    # Бланк теперь собирается из шести полей персонажа (см. `_template_document`),
    # а всё, что относится к конкретному постановлению, вводится в самом
    # конструкторе «Документы → Постановление».
    EXTRA_FIELDS = []

    @stage
    def __init__(self, cfg, token="", parent=None):
        super().__init__(parent)
        self.cfg = cfg
        # v26: сервера нет — token оставлен в подписи для совместимости вызовов.
        self.token = token
        self.setWindowTitle("Шаблон данных")
        self.setFixedSize(560, 720)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Dialog
        )
        self.setStyleSheet(BASE_QSS)
        self.setModal(True)

        root = QVBoxLayout(self)
        root.setContentsMargins(30, 26, 30, 24)
        root.setSpacing(6)

        title = QLabel("Шаблон данных")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"font-size: 19px; font-weight: 700; color: {THEME['accent']};")
        root.addWidget(title)

        hint = QLabel("Поля подставляются в промт перед экспортом в чат")
        hint.setObjectName("Caption")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(hint)

        root.addSpacing(10)

        # ── v35: выбор персонажа (шаблонов может быть несколько) ──────────
        # v35.1: выбор персонажа — отдельная строка, кнопки управления —
        # следующая. В одну строку они не помещались и обрезались по высоте.
        profile_row = QHBoxLayout()
        profile_row.setSpacing(8)
        profile_caption = QLabel("Персонаж")
        profile_caption.setStyleSheet(f"color: {THEME['muted']}; font-size: 12px;")
        profile_row.addWidget(profile_caption)
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumHeight(30)
        self.profile_combo.currentTextChanged.connect(self._on_profile_changed)
        profile_row.addWidget(self.profile_combo, 1)
        root.addLayout(profile_row)

        profile_actions = QHBoxLayout()
        profile_actions.setSpacing(6)
        profile_actions.addSpacing(70)          # выравнивание под списком

        def _profile_button(caption, tip, slot):
            """Кнопки персонажей: высота с запасом, без обрезки по вертикали."""
            button = QPushButton(caption)
            button.setToolTip(tip)
            button.setMinimumHeight(30)
            button.setFixedHeight(30)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setStyleSheet(
                "QPushButton { font-size: 11px; padding: 0px 8px; }")
            button.clicked.connect(lambda _c=False: slot())
            return button

        self.btn_add_profile = _profile_button(
            "Добавить", "Новый персонаж со своим набором данных", self._add_profile)
        profile_actions.addWidget(self.btn_add_profile, 1)

        self.btn_rename_profile = _profile_button(
            "Переименовать", "Переименовать текущего персонажа", self._rename_profile)
        profile_actions.addWidget(self.btn_rename_profile, 1)

        self.btn_delete_profile = _profile_button(
            "Удалить", "Удалить текущего персонажа", self._delete_profile)
        profile_actions.addWidget(self.btn_delete_profile, 1)
        root.addLayout(profile_actions)

        self.profile_hint = QLabel("Переключаться между персонажами можно в любой момент.")
        self.profile_hint.setObjectName("Caption")
        self.profile_hint.setWordWrap(True)
        root.addWidget(self.profile_hint)

        root.addSpacing(10)

        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.DontWrapRows)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        form.setFormAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(12)

        self.fields = {}
        # v35: поля показывают данные АКТИВНОГО персонажа
        template = active_template(cfg)

        for key, caption, placeholder in self.FIELDS:
            lbl = QLabel(f"{caption}")
            lbl.setMinimumWidth(130)
            lbl.setStyleSheet(f"color: {THEME['muted']}; font-size: 13px;")
            inp = QLineEdit()
            inp.setPlaceholderText(placeholder)
            val = template.get(key, "")
            inp.setText(val if val is not None else "")
            inp.setMinimumHeight(40)
            inp.setMinimumWidth(300)
            self.fields[key] = inp
            form.addRow(lbl, inp)

        # v37: строки «для бланков» убраны — бланк берёт данные из полей
        # персонажа выше. Блок остаётся на случай, если понадобится вернуть
        # отдельный реквизит: пустой список ничего не рисует.
        if self.EXTRA_FIELDS:
            extra_title = QLabel("Дополнительные реквизиты бланка")
            extra_title.setObjectName("Caption")
            form.addRow(QLabel(""), extra_title)
        for key, caption, placeholder in self.EXTRA_FIELDS:
            lbl = QLabel(f"{caption}")
            lbl.setMinimumWidth(130)
            lbl.setStyleSheet(f"color: {THEME['muted']}; font-size: 13px;")
            inp = QLineEdit()
            inp.setPlaceholderText(placeholder)
            val = template.get(key, "")
            inp.setText(val if val is not None else "")
            inp.setMinimumHeight(34)
            inp.setMinimumWidth(300)
            self.fields[key] = inp
            form.addRow(lbl, inp)

        # v27: строк стало больше — форма прокручивается, окно сохраняет размер.
        form_host = QWidget()
        form_host.setLayout(form)
        form_scroll = QScrollArea()
        form_scroll.setWidgetResizable(True)
        form_scroll.setFrameShape(QFrame.Shape.NoFrame)
        form_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        form_scroll.setWidget(form_host)
        form_host.setStyleSheet("background: transparent;")
        root.addWidget(form_scroll, 1)

        self.sync_label = QLabel("")
        self.sync_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.sync_label.setStyleSheet("color: #f59e0b; font-size: 11px;")
        root.addWidget(self.sync_label)

        btn = QPushButton("Сохранить")
        btn.setObjectName("Primary")
        btn.setMinimumHeight(46)
        btn.setMinimumWidth(200)
        btn.clicked.connect(lambda _checked=False: self._save())

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("Ghost")
        cancel_btn.setMinimumHeight(46)
        cancel_btn.setMinimumWidth(200)
        cancel_btn.clicked.connect(lambda _checked=False: self.reject())
        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(btn)
        btn_layout.addStretch()
        root.addLayout(btn_layout)

        # v35: список персонажей заполняем после формы
        self._reload_profiles()

    # ------------------------------------------------- персонажи (v35)

    def _reload_profiles(self) -> None:
        """Перечитывает список персонажей из конфига и ставит активного."""
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItems([p["name"] for p in template_profiles(self.cfg)])
        self.profile_combo.setCurrentText(active_profile_name(self.cfg))
        self.profile_combo.blockSignals(False)
        single = self.profile_combo.count() <= 1
        self.btn_delete_profile.setEnabled(not single)
        self.btn_delete_profile.setToolTip(
            "Нельзя удалить единственного персонажа" if single else "Удалить персонажа")

    def _on_profile_changed(self, name: str) -> None:
        """Переключение персонажа: подставляем его данные в поля."""
        name = str(name or "").strip()
        if not name:
            return
        # сохраняем текущие правки в профиль, который был активным
        current = active_profile_name(self.cfg)
        if current and current != name:
            save_template(self.cfg, self.get_template())
        if select_profile(self.cfg, name):
            save_config(self.cfg)
            self.set_template(active_template(self.cfg))
            self.status_profile(f"Выбран персонаж: {name}")

    def set_template(self, template: dict) -> None:
        """Заполняет поля формой другого шаблона (v35)."""
        for key, widget in self.fields.items():
            widget.setText(str((template or {}).get(key, "") or ""))

    def status_profile(self, text: str) -> None:
        if hasattr(self, "sync_label"):
            self.sync_label.setStyleSheet("color: #34d399; font-size: 11px;")
            self.sync_label.setText(text)

    def _add_profile(self) -> None:
        """Новый персонаж: пустая форма, имя можно сразу задать."""
        name, ok = QInputDialog.getText(
            self, "Новый персонаж",
            "Имя персонажа (подпись профиля):",
            text=f"Персонаж {self.profile_combo.count() + 1}")
        if not ok or not str(name).strip():
            return
        # сохраняем текущего, чтобы не потерять правки
        save_template(self.cfg, self.get_template())
        new_name = add_profile(self.cfg, str(name).strip(),
                               {field: "" for field in self.fields})
        select_profile(self.cfg, new_name)
        save_config(self.cfg)
        self._reload_profiles()
        self.set_template(active_template(self.cfg))
        self.status_profile(f"Добавлен персонаж: {new_name} — заполните его данные")

    def _rename_profile(self) -> None:
        old_name = self.profile_combo.currentText().strip()
        if not old_name:
            return
        name, ok = QInputDialog.getText(self, "Переименовать персонажа",
                                        "Новое имя:", text=old_name)
        if not ok or not str(name).strip() or str(name).strip() == old_name:
            return
        save_template(self.cfg, self.get_template())
        if not rename_profile(self.cfg, old_name, str(name).strip()):
            QMessageBox.information(self, "Имя занято",
                                    "Персонаж с таким именем уже есть.")
            return
        save_config(self.cfg)
        self._reload_profiles()
        self.status_profile("Персонаж переименован")

    def _delete_profile(self) -> None:
        name = self.profile_combo.currentText().strip()
        if not name:
            return
        if len(template_profiles(self.cfg)) <= 1:
            QMessageBox.information(self, "Нельзя удалить",
                                    "Должен остаться хотя бы один персонаж.")
            return
        answer = QMessageBox.question(
            self, "Удалить персонажа",
            f"Удалить персонажа «{name}» и все его данные?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        if delete_profile(self.cfg, name):
            save_config(self.cfg)
            self._reload_profiles()
            self.set_template(active_template(self.cfg))
            self.status_profile(f"Персонаж «{name}» удалён")

    def _save(self):
        # v26: шаблон сохраняется только локально (config.json + Шаблон.txt).
        # v35: и обязательно в профиль ТЕКУЩЕГО персонажа.
        save_template(self.cfg, self.get_template())
        save_config(self.cfg)
        self.accept()

    def get_template(self):
        return {k: v.text().strip() for k, v in self.fields.items()}


class HotkeyDialog(DraggableDialog):
    @stage
    def __init__(self, current_key, title="Горячая клавиша", taken=None, parent=None):
        super().__init__(parent)

        self.selected = current_key
        self.taken = set(taken or [])

        self.setWindowTitle(title)
        self.setFixedSize(380, 240)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Dialog
        )
        self.setStyleSheet(BASE_QSS)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        head = QLabel(title)
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {THEME['accent']};")
        layout.addWidget(head)

        cap = QLabel("Нажмите нужную клавишу на клавиатуре")
        cap.setObjectName("Caption")
        cap.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(cap)

        self.capture_label = QLabel(self.selected if self.selected else "Нажмите клавишу…")
        self.capture_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.capture_label.setMinimumHeight(60)
        self.capture_label.setStyleSheet(
            f"background: {THEME['bg2']}; border: 2px dashed {THEME['accent']};"
            f"border-radius: 10px; font-size: 22px; font-weight: 700; color: {THEME['accent']};"
        )
        layout.addWidget(self.capture_label)

        self.error = QLabel("")
        self.error.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.error.setStyleSheet("color: #f87171; font-size: 11px;")
        layout.addWidget(self.error)

        layout.addStretch()

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("Ghost")
        cancel_btn.clicked.connect(lambda _checked=False: self.reject())
        btn_layout.addWidget(cancel_btn)

        self.ok_btn = QPushButton("Применить")
        self.ok_btn.setObjectName("Primary")
        self.ok_btn.clicked.connect(lambda _checked=False: self._accept_if_valid())
        btn_layout.addWidget(self.ok_btn)

        layout.addLayout(btn_layout)
        self._validate()
        self.setFocus()

    def keyPressEvent(self, event):
        if event.isAutoRepeat():
            return

        key = Qt.Key(event.key())
        if key in (Qt.Key.Key_Escape,):
            self.reject()
            return

        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self._accept_if_valid()
            return

        name = resolve_key_event(event)
        if not name or name not in VK_MAP:
            self.error.setText("Эта клавиша не поддерживается")
            return

        self.selected = name
        self.capture_label.setText(name)
        self._validate()

    def _validate(self) -> bool:
        if not self.selected:
            self.error.setText("Нажмите клавишу на клавиатуре")
            self.ok_btn.setEnabled(False)
            return False
        if self.selected in self.taken:
            self.error.setText("Эта клавиша уже занята другой функцией")
            self.ok_btn.setEnabled(False)
            return False
        self.error.setText("")
        self.ok_btn.setEnabled(True)
        return True

    def _accept_if_valid(self):
        if self.selected and self._validate():
            self.accept()

    def get_key(self):
        return self.selected


class KeyCaptureButton(QPushButton):
    """Кнопка прямого захвата горячей клавиши по нажатию на клавиатуре (v25)."""
    key_captured = pyqtSignal(str)

    def __init__(self, current_key="", default_text="[ Нажмите клавишу ]", parent=None):
        super().__init__(parent)
        self._key = current_key
        self._default_text = default_text
        self._listening = False
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._update_display()
        self.clicked.connect(self._start_listening)

    def _update_display(self):
        if self._listening:
            self.setText("Нажмите клавишу…")
            self.setStyleSheet(
                f"background: {THEME['bg2']}; border: 2px dashed {THEME['accent']};"
                f"color: {THEME['accent']}; font-weight: 700; font-size: 13px; border-radius: 8px; padding: 6px 12px;"
            )
        elif self._key:
            self.setText(self._key)
            self.setStyleSheet(
                f"background: {THEME['bg2']}; border: 1px solid {THEME['accent']};"
                f"color: {THEME['text']}; font-weight: 700; font-size: 14px; border-radius: 8px; padding: 6px 12px;"
            )
        else:
            self.setText(self._default_text)
            self.setStyleSheet(
                f"background: {THEME['bg2']}; border: 1px dashed {THEME['muted']};"
                f"color: {THEME['muted']}; font-size: 13px; border-radius: 8px; padding: 6px 12px;"
            )

    def _start_listening(self):
        self._listening = True
        self._update_display()
        self.setFocus()

    def focusOutEvent(self, event):
        if self._listening:
            self._listening = False
            self._update_display()
        super().focusOutEvent(event)

    def keyPressEvent(self, event):
        if not self._listening:
            super().keyPressEvent(event)
            return

        if event.key() == Qt.Key.Key_Escape:
            self._listening = False
            self._update_display()
            return

        name = resolve_key_event(event)
        if not name or name not in VK_MAP:
            return

        self._key = name
        self._listening = False
        self._update_display()
        self.key_captured.emit(name)

    def get_key(self) -> str:
        return self._key

    def set_key(self, key: str):
        self._key = key
        self._listening = False
        self._update_display()


class OnboardingHotkeyWindow(DraggableDialog):
    """Окно первичной настройки горячих клавиш с объяснением функций на подобии «Шаблон» (v25)."""
    @stage
    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Настройка горячих клавиш")
        self.setFixedSize(560, 480)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Dialog
        )
        self.setStyleSheet(BASE_QSS)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 24)
        layout.setSpacing(6)

        title = QLabel("Горячие клавиши")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"font-size: 19px; font-weight: 700; color: {THEME['accent']};")
        layout.addWidget(title)

        subtitle = QLabel("Для быстрого доступа назначьте горячие клавиши поверх других окон")
        subtitle.setObjectName("Caption")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        layout.addSpacing(14)

        # Секция: Микрофон
        mic_box = QFrame()
        mic_box.setStyleSheet(
            f"background: {THEME['bg2']}; border: 1px solid {THEME['line']}; border-radius: 10px;"
        )
        mic_layout = QHBoxLayout(mic_box)
        mic_layout.setContentsMargins(18, 14, 18, 14)
        mic_info = QVBoxLayout()
        mic_info.setSpacing(4)
        mic_title = QLabel("Микрофон (голосовой ввод в ИИ)")
        mic_title.setStyleSheet(f"font-weight: 700; font-size: 14px; color: {THEME['text']}; border: none;")
        mic_desc = QLabel("Запись голоса с микрофона и отправка вопроса напрямую в нейросеть.")
        mic_desc.setObjectName("Caption")
        mic_desc.setWordWrap(True)
        mic_desc.setStyleSheet(f"border: none; color: {THEME['muted']}; font-size: 11px;")
        mic_info.addWidget(mic_title)
        mic_info.addWidget(mic_desc)
        mic_layout.addLayout(mic_info, 1)

        initial_mic = cfg.get("hotkey_mic", "") if cfg.get("hotkeys_configured") else ""
        self.btn_mic = KeyCaptureButton(current_key=initial_mic, default_text="[ Нажмите клавишу ]")
        self.btn_mic.setFixedWidth(160)
        self.btn_mic.setFixedHeight(44)
        self.btn_mic.key_captured.connect(lambda _k: self._validate())
        mic_layout.addWidget(self.btn_mic)
        layout.addWidget(mic_box)

        layout.addSpacing(4)

        # Секция: Окно
        toggle_box = QFrame()
        toggle_box.setStyleSheet(
            f"background: {THEME['bg2']}; border: 1px solid {THEME['line']}; border-radius: 10px;"
        )
        toggle_layout = QHBoxLayout(toggle_box)
        toggle_layout.setContentsMargins(18, 14, 18, 14)
        toggle_info = QVBoxLayout()
        toggle_info.setSpacing(4)
        toggle_title = QLabel("Окно (скрыть / показать)")
        toggle_title.setStyleSheet(f"font-weight: 700; font-size: 14px; color: {THEME['text']}; border: none;")
        toggle_desc = QLabel("Мгновенно сворачивает или разворачивает Legalyze поверх других окон.")
        toggle_desc.setObjectName("Caption")
        toggle_desc.setWordWrap(True)
        toggle_desc.setStyleSheet(f"border: none; color: {THEME['muted']}; font-size: 11px;")
        toggle_info.addWidget(toggle_title)
        toggle_info.addWidget(toggle_desc)
        toggle_layout.addLayout(toggle_info, 1)

        initial_toggle = cfg.get("hotkey_toggle", "") if cfg.get("hotkeys_configured") else ""
        self.btn_toggle = KeyCaptureButton(current_key=initial_toggle, default_text="[ Нажмите клавишу ]")
        self.btn_toggle.setFixedWidth(160)
        self.btn_toggle.setFixedHeight(44)
        self.btn_toggle.key_captured.connect(lambda _k: self._validate())
        toggle_layout.addWidget(self.btn_toggle)
        layout.addWidget(toggle_box)

        layout.addStretch()

        self.error_label = QLabel("")
        self.error_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.error_label.setStyleSheet("color: #ef4444; font-size: 12px; font-weight: 600;")
        layout.addWidget(self.error_label)

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("Ghost")
        cancel_btn.setMinimumHeight(46)
        cancel_btn.setMinimumWidth(180)
        cancel_btn.clicked.connect(lambda _checked=False: self.reject())
        btn_layout.addWidget(cancel_btn)

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.setObjectName("Primary")
        self.save_btn.setMinimumHeight(46)
        self.save_btn.setMinimumWidth(200)
        self.save_btn.clicked.connect(lambda _checked=False: self._save_and_accept())
        btn_layout.addWidget(self.save_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        self._validate()

    def _validate(self) -> bool:
        t_key = self.btn_toggle.get_key()
        m_key = self.btn_mic.get_key()
        if not t_key and not m_key:
            self.error_label.setText("Нажмите на поле и назначьте клавиши")
            self.save_btn.setEnabled(False)
            return False
        if not t_key or not m_key:
            self.error_label.setText("Пожалуйста, назначьте обе горячие клавиши")
            self.save_btn.setEnabled(False)
            return False
        if t_key == m_key:
            self.error_label.setText("Горячие клавиши не должны совпадать")
            self.save_btn.setEnabled(False)
            return False
        self.error_label.setText("")
        self.save_btn.setEnabled(True)
        return True

    def _save_and_accept(self):
        if self._validate():
            self.accept()

    def get_toggle_key(self) -> str:
        return self.btn_toggle.get_key()

    def get_mic_key(self) -> str:
        return self.btn_mic.get_key()


class HotkeyChip(QWidget):
    clicked = pyqtSignal()

    @stage
    def __init__(self, caption: str, key: str, parent=None):
        super().__init__(parent)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(1)

        self.caption = QLabel(caption)
        self.caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.caption.setStyleSheet(
            f"color: {THEME['muted']}; font-size: 9px; letter-spacing: 0.4px; border: none;"
        )
        lay.addWidget(self.caption)

        self.button = QPushButton(key if key else "—")
        self.button.setFixedHeight(22)
        self.button.setMinimumWidth(58)
        self.button.setSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._apply_style(False)
        self.button.clicked.connect(lambda _checked=False: self.clicked.emit())
        lay.addWidget(self.button)

    def _apply_style(self, active: bool):
        if not self.button.isEnabled():
            self.button.setStyleSheet("""
                QPushButton {
                    background: rgba(255, 255, 255, 0.05);
                    color: #555875;
                    border: 1px solid #262a4a;
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 700;
                    padding: 1px 6px;
                }
            """)
            return

        if active:
            self.button.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(52, 211, 153, 0.28);
                    color: #a7f3d0;
                    border: 1px solid {THEME['ok']};
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 700;
                    padding: 1px 6px;
                }}
            """)
        else:
            self.button.setStyleSheet(f"""
                QPushButton {{
                    background: rgba(124, 131, 255, 0.16);
                    color: #cdd2ff;
                    border: 1px solid rgba(124, 131, 255, 0.55);
                    border-radius: 6px;
                    font-size: 11px;
                    font-weight: 700;
                    padding: 1px 6px;
                }}
                QPushButton:hover {{
                    background: rgba(124, 131, 255, 0.32);
                    border-color: rgba(124, 131, 255, 0.85);
                    color: #ffffff;
                }}
            """)

    def set_key(self, key: str):
        self.button.setText(key if key else "—")

    def set_active(self, active: bool):
        self._apply_style(active)


class LoadingOverlay(QWidget):
    @stage
    def __init__(self, parent_window):
        super().__init__(None)
        self._owner = parent_window
        self._angle = 0.0
        self._pulse = 0.0
        self._title = "Подготовка промта"
        self._message = "Пожалуйста, подождите…"
        self._error = False

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.setCursor(Qt.CursorShape.BusyCursor)

        self._anim = QTimer(self)
        self._anim.timeout.connect(self._tick)
        self._anim.setInterval(16)

    def show_state(self, title: str, message: str, error: bool = False):
        if (
            self.isVisible()
            and self._title == title
            and self._message == message
            and self._error == error
        ):
            if not self._anim.isActive():
                self._anim.start()
            return
        self._title = title
        self._message = message
        self._error = error
        self.sync_geometry()
        if not self.isVisible():
            self.show()
        if not self._anim.isActive():
            self._anim.start()
        force_topmost(int(self.winId()))
        self.update()

    def set_message(self, message: str):
        self._message = message
        self.update()

    def finish(self):
        self._anim.stop()
        self.hide()

    def sync_geometry(self):
        try:
            owner = self._owner
            if not owner:
                return
            g = owner.geometry()
            top = owner.top_inset
            bottom = owner.bottom_inset
            self.setGeometry(g.x(), g.y() + top, g.width(), g.height() - top - bottom)
        except Exception:
            diag.exception("main.py:2285")
            pass

    def _tick(self):
        self._angle = (self._angle + 4.2) % 360.0
        self._pulse = (self._pulse + 0.035) % (2 * math.pi)
        self.update()

    def mousePressEvent(self, event):
        event.accept()

    def mouseDoubleClickEvent(self, event):
        event.accept()

    def wheelEvent(self, event):
        event.accept()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = self.rect()
        p.fillRect(rect, QColor(9, 11, 24, 238))

        cx = rect.width() / 2
        cy = rect.height() / 2

        glow = QColor(124, 131, 255, 26)
        radius = 90 + 12 * math.sin(self._pulse)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(glow))
        p.drawEllipse(QRectF(cx - radius, cy - radius - 40, radius * 2, radius * 2))

        card_w = min(rect.width() - 40, 340)
        card_h = 210
        card = QRectF(cx - card_w / 2, cy - card_h / 2, card_w, card_h)
        path = QPainterPath()
        path.addRoundedRect(card, 16, 16)
        p.setBrush(QBrush(QColor(21, 24, 48, 245)))
        p.setPen(QPen(QColor(38, 42, 74), 1))
        p.drawPath(path)

        spin_r = 26.0
        spin_rect = QRectF(cx - spin_r, card.top() + 34, spin_r * 2, spin_r * 2)

        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(42, 47, 84), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(spin_rect, 0, 360 * 16)

        accent = QColor(239, 68, 68) if self._error else QColor(124, 131, 255)
        p.setPen(QPen(accent, 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        span = int((110 + 40 * math.sin(self._pulse)) * 16)
        p.drawArc(spin_rect, int(-self._angle * 16), span)

        p.setPen(QColor(230, 232, 245))
        f = QFont("Segoe UI", 12, QFont.Weight.Bold)
        p.setFont(f)
        title_rect = QRectF(card.left() + 16, card.top() + 100, card.width() - 32, 26)
        p.drawText(title_rect, int(Qt.AlignmentFlag.AlignCenter), self._title)

        p.setPen(QColor(143, 150, 191))
        p.setFont(QFont("Segoe UI", 9))
        msg_rect = QRectF(card.left() + 18, card.top() + 128, card.width() - 36, 52)
        p.drawText(
            msg_rect,
            int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap),
            self._message,
        )

        bar_w = card.width() - 44
        bar = QRectF(card.left() + 22, card.bottom() - 26, bar_w, 4)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(38, 42, 74))
        p.drawRoundedRect(bar, 2, 2)

        seg_w = bar_w * 0.32
        pos = (self._angle / 360.0) * (bar_w + seg_w) - seg_w
        seg = QRectF(bar.left() + max(0.0, pos), bar.top(),
                     min(seg_w, bar_w - max(0.0, pos)), bar.height())
        p.setBrush(accent)
        p.drawRoundedRect(seg, 2, 2)

        p.end()


class TemplateSyncWorker(QThread):
    """Раньше тянул шаблон с сервера. В v26 сервера нет — потока тоже.

    Класс оставлен пустым наследником, чтобы `_sync_template_from_server`
    и любые внешние вызовы не падали: он просто сразу завершается.
    """

    done = pyqtSignal(dict)

    @stage
    def __init__(self, token="", parent=None):
        super().__init__(parent)
        self.token = token

    def run(self):
        return


class NativeHost(QObject):
    """Owns the real browser process and its embedded window.

    The page's own microphone lives in the browser, not in Qt: Web Speech API
    and getUserMedia+upload are wired to the vendor's cloud service and only
    exist in branded builds. So the browser runs out of process and its window
    is parented into the Qt placeholder.

    Every step is supervised, which is what the old `release/` build lacked:
    * DevTools never answers   -> retry with a fresh profile (a stale singleton
      owning the profile makes a new Chromium exit immediately),
    * still nothing            -> retry with `--disable-gpu` (Parsec/hybrid GPU
      stalls were one of the reported hangs),
    * still nothing            -> next installed browser.
    Any embedding failure is rolled back, so the user never keeps an invisible
    or detached browser window.
    """

    POLL_MS = 250
    DEVTOOLS_TIMEOUT = 25.0
    WINDOW_TIMEOUT = 30.0
    MAX_ATTEMPTS = 6

    ready = pyqtSignal(int)     # DevTools port
    failed = pyqtSignal(str)    # human readable reason

    def __init__(self, parent=None, url=URL, profile=None, app_dir=None,
                 width=W, height=H, configured=None, lang="ru-RU",
                 light_theme=True, accept_languages=None):
        super().__init__(parent)
        # v18: язык речевого ввода и светлая тема страницы.
        self.lang = str(lang or "ru-RU")
        self.light_theme = bool(light_theme)
        self.accept_languages = accept_languages
        self.url = url
        self.width = int(width)
        self.height = int(height)
        self.configured = configured
        self.placeholder = None
        self.candidates = []
        self.index = 0
        self.attempt = 0          # 0 = normal, 1 = fresh profile, 2 = GPU off
        self.attempts = 0
        self.gpu_off = os.environ.get("LEGALYZE_DISABLE_GPU") == "1"
        self.native = None
        self.hwnd = None
        self.port = None
        # v51: признак «хост остановлен» — по нему отсекаются поздние
        # Win32-вызовы по мёртвому окну браузера.
        self.stopped = False
        self.stage = "idle"
        self.stage_deadline = 0.0
        self.pids = set()
        # v15: сдвиг/размер окна браузера внутри плейсхолдера, физические px.
        self.inset = (0, 0, 0, 0)
        self.user32 = None
        self.kernel32 = None
        self.focus_bridge = None
        # v17: виджет-шторка приложения. Её hwnd передаётся в `embed`, чтобы
        # поднять шторку ДО показа окна браузера.
        self.cover_widget = None
        self.app_dir = Path(app_dir) if app_dir else Path(sys.argv[0]).resolve().parent
        self.profile = Path(profile) if profile else BROWSER_PROFILE
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self._init_win32()

    def _init_win32(self):
        if sys.platform != "win32":
            return
        try:
            self.user32 = ctypes.WinDLL("user32", use_last_error=True)
            self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            win32_embed.configure(self.user32)
            browser_focus.configure(self.user32, self.kernel32)
            self.focus_bridge = browser_focus.BrowserFocusBridge(self.user32, self.kernel32)
        except Exception:
            diag.exception("main.native_win32")
            self.user32 = None

    # ------------------------------------------------------------- lifecycle
    def start(self, placeholder):
        self.placeholder = placeholder
        self.candidates = discover_browsers(self.app_dir, self.configured)
        if not self.candidates:
            diag.event("browser.no_candidate", app_dir=str(self.app_dir))
            self.failed.emit("no-browser")
            return False
        self._spawn()
        return True

    def _spawn(self):
        if self.attempts >= self.MAX_ATTEMPTS:
            self.failed.emit("attempts-exhausted")
            return
        if self.index >= len(self.candidates):
            self.failed.emit("no-browser")
            return
        self.attempts += 1
        candidate = self.candidates[self.index]
        self.native = NativeBrowser(url=self.url, profile_dir=self.profile,
                                    app_dir=self.app_dir, gpu=not self.gpu_off,
                                    attempt=self.attempt,
                                    lang=self.lang,
                                    light_theme=self.light_theme,
                                    accept_languages=self.accept_languages)
        diag.event("browser.try", name=candidate.name, kind=candidate.kind,
                   attempt=self.attempts, gpu=not self.gpu_off)
        try:
            # Off-screen staging: the window is created (so it can be found)
            # but is never visible before the Qt cover is on top of it.
            self.native.launch(candidate, self.width, self.height, staging=(-8192, -8192))
        except Exception:
            diag.exception("main.browser_spawn")
            self._retry("spawn")
            return
        self.pids = {int(self.native.proc.pid)}
        _pid_journal_write(self.pids)
        self.stage = "devtools"
        self.stage_deadline = time.monotonic() + self.DEVTOOLS_TIMEOUT
        self.timer.start(self.POLL_MS)

    def _tick(self):
        if self.native is None:
            self.timer.stop()
            return
        if self.stage == "devtools":
            state, version, targets = self.native.probe()
            if state == "exited":
                self._retry("browser-exited")
                return
            if state == "ready":
                page = choose_target(targets or [])
                if page is None:
                    if time.monotonic() > self.stage_deadline:
                        self._retry("no-page")
                    return
                self.port = self.native.port
                diag.event("browser.devtools", browser=(version or {}).get("Browser"),
                           url=str(page.get("url"))[:120])
                self.stage = "window"
                self.stage_deadline = time.monotonic() + self.WINDOW_TIMEOUT
                return
            if time.monotonic() > self.stage_deadline:
                self._retry("devtools-timeout")
            return
        if self.stage == "window":
            self.refresh_pids()
            _pid_journal_write(self.pids)
            hwnd = win32_embed.find_browser_window(self.user32, self.pids, timeout=0.5)
            if hwnd:
                self._embed(hwnd)
                return
            if time.monotonic() > self.stage_deadline:
                self._retry("window-timeout")

    @diag.trace
    def _embed(self, hwnd):
        parent = int(self.placeholder.winId()) if self.placeholder else 0
        if not parent:
            self._retry("no-placeholder")
            return
        # Скрыть ДО встраивания: без этого окно на мгновение появляется
        # настоящим окном (со всеми элементами браузера) и попадает в Alt+Tab.
        win32_embed.hide_window(self.user32, hwnd)
        # v17: hwnd шторки — `embed` поднимет её до показа окна браузера.
        cover = 0
        if self.user32 is not None and self.cover_widget is not None:
            try:
                cover = int(self.cover_widget.winId())
            except Exception:
                diag.exception("main.cover_hwnd")
                cover = 0
        if not win32_embed.embed(self.user32, hwnd, parent, self.inset, cover=cover):
            self._retry("embed-failed")
            return
        self.hwnd = hwnd
        self.stage = "ready"
        self.timer.stop()
        win32_embed.sync(self.user32, hwnd, parent, self.inset)
        # v15: панель задач. Chrome сам возвращает свою кнопку через
        # ITaskbarList::AddTab и не сразу, поэтому скрываем сразу и повторяем.
        self.hide_taskbar()
        # Chrome поднимает окна и возвращает кнопку не сразу: первые секунды
        # проверяем часто, потом достаточно одного таймера раз в 5 с.
        for delay in (300, 800, 1500, 2500, 4000):
            QTimer.singleShot(delay, self.hide_taskbar)
        QTimer.singleShot(1200, self.hide_taskbar)
        QTimer.singleShot(4000, self.hide_taskbar)
        diag.event("browser.embedded", hwnd=int(hwnd), parent=parent, port=self.port,
                   exe=self.native.exe, kind=self.native.kind, inset=list(self.inset))
        self.ready.emit(int(self.port))

    @diag.trace
    def hide_taskbar(self):
        """Убрать из панели задач и встроенное окно, и все лишние окна браузера.

        Безопасна при повторном вызове: стиль меняется только если он уже не
        тот, а DeleteTab идемпотентен. Дерево pid пересчитывается каждый раз,
        иначе всплывшие позже окна остаются висеть.
        """
        if not self.hwnd or not self.user32 or getattr(self, "stopped", False):
            return
        if not self.alive_window():
            return
        self.refresh_pids()
        try:
            win32_embed.hide_from_taskbar(self.user32, self.hwnd,
                                          delete_tab=bool(TASKBAR_DELETE_TAB))
            self._hide_strays(keep=self.hwnd)
        except Exception:
            diag.exception("main.hide_taskbar")

    def refresh_pids(self):
        """Пересчитать дерево pid.

        После `ready` таймер останавливается, и `pids` застывает: процессы,
        поднятые позже (рендереры, утилиты), в него не попадают, и их окна
        остаются висеть в Alt+Tab.
        """
        proc = getattr(self.native, "proc", None)
        if proc is None:
            return
        try:
            root = int(proc.pid)
            self.pids |= {root} | win32_embed.descendant_pids(root)
        except Exception:
            diag.exception("main.refresh_pids")

    def _hide_strays(self, keep=0):
        """Скрыть (и закрыть) все окна браузера, кроме встроенного."""
        if not self.user32:
            return
        try:
            win32_embed.hide_stray_windows(self.user32, self.pids, keep=keep,
                                           close_after_hide=bool(CLOSE_STRAY_WINDOWS),
                                           delete_tab=bool(TASKBAR_DELETE_TAB))
        except Exception:
            diag.exception("main.hide_strays")

    def _kill_all(self):
        """Снять ВСЁ дерево браузера.

        `proc.terminate()` убивает только родителя: рендереры, GPU и утилиты
        выживают, их окна остаются — из-за этого «плодятся браузеры».
        Чужие процессы не трогаем: только pid своего дерева.
        """
        self.refresh_pids()
        pids = set(int(p) for p in (self.pids or ()))
        proc = getattr(self.native, "proc", None)
        if proc is not None:
            try:
                pids.add(int(proc.pid))
            except Exception:
                pass
        if not pids:
            return
        try:
            win32_embed.hide_stray_windows(self.user32, pids)
        except Exception:
            diag.exception("main.hide_stray_before_kill")
        try:
            win32_embed.kill_tree(pids)
        except Exception:
            diag.exception("main.kill_tree")

    def _retry(self, reason):
        self.timer.stop()
        diag.event("browser.retry", reason=reason, index=self.index,
                   attempt=self.attempts, gpu=not self.gpu_off)
        self._kill_all()
        if self.native is not None:
            self.native.close()
            self.native = None
        self.hwnd = None
        self.port = None
        # 1st: same browser, fresh profile. 2nd: GPU off. 3rd: next browser.
        if self.attempt == 0:
            self.attempt = 1
        elif self.attempt == 1:
            self.attempt = 2
            self.gpu_off = True
        else:
            self.index += 1
            self.attempt = 0
            self.gpu_off = os.environ.get("LEGALYZE_DISABLE_GPU") == "1"
            if self.index >= len(self.candidates):
                self.failed.emit(reason)
                return
        self._spawn()

    def restart_next(self):
        """Switch to the next browser (used when this build cannot do the
        page's voice input)."""
        self.timer.stop()
        self._kill_all()
        if self.native is not None:
            self.native.close()
            self.native = None
        self.hwnd = None
        self.port = None
        self.index += 1
        self.attempt = 0
        self.attempts = 0
        if self.index >= len(self.candidates):
            return False
        self._spawn()
        return True

    # --------------------------------------------------------------- helpers
    def sync(self):
        if not (self.hwnd and self.placeholder):
            return
        if not self.alive_window():
            diag.event("win32.sync_skipped", reason="window_gone")
            return
        try:
            win32_embed.sync(self.user32, self.hwnd, int(self.placeholder.winId()),
                             self.inset)
        except Exception:
            diag.exception("main.sync_geometry")

    def poll_focus(self, host_hwnd, enabled):
        if self.focus_bridge is None or not self.hwnd:
            return
        if not self.alive_window():
            return
        try:
            self.focus_bridge.poll(host_hwnd, self.hwnd, enabled)
        except Exception:
            diag.exception("main.focus_poll")

    def alive(self):
        return self.native is not None and self.native.alive()

    def stop(self):
        # v51: после остановки никакой Win32-вызов по этому hwnd не должен
        # выполняться. Раньше сторож фокуса и `sync()` продолжали работать по
        # уже убитому окну, а `kill_tree` убивал дерево асинхронно — гонка
        # «окно убито, дескриптор ещё в руках» и роняла процесс (п.2).
        self.stopped = True
        self.timer.stop()
        self._kill_all()
        if self.native is not None:
            self.native.close()
            self.native = None
        self.hwnd = None
        self.port = None
        self.stage = "stopped"

    def alive_window(self) -> bool:
        """Окно браузера существует и процесс жив (v51).

        Всё, что дёргает Win32 по hwnd браузера, сначала спрашивает здесь.
        """
        if getattr(self, "stopped", False) or not self.hwnd:
            return False
        if not self.alive():
            return False
        try:
            return win32_embed.is_window(self.user32, self.hwnd)
        except Exception:
            diag.exception("main.alive_window")
            return False


class BrowserFetchWorker(QThread):
    """Скачивает официальный Chrome for Testing (v18).

    Зачем: ШТАТНЫЙ микрофон страницы работает только в настоящем Chrome.
    Если его нет, приложение уходит во встроенный движок, а там запись идёт
    через Windows System.Speech — и пользователь видит «В Windows не
    установлен распознаватель речи». Скачивание устраняет ПРИЧИНУ.
    """

    progress = pyqtSignal(float, str)
    succeeded = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, dest, parent=None):
        super().__init__(parent)
        self.dest = Path(dest)
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            exe = browser_fetch.install(
                self.dest,
                report=lambda ratio, text: self.progress.emit(float(ratio), str(text)),
                cancel=lambda: self._cancel)
            self.succeeded.emit(str(exe))
        except Exception as exc:
            self.failed.emit(str(exc))


def app_dir() -> Path:
    r"""Папка приложения: для exe — рядом с ним, для исходников — рядом с main.py.

    Именно здесь `discover_browsers` ищет закреплённую сборку `browser\chrome.exe`.
    """
    try:
        return Path(sys.argv[0]).resolve().parent
    except Exception:
        diag.exception("main.app_dir")
        return Path.cwd()


class ChromeWorker(QThread):
    """CDP automation only: Qt owns the embedded view and browser processes."""
    hwnd_ready = pyqtSignal(object)
    failed = pyqtSignal()

    def __init__(self, parent=None, port=None, native=False, size=None,
                 lang="ru-RU", light=True):
        super().__init__(parent)
        self.proc = None
        self.browser = None
        self.page = None
        self.failure = {}
        self.port = port
        self.native = native
        # (physical width, height) of the placeholder: the zoom is computed from
        # it, so the layout is identical at 100 %, 125 % and 150 %.
        self.size = size
        # v18: язык речевого ввода и тема страницы (приходят из MainWindow).
        self.lang = lang
        self.light = light
        # v19: отпечаток поверхности (заполняется воротами готовности).
        self.surface = {}

    @diag.trace
    def run(self):
        try:
            self.browser, self.page = attach_chrome(self.port or DEBUG_PORT, timeout=30)
            try:
                install_compat(self.browser, self.page, native=self.native)
                grant_mic_permission(self.browser, self.page)
            except Exception:
                diag.exception("webengine.compat_stage")
            # v19: ворота готовности. Раньше «чатом» считалось любое текстовое
            # поле на странице с `readyState == "interactive"` — GUI прогрузки
            # снимали на недогруженной странице (именно это и описано в
            # «Error - 1»: «браузер как будто не прогрузился»).
            self.surface = wait_for_chat_surface(
                self.page, timeout=SURFACE_READY_TIMEOUT, lang=self.lang,
                light=self.light, should_stop=self.isInterruptionRequested)
            diag.state("page.verdict", self.surface.get("verdict"))
            diag.state("page.ready", bool(self.surface.get("ready")))
            diag.state("page.blocked", self.surface.get("blocked") or "")
            try:
                install_purge(self.page, lang=self.lang, light=self.light)
                if self.native:
                    self._apply_zoom()
                    grant_microphone(self.browser, self.page)
            except Exception:
                diag.exception("webengine.purge_stage")
            diag.event("webengine.chat_ready",
                       ready=bool(self.surface.get("ready")),
                       verdict=self.surface.get("verdict"),
                       blocked=self.surface.get("blocked") or "",
                       rounds=self.surface.get("rounds"),
                       theme_repairs=self.surface.get("theme_repairs"))
            # Чатом это не оказалось (вход / согласие / залипание) — приложение
            # НЕ падает: страница показывается, а причина уходит в лог и в
            # строку состояния, чтобы пользователь мог войти в аккаунт.
            self.hwnd_ready.emit(True)
            return
        except Exception as exc:
            self.failure = {"phase": "web_page", "type": type(exc).__name__, "exit_code": None}
            diag.exception("webengine.worker")
            if not self.isInterruptionRequested():
                self.failed.emit()

    def _apply_zoom(self):
        """Native 67 % zoom, measured — never assumed (see native_browser.apply_zoom)."""
        logical_w, logical_h, physical_w, physical_h = self.size or (W, H, W, H)
        if not logical_w or not logical_h:
            return
        try:
            result = apply_zoom(self.page, int(logical_w), int(logical_h),
                                int(physical_w or logical_w), int(physical_h or logical_h))
        except Exception:
            diag.exception("webengine.zoom")
            return
        diag.event("webengine.zoom_applied", source=(result or {}).get("source"),
                   logical=(int(logical_w), int(logical_h)),
                   physical=(int(physical_w or logical_w), int(physical_h or logical_h)))

    def close_connections(self):
        for connection in (self.page, self.browser):
            if connection:
                try:
                    connection.close()
                except Exception:
                    diag.exception("webengine.close_connection")



class UploadThread(QThread):
    """Держит в чате ОБА файла: PDF промт и Шаблон.txt (ТЗ 1.3)."""

    decrement_signal = pyqtSignal()
    attached = pyqtSignal(bool)
    failed = pyqtSignal(str)
    #: v19: «на этой странице вложение не работает» — приходит с вердиктом.
    blocked = pyqtSignal(str)

    @stage
    def __init__(self, page, pdf_path, template_path, token, page_provider=None,
                 document_path=None, appeal_path=None):
        super().__init__()
        self.page = page
        # CDP-соединение умирает при навигации/перезагрузке страницы: поток
        # берёт актуальный page у воркера, иначе он вечно долбится в мёртвый
        # websocket и файлы не появляются до ручного Ctrl+R (v6, лог 20260930).
        self.page_provider = page_provider
        self.pdf_path = pdf_path
        self.template_path = template_path
        # v27: третье, необязательное вложение — заявка на постановление.
        self.document_path = document_path
        # v50: четвёртое, необязательное вложение — «Обращение.txt» с текстом
        # обращения. Текст в поле запроса больше не печатается.
        self.appeal_path = appeal_path
        self.token = token

        self._stop = False
        self.last_upload = 0
        self.files_loaded = False
        self._dedup_done = False
        self.wait_started = time.monotonic()
        self._next_diagnostic = 0.0
        self.fails = 0
        self.end_check_counter = 0
        # v19: сколько проверок подряд в чате НИ ОДНОГО файла. Если порог
        # превышен — это не «медленно грузится», а «на этой поверхности вложение
        # не работает» (жалоба «Error - 1»: .pdf и .txt не экспортировались).
        self.empty_rounds = 0
        self._last_block_log = 0.0

    def _report_blocked(self, state):
        """Один раз на `UPLOAD_BLOCK_LOG_EVERY` секунд: почему файлов нет."""
        now = time.monotonic()
        if now - self._last_block_log < float(UPLOAD_BLOCK_LOG_EVERY):
            return
        self._last_block_log = now
        surface = probe_page_surface(self.page)
        verdict = str(surface.get("verdict") or "unknown")
        diag.warn("upload_blocked", verdict=verdict, empty_rounds=self.empty_rounds,
                  files=surface.get("files"), chips=surface.get("chips"),
                  composer=surface.get("composer"), ready=surface.get("ready"),
                  account=surface.get("account"), pending=surface.get("pending"),
                  probe_ok=bool(state.get("probe_ok")),
                  uploading=bool(state.get("uploading")), fails=self.fails)
        # v20: один раз на поток — снимок «кода» страницы, на которой вложение
        # не работает. Именно этот файл показывает, ЧТО за поверхность отдал
        # сервис (например, режим ИИ в поиске без input[type=file]).
        if not getattr(self, "_trace_code_done", False):
            self._trace_code_done = True
            try:
                btrace.capture_page(self.page, reason="upload_blocked-%s" % verdict,
                                    full=True)
            except Exception:
                diag.exception("main.upload_blocked_capture")
        try:
            self.blocked.emit(verdict)
        except Exception:
            diag.exception("main.upload_blocked_signal")
        # Страницу без толку долбить не надо: вложений там нет.
        time.sleep(1.5)

    def _missing_files(self, names):
        missing = []
        try:
            pdf_name = Path(self.pdf_path).name if self.pdf_path else ""
        except Exception:
            diag.exception("main.py:2470")
            pdf_name = ""
        if pdf_name and self.pdf_path and not _chat_has_file(names, pdf_name):
            missing.append(self.pdf_path)
        if self.template_path and not _chat_has_file(names, TEMPLATE_EXPORT_NAME):
            missing.append(self.template_path)
        # v27: заявка на постановление — необязательное вложение. Держим её в
        # чате, только пока она реально нужна (файл выставлен).
        if self.document_path and not _chat_has_file(names, Path(self.document_path).name):
            missing.append(self.document_path)
        if self.appeal_path and not _chat_has_file(names, Path(self.appeal_path).name):
            missing.append(self.appeal_path)
        return missing

    def _has_both_files(self, names):
        try:
            pdf_name = Path(self.pdf_path).name if self.pdf_path else ""
        except Exception:
            diag.exception("main.py:2482")
            pdf_name = ""
        return bool(
            pdf_name
            and _chat_has_file(names, pdf_name)
            and _chat_has_file(names, TEMPLATE_EXPORT_NAME)
            and (not self.document_path
                 or _chat_has_file(names, Path(self.document_path).name))
            and (not self.appeal_path
                 or _chat_has_file(names, Path(self.appeal_path).name))
        )

    def _required_count(self) -> int:
        """Сколько вложений держим в чате: 2 обычно, 3–4 при заявке (v27, v50)."""
        return (REQUIRED_CHAT_FILES + (1 if self.document_path else 0)
                + (1 if self.appeal_path else 0))

    def _all_files(self) -> list:
        files = [self.pdf_path, self.template_path]
        if self.document_path:
            files.append(self.document_path)
        if self.appeal_path:
            files.append(self.appeal_path)
        return [f for f in files if f]

    def _refresh_page(self):
        if self.page_provider is None:
            return
        try:
            fresh = self.page_provider()
        except Exception:
            diag.exception("main.upload_page_provider")
            return
        if fresh is not None and fresh is not self.page:
            self.page = fresh
            diag.event("upload.page_refreshed")

    def run(self):
        while not self._stop:
            try:
                self._refresh_page()
                if self.wait_started is not None and time.monotonic() - self.wait_started >= 90:
                    self.failed.emit("attachment_deadline")
                    return
                pdf_ok = bool(self.pdf_path) and Path(self.pdf_path).exists()
                tpl_ok = bool(self.template_path) and Path(self.template_path).exists()
                if not self.page or not pdf_ok or not tpl_ok:
                    self.attached.emit(False)
                    time.sleep(0.2)
                    continue

                state = check_state(self.page)
                # v19: считаем проверки, на которых в чате нет ни одного файла.
                # Раньше поток молча повторял впрыск десятки раз подряд (в логе
                # «Error - 1» — 92 попытки и ни одной ошибки), и по логу было
                # невозможно понять, что вложение вообще не работает.
                if int(state.get("present", 0) or 0) == 0:
                    self.empty_rounds += 1
                else:
                    self.empty_rounds = 0
                if (self.empty_rounds >= int(UPLOAD_BLOCK_THRESHOLD)
                        and self.wait_started is not None
                        and time.monotonic() - self.wait_started > 12):
                    self._report_blocked(state)
                if time.monotonic() >= self._next_diagnostic:
                    self._next_diagnostic = time.monotonic() + 5
                    diag.event("upload.state", present=state.get("present"), uploading=state.get("uploading"),
                               probe_ok=state.get("probe_ok", False), pdf_exists=pdf_ok, template_exists=tpl_ok,
                               attempts_failed=self.fails)
                    log_page_probe(self.page)

                if state["uploading"]:
                    time.sleep(0.05)
                    continue

                present = int(state.get("present", 0) or 0)
                names = state.get("names", []) or []
                names_ok = any(str(n or "").strip() for n in names)
                # v58: чип с ошибкой загрузки — это НЕ вложение. Раньше он
                # попадал в `names`, файл считался прикреплённым и повторно не
                # отправлялся, а запрос уходил без файла. Теперь «грязные»
                # имена убираем, и автодогрузка прикрепляет файл заново
                # (замечание по «Ошибка загрузки.txt»).
                bad = [str(chip.get("name") or "").strip().lower()
                       for chip in ugate.error_chips(
                           ugate.normalize_chips(state.get("chips")))]
                if bad:
                    names = [n for n in names
                             if str(n or "").strip().lower() not in bad]
                    present = max(0, present - len(bad))
                    names_ok = any(str(n or "").strip() for n in names)
                    diag.event("upload.chip_error_seen", names=bad[:4],
                               present=present, attempt=int(self.fails))

                required = self._required_count()
                # v43.4 (сессия logs_43v): «готово» — это когда в чате лежат
                # ИМЕННО нужные файлы. `present >= required` подтверждал
                # готовность по счётчику: 3 чужих файла проходили проверку, и
                # запрос уходил без «Шаблон.txt» / без заявки. Теперь без
                # имён готовность не объявляется вовсе, а недостающие файлы
                # догружаются.
                if names_ok:
                    missing = self._missing_files(names)
                    complete = present >= required and not missing
                else:
                    missing = list(self._all_files())
                    complete = False

                if complete:
                    self.wait_started = None
                    # v44: дедупликация не должна сбрасывать подтверждение
                    # перед отправкой — после удаления дублей файлы догружались
                    # заново, состояние прыгало false → true, и вызывалась
                    # повторная отправка того же текста. Ждём, пока вложения
                    # понадобятся заново (сброс `_dedup_done` при новой заявке).
                    if (
                        not getattr(self, "_keep_attachments", False)
                        and names_ok
                        and not self._dedup_done
                        and present > required + 2
                        and self._has_both_files(names)
                    ):
                        self._dedup_done = True
                        self.files_loaded = False
                        self.attached.emit(False)
                        try:
                            self.page.eval(JS_REMOVE_ALL_FILES, timeout=3)
                        except Exception:
                            diag.exception("main.py:2530")
                            pass
                        self.last_upload = 0
                        time.sleep(0.8)
                        continue
                    if not self.files_loaded:
                        self.attached.emit(True)
                    self.files_loaded = True
                    self.fails = 0
                    # v20: «оба файла на месте» подтверждается замером ещё раз —
                    # теперь уже по финальному состоянию чата (имена, чипы),
                    # а не по счётчику.
                    try:
                        btrace.audit_export(
                            self.page, "complete",
                            [self.pdf_path, self.template_path],
                            extra={"present": int(present),
                                   "names": [str(n)[:80] for n in (names or [])][:8]})
                    except Exception:
                        diag.exception("main.audit_complete")
                    time.sleep(0.15)
                    continue

                if self.wait_started is None:
                    self.wait_started = time.monotonic()
                if self.files_loaded:
                    self.files_loaded = False
                    self.last_upload = 0
                    self.end_check_counter = 0
                    self.attached.emit(False)

                if (time.time() - self.last_upload) > 0.8:
                    time.sleep(random.uniform(0.05, 0.2))

                    if names_ok:
                        to_upload = list(missing) or (
                            self._all_files() if present < required else []
                        )
                    elif present == 0:
                        to_upload = self._all_files()
                    else:
                        try:
                            self.page.eval(JS_REMOVE_ALL_FILES, timeout=3)
                        except Exception:
                            diag.exception("main.py:2562")
                            pass
                        self.last_upload = time.time()
                        time.sleep(0.6)
                        continue

                    if not to_upload:
                        time.sleep(0.15)
                        continue

                    ok = True
                    for path in to_upload:
                        if self._stop:
                            return
                        started_attempt = time.monotonic()
                        if path == self.pdf_path:
                            kind = "pdf"
                        elif path == self.template_path:
                            kind = "template"
                        else:
                            kind = "document"
                        try:
                            size = Path(path).stat().st_size if path else 0
                        except Exception:
                            size = 0
                        injected = upload_file_advanced(self.page, path)
                        # v19: попытка видна целиком — чем впрыскивали, сколько
                        # весило, сколько заняло и во что (сколько в странице
                        # полей для файла). Без этого «файлы не экспортируются»
                        # остаётся непроверяемым утверждением.
                        diag.event("upload.attempt", kind=kind, injected=bool(injected),
                                   bytes=int(size),
                                   ms=round((time.monotonic() - started_attempt) * 1000),
                                   empty_rounds=int(self.empty_rounds),
                                   fails=int(self.fails),
                                   name=Path(path).name if path else "")
                        # v20: доказательство экспорта по каждому вложению —
                        # файл на диске (размер/sha), результат впрыска, что
                        # оказалось в input[type=file] и в чипах чата.
                        try:
                            btrace.audit_export(
                                self.page, "after_inject" if injected else "inject_failed",
                                [path], extra={"attach": kind, "injected": bool(injected),
                                               "bytes": int(size),
                                               "ms": round((time.monotonic() - started_attempt) * 1000)})
                        except Exception:
                            diag.exception("main.audit_inject")
                        if not injected:
                            ok = False
                            break
                        time.sleep(0.3)

                    if ok:
                        self.last_upload = time.time()
                        self.fails = 0
                        time.sleep(0.3)
                        continue

                    self.fails += 1
                    # Безопасный повтор без аварийного выхода из цикла
                    backoff = min(3.0, 0.5 + 0.3 * min(self.fails, 8))
                    time.sleep(backoff)
                    continue

                time.sleep(0.05)

            except Exception:
                diag.exception("main.py:2594")
                time.sleep(0.2)

    def stop(self):
        self._stop = True


class PromptSelectionWindow(DraggableDialog):
    @stage
    def __init__(self, items, display_names, current_index, parent=None):
        super().__init__(parent)
        self.items = items
        self.choice = None

        self.setWindowTitle("Выбор промта")
        self.setFixedSize(280, 160)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Dialog
        )
        self.setStyleSheet(BASE_QSS)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel("Выберите рабочий промт")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {THEME['accent']};")
        layout.addWidget(title)

        self.combo = QComboBox()
        self.combo.addItems(display_names)
        self.combo.setCurrentIndex(current_index)
        self.combo.setMinimumHeight(38)
        layout.addWidget(self.combo)

        layout.addStretch()

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(8)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("Ghost")
        cancel_btn.clicked.connect(lambda _checked=False: self.reject())
        btn_layout.addWidget(cancel_btn)

        ok_btn = QPushButton("Выбрать")
        ok_btn.setObjectName("Primary")
        ok_btn.clicked.connect(lambda _checked=False: self._on_accept())
        btn_layout.addWidget(ok_btn)

        layout.addLayout(btn_layout)
        self.sync_position()

    def sync_position(self):
        parent = self.parentWidget()
        if parent:
            pg = parent.geometry()
            # v24: строго слева от главного окна
            self.move(pg.x() - self.width() - 8, pg.y())

    def _on_accept(self):
        idx = self.combo.currentIndex()
        if 0 <= idx < len(self.items):
            self.choice = self.items[idx]
        self.accept()


class BrowserOfferDialog(DraggableDialog):
    """Окно подтверждения скачивания Chrome for Testing (v24/v25 draggable).

    Располагается СЛЕВА от главного окна (по аналогии с «Промт»).
    Никогда не перекрывает главное GUI и не прячется под шторкой загрузки.
    """
    @stage
    def __init__(self, parent=None):
        super().__init__(parent)
        self.choice = False
        self.setWindowTitle("Речевой ввод")
        self.setFixedSize(300, 230)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Dialog
        )
        self.setStyleSheet(BASE_QSS)
        self.setModal(True)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(10)

        title = QLabel("Установка речевого ввода")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"font-size: 14px; font-weight: 700; color: {THEME['accent']};")
        layout.addWidget(title)

        desc = QLabel(
            "Голосовой ввод работает через штатный микрофон Google Chrome.\n\n"
            "Скачать официальный Chrome for Testing (~170 МБ) прямо сейчас?\n\n"
            "Без него ввод пойдёт через распознавание Windows."
        )
        desc.setWordWrap(True)
        desc.setStyleSheet(f"color: {THEME['text']}; font-size: 11px;")
        layout.addWidget(desc)

        layout.addStretch()

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(8)

        later_btn = QPushButton("Позже")
        later_btn.setObjectName("Ghost")
        later_btn.clicked.connect(self._on_later)
        btn_layout.addWidget(later_btn)

        install_btn = QPushButton("Скачать")
        install_btn.setObjectName("Primary")
        install_btn.clicked.connect(self._on_install)
        btn_layout.addWidget(install_btn)

        layout.addLayout(btn_layout)
        self.sync_position()

    def sync_position(self):
        parent = self.parentWidget()
        if parent:
            pg = parent.geometry()
            self.move(pg.x() - self.width() - 8, pg.y())

    def _on_install(self):
        self.choice = True
        self.accept()

    def _on_later(self):
        self.choice = False
        self.reject()


class MainWindow(QMainWindow):
    overlay_state = pyqtSignal(str, str, bool)
    # v18.2: браузер устоялся — можно снимать шторку (сигнал нужен, потому что
    # измерение идёт в фоновом потоке, а шторку снимает только главный).
    revive_settled = pyqtSignal(bool)
    response_poll_finished = pyqtSignal(object)
    # v27: разбор ответа ИИ под постановление идёт в фоновом потоке (CDP),
    # результат приходит в главный поток этим сигналом.
    _doc_answer_ready = pyqtSignal(str)
    # v43.4: отправка отложенной заявки идёт в фоновом потоке (внутри были
    # sleep и CDP-вызовы — интерфейс замирал на секунды, а таймер продолжал
    # тикать). Результат приходит этим сигналом: (ok, состояние).
    _pending_send_done = pyqtSignal(bool, str)
    # Горячие клавиши опрашиваются таймером главного потока (win32_hotkeys),
    # никаких потоков/скрытых окон: колбэк приходит сразу в контекст Qt GUI.

    @stage
    def __init__(self, cfg, token="", user_data=None):
        super().__init__()
        self.cfg = cfg
        # v26: ни аккаунта, ни сервера — token/user_data остались в подписи,
        # чтобы не менять вызовы, но ни на что не влияют.
        self.token = token
        self.user_data = user_data or {}

        self.mic_active = False
        self._mic_got_text = False
        # Режим браузера: native = настоящий Chrome/Chromium (штатный микрофон
        # страницы), False = встроенный QtWebEngine (резерв: диктовка Windows).
        self.native_mode = False
        self.cdp_port = DEBUG_PORT
        self.browser_host = None
        self.browser_physical = None
        self.browser_logical = None
        self._browser_demoted = False
        self._mic_retried = False
        self._mic_last_ts = 0.0
        self._mic_busy = False
        # v18: установка браузера и «оживление» после сворачивания.
        self._browser_install_offered = False
        self._fetch_worker = None
        self._fetch_dialog = None
        self._was_hidden = False
        self._was_minimized = False
        self._revive_settled = 0
        self._revive_last = None
        self._settling = False
        self._zoom_lock = threading.Lock()
        self.revive_settled.connect(self._on_revive_settled)
        # v18: язык речевого ввода и тема страницы (правятся в config.json).
        self.speech_lang = str(self.cfg.get("speech_lang") or SPEECH_LANG or "ru-RU")
        self.light_theme = bool(self.cfg.get("light_theme", FORCE_LIGHT_THEME))
        self.accept_languages = (str(self.cfg.get("accept_languages")
                                     or ACCEPT_LANGUAGES or "") or None)

        self.worker = None
        self.chrome_hwnd = None
        self.upload_thread = None
        #: v50: второе вложение заявки — «Обращение.txt» с текстом обращения.
        self.appeal_path = None
        self.pdf_path = None
        self.template_path = None
        # v27: заявка на постановление (третье вложение) и её состояние.
        self.document_path = None
        self._doc_sent_path = None
        self._document_doc = None
        self._document_pngs = []
        self.prompt_loader = None
        self.pdf_attached = False
        self.pdf_was_loaded_once = False
        self._last_attached_state = None
        self._closing = False
        self._cleaned = False
        self._hotkeys_registered = False
        self._chat_ready = False
        self._crash_recoveries = 0
        self.hotkeys = HotkeyMonitor(on_event=self._on_hotkey)
        # Опрос GetAsyncKeyState из главного потока Qt (~25 мс): работает с
        # любым фокусом/раскладкой и не может "не сработать".
        self._hotkey_timer = QTimer(self)
        self._hotkey_timer.setInterval(25)
        self._hotkey_timer.timeout.connect(self._hotkey_tick)
        self._hotkey_timer.start()
        self._response_poll_busy = False
        self.response_poll_finished.connect(self._apply_response_poll)
        self._doc_answer_ready.connect(self._apply_document_answer)
        self._pending_send_done.connect(self._on_pending_send_done)
        self._upload_failed = False
        # v26: автовыбор промта из локальной папки выполняется один раз за запуск.
        self._prompt_picker_shown = False
        self._auto_prompt_tried = False
        self.upload_deadline_timer = QTimer(self)
        self.upload_deadline_timer.setSingleShot(True)
        self.upload_deadline_timer.timeout.connect(self._upload_wait_expired)

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Window
        )
        self.setWindowTitle("Legalyze")
        if ICON_FILE.exists():
            self.setWindowIcon(QIcon(str(ICON_FILE)))
        self.drag_position = QPoint()

        self.setFixedSize(W, H)
        self.setGeometry(X, Y, W, H)

        self.top_inset = 54
        self.bottom_inset = 30
        self.side_inset = 20

        self.central_widget = QWidget()
        self.central_widget.setStyleSheet(f"background: {THEME['bg']};")
        self.setCentralWidget(self.central_widget)

        self.browser_placeholder = QWidget(self.central_widget)
        self.browser_placeholder.setGeometry(0, 0, W, H)
        self.browser_placeholder.setStyleSheet(f"background: {THEME['bg']};")
        self.browser_placeholder.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.browser_cover = QWidget(self.browser_placeholder)
        self.browser_cover.setGeometry(0, 0, W, H)
        self.browser_cover.setStyleSheet(f"background: {THEME['bg']};")
        # Окно браузера — настоящее HWND-окно внутри плейсхолдера, а обычный
        # виджет-потомок Qt всегда рисуется ПОД ним. Только нативное окно
        # поднимается выше: без этого «сырой» браузер виден до загрузки.
        self.browser_cover.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)
        self.browser_cover.hide()

        # v15: Chrome сам возвращает кнопку в панель задач — следим periodically.
        self.taskbar_timer = QTimer(self)
        self.taskbar_timer.timeout.connect(self._hide_browser_taskbar)

        self._build_chrome_ui()

        self.overlay = LoadingOverlay(self)
        self.overlay_state.connect(self._apply_overlay_state)
        self.overlay_state.emit("Инициализация", "Запуск защищённого браузера…", False)

        self._register_hotkeys()

        # v26: раньше браузер запускался «после ответа сервера о балансе».
        # Сервера нет — стартуем сразу, без ожидания сети.
        self.init_timer = QTimer(self)
        self.init_timer.timeout.connect(self._start_chrome)
        self.init_timer.setSingleShot(True)
        # v26: если Шаблон не заполнен — начинаем ИМЕННО С НЕГО, а не с
        # браузера. После сохранения шаблона работа идёт обычным порядком.
        if get_template_filled(self.cfg):
            self.init_timer.start(50)
        else:
            diag.event("template.required", filled=False)
            QTimer.singleShot(0, self._start_with_template)

        self.response_end_timer = QTimer(self)
        self.response_end_timer.timeout.connect(self._check_response_end_from_ui)
        self.response_end_timer.start(1000)

        self.topmost_timer = QTimer(self)
        self.topmost_timer.timeout.connect(self._enforce_topmost)
        self.topmost_timer.start(1200)

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _start_with_template(self):
        """Первый запуск: показываем «Шаблон», затем запускаем браузер (v26).

        Авторизации нет, поэтому единственное, что мешает работать на чистой
        машине, — незаполненный Шаблон. Окно открывается один раз и поверх
        шторки; после сохранения всё идёт как обычно.
        """
        try:
            self.raise_()
            self.activateWindow()
            dlg = TemplateWindow(self.cfg, parent=self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                save_template(self.cfg, dlg.get_template())
                diag.event("template.saved", source="startup")
            else:
                diag.event("template.dismissed", source="startup")
        except Exception:
            diag.exception("main.start_with_template")
        if not self._closing:
            self.init_timer.start(50)

    def _build_chrome_ui(self):
        panel = f"background-color: {THEME['panel']};"
        side_height = H - self.top_inset - self.bottom_inset

        self.overlay_top = QWidget(self.central_widget)
        self.overlay_top.setGeometry(0, 0, W, self.top_inset)
        self.overlay_top.setStyleSheet(
            panel + f"border-bottom: 1px solid {THEME['line']};"
        )

        shadow = QGraphicsDropShadowEffect(self.overlay_top)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 3)
        shadow.setColor(QColor(0, 0, 0, 170))
        self.overlay_top.setGraphicsEffect(shadow)

        icon_btn = f"""
            QPushButton {{
                background: rgba(255, 255, 255, 0.04);
                color: {THEME['text']};
                border: 1px solid {THEME['line']};
                border-radius: 5px;
                font-size: 9px;
                font-weight: 600;
                padding: 2px 5px;
                min-width: 0px;
            }}
            QPushButton:hover {{
                background: rgba(124, 131, 255, 0.24);
                border-color: {THEME['accent']};
                color: #ffffff;
            }}
            QPushButton:pressed {{ background: rgba(124, 131, 255, 0.4); }}
        """

        top_layout = QHBoxLayout(self.overlay_top)
        top_layout.setContentsMargins(12, 6, 10, 6)
        top_layout.setSpacing(6)

        brand = QVBoxLayout()
        brand.setSpacing(0)

        title_label = QLabel("Legalyze")
        title_label.setStyleSheet(
            f"color: {THEME['accent']}; font-weight: 800; font-size: 15px;"
            "letter-spacing: 0.3px; border: none;"
        )
        brand.addWidget(title_label)

        self.status_label = QLabel("Подключение…")
        self.status_label.setStyleSheet(
            f"color: {THEME['muted']}; font-size: 9px; border: none;"
        )
        brand.addWidget(self.status_label)
        top_layout.addLayout(brand)

        top_layout.addStretch()

        # ── чипы горячих клавиш с подписями ──
        mic_key = self.cfg.get("hotkey_mic", "")
        self.chip_mic = HotkeyChip("Микрофон", mic_key if mic_key else "—")
        self.chip_mic.button.setEnabled(True)
        self.chip_mic.clicked.connect(lambda _checked=False: self._choose_mic_hotkey())
        top_layout.addWidget(self.chip_mic)

        toggle_key = self.cfg.get("hotkey_toggle", "")
        self.chip_toggle = HotkeyChip("Окно", toggle_key if toggle_key else "—")
        self.chip_toggle.clicked.connect(lambda _checked=False: self._choose_hotkey())
        top_layout.addWidget(self.chip_toggle)

        sep = QLabel("")
        sep.setFixedWidth(1)
        sep.setStyleSheet(f"background: {THEME['line']}; border: none;")
        top_layout.addWidget(sep)

        self.btn_template = QPushButton("Шаблон")
        self.btn_template.setToolTip("Данные шаблона")
        self.btn_template.setFixedHeight(20)
        self.btn_template.setStyleSheet(icon_btn)
        self.btn_template.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_template.clicked.connect(lambda _checked=False: self._open_template())
        top_layout.addWidget(self.btn_template)
        self._refresh_template_button()

        # v27: универсальная кнопка документов (пока внутри — Постановление;
        # сюда же придут Жалобы, Иски и Обращения).
        self.btn_documents = QPushButton("Документ")
        self.btn_documents.setToolTip("Постановления (позже — жалобы, иски, обращения)")
        self.btn_documents.setFixedHeight(20)
        self.btn_documents.setStyleSheet(icon_btn)
        self.btn_documents.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_documents.clicked.connect(lambda _checked=False: self._open_documents())
        top_layout.addWidget(self.btn_documents)

        self.btn_prompt = QPushButton("Промт")
        self.btn_prompt.setToolTip("Выбор промта")
        self.btn_prompt.setFixedHeight(20)
        self.btn_prompt.setStyleSheet(icon_btn)
        self.btn_prompt.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_prompt.clicked.connect(lambda _checked=False: self._choose_prompt())
        top_layout.addWidget(self.btn_prompt)

        btn_restart = QPushButton("⟳")
        btn_restart.setToolTip("Перезапуск")
        btn_restart.setStyleSheet(icon_btn)
        btn_restart.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_restart.clicked.connect(lambda _checked=False: self._restart())
        top_layout.addWidget(btn_restart)

        btn_close = QPushButton("✕")
        btn_close.setToolTip("Закрыть")
        btn_close.setCursor(Qt.CursorShape.PointingHandCursor)
        btn_close.setStyleSheet(f"""
            QPushButton {{
                background: rgba(239, 68, 68, 0.16);
                color: #fca5a5;
                border: 1px solid rgba(239, 68, 68, 0.5);
                border-radius: 7px;
                font-size: 12px;
                font-weight: 700;
                padding: 5px 10px;
            }}
            QPushButton:hover {{ background: rgba(239, 68, 68, 0.55); color: #fff; }}
        """)
        btn_close.clicked.connect(lambda _checked=False: self._close_app())
        top_layout.addWidget(btn_close)

        self.overlay_left = QWidget(self.central_widget)
        self.overlay_left.setGeometry(0, self.top_inset, self.side_inset, side_height)
        self.overlay_left.setStyleSheet(panel + f"border-right: 1px solid {THEME['line']};")

        self.overlay_right = QWidget(self.central_widget)
        self.overlay_right.setGeometry(W - self.side_inset, self.top_inset, self.side_inset, side_height)
        self.overlay_right.setStyleSheet(panel + f"border-left: 1px solid {THEME['line']};")

        self.overlay_bottom = QWidget(self.central_widget)
        self.overlay_bottom.setGeometry(0, H - self.bottom_inset, W, self.bottom_inset)
        self.overlay_bottom.setStyleSheet(panel + f"border-top: 1px solid {THEME['line']};")

        bottom_layout = QHBoxLayout(self.overlay_bottom)
        bottom_layout.setContentsMargins(12, 4, 12, 4)
        bottom_layout.setSpacing(8)

        self.query_label = QLabel()
        self.query_label.setStyleSheet(
            f"color: {THEME['text']}; font-size: 11px; font-weight: 600; border: none;"
        )
        # v26: счётчик запросов из главного GUI убран — локальной сборке
        # нечего считать, баланса и аккаунта больше нет.
        self.query_label.hide()

        bottom_layout.addStretch()

        self.prompt_label = QLabel("промт: —")
        self.prompt_label.setStyleSheet(f"color: {THEME['muted']}; font-size: 10px; border: none;")
        bottom_layout.addWidget(self.prompt_label)

        self.dot_label = QLabel("●")
        self.dot_label.setStyleSheet("color: #f59e0b; font-size: 11px; border: none;")
        bottom_layout.addWidget(self.dot_label)

        self._update_query_label()
        self._update_prompt_label()

        for w in (self.overlay_top, self.overlay_left, self.overlay_right, self.overlay_bottom):
            w.raise_()

    def _update_query_label(self):
        """Счётчика запросов в главном GUI больше нет (v26).

        Метод оставлен пустым: он вызывается из нескольких мест, и удалять
        вызовы «на всякий случай» не нужно — счётчик просто не отображается.
        """
        return

    def _update_prompt_label(self):
        sel = self.cfg.get("selected_prompt", "")
        self.prompt_label.setText(f"промт: {prompt_display_name(sel) if sel else '—'}")

    def _set_status(self, text: str, color: str = None):
        self.status_label.setText(text)
        self.status_label.setStyleSheet(
            f"color: {color or THEME['muted']}; font-size: 9px; border: none;"
        )

    def _set_dot(self, color: str):
        self.dot_label.setStyleSheet(f"color: {color}; font-size: 11px; border: none;")

    def _apply_overlay_state(self, title, message, error):
        if not title:
            self.overlay.finish()
            return
        self.overlay.show_state(title, message, error)

    def _show_overlay(self, title, message, error=False):
        self.browser_cover.show()
        # Шторка должна быть ПОВЕРХ встроенного браузера (web-виджет создаётся
        # позже и иначе перекрывает её в z-порядке Qt).
        self.browser_cover.raise_()
        self.overlay_state.emit(title, message, error)

    def _prompt_selected(self) -> bool:
        """Выбран ли промт (v17).

        Пока промт не выбран, браузер не показывается: окно ожидания стоит
        ровно до момента выбора. Если конфиг по какой-то причине недоступен —
        интерфейс не блокируем (возвращаем True).
        """
        try:
            return bool(str(self.cfg.get("selected_prompt", "") or "").strip())
        except Exception:
            diag.exception("main.prompt_selected")
            return True

    # ------------------------------------------------------- v20: приборная панель
    def _trace_qt_probe(self):
        """Состояние Qt читается ТОЛЬКО в потоке GUI (v20).

        Виджеты Qt нельзя опрашивать из чужого потока — это как раз тот случай,
        когда «сбор логов» сам стал бы причиной нестабильности. Поэтому GUI
        раз в 100 мс обновляет простой словарь, а фоновой шкале достаётся уже
        готовый снимок (обычные числа и флаги, без обращений к Qt).
        """
        data = {}
        try:
            data["win_visible"] = bool(self.isVisible())
            data["win_min"] = bool(self.isMinimized())
            data["win_geo"] = list(self.geometry().getRect())
            data["dpr"] = round(float(self.devicePixelRatioF()), 3)
            data["cover"] = bool(self.browser_cover.isVisible())
            data["settling"] = bool(getattr(self, "_settling", False))
            data["overlay"] = bool(self.overlay.isVisible())
            data["chat_ready"] = bool(getattr(self, "_chat_ready", False))
            data["native"] = bool(getattr(self, "native_mode", False))
        except Exception:
            diag.exception("main.trace_qt_probe")
        return data

    def _trace_qt_tick(self):
        """Тик GUI-таймера: обновить снимок состояния для временной шкалы."""
        try:
            self._trace_qt_cache = self._trace_qt_probe()
            self._trace_qt_cache_at = time.monotonic()
            # Шкал больше нет — таймер не нужен: сбор не должен работать вхолостую.
            if btrace.active_watchers() == 0 and getattr(self, "_trace_qt_timer", None):
                self._trace_qt_timer.stop()
        except Exception:
            diag.exception("main.trace_qt_tick")

    def _trace_extra(self):
        """Снимок состояния Qt для записи (никогда не трогает виджеты извне)."""
        cache = getattr(self, "_trace_qt_cache", None)
        stamp = float(getattr(self, "_trace_qt_cache_at", 0.0) or 0.0)
        if cache and (time.monotonic() - stamp) < 2.0:
            return dict(cache)
        # Кэша ещё нет (первый вызов) — читаем сами. Сюда попадаем только из
        # потока GUI: таймер запускается ДО первой шкалы.
        return self._trace_qt_probe()

    def _trace_qt_keepalive(self):
        """Держать GUI-снимок свежим, пока есть хоть одна шкала (v20)."""
        if not getattr(self, "_trace_qt_timer", None):
            self._trace_qt_timer = QTimer(self)
            self._trace_qt_timer.setInterval(100)
            self._trace_qt_timer.timeout.connect(self._trace_qt_tick)
        if not self._trace_qt_timer.isActive():
            self._trace_qt_tick()
            self._trace_qt_timer.start()

    def _trace_args(self):
        """(user32, hwnd, parent, inset) для приборной панели. None — нет окна."""
        host = getattr(self, "browser_host", None)
        if host is None or getattr(host, "user32", None) is None or not getattr(host, "hwnd", 0):
            return None
        try:
            inset = tuple(self._browser_inset())
        except Exception:
            diag.exception("main.trace_inset")
            inset = tuple(getattr(host, "inset", (0, 0, 0, 0)) or (0, 0, 0, 0))
        try:
            parent = int(self.browser_placeholder.winId())
        except Exception:
            diag.exception("main.trace_parent")
            parent = 0
        return int(host.hwnd), parent, inset

    def _trace_watch(self, tag, duration=8.0, fast_until=3.0, min_ms=1200,
                     fast_ms=20, slow_ms=250, stable_needed=3):
        """Запустить временную шкалу окна вокруг возмущения (v20).

        Ничего в приложении не меняет: только измеряет. Если окна ещё нет
        (резервный движок, страница не поднялась) — просто ничего не делает.
        """
        if not BROWSER_TRACE_ON:
            return None
        args = self._trace_args()
        if args is None:
            btrace.mark("watch.skip", tag=str(tag), reason="no-native-window")
            return None
        hwnd, parent, inset = args
        # Снимок Qt обязана обновлять GUI-сторона — фоновая шкала только читает.
        self._trace_qt_keepalive()
        try:
            return btrace.watch(tag, hwnd, parent, inset,
                                page_provider=self._current_page,
                                extra_provider=self._trace_extra,
                                duration=duration, fast_until=fast_until,
                                min_ms=min_ms, fast_ms=fast_ms, slow_ms=slow_ms,
                                stable_needed=stable_needed)
        except Exception:
            diag.exception("main.trace_watch")
            return None

    def _trace_page(self, reason, full=False):
        """Снимок страницы в фоне: структура, метрики, при full — «код» (v20)."""
        if not BROWSER_TRACE_ON:
            return

        def task():
            page = self._current_page()
            if page is None:
                btrace.mark("page.snapshot_skipped", reason=str(reason))
                return
            try:
                btrace.capture_page(page, reason=reason, full=bool(full))
            except Exception:
                diag.exception("main.trace_page")

        threading.Thread(target=task, name="PageSnapshot", daemon=True).start()

    def _cover_to_top(self):
        """Шторка поверх окна браузера: и по z-порядку Qt, и по Win32 (v17).

        Окно браузера — настоящее HWND-окно внутри плейсхолдера. После
        `SetParent` оно встаёт поверх всех соседей, поэтому одного `raise_()`
        мало: поднимаем шторку принудительно через `SetWindowPos(HWND_TOP)`.
        """
        try:
            if not self.browser_cover.isVisible():
                self.browser_cover.show()
            self.browser_cover.raise_()
        except Exception:
            diag.exception("main.cover_raise")
        host = getattr(self, "browser_host", None)
        user32 = getattr(host, "user32", None) if host is not None else None
        if user32 is None:
            return
        try:
            win32_embed.raise_window(user32, int(self.browser_cover.winId()))
        except Exception:
            diag.exception("main.cover_top_win32")

    def _hold_cover_if_needed(self):
        """Держать шторку, пока браузер не должен быть виден (v17).

        Условие ровно одно: чат подтвердил готовность **И** промт выбран.
        Пока второго нет (чистый первый запуск), браузер остаётся закрытым —
        окно ожидания стоит до момента выбора промта, а не на секунду.
        """
        if self._closing:
            return
        # v18.3: пока браузер «устаивается» после показа окна, GUI прогрузки
        # стоит независимо ни от чего — иначе съехавшая раскладка видна.
        if getattr(self, "_settling", False):
            self._cover_to_top()
            try:
                if self.overlay.isVisible():
                    self.overlay.sync_geometry()
                    force_topmost(int(self.overlay.winId()))
            except Exception:
                diag.exception("main.settle_overlay_top")
            return
        if self._chat_ready and self._prompt_selected():
            return
        self._cover_to_top()

    @pyqtSlot(bool)
    def _on_revive_settled(self, stable):
        """Снять шторку: браузер встал на место (v18.2)."""
        self._settling = False
        if self._closing:
            return
        self._hide_overlay()
        diag.event("browser.revealed", stable=bool(stable),
                   settling=bool(getattr(self, "_settling", False)))

    def _hide_overlay(self):
        # v18.2: во время стабилизации шторку не снимает никто — только
        # `_on_revive_settled`, когда измерение подтвердило, что всё на месте.
        if getattr(self, "_settling", False):
            self._cover_to_top()
            return
        self.overlay_state.emit("", "", False)
        # v17: пока промт не выбран, браузер остаётся закрытым шторкой —
        # окно ожидания стоит ровно до момента выбора промта.
        if not self._prompt_selected():
            self._cover_to_top()
            return
        self.browser_cover.hide()


    def _enforce_topmost(self):
        if self._closing or not self.isVisible():
            return

        hwnd = int(self.winId())
        force_topmost(hwnd)

        if self.overlay.isVisible():
            self.overlay.sync_geometry()
            force_topmost(int(self.overlay.winId()))

    def moveEvent(self, event):
        super().moveEvent(event)
        try:
            if self.overlay.isVisible():
                self.overlay.sync_geometry()
        except Exception:
            diag.exception("main.py:2960")
            pass
        # v16: окно перетащили на монитор с другим масштабом — пересчитываем
        # сдвиг и зум СРАЗУ, а не по 5-секундному таймеру. Иначе браузер
        # уезжает в угол или в сторону.
        self._check_dpi_drift()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._sync_chrome_geometry()

    def showEvent(self, event):
        super().showEvent(event)
        try:
            apply_win32_icon(int(self.winId()))
        except Exception:
            pass
        self._sync_chrome_geometry()
        was_hidden = bool(getattr(self, "_was_hidden", False))
        # v18: окно вернулось после скрытия (F2) — браузер нужно перерисовать.
        if was_hidden:
            self._was_hidden = False
            self._schedule_revive()
        # v20: приборная панель. Показ окна — главное возмущение из всех: именно
        # после него пользователь видит «съехало и встало на место». Шкала
        # измеряет и окно, и страницу, и состояние Qt — по миллисекундам.
        btrace.mark("window.show", was_hidden=was_hidden, args=self._trace_extra())
        self._trace_watch("show", duration=10.0, fast_until=4.0, min_ms=1200)

    def hideEvent(self, event):
        super().hideEvent(event)
        self._was_hidden = True
        # v20: скрытие — начало возмущения; фиксируем позицию на момент ухода.
        btrace.mark("window.hide", args=self._trace_extra())
        self._trace_watch("hide", duration=4.0, fast_until=1.5, min_ms=300)
        if not REVIVE_AFTER_SHOW:
            return
        # v18.2: шторка встаёт СЕЙЧАС, пока окно не видно. Когда окно
        # покажут, пользователь увидит панель приложения, а не съезжающую
        # страницу: шторка снимется только по сигналу «устоялось».
        self._cover_to_top()
        # v18.1: окно всё равно не видно — ставим браузер точно на место,
        # чтобы к следующему показу он уже стоял там, где нужно.
        self._sync_browser_now()

    def changeEvent(self, event):
        super().changeEvent(event)
        self._sync_chrome_geometry()
        # v16: сам Windows/Qt сообщает о смене DPI или монитора — та же реакция.
        try:
            if event.type() in _METRIC_CHANGE_EVENTS:
                self._on_screen_metrics_changed("change_event")
        except Exception:
            diag.exception("main.change_metrics")
        # v18: вернулись из «свёрнутого» состояния — браузер перерисовываем.
        try:
            if event.type() == QEvent.Type.WindowStateChange:
                if self.isMinimized():
                    self._was_minimized = True
                    # v20: сворот — тоже возмущение: окно теряет кадр, а при
                    # развороте Chromium пересобирает раскладку.
                    btrace.mark("window.minimize", args=self._trace_extra())
                    self._trace_watch("minimize", duration=6.0, fast_until=2.0,
                                      min_ms=300)
                    # v18.2: свёрнутое окно всё равно не видно — поднимаем
                    # шторку заранее, чтобы при развороте не мелькнула
                    # съехавшая страница.
                    if REVIVE_AFTER_SHOW:
                        self._cover_to_top()
                elif self._was_minimized:
                    self._was_minimized = False
                    btrace.mark("window.restore", args=self._trace_extra())
                    self._schedule_revive()
        except Exception:
            diag.exception("main.revive_state")

    def _check_dpi_drift(self):
        """Среагировать на смену масштаба монитора под окном (v16).

        `devicePixelRatioF()` меняется, когда окно переезжает на монитор с
        другим масштабом. Пересчитываем сдвиг окна браузера, цель зума и
        убираем кнопку из панели задач — ровно то, что делает 5-секундный
        таймер, но немедленно. Пока монитор один и тот же — вызов пустой.
        """
        if self._closing or not self.native_mode:
            return
        try:
            dpr = float(self.devicePixelRatioF())
        except Exception:
            return
        if dpr <= 0:
            return
        previous = float(getattr(self, "_last_dpr", 0.0) or 0.0)
        if abs(dpr - previous) < 0.001:
            return
        self._last_dpr = dpr
        self._on_screen_metrics_changed("dpi_drift")

    def _on_screen_metrics_changed(self, source):
        """Пересчитать геометрию браузера под текущий монитор и масштаб (v16).

        Ничего не «поправляет» вручную: сдвиг считается из BROWSER_DX/DY в
        физические пиксели ТЕКУЩЕГО монитора, а зум — от РЕАЛЬНОГО размера
        окна браузера. Поэтому при 100 %, 125 % и 150 % раскладка одна и та
        же, окно не уезжает ни в угол, ни в сторону, и поле ввода остаётся на
        месте. Браузер при этом НЕ перезапускается.
        """
        if self._closing or not self.native_mode:
            return
        try:
            diag.event("main.screen_metrics_changed", source=str(source),
                       dpr=round(float(self.devicePixelRatioF()), 4),
                       scale=round(float(self._monitor_scale()), 4),
                       inset=list(self._browser_inset()))
        except Exception:
            diag.exception("main.metrics_log")
        # Реальный размер окна браузера — от него считается нативный зум 67 %.
        try:
            self.browser_physical = self._placeholder_physical_size()
            self.browser_logical = self._placeholder_logical_size()
        except Exception:
            diag.exception("main.metrics_size")
        self._sync_chrome_geometry()
        try:
            if self.worker is not None:
                self.worker.size = self._zoom_size()
        except Exception:
            diag.exception("main.metrics_worker_size")
        # Зум проверяется и, если нужно, возвращается в фоновом потоке:
        # GUI не блокируется, браузер не перезапускается.
        self._ensure_zoom()
        self._hide_browser_taskbar()

    def _sync_chrome_geometry(self):
        host = getattr(self, "browser_host", None)
        if self.native_mode and host is not None:
            # v16: сдвиг пересчитывается на КАЖДОЙ синхронизации. При смене
            # монитора или масштаба физический размер плейсхолдера меняется, и
            # сдвиг в пикселях обязан меняться вместе с ним: в DIP он как был
            # -10/-40, так и остаётся, а в пикселях при 150 % это -15/-60.
            # Без этого окно браузера уезжало бы в сторону на чужом масштабе.
            # Пока монитор не менялся — значение то же самое, до пикселя.
            try:
                host.inset = self._browser_inset()
            except Exception:
                diag.exception("main.reinset_sync")
            host.sync()
            return
        if getattr(self, "web_browser", None) is not None:
            try:
                self.web_browser.setGeometry(self.side_inset, self.top_inset,
                                             W - 2 * self.side_inset,
                                             H - self.top_inset - self.bottom_inset)
            except Exception:
                diag.exception("main.sync_embedded")

    def _browser_inset(self):
        """(left, top, right, bottom) окна браузера в ФИЗИЧЕСКИХ px плейсхолдера.

        Сдвиг из pre14, переведённый в физические пиксели текущего монитора:
        при 125 % и 150 % сдвиг в DIP тот же самый, а в пикселях — во столько
        же раз больше. Размер окна меняется только если заданы BROWSER_DW/DH.
        """
        try:
            dx = int(self.cfg.get("browser_dx", BROWSER_DX))
            dy = int(self.cfg.get("browser_dy", BROWSER_DY))
            dw = int(self.cfg.get("browser_dw", BROWSER_DW))
            dh = int(self.cfg.get("browser_dh", BROWSER_DH))
        except (TypeError, ValueError):
            dx, dy, dw, dh = BROWSER_DX, BROWSER_DY, BROWSER_DW, BROWSER_DH
        logical_w, logical_h = self._placeholder_logical_size()
        physical_w, physical_h = self._placeholder_physical_size()
        scale = (float(physical_w) / float(logical_w)) if logical_w else 1.0
        left = int(round(dx * scale))
        top = int(round(dy * scale))
        right = -int(round((dx + dw) * scale))
        bottom = -int(round((dy + dh) * scale))
        return (left, top, right, bottom)

    def _hide_browser_taskbar(self):
        """Периодически убираем кнопку браузера из панели задач (v15)."""
        host = getattr(self, "browser_host", None)
        if host is None or self._closing or not self.native_mode:
            return
        if getattr(host, "stopped", False):
            return
        try:
            host.hide_taskbar()
        except Exception:
            diag.exception("main.taskbar_timer")

    def _hide_strays_once(self):
        """Убрать лишние окна браузера, пересчитав дерево pid (v16).

        Без `refresh_pids()` дерево застывает на моменте `ready`, и окна,
        поднятые позже, остаются висеть в Alt+Tab.
        """
        host = getattr(self, "browser_host", None)
        if host is None or self._closing or not self.native_mode:
            return
        try:
            host.refresh_pids()
            host._hide_strays(keep=int(getattr(host, "hwnd", 0) or 0))
        except Exception:
            diag.exception("main.hide_strays_once")

    def _placeholder_logical_size(self):
        """РЕАЛЬНЫЙ размер плейсхолдера в DIP (Qt работает в DIP).

        Размер берётся у самого виджета, а не у воображаемого «слота» между
        рамками: плейсхолдер занимает всё окно (0, 0, W, H) = 453x735 DIP, и
        окно браузера растягивается именно на него. Прежняя формула давала
        413x651 DIP, то есть ширину раскладки 413 / 0.667 = 620 CSS px вместо
        нужных 453 / 0.667 = 680 CSS px — поэтому поле ввода и поле ответа ИИ
        стояли не на своих местах и съезжали вправо.
        """
        placeholder = getattr(self, "browser_placeholder", None)
        if placeholder is not None:
            try:
                width, height = int(placeholder.width()), int(placeholder.height())
                if width > 0 and height > 0:
                    return width, height
            except Exception:
                diag.exception("main.placeholder_logical")
        return int(W), int(H)

    def _browser_physical_size(self):
        """Физический размер клиентской области САМОГО окна браузера.

        Именно эта область видна пользователю, поэтому раскладка считается от
        неё: у окна приложения может быть рамка/заголовок, и тогда поверхность
        по высоте плейсхолдера срезала бы нижнюю часть страницы — поле ввода.
        Резерв — клиентская область плейсхолдера (пока окно ещё не встроено).
        """
        host = getattr(self, "browser_host", None)
        user32 = getattr(host, "user32", None) if host is not None else None
        hwnd = (getattr(host, "hwnd", 0) if host is not None else 0) \
            or getattr(self, "chrome_hwnd", 0)
        placeholder_size = self._placeholder_physical_size()
        if user32 and hwnd:
            try:
                width, height = win32_embed.client_size(user32, int(hwnd))
                width, height = int(width), int(height)
                if width > 0 and height > 0:
                    # Окно ещё не растянуто под плейсхолдер — не верим ему.
                    if abs(width - placeholder_size[0]) <= 0.4 * placeholder_size[0]:
                        return width, height
            except Exception:
                diag.exception("main.browser_physical")
        return placeholder_size

    def _monitor_scale(self):
        """Масштаб монитора: физический пиксель / DIP.

        1.0 при 100 %, 1.25 при 125 %, 1.5 при 150 %. Без этого метода перевод
        физического размера окна в DIP невозможен.
        """
        logical_w, logical_h = self._placeholder_logical_size()
        physical_w, physical_h = self._placeholder_physical_size()
        scale = (float(physical_w) / float(logical_w)) if logical_w else 0.0
        if scale <= 0:
            # Резерв: масштаб самого окна Qt. При 100 % оба пути дают 1.0,
            # поэтому на отлаженной машине ровным счётом ничего не меняется.
            try:
                scale = float(self.devicePixelRatioF())
            except Exception:
                diag.exception("main.monitor_scale_dpr")
                scale = 0.0
        return scale if scale > 0 else 1.0

    def _browser_logical_size(self):
        """Логический (DIP) размер САМОГО окна браузера.

        Резерв — плейсхолдер, пока окно ещё не встроено.
        """
        physical_w, physical_h = self._browser_physical_size()
        scale = self._monitor_scale()
        if scale <= 0:
            scale = 1.0
        width = int(round(physical_w / scale))
        height = int(round(physical_h / scale))
        if width > 0 and height > 0:
            return width, height
        return self._placeholder_logical_size()

    def _zoom_size(self):
        """(логические DIP, физические пиксели) — для расчёта зума 67 %.

        Логический размер берётся у САМОГО окна браузера, а НЕ у плейсхолдера:
        на Windows клиентская область окна браузера на 14x7 px меньше
        плейсхолдера (453x735 против 439x728). Цель, посчитанная от
        плейсхолдера, даёт dsf 439/679 = 0.6465 вместо 439/658 = 0.667 —
        страница получается на 3 % мельче, и именно поэтому отображение
        объектов в v15 отличалось от замеров pre14. От своего окна цель
        совпадает с нативным рендером ровно, и ничего переопределять не нужно.
        """
        logical_w, logical_h = self._browser_logical_size()
        physical_w, physical_h = self._browser_physical_size()
        return logical_w, logical_h, physical_w, physical_h

    def _zoom_args(self):
        """(logical_w, logical_h, physical_w, physical_h) для native_browser.

        Поправки блока настроек подаются так, что `target_css` вернёт ровно
        нужные css и dsf: `target_css` считает `css = logical / zoom` и
        `css_h = physical_h / dsf`.
        """
        logical_w, logical_h, physical_w, physical_h = self._zoom_size()
        css_w = max(320, int(round(logical_w / float(PAGE_ZOOM))) + int(WIDTH_DELTA))
        dsf = (float(physical_w) / css_w) if css_w else 1.0
        css_h = max(320, int(round(physical_h / dsf)) + int(HEIGHT_DELTA))
        return (css_w * float(PAGE_ZOOM), logical_h, physical_w, css_h * dsf)

    def _placeholder_physical_size(self):
        """Физический размер плейсхолдера (GetClientRect даёт физические пиксели).

        Зум считается от него: страница верстается в `physical / 0.667` CSS px и
        масштабируется в окно. Поэтому раскладка одинаковая при 100 %, 125 % и
        150 % — и текст никогда не уезжает за правую границу.
        """
        user32 = None
        host = getattr(self, "browser_host", None)
        if host is not None:
            user32 = getattr(host, "user32", None)
        placeholder = getattr(self, "browser_placeholder", None)
        if user32 is not None and placeholder is not None:
            try:
                width, height = win32_embed.client_size(user32, int(placeholder.winId()))
                if width > 0 and height > 0:
                    return int(width), int(height)
            except Exception:
                diag.exception("main.placeholder_size")
        # Резерв: логический размер плейсхолдера (до появления окна браузера).
        return (int(W - 2 * self.side_inset),
                int(H - self.top_inset - self.bottom_inset))

    def _ensure_zoom(self):
        """Держать нативный зум 67 % (защита от «широкого окна» и сдвига вправо).

        Метрики сбрасываются при смене таргета/перезагрузке, после чего чат
        снова рисует desktop-раскладку: широкую, со словом «ИИ» по центру и
        текстом, уезжающим за правую границу окна. Проверяем в фоновом потоке —
        GUI не блокируется.
        """
        if self._closing or not self.native_mode:
            return
        # v51: по остановленному хосту зум не проверяем.
        if getattr(getattr(self, "browser_host", None), "stopped", False):
            return
        page = getattr(getattr(self, "worker", None), "page", None)
        if page is None:
            return
        threading.Thread(target=self._zoom_guard_once, args=(page, "timer"),
                         daemon=True).start()

    def _zoom_guard_once(self, page, reason="guard", pin_first=False):
        """ОДИН проход сторожа зума: измерить и, если надо, вернуть. True — всё верно.

        Выделено из `_ensure_zoom` в v18.1: после показа окна раскладку надо
        проверять и чинить **сразу**, а не ждать следующего тика таймера
        (5 с — отсюда и «съехало и встало на место только через пару секунд»).

        Одновременные проходы исключены (`_zoom_lock`): два потока не должны
        наперебой слать `Emulation.setDeviceMetricsOverride`.
        """
        if page is None or self._closing:
            return False
        if not self._zoom_lock.acquire(blocking=False):
            # Уже проверяется в соседнем потоке. Раньше здесь возвращалось
            # True, и пропущенный проход засчитывался как «всё верно».
            return None
        try:
            logical_w, logical_h, physical_w, physical_h = self._zoom_args()
            # v18: язык и тема держатся намертво — после перезагрузки
            # страницы Chrome возвращает системные значения.
            try:
                apply_language_and_theme(page, self.speech_lang, self.light_theme)
            except Exception:
                diag.exception("main.zoom_guard_theme")
            # Сдвиги страницы внедряются и держатся (после перезагрузки
            # стиль пропадает, поэтому он проверяется каждый проход).
            if page_tuning_needed():
                try:
                    page.eval(page_tune_js(with_scroll=False), timeout=4)
                except Exception:
                    diag.exception("main.page_tune")
            ok, metrics = zoom_ok(page, logical_w, logical_h, physical_w,
                                  physical_h, zoom=PAGE_ZOOM)
            if ok:
                return True
            if pin_first:
                # v18.2: сначала прибиваем раскладку ОДНИМ вызовом — так
                # ширина страницы перестаёт зависеть от размера окна, и
                # «качка» прекращается. Лестница переборов ниже даёт несколько
                # видимых перевёрсток подряд — она только на крайний случай.
                #
                # v20: форма объявления — «окно» (логические px, dsf=1.0).
                # Причина: dsf-масштаб СКЛАДЫВАЕТСЯ с зумом профиля
                # (0.667 x 0.667 = 0.445, innerWidth 658 → 987) — ровно это и
                # видел пользователь в сессии 20261004-162559-12408-c5e41c.
                # Там раскладку сломало объявление с dsf=0.6672, а вылечила её
                # форма dsf=1.0 (`browser.zoom source=emulation-adaptive`).
                try:
                    healed = native_browser.refresh_emulation(
                        page, logical_w, logical_h, physical_w, physical_h,
                        PAGE_ZOOM)
                    if healed.get("ok"):
                        diag.event("browser.zoom_pinned", reason=str(reason),
                                   via="window-dsf1",
                                   innerWidth=healed.get("innerWidth"),
                                   dpr=healed.get("dpr"))
                        return True
                except Exception:
                    diag.exception("main.zoom_pin_window")
                # Замер сказал, что зум профиля раскладку не держит (например,
                # его нет вовсе): тогда раскладку задаёт только CDP — силовая
                # форма с dsf.
                try:
                    apply_viewport(page, logical_w, logical_h, physical_w,
                                   physical_h, PAGE_ZOOM)
                    time.sleep(0.12)
                except Exception:
                    diag.exception("main.zoom_pin")
                ok, metrics = zoom_ok(page, logical_w, logical_h, physical_w,
                                      physical_h, zoom=PAGE_ZOOM)
                if ok:
                    diag.event("browser.zoom_pinned", reason=str(reason),
                               via="dsf")
                    return True
            result = apply_zoom(page, logical_w, logical_h, physical_w,
                                physical_h, zoom=PAGE_ZOOM)
            diag.event("browser.zoom_restored",
                       source=(result or {}).get("source"), reason=str(reason),
                       inner=(metrics or {}).get("innerWidth"),
                       dpr=round(float((metrics or {}).get("dpr") or 0.0), 3))
            return bool((result or {}).get("ok"))
        except Exception:
            diag.exception("main.zoom_guard")
            return False
        finally:
            self._zoom_lock.release()

    def _apply_page_tuning(self):
        """Однократно применить сдвиги страницы вместе с прокруткой."""
        if self._closing or not self.native_mode or not page_tuning_needed():
            return
        page = getattr(getattr(self, "worker", None), "page", None)
        if page is None:
            return
        js = page_tune_js(with_scroll=True)

        def task():
            try:
                page.eval(js, timeout=4)
            except Exception:
                diag.exception("main.page_tune_once")

        threading.Thread(target=task, daemon=True).start()

    @stage
    def _register_hotkeys(self):
        try:
            toggle_key = self.cfg.get("hotkey_toggle", "")
            mic_key = self.cfg.get("hotkey_mic", "")

            vk_toggle = VK_MAP.get(toggle_key, 0)
            vk_mic = VK_MAP.get(mic_key, 0)

            # Опрос работает всегда: ложный статус конфликта невозможен.
            self._hotkeys_registered = bool(self.hotkeys.set_keys(vk_toggle, vk_mic))
            try:
                suppressed = self.hotkeys.try_suppress(int(self.winId() or 0))
            except Exception:
                suppressed = False
            diag.event(
                "hotkeys.configured",
                toggle=str(toggle_key),
                mic=str(mic_key),
                suppressed=bool(suppressed),
            )
            # v20 (ТЗ § 4): хоткей — часть «предсказуемости без администратора».
            # Вердикт пишется всегда: и «ок», и «не ок» с причиной.
            try:
                btrace.selfcheck(
                    "hotkeys", bool(self._hotkeys_registered),
                    detail="%s / %s, подавление: %s" % (toggle_key, mic_key,
                                                        "есть" if suppressed else "нет"),
                    advice=("" if self._hotkeys_registered else
                            "опрос клавиш не поднялся: проверить "
                            "`hotkeys.configured` и занятость клавиш другими "
                            "программами (без прав администратора)"))
            except Exception:
                diag.exception("main.selfcheck_hotkeys")
            return self._hotkeys_registered
        except Exception:
            diag.exception("main.register_hotkeys")
            return False

    def _hotkey_tick(self):
        """Тик опроса клавиатуры (главный поток Qt)."""
        try:
            self.hotkeys.tick()
        except Exception:
            diag.exception("main.hotkey_tick")

    def _unregister_hotkeys(self):
        try:
            self.hotkeys.clear()
        except Exception:
            diag.exception("main.unregister_hotkeys")
        self._hotkeys_registered = False

    @diag.trace
    def _on_hotkey(self, key_id):
        if self._closing:
            return
        # v20: в лог попадает и сам факт нажатия, и его время: без этого
        # невозможно отличить «хоткей не сработал» от «сработал поздно».
        btrace.mark("hotkey.pressed", id=int(key_id),
                    visible=bool(self.isVisible()),
                    args=self._trace_extra())
        if key_id == HOTKEY_TOGGLE_ID:
            self._toggle_visibility()
        elif key_id == HOTKEY_MIC_ID:
            self._toggle_mic()

    def _change_hotkey(self, cfg_key: str, default: str, caption: str, chip: HotkeyChip, other_cfg_key: str):
        current = self.cfg.get(cfg_key) or default
        taken = {self.cfg.get(other_cfg_key) or ""} - {current}

        self._unregister_hotkeys()
        try:
            dlg = HotkeyDialog(current, title=caption, taken=taken, parent=self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                key = dlg.get_key()
                if key and key in VK_MAP:
                    self.cfg[cfg_key] = key
                    self.cfg["hotkeys_configured"] = bool(self.cfg.get("hotkey_toggle") and self.cfg.get("hotkey_mic"))
                    save_config(self.cfg)
                    chip.set_key(key)
        finally:
            if self._register_hotkeys():
                self._set_status("Готов к работе", THEME["ok"])

    def _choose_hotkey(self):
        self._change_hotkey(
            "hotkey_toggle", "", "Клавиша: скрыть/показать окно",
            self.chip_toggle, "hotkey_mic",
        )

    def _choose_mic_hotkey(self):
        self._change_hotkey(
            "hotkey_mic", "", "Клавиша: микрофон",
            self.chip_mic, "hotkey_toggle",
        )

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _toggle_visibility(self):
        # v20: хоткей «Окно» — точная точка отсчёта для временной шкалы. По ней
        # видно, через сколько миллисекунд после показа браузер встал на место
        # (жалоба «объекты съезжают и возвращаются через 2–3 секунды»).
        action = "hide" if self.isVisible() else "show"
        btrace.mark("hotkey.toggle.begin", action=action, args=self._trace_extra())
        if action == "hide":
            self.hide()
            if self.overlay.isVisible():
                self.overlay.hide()
        else:
            self.show()
            self.activateWindow()
            force_topmost(int(self.winId()))
            if self.overlay._anim.isActive():
                self.overlay.show()
                self.overlay.sync_geometry()
                force_topmost(int(self.overlay.winId()))
        btrace.mark("hotkey.toggle.end", action=action, args=self._trace_extra())

    def _page_eval_async(self, expression, timeout=3, callback=None):
        page = getattr(self.worker, "page", None) if self.worker else None
        if not page:
            return

        def task():
            value = None
            try:
                value = page.eval(expression, timeout=timeout).get("value")
            except Exception:
                diag.exception("main.py:3145")
                value = None
            if callback:
                try:
                    callback(value)
                except Exception:
                    diag.exception("main.py:3151")
                    pass

        threading.Thread(target=task, daemon=True).start()

    def _cdp_click_coords(self, x, y):
        page = getattr(self.worker, "page", None) if self.worker else None
        if not page or x is None or y is None:
            return
        try:
            page.send("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": float(x), "y": float(y)}, timeout=2)
            page.send("Input.dispatchMouseEvent", {"type": "mousePressed", "button": "left", "x": float(x), "y": float(y), "clickCount": 1}, timeout=2)
            page.send("Input.dispatchMouseEvent", {"type": "mouseReleased", "button": "left", "x": float(x), "y": float(y), "clickCount": 1}, timeout=2)
        except Exception:
            diag.exception("main.py:3165")
            pass

    def _toggle_mic(self):
        if not self.worker or not getattr(self.worker, "page", None):
            return
        if not self._chat_ready:
            self._set_status("Страница ещё загружается — подождите…", THEME["muted"])
            return

        now = time.monotonic()
        # Защита от дребезга и удержания клавиши (одиночное нажатие)
        if self._mic_busy or (now - self._mic_last_ts) < 0.35:
            return

        self._mic_last_ts = now
        self._mic_busy = True

        # Снимаем блокировку СТРОГО в главном потоке Qt
        QTimer.singleShot(350, lambda: setattr(self, "_mic_busy", False))

        if not self.mic_active:
            # ─────────────────────────────────────────────────────────────
            # 1-е нажатие: старт записи речи (п.1 ТЗ)
            # ─────────────────────────────────────────────────────────────
            self.mic_active = True
            # v24: сразу выставляем готовность к отправке, чтобы быстрый повторный клик не отменял запись
            self._mic_got_text = True
            self.chip_mic.set_active(True)
            self._set_status("Запись голоса… (повтор: отправить)", THEME["ok"])

            if self.native_mode:
                # ШТАТНАЯ запись голоса самим браузером: клик по кнопке
                # микрофона страницы. Ни моста, ни диктовки Windows.
                self._mic_retried = False
                self._native_mic_start()
                return

            def on_shim_eval(ok):
                if ok:
                    # НАСТОЯЩАЯ диктовка (Windows System.Speech) запущена:
                    # текст идёт в поле ввода. Кнопка сайта/реплика лишь
                    # показывает состояние — веб-конвейер сайта не вызывается.
                    diag.event("mic.dictation_started")
                    try:
                        btrace.selfcheck(
                            "mic", False,
                            detail="запись идёт диктовкой Windows, не страницей",
                            advice="резервный путь: у большинства пользователей "
                                   "Win11 диктовки нет — нужен внешний Chrome")
                    except Exception:
                        diag.exception("main.selfcheck_mic")
                    return
                diag.event("mic.dictation_unavailable")

                # Запасной путь: штатный сценарий клика по кнопке микрофона.
                def on_mic_eval(val):
                    if isinstance(val, dict) and "x" in val and "y" in val:
                        self._cdp_click_coords(val["x"], val["y"])
                    else:
                        reason = val.get("reason") if isinstance(val, dict) else "no_result"
                        diag.event("mic.button_missing", reason=str(reason))
                        self.mic_active = False
                        self.chip_mic.set_active(False)
                        self._set_status(
                            "Микрофон недоступен — проверьте разрешения Windows",
                            THEME["danger"],
                        )

                self._page_eval_async(JS_START_RECORDING, timeout=3, callback=on_mic_eval)

            # Явный старт (не toggle): если состояние страницы рассинхронизировалось,
            # первое нажатие всё равно должно НАЧАТЬ запись, а не отправить.
            self._page_eval_async(JS_MIC_START, timeout=3, callback=on_shim_eval)
        else:
            # ─────────────────────────────────────────────────────────────
            # 2-е нажатие: отправка запроса в чат ИИ (п.3 ТЗ)
            # ─────────────────────────────────────────────────────────────
            # Отправляем ТОЛЬКО когда диктовка дала текст. Если хост
            # умер/язык не поддерживается, второе нажатие обязано
            # СНОВА начать запись, а не отправить пустой запрос
            # (реальный лог v6: "нажимаю микрофон — сразу отправка").
            if not self._mic_got_text:
                self._mic_cancel("Запись не началась — нажмите «Микрофон» ещё раз")
                return

            self.mic_active = False
            self._mic_got_text = False
            self.chip_mic.set_active(False)
            self._set_status("Отправка запроса…", THEME["accent"])

            if self.native_mode:
                # v24: в нативном режиме Chrome отправка происходит МГНОВЕННО одним вызовом JS_STOP_AND_SEND
                # без лишнего промежуточного JS_MIC_STOP и без задержки повторного _cdp_click_coords.
                def on_native_send(val):
                    diag.event("mic.native_sent", result=str((val or {}).get("ok") or (val or {}).get("fallback")))
                    if not (isinstance(val, dict) and (val.get("ok") is True or val.get("fallback"))):
                        diag.event("mic.send_missing")
                        self._set_status("Кнопка отправки не найдена — проверьте страницу", THEME["danger"])

                self._page_eval_async(JS_STOP_AND_SEND, timeout=3, callback=on_native_send)
                QTimer.singleShot(2500, lambda: self._set_status("Готов к работе", THEME["ok"]))
            else:
                def on_send_eval(val):
                    if isinstance(val, dict) and "x" in val and "y" in val:
                        self._cdp_click_coords(val["x"], val["y"])
                    elif not (isinstance(val, dict) and val.get("ok") is True):
                        diag.event("mic.send_missing")
                        self._set_status("Кнопка отправки не найдена — проверьте страницу", THEME["danger"])

                def on_stop_eval(_val):
                    self._page_eval_async(JS_STOP_AND_SEND, timeout=3, callback=on_send_eval)

                self._page_eval_async(JS_MIC_STOP, timeout=3, callback=on_stop_eval)
                QTimer.singleShot(2500, lambda: self._set_status("Готов к работе", THEME["ok"]))

    def _native_mic_start(self):
        """Первое нажатие: запустить ШТАТНУЮ запись голоса страницы."""

        def on_click(val):
            if not (isinstance(val, dict) and val.get("ok")):
                diag.event("mic.native_button_missing",
                           reason=str((val or {}).get("reason")))
                self._mic_reset_state()
                self._set_status("Кнопка микрофона не найдена — обновите страницу (Ctrl+R)",
                                 THEME["danger"])
                return
            diag.event("mic.native_started")
            try:
                btrace.selfcheck("mic", True,
                                 detail="штатная запись страницы (кнопка микрофона)")
            except Exception:
                diag.exception("main.selfcheck_mic")
            QTimer.singleShot(700, self._native_mic_verify)

        self._page_eval_async(JS_START_RECORDING, timeout=3, callback=on_click)

    def _native_mic_verify(self):
        """Убеждаемся, что страница ДЕЙСТВИТЕЛЬНО записывает.

        Прежняя сборка просто отправляла запрос, не проверяя этого, — отсюда
        «нажимаю на микрофон и всё, сразу отправка без записи».
        """
        def on_check(val):
            recording = bool(isinstance(val, dict) and val.get("recording"))
            diag.event("mic.native_verify", recording=recording)
            if recording:
                # Сайт записывает сам: повторное нажатие = отправка.
                self._mic_got_text = True
                self._set_status("Идёт запись… (повтор: отправить)", THEME["ok"])
                return
            if not self._mic_retried:
                # Клик мог не дойти во время перерисовки — один повтор.
                self._mic_retried = True
                self._page_eval_async(JS_START_RECORDING, timeout=3)
                QTimer.singleShot(900, self._native_mic_verify)
                return
            self._mic_retried = False
            self._mic_reset_state()
            self._set_status(
                "Запись не началась — разрешите микрофон в Windows и повторите (F3)",
                THEME["danger"])

        self._page_eval_async(JS_CHECK_RECORDING, timeout=3, callback=on_check)

    def _open_template(self):
        # v35: гасим оверлей, чтобы окно «Шаблон» было доступно для ввода
        overlay_was_visible = self.overlay.isVisible()
        if overlay_was_visible:
            self.overlay.hide()

        dlg = TemplateWindow(self.cfg, token=self.token, parent=self)
        dialog_result = dlg.exec()

        if overlay_was_visible:
            self.overlay.show()
            self.overlay.sync_geometry()
            force_topmost(int(self.overlay.winId()))

        if dialog_result == QDialog.DialogCode.Accepted:
            save_template(self.cfg, dlg.get_template())
            save_config(self.cfg)
            self._reload_prompt()
        # v35: даже без «Сохранить» персонаж мог быть переключён — подпись
        # кнопки всегда показывает активного.
        self._refresh_template_button()

    def _refresh_template_button(self):
        """v35: подпись кнопки всегда короткая — «Шаблон».

        Активный персонаж показывается ТОЛЬКО в подсказке: название профиля
        на кнопке распирало верхнюю панель и было причиной замечания.
        """
        self.btn_template.setText("Шаблон")
        try:
            name = active_profile_name(self.cfg)
            self.btn_template.setToolTip(
                f"Данные шаблона. Активный персонаж: {name}")
        except Exception:
            diag.exception("main.refresh_template_button")

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _sync_template_from_server(self):
        """Шаблон с сервера больше не приходит (v26): он всегда локальный.

        Метод сохранён, потому что вызывается из конструктора; ничего не делает.
        """
        return

    # ─────────────────────────── v27: документы (постановления) ──────────

    def _open_documents(self):
        """«Документы» → выбор вида документа. Пока один: Постановление."""
        menu = QDialog(self)
        menu.setWindowTitle("Документы")
        menu.setMinimumWidth(360)
        menu.setStyleSheet(self.styleSheet() or "")
        layout = QVBoxLayout(menu)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(8)
        title = QLabel("Документы")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)
        hint = QLabel("Выберите документ. Форма сама возьмёт данные из «Шаблон».")
        hint.setStyleSheet(f"color: {THEME['muted']}; font-size: 11px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        btn_decree = QPushButton("Постановление IAD")
        btn_decree.setMinimumHeight(38)
        btn_decree.setToolTip("Постановление Internal Affairs Division (LSCSD)")
        btn_decree.clicked.connect(lambda _c=False: (menu.accept(), self._open_postanovlenie()))
        layout.addWidget(btn_decree)

        # v36: постановления Прокурора — свой бланк, герб и печать ОГП.
        btn_gov = QPushButton("Постановление Прокурора")
        btn_gov.setMinimumHeight(38)
        btn_gov.setToolTip("Постановление по обращению в Офис Генерального прокурора")
        btn_gov.clicked.connect(
            lambda _c=False: (menu.accept(), self._open_postanovlenie_prokurora()))
        layout.addWidget(btn_gov)

        # v60: «Обращение в ОГП» — описать ситуацию и доказательства, а
        # готовый текст в BB-коде вернёт ИИ (форма ст. 6 ч. 4 Регламента).
        btn_appeal = QPushButton("Обращение в ОГП")
        btn_appeal.setMinimumHeight(38)
        btn_appeal.setToolTip(
            "Обращение в Офис Генерального прокурора: вы описываете ситуацию, "
            "ИИ возвращает готовый текст в BB-коде")
        btn_appeal.clicked.connect(
            lambda _c=False: (menu.accept(), self._open_appeal_ogp()))
        layout.addWidget(btn_appeal)

        for label in ("Жалоба", "Иск"):
            stub = QPushButton(f"{label} — в следующей версии")
            stub.setEnabled(False)
            layout.addWidget(stub)

        close = QPushButton("Отмена")
        close.clicked.connect(lambda _c=False: menu.reject())
        layout.addWidget(close)
        menu.exec()

    def _document_assets(self):
        """Герб/печать/шрифты бланка.

        v29: `DocAssets` сам перебирает папки данных (APP_DIR/data,
        BUNDLE_DATA_DIR, папка программы, папка exe), поэтому ресурсы
        находятся и в скрипте, и в собранном exe. Здесь только кэш и лог.
        """
        if getattr(self, "_doc_assets_cache", None) is None:
            # base_dir — папка программы (ресурсы), а не APP_DIR (%APPDATA%).
            self._doc_assets_cache = prender.DocAssets(self._program_dir())
            diag.event("documents.assets", **self._doc_assets_cache.describe())
        return self._doc_assets_cache

    def _program_dir(self) -> Path:
        """Папка программы: там лежат data/ (герб, печать, шрифты, устав).

        v35: в сборке Nuitka `__file__` может указывать внутрь
        `Legalyze.dist` (или во временную папку), а ресурсы едут рядом с exe.
        Поэтому перебираем: папка exe → BUNDLE_DIR → папка модуля. Иначе в
        собранной программе не находились герб, печать и устав.
        """
        candidates = []
        try:
            if getattr(sys, "frozen", False) or "__compiled__" in globals():
                candidates.append(Path(sys.executable).resolve().parent)
        except Exception:
            diag.exception("main.program_dir_exe")
        try:
            from config import RESOURCE_DIR
            candidates.append(Path(RESOURCE_DIR))
        except Exception:
            diag.exception("main.program_dir_bundle")
        candidates.append(Path(__file__).resolve().parent)
        for folder in candidates:
            try:
                if (folder / "data").is_dir():
                    return folder
            except Exception:
                continue
        return Path(__file__).resolve().parent

    def _document_regulation(self):
        """Правила ведомства из законодательной базы (data/reestr/*.json)."""
        if not hasattr(self, "_doc_regulation_cache"):
            path = pdoc.default_regulation_path(self._program_dir() / "data")
            self._doc_regulation_cache = pdoc.Regulation(path)
            diag.event("documents.regulation", loaded=bool(path),
                       title=self._doc_regulation_cache.title)
        return self._doc_regulation_cache

    def _document_history(self):
        """История постановлений IAD (v41: с папкой вида, не общей)."""
        if getattr(self, "_doc_history", None) is None:
            self._doc_history = pdoc.DocumentHistory(
                self._documents_root(), kind=pdoc.HISTORY_KIND_IAD)
        return self._doc_history

    def _document_gov_history(self):
        """История постановлений Прокурора — отдельная от IAD (v41).

        Раньше обе формы делили одну историю: в списке IAD появлялись
        постановления Прокурора, «Загрузить в форму» падал с AttributeError
        (документ собирался моделью IAD), а номера AG и LSCSD-IAD считались
        по общему списку.
        """
        if getattr(self, "_doc_gov_history", None) is None:
            self._doc_gov_history = pgov.GovHistory(self._documents_root())
        return self._doc_gov_history

    def _open_postanovlenie(self):
        """Форма постановления: заполнить → «Сформировать» → .txt в чат → PNG."""
        overlay_was_visible = self.overlay.isVisible() if self.overlay else False
        if overlay_was_visible:
            self.overlay.hide()
        try:
            dlg = PostanovlenieDialog(
                self.cfg,
                base_dir=self._program_dir(),
                history=self._document_history(),
                assets=self._document_assets(),
                regulation=self._document_regulation(),
                parent=self,
            )
            dlg.formed.connect(self._on_document_formed)
            # v56: у формы IAD тот же порядок, что у Прокурора — сначала
            # чистый чат, потом заявка (см. `_on_pending_send_restart`).
            if hasattr(dlg, "restart_requested"):
                dlg.restart_requested.connect(self._on_pending_send_restart)
            # v65 (`keep_draft`): «Повторить отправку» — у формы IAD тот же
            # порядок, если сигнал в ней есть.
            if hasattr(dlg, "resend_requested"):
                dlg.resend_requested.connect(self._on_resend_pending_request)
            # v56: форма не закрывается по «Сформировать» и обновляется по
            # ответу ИИ (как окно «Постановление Обращение №» у Прокурора).
            if hasattr(dlg, "finished"):
                dlg.finished.connect(lambda _r=0: self._on_iad_dialog_finished())
            self._iad_dialog = dlg
            dlg.exec()
        finally:
            self._iad_dialog = None
            if overlay_was_visible and self.overlay:
                self.overlay.show()
                self.overlay.sync_geometry()
                force_topmost(int(self.overlay.winId()))

    def _on_iad_dialog_finished(self, _result=0):
        """Форма IAD закрыта пользователем (v56)."""
        self._iad_dialog = None

    def _open_postanovlenie_prokurora(self):
        """Форма постановления Прокурора: заявка в чат → PNG из ответа ИИ.

        v43: сначала открывается стартовое окно «Обращения» со списком дел и
        их состояний — из него можно открыть обращение или начать новое.
        """
        overlay_was_visible = self.overlay.isVisible() if self.overlay else False
        if overlay_was_visible:
            self.overlay.hide()
        # v47: признак «пользователь нажал „Новое обращение"» — на один показ
        # формы. Прошлый выбор не должен влиять на следующее открытие.
        self._gov_case_new_requested = False
        try:
            store = self._document_case_store()
            chosen = self._choose_gov_case(store)
            if chosen is False:
                return                      # список закрыт без выбора
            dlg = PostanovlenieProkuroraDialog(
                self.cfg,
                base_dir=self._program_dir(),
                history=self._document_gov_history(),
                assets=self._document_gov_assets(),
                parent=self,
                case_store=store,
                case=chosen or None,
                # v47 (замечание пользователя): «для создания в „Обращения"
                # обращения нужно 2 раза нажать на „Новое обращение"». Дело
                # None значило и «создать новое», и «дело не выбрано», поэтому
                # форма на первом показе снова открывала список обращений.
                # Раз пользователь уже нажал «Новое обращение», второй раз
                # спрашивать нечего.
                ask_case=not self._gov_case_new_requested,
            )
            # v47: «Новое обращение» — сразу чистое дело: пустое поле
            # обращения, подсказки и номер. Раньше это делало ВТОРОЕ нажатие
            # «Новое обращение» во втором окне списка.
            if self._gov_case_new_requested:
                dlg.new_case()
            dlg.formed.connect(self._on_document_formed)
            # v42: «Проверка ИИ» — отдельный запрос в чат; ответ приходит в
            # `_apply_gov_intake`. Окно закрывается сразу после отправки, как и
            # «Сформировать»: ответ ИИ приходит в чат, а PNG собирается там же.
            dlg.intake_requested.connect(self._on_gov_intake_requested)
            # v43.2: «Сформировать» и «Проверка ИИ» больше не отправляют заявку
            # сразу — клиент перезапускается с чистым чатом, и уже после
            # перезапуска заявка уходит в ИИ.
            dlg.restart_requested.connect(self._on_pending_send_restart)
            dlg.resend_requested.connect(self._on_resend_pending_request)
            # v64: «Сформировать» — это ЗАЯВКА НА ДОКУМЕНТ в чат (решение
            # пользователя), поэтому отдельного сигнала печати нет: .png
            # собирает `_apply_gov_answer` из ответа ИИ.
            # v65 (решение пользователя по выгрузке «Обращение №1.7z»): ЛЮБАЯ
            # заявка формы — «Этап 1», «Этап 2.N», «Этап 3», «Сформировать»,
            # «Согласовать порядок» — уходит через чистый чат
            # (`restart_requested`). Отдельного сигнала «в текущий диалог»
            # больше нет: на странице с историей клиент разбирал ответ
            # прошлого шага вместо текущего.
            # v63: «Закрыть обращение» на этапе 3 — дело отработано, браузер
            # перезагружается с чистым чатом.
            dlg.case_closed.connect(self._on_gov_case_closed)
            self._gov_dialog = dlg
            # v49 (замечание пользователя): «окна и кнопки „Проверка ИИ“,
            # „Сформировать“ и схожие не должны закрывать окно „Постановление
            # Обращение №“ — форма должна обновляться по отправленному запросу
            # и полученному ответу ИИ». Кнопки больше не вызывают `accept()`,
            # поэтому `exec()` продолжает работать: окно остаётся на экране,
            # опрос чата идёт своим ходом, а ответ ИИ обновляет эту же форму.
            dlg.finished.connect(self._on_gov_dialog_finished)
            dlg.exec()
        finally:
            if overlay_was_visible and self.overlay:
                self.overlay.show()
                self.overlay.sync_geometry()
                force_topmost(int(self.overlay.winId()))

    @pyqtSlot(str)
    def _on_gov_case_closed(self, case_number=""):
        """v63: обращение закрыто кнопкой «Закрыть обращение» на этапе 3.

        Пользователь: «по нажатию обращение закрывается и помечается как
        отработанное, и браузер перезагружается». Дело уже сохранено формой;
        здесь — чистый чат для следующего обращения.
        """
        diag.event("gov.case_closed", case=str(case_number or ""))
        self._set_status(
            f"Обращение №{case_number} закрыто: отработано", THEME["ok"])
        self._pending_send_record_data = {}
        self._pending_answer_role = ""
        self._pending_answer_node = ""
        self._pending_send_started = False
        self._pending_send_expected = False
        self._fresh_chat_requested = True
        # Чистый чат обязателен: это единственная точка, где страница ИИ
        # перезагружается после работы по обращению (v63).
        self._fresh_chat_after_answer = True
        self._schedule_fresh_chat_after_answer()

    def _on_gov_dialog_finished(self, _result=0):
        """Форма «Постановление» закрыта пользователем (v49)."""
        self._gov_dialog = None

    # ─────────────────────────── v60: «Обращение в ОГП» ──────────────────

    def _open_appeal_ogp(self):
        """«Документы → Обращение в ОГП»: анкета → заявка в чат → BB-код.

        Окно устроено так же, как формы постановлений: заявка уходит в ИИ, а
        ответ возвращается в это же окно (`_apply_appeal_ogp`). Постоянные
        реквизиты (телефон, почта, Discord) подставляются из «Шаблон».
        """
        overlay_was_visible = self.overlay.isVisible() if self.overlay else False
        if overlay_was_visible:
            self.overlay.hide()
        try:
            dialog = ogp_appeal_ui.OgpAppealDialog(
                self.cfg,
                template=active_template(self.cfg),
                documents_root=self._documents_root(),
                parent=self)
            dialog.request_ready.connect(self._on_appeal_ogp_requested)
            self._appeal_dialog = dialog
            dialog.exec()
            self._appeal_dialog = None
        except Exception:
            diag.exception("appeal_ogp.open")
            QMessageBox.warning(
                self, "Обращение в ОГП",
                "Не удалось открыть форму обращения. Подробности в логе.")
        finally:
            if overlay_was_visible and self.overlay:
                self.overlay.show()
                self.overlay.sync_geometry()
                force_topmost(int(self.overlay.winId()))

    def _on_appeal_ogp_requested(self, text, title=""):
        """Заявка обращения готова: отправляем её в чат как обычный запрос.

        Вложения не нужны: весь текст заявки уже содержит анкету и правила
        формы. Отправка идёт через тот же шлюз, что и остальные запросы
        (v58: только по активной кнопке «Отправить»).
        """
        if not str(text or "").strip():
            return
        self._appeal_request_text = str(text)
        page = getattr(self.worker, "page", None) if self.worker else None
        if page is None:
            self._set_status("Чат ещё не готов — откройте форму позже", "#f59e0b")
            return
        self._doc_request_mode = "appeal"
        self._set_status("Обращение в ОГП: отправляю заявку в чат…", THEME["accent"])
        payload = str(text)

        def do_send():
            try:
                page.eval(JS_FOCUS_INPUT, timeout=2)
            except Exception:
                diag.exception("appeal_ogp.focus_input")
            time.sleep(0.15)
            try:
                page.send("Input.insertText", {"text": payload}, timeout=5)
            except Exception:
                diag.exception("appeal_ogp.insert_text")
            time.sleep(0.3)
            # v58: отправляем только по активной кнопке «Отправить».
            if not wait_send_button(page).get("enabled"):
                diag.event("appeal_ogp.send_blocked", reason="send-button-disabled")
                return
            try:
                sent = page.eval(JS_STOP_AND_SEND, timeout=3).get("value")
                diag.event("appeal_ogp.sent", result=str(sent)[:120])
            except Exception:
                diag.exception("appeal_ogp.send")

        threading.Thread(target=do_send, name="AppealOgpSend", daemon=True).start()
        self._watch_document_answer()

    def _apply_appeal_ogp(self, text):
        """Ответ ИИ с готовым обращением: отдаём его в окно обращения.

        Возвращает True, если это был ответ на заявку обращения.
        """
        if ogp_appeal_mod.APPEAL_START not in str(text or ""):
            return False
        dialog = getattr(self, "_appeal_dialog", None)
        if dialog is None:
            # Окно закрыто: сохраняем текст в файл, чтобы он не потерялся.
            try:
                folder = Path(self._documents_root()) / "Обращения в ОГП"
                folder.mkdir(parents=True, exist_ok=True)
                (folder / ogp_appeal_mod.docx_name({})).write_text(
                    ogp_appeal_mod.extract_appeal(text), encoding="utf-8")
            except Exception:
                diag.exception("appeal_ogp.save_closed")
            self._set_status("Обращение в ОГП сохранено в файл", THEME["ok"])
            return True
        dialog.note_answer_received(text)
        self._set_status("Обращение в ОГП: ответ ИИ получен, текст в окне", THEME["ok"])
        return True

    def _choose_gov_case(self, store):
        """Стартовое окно «Обращения» (v43): дело, False или «новое» (None)."""
        try:
            from postanovlenie_prokuror_ui import GovCasesDialog
        except Exception:
            diag.exception("gov.cases.import")
            return None
        dialog = GovCasesDialog(store, parent=self)
        self._gov_cases_dialog = dialog
        # v47: запоминаем, что пользователь выбрал именно «Новое обращение»:
        # возвращаемый None означает и это, и «список закрыт без выбора».
        self._gov_case_new_requested = False
        if dialog.exec() != dialog.DialogCode.Accepted:
            self._gov_cases_dialog = None
            return False
        if dialog.new_requested:
            self._gov_case_new_requested = True
            return None
        return dialog.selected_case

    # ------------------------------------------------------------- v43.2 --
    #  Перезапуск перед отправкой заявки (кнопки «Сформировать»/«Проверка ИИ»).

    def _on_pending_send_restart(self, record, source_path=""):
        """Заявка готова: перезапускаем клиент, отправка — после старта.

        Замечание пользователя: перезапуск нужен, чтобы чат с ИИ был пустым —
        без старых записей и ответов. Поэтому кнопки формы ничего не отправляют
        сами: они сохраняют заявку, а `_resume_pending_send` отправит её уже в
        новом запуске, когда чат поднимется и файлы прикрепятся.
        """
        root = self._documents_root()
        try:
            record = dict(record or {})
            record["state"] = psend.STATE_WAITING
            psend.save(root, record)
        except Exception:
            diag.exception("main.pending_send.save")
        diag.event("pending_send.queued", kind=(record or {}).get("kind"),
                   stage=(record or {}).get("stage_index"),
                   case=(record or {}).get("case_number"),
                   chars=len(str((record or {}).get("request_text") or "")))
        # v43.4 (замечание): перезапускать ВСЁ приложение не нужно — задача
        # чистого чата решается внутри GUI. Здесь только перезапускается
        # браузер: он открывается на пустой странице ИИ, история переписки
        # остаётся на месте (в профиле), а текущий диалог начинается заново.
        # Заявка уходит автоматически, когда страница готова и файлы на месте.
        self._pending_send_started = False
        self._pending_send_wait_reason = ""
        # v56: признак «заявка пойдёт через чистый чат» — по нему
        # `_on_document_formed` не начинает выгрузку в текущую страницу
        # (порядок: сначала обновить браузер, потом экспорт материала).
        self._pending_send_expected = True
        # v65: новая заявка — новое ожидание ответа. Раньше эти поля
        # сбрасывал только удалённый теперь `_on_send_in_chat`; если их не
        # сбросить, текст прошлого ответа считается «уже обработанным» и
        # разбор нового ответа пропускается.
        self._doc_handled_text = None
        self._doc_last_text = None
        self._doc_settle_text = None
        self._doc_settle_count = 0
        self._doc_warned_text = None
        # v66: ожидание ответа этапа 1 ведёт свой счётчик стабильности текста.
        self._intake_settle_text = None
        self._intake_settle_count = 0
        # v51: заявку запоминаем В ПАМЯТИ до любого обновления чата. После
        # перезапуска браузера окно формы уже закрыто, и раньше запись бралась
        # только с диска: если файл не успевали прочитать, `pending_send.resume`
        # не наступал вовсе — чат оставался с ответом ИИ (замечание п.3).
        self._pending_send_record_data = record
        self._fresh_chat_requested = True
        self._set_status("Очистка чата: открываем новый диалог с ИИ…",
                         THEME["accent"])
        self._restart_browser_for_fresh_chat()

    def _pending_send_record(self, allow_stale: bool = False):
        """Актуальная отложенная заявка (или пустой словарь).

        v65 (`keep_draft`): `allow_stale=True` возвращает запись даже
        устаревшую и уже отправленную — так «Повторить отправку» поднимает
        заявку, которую человек нажимает сам, а не автозапуск.
        """
        try:
            record = psend.load(self._documents_root())
        except Exception:
            diag.exception("main.pending_send.load")
            return {}
        if allow_stale:
            return record
        if not psend.is_fresh(record):
            if record:
                diag.event("pending_send.stale", kind=record.get("kind"))
            return {}
        return record

    @pyqtSlot()
    def _on_resend_pending_request(self) -> None:
        """«Повторить отправку»: та же заявка уходит ещё раз (v65).

        Решение пользователя: если после перезагрузки страницы ИИ не ответил,
        заявка остаётся в записи отложенной отправки, а прокурор повторяет её
        одной кнопкой — заново собирать документ и заполнять поля не нужно.
        """
        record = self._pending_send_record(allow_stale=True)
        if not psend.can_resend(record):
            self._set_status("Сохранённой заявки нет — нажмите кнопку этапа "
                             "заново", "#f59e0b")
            diag.event("pending_send.resend_empty")
            return
        source = str(record.get("source_path") or "")
        record = psend.rearm(record)
        diag.event("pending_send.resend", kind=record.get("kind"),
                   node=record.get("node_kind") or record.get("stage_kind"),
                   restarts=record.get("restarts"))
        self._on_pending_send_restart(record, source)

    def _pending_answer_received(self, node: str = "") -> None:
        """Ответ ИИ разобран — сохранённую заявку можно убрать (v65).

        До этого момента запись живёт на диске: по ней форма показывает
        «Повторить отправку», если ответ так и не пришёл.
        """
        try:
            record = psend.load(self._documents_root()) or {}
        except Exception:
            diag.exception("main.pending_send.load")
            return
        if not record:
            return
        # v67 (п.3): узел берём через `psend.record_node` — заявка проверки
        # обращения относится к узлу «1», иначе слот оставался занятым и
        # очередь не поднималась (см. `pending_send.record_node`).
        saved_node = psend.record_node(record)
        if node and saved_node and saved_node != str(node):
            return                      # ответ не по этой заявке — не трогаем
        # v67 (находка 1, одобрена пользователем): роль ответившей заявки нужна
        # рендеру, чтобы отметить автозапрос узла выполненным (`done`). Раньше
        # рендер читал роль из `_pending_send_record_data`, который здесь уже
        # очищен, — поэтому в `case.json` навсегда оставалось
        # `auto_document: "requested"` (выгрузка «Постановление_66v.7z»: узлы 1
        # и 3 при напечатанных 0002-1 и 0002-6).
        self._pending_answer_role = psend.record_role(record)
        self._pending_answer_node = saved_node
        psend.clear(self._documents_root())
        self._pending_send_record_data = {}
        diag.event("pending_send.answered", kind=record.get("kind"),
                   node=saved_node)

    def _refresh_gov_resend_button(self) -> None:
        """«Повторить отправку» в открытой форме: видна, пока заявка жива (v65).

        Решение пользователя `keep_draft`: если ИИ не ответил, заявка остаётся
        в записи отложенной отправки, и прокурор повторяет её одной кнопкой.
        """
        dialog = getattr(self, "_gov_dialog", None)
        if dialog is None or not hasattr(dialog, "set_resend_available"):
            return
        try:
            record = psend.load(self._documents_root()) or {}
            dialog.set_resend_available(psend.can_resend(record),
                                        psend.describe(record))
        except Exception:
            diag.exception("gov.resend.refresh")

    def _remember_gov_dialog_visibility(self) -> bool:
        """Форма «Постановление» открыта до перезапуска браузера (v49)."""
        dialog = getattr(self, "_gov_dialog", None)
        try:
            return bool(dialog is not None and dialog.isVisible())
        except Exception:
            return False

    def _restore_gov_dialog_visibility(self) -> None:
        """Показывает форму «Постановление» снова после перезапуска чата (v49).

        Клиент на время смены браузера прячет своё окно (и форму вместе с
        ним). Замечание пользователя: «окно „Постановление Обращение №“ не
        должно закрываться» — поэтому форма возвращается на экран, как только
        новый браузер поднят, и остаётся ждать ответ ИИ.
        """
        if not getattr(self, "_gov_dialog_visibility", False):
            return
        self._gov_dialog_visibility = False
        dialog = getattr(self, "_gov_dialog", None)
        if dialog is None:
            return
        try:
            dialog.show()
            dialog.raise_()
            dialog.activateWindow()
        except Exception:
            diag.exception("gov.dialog.restore")

    def _restart_browser_for_fresh_chat(self):
        """Чистый диалог с ИИ БЕЗ убийства браузера (v51).

        Замечание пользователя (п.2/п.3 v51): «на этапе „Сформировать“ окно
        крашнулось», и «после „Сформировать“ браузер внутри не обновляется —
        остаётся с ответом ИИ».

        Причина обеих жалоб одна. Раньше здесь гасилось ВСЁ дерево процессов
        браузера (`NativeHost.stop()` → `win32_embed.kill_tree`), а затем заново
        создавалось встраивание окна. В логе 20261110-021708-9752-bba914 лента
        обрывается ровно на `win32.tree_killed` → `browser.closed`, без
        `_cleanup`/`selfcheck.summary`/`session.atexit` — то есть падение
        процесса происходит в момент убийства дерева и пересоздания embedding
        (гонка Win32: gtk-цикл ещё держит hwnd, а окно уже убито). В соседней
        сессии та же цепочка прошла целиком — отсюда «падает не всегда».

        Поэтому порядок теперь такой:

        1. МЯГКИЙ путь (штатный): перезагружаем САМУ страницу ИИ по CDP
           (`Page.navigate` на ``URL``) — новый диалог без прошлых сообщений.
           Ровно этим уже пользуется «Проверка ИИ» (`gov.intake.browser_reload`,
           в логе 20261110-021038-18504-f9d45c отработала без падения), но там
           вызов уходил в `_recover_web` и всё равно перезапускал хост. Здесь
           хост, окно и встраивание остаются живыми, меняется только страница;
        2. ЖЁСТКИЙ путь (страница не ожила за `FRESH_CHAT_RELOAD_TIMEOUT` или
           CDP недоступен): прежний перезапуск хоста — он нужен, когда браузер
           действительно мёртв.

        Заявка (`pending_send`) уходит после готовности чата в обоих случаях:
        мягкий путь заканчивается тем же `_on_hwnd` → `_resume_pending_send`.
        """
        if self._closing:
            return
        diag.event("browser.fresh_chat.begin", native=bool(self.native_mode),
                   engine="qtwebengine" if not self.native_mode else "external_chrome")
        self._pending_send_stop()
        try:
            if getattr(self, "upload_thread", None) is not None:
                self.upload_thread.stop()
                self.upload_thread.wait(500)
        except Exception:
            diag.exception("main.fresh_chat_upload_stop")
        self.upload_thread = None
        self.upload_deadline_timer.stop()
        self.pdf_attached = False
        self._last_attached_state = None
        self._upload_confirmed_at = None
        self._pending_send_started_at = time.monotonic()
        self._pending_send_started = False
        try:
            if getattr(self, "_doc_watch_timer", None) is not None:
                self._doc_watch_timer.stop()
        except Exception:
            diag.exception("main.fresh_chat_watch_stop")
        self.worker = None
        self._chat_ready = False
        self._trace_chat_captured = False
        self._show_overlay("Новый диалог с ИИ",
                           "Очищаем чат: открываем страницу заново…")
        # v51: форма «Постановление Обращение №» не должна закрываться — её
        # видимость запоминается до любых действий с окном.
        self._gov_dialog_visibility = self._remember_gov_dialog_visibility()
        if self.native_mode and self._fresh_chat_reload_page():
            diag.event("browser.fresh_chat.soft", stage="page_reload")
            return
        self._restart_browser_hard("fresh-chat")

    def _fresh_chat_reload_page(self) -> bool:
        """Мягкий «новый диалог»: перезагрузка страницы ИИ по CDP (v51).

        Возвращает True, когда страница перезагружена и автоматизация запущена
        заново — браузер, его окно и встраивание остаются прежними.
        """
        page = None
        try:
            worker = getattr(self, "worker", None)
            page = getattr(worker, "page", None)
        except Exception:
            page = None
        if page is None:
            diag.event("browser.fresh_chat.soft_skipped", reason="no_page")
            return False
        try:
            diag.event("browser.fresh_chat.reload", url=str(URL))
            page.send("Page.navigate", {"url": URL}, timeout=10)
        except Exception:
            diag.exception("main.fresh_chat_page_reload")
            return False
        # Старое CDP-соединение умирает на навигации: закрываем его и поднимаем
        # автоматизацию заново — она заново найдёт страницу, ворота готовности
        # снова отработают `_on_hwnd`, а тот подхватит отложенную заявку.
        try:
            page.close()
        except Exception:
            diag.exception("main.fresh_chat_page_close")
        self._start_web_automation()
        QTimer.singleShot(int(FRESH_CHAT_RELOAD_TIMEOUT * 1000),
                          self._fresh_chat_reload_watchdog)
        return True

    def _fresh_chat_reload_watchdog(self) -> None:
        """Страница не ожила после мягкой перезагрузки — жёсткий перезапуск."""
        if self._closing or self._chat_ready:
            return
        if not getattr(self, "_fresh_chat_requested", False):
            return
        diag.event("browser.fresh_chat.soft_timeout", reason="no_chat_surface")
        self._restart_browser_hard("fresh-chat-timeout")

    def _restart_browser_hard(self, reason="fresh-chat") -> None:
        """Прежний путь: погасить дерево браузера и поднять его заново (v51).

        Дерево гасим ТОЛЬКО здесь — когда мягкая перезагрузка не помогла или
        браузера действительно нет. Убийство дерева необратимо и раньше роняло
        процесс (см. `_restart_browser_for_fresh_chat`), поэтому оно вынесено в
        отдельный метод и вызывается по одному месту.
        """
        if self._closing:
            return
        diag.event("browser.fresh_chat.hard", reason=str(reason)[:40])
        # Поток автоматизации держит CDP-соединение с убиваемым браузером.
        worker = getattr(self, "worker", None)
        try:
            if worker is not None:
                worker.close_connections()
        except Exception:
            diag.exception("main.fresh_chat_close_connections")
        self.worker = None
        host = getattr(self, "browser_host", None)
        if self.native_mode and host is not None:
            try:
                host.stop()
            except Exception:
                diag.exception("main.fresh_chat_host_stop")
            self.chrome_hwnd = None
            # Тот же путь запуска, что при старте: страница, профиль, зум,
            # встраивание окна в плейсхолдер.
            QTimer.singleShot(400, self._start_chrome)
            return
        # Резервный (встроенный) движок: новый диалог = домашняя страница.
        try:
            self.web_browser.open_home()
        except Exception:
            diag.exception("main.fresh_chat_open_home")
        QTimer.singleShot(600, self._start_web_automation)
        self._start_web_automation()

    def _load_pending_document(self):
        """Готовит вложения для отложенной заявки после чистого чата (v43.4).

        Раньше заявку подхватывал новый процесс, и путь к .txt приходил с
        диска через запись `pending_send.json`. Теперь приложение не
        перезапускается, поэтому путь к заявке восстанавливаем из самой записи
        — иначе `document_path` остался бы пустым, а поток вложений не
        приложил бы заявку к чату.
        """
        record = getattr(self, "_pending_send_record_data", {}) or {}
        source = str(record.get("source_path") or "")
        if not source:
            return
        try:
            path = Path(source)
            if not path.exists():
                diag.event("pending_send.source_missing", path=path.name)
                return
            if str(record.get("kind") or "") == "intake":
                # У «Проверки ИИ» вложение — сама заявка-обращение.
                self.document_path = path
                self._document_kind = "gov"
            else:
                self.document_path = path
                self._document_kind = str(record.get("document_kind") or "gov")
            # v50: второе вложение — «Обращение.txt» (текст обращения). Путь
            # берём из записи: после перезапуска формы уже нет.
            appeal_path = str(record.get("appeal_path") or "")
            if appeal_path and Path(appeal_path).exists():
                self.appeal_path = Path(appeal_path)
            else:
                self.appeal_path = None
            self._doc_request_text = path.read_text(encoding="utf-8")
            self._load_pending_fields(record, path)
            diag.event("pending_send.source_loaded", kind=record.get("kind"),
                       name=path.name, appeal=Path(appeal_path).name
                       if appeal_path else "")
        except Exception:
            diag.exception("main.pending_send.source")

    def _load_pending_fields(self, record, source_path):
        """Возвращает ДОКУМЕНТ этапа, по которому отправлена заявка (v51).

        Замечание п.1 v51 (пустой PNG этапа 2 у AG-2): после «чистого чата»
        `_document_doc` терялся, и разбор ответа шёл от пустого документа —
        этап, номер дела и вид этапа (``case_stage_kind``) не восстанавливались.
        Из-за этого ответ ИИ этапа 2 печатался в папку ЭТАПА 1, а «Проверка»
        ругалась на «первичный вид решения с санкцией» (в логе
        `gov.rendered stage="intake"` для заявки этапа 2).

        Источник — файл «Заявка-поля.json», который форма кладёт рядом с заявкой
        (``record["source_path"]``). Тип документа не меняется: как и раньше,
        это `PostanovlenieProkurora` или `Postanovlenie` — от него зависит и
        бланк, и `_apply_gov_answer`.
        """
        if str(record.get("kind") or "") == "intake":
            return                      # «Проверка ИИ» документа не формирует
        kind = str(record.get("document_kind") or "gov")
        fields_path = Path(source_path).parent / "Заявка-поля.json"
        if not fields_path.exists():
            return
        try:
            payload = json.loads(fields_path.read_text(encoding="utf-8"))
            fields = (payload or {}).get("поля") or payload or {}
        except Exception:
            diag.exception("main.pending_send.fields")
            return
        if not isinstance(fields, dict) or not fields:
            return
        try:
            if kind == "gov":
                doc = pgov.PostanovlenieProkurora.from_dict(fields)
            else:
                doc = pdoc.Postanovlenie.from_dict(fields)
        except Exception:
            diag.exception("main.pending_send.fields_parse")
            return
        # Этап и дело — из записи: они главнее, чем поля формы (их могло не
        # быть в снимке), и именно по ним выбирается папка этапа.
        if not doc.get("case_number"):
            doc.case_number = str(record.get("case_number") or "")
        if not doc.get("case_stage_kind"):
            doc.case_stage_kind = str(record.get("stage_kind") or "")
        if not doc.get("doc_stage"):
            doc.doc_stage = pcases.gov_stage_for_kind(doc.case_stage_kind)
        self._document_doc = doc
        self._document_kind = kind
        self._doc_case_number = str(record.get("case_number") or "")
        self._doc_stage_kind = str(record.get("stage_kind") or "")
        # v62: узел цепочки («1», «2.1», «3»); служебная запись калибровки
        # порядка приходит с меткой `__reorder__`.
        # v64: узел берётся из своего поля записи (`node_kind`), а
        # `stage_kind` остаётся ВИДОМ этапа — иначе `stage_number("2.1")`
        # давал 3 и документ подэтапа уезжал в папку «этап-3 — санкция».
        self._doc_node_kind = str(record.get("node_kind")
                                  or record.get("stage_kind") or "")
        diag.event("pending_send.fields_loaded", kind=kind,
                   stage=doc.get("case_stage_kind"), stage_doc=doc.get("doc_stage"),
                   number=doc.get("doc_number"), type=str(doc.get("doc_type"))[:40])

    def _resume_pending_send(self):
        """Старт клиента: подхватить заявку и отправить её после готовности чата.

        Вызывается один раз за запуск, когда поверхность чата распознана и
        файлы прикреплены. Заявка отправляется ровно один раз: после успеха
        запись удаляется.
        """
        # v43.4: если заявку положили в этой же сессии (перезапускается только
        # браузер), она уже в памяти — с диска её не перечитываем: файл мог
        # быть удалён после отправки, а отправлять всё равно нужно.
        record = getattr(self, "_pending_send_record_data", {}) or {}
        if not record:
            record = self._pending_send_record()
        if not record:
            return False
        if getattr(self, "_pending_send_started", False):
            return False
        self._pending_send_started = True
        self._pending_send_record_data = record
        self._pending_send_wait_reason = ""
        # v44: пока заявка ждёт отправки, поток вложений не пересоздаёт
        # вложения (дедупликация) — иначе состояние «готово» сбрасывается.
        self._keep_attachments = True
        self._pending_send_started_at = time.monotonic()
        diag.event("pending_send.resume", kind=record.get("kind"),
                   stage=record.get("stage_index"),
                   same_session=bool(getattr(self, "_fresh_chat_requested", False)))
        title = psend.describe(record) or "Заявка"
        self._set_status(f"Чат чистый: готовим файлы — {title}", THEME["accent"])
        # Вложения для новой страницы: .pdf и «Шаблон.txt» выгружает обычный
        # поток, заявку возвращаем из записи (после чистого чата путь к ней
        # больше не приходит из нового процесса).
        self._load_pending_document()
        # v44: если в ЭТОМ диалоге файлы уже прикреплены (кнопку нажали при
        # открытом чате, без перезапуска браузера), второй раз их выгружать
        # нельзя: в сессии 20261109-145359-16532-54c702 повторная выгрузка
        # сбросила подтверждение (complete=false), поток заново «вспомнил»
        # файлы и вызвал авто-отправку — в чат ушло второе сообщение.
        if getattr(self, "pdf_attached", False) and not getattr(
                self, "_fresh_chat_requested", False):
            diag.event("pending_send.files_already_attached")
            state = {}
            page = getattr(self.worker, "page", None) if self.worker else None
            if page is not None:
                try:
                    state = check_state(page)
                except Exception:
                    diag.exception("pending_send.check_state_reuse")
            required = cread.required_names(
                getattr(self, "pdf_path", None), getattr(self, "template_path", None),
                getattr(self, "document_path", None), TEMPLATE_EXPORT_NAME,
                appeal_path=getattr(self, "appeal_path", None))
            if cread.check(state, required,
                           confirmed_at=getattr(self, "_upload_confirmed_at", None)
                           ).get("ready"):
                # Файлы на месте — сразу к отправке, без повторной загрузки.
                pass
            else:
                self._start_upload_thread()
        elif not getattr(self, "pdf_path", None):
            self._load_prompt()
        else:
            self._start_upload_thread()
        # v43.4: контекст ответа. Раньше `_gov_intake_case`/`_gov_intake_text`
        # заполнял диалог перед отправкой (следующий процесс). После чистого
        # чата диалога уже нет, и ответ ИИ приходил при пустых полях — разбор
        # падал с AttributeError в `sys.excepthook`, дело не обновлялось.
        self._doc_request_mode = ("intake"
                                  if str(record.get("kind") or "") == "intake"
                                  else "document")
        # v45: после перезапуска браузера окно формы уже закрыто, и режим
        # ожидания знает только запись. Пишем его в журнал: по нему видно,
        # что именно ждали (проверку обращения или постановление).
        diag.event("pending_send.mode", kind=record.get("kind"),
                   mode=self._doc_request_mode,
                   stage=record.get("stage_kind"))
        # v45: номер дела нужен и заявке на постановление. Раньше он заполнялся
        # только для «Проверки ИИ», и документ по «Сформировать» сохранялся в
        # НОВОЕ дело (store.next_number) — PNG уходил в чужую папку, а в списке
        # обращений появлялся дубль.
        self._doc_case_number = str(record.get("case_number") or "")
        if str(record.get("kind") or "") == "intake":
            self._gov_intake_case = str(record.get("case_number") or "")
            self._gov_intake_text = str(record.get("request_text") or "")
            # v44: дело ищем по ТЕКСТУ ОБРАЩЕНИЯ, а не по тексту заявки.
            # Раньше сюда попадала вся заявка («ЗАЯВКА НА ПРОВЕРКУ …»), и в
            # дело записывался служебный текст вместо обращения гражданина.
            self._gov_intake_appeal = str(
                record.get("appeal_text") or record.get("request_text") or "")
            self._gov_intake_handled = None
        # Отправляем только когда файлы подтверждены и «устоялись»: иначе
        # текст уйдёт в чат без вложений (ошибка сессии logs_43v).
        if getattr(self, "_pending_send_timer", None) is None:
            self._pending_send_timer = QTimer(self)
            self._pending_send_timer.setInterval(700)
            self._pending_send_timer.timeout.connect(self._try_send_pending)
        self._pending_send_timer.start()
        return True

    # ----------------------------------------------------------------- #
    #  v58: шлюз экспорта в чат — ошибки чипов и активная кнопка
    # ----------------------------------------------------------------- #
    def _chip_error_streak(self, chips) -> int:
        """Сколько замеров ПОДРЯД в чате есть чип с ошибкой загрузки.

        Решение пользователя: ошибку считаем настоящей с задержкой 1–2 замера,
        чтобы мигание индикатора не запускало удаление и повторную загрузку.
        """
        bad = bool(ugate.error_chips(ugate.normalize_chips(chips)))
        if bad:
            self._chip_error_seen = int(getattr(self, "_chip_error_seen", 0)) + 1
        else:
            self._chip_error_seen = 0
        return int(getattr(self, "_chip_error_seen", 0))

    def _chip_error_streak_reset(self):
        self._chip_error_seen = 0

    def _handle_chip_error(self, page, names):
        """Сломанный файл: удалить ТОЛЬКО его и дать автодогрузке вернуть его.

        Замечание пользователя по «Ошибка загрузки.txt»: «чат не перезагружай,
        а используй логику в „Удалить.txt“, то есть удалить файл и заново его
        загрузить… только удалить (исключить) его из чата с ИИ, так как логика
        автодогрузки при отсутствующих файлах уже имеется». После 3 неудачных
        попыток на файл — перезагрузка браузера.
        """
        retry = int(getattr(self, "_chip_retry", 0)) + 1
        self._chip_retry = retry
        self._chip_error_seen = 0
        diag.event("upload.chip_error", names=[str(n)[:80] for n in (names or [])][:4],
                   attempt=retry)
        if ugate.retries_exhausted(retry):
            diag.event("upload.chip_retries_exhausted", attempt=retry)
            self._chip_retry = 0
            self._reload_for_upload_retry(reason="chip-error")
            return
        self._set_status(ugate.status_text(ugate.REASON_ERROR, attempt=retry),
                         THEME["accent"])
        for name in (names or [])[:1]:
            try:
                remove_chip(page, str(name))
            except Exception:
                diag.exception("pending_send.remove_chip")
        # Удаление освобождает место в чате: автодогрузка (`missing_files`)
        # прикрепит файл заново, а шлюз снова дождётся активной кнопки.
        self.pdf_attached = False
        self._last_attached_state = None

    def _reload_for_upload_retry(self, reason="button-timeout"):
        """Перезагрузить страницу ИИ и повторить экспорт (v58).

        Мягкая перезагрузка по CDP — та же, что при «Сформировать»: браузер не
        убивается, окно остаётся. Всего не больше `ugate.RELOAD_RETRIES` раз.
        """
        count = int(getattr(self, "_upload_reloads", 0)) + 1
        self._upload_reloads = count
        diag.event("upload.reload_retry", reason=str(reason), attempt=count)
        if ugate.reloads_exhausted(count):
            diag.event("upload.send_blocked", reason=str(reason), attempt=count)
            self._set_status(ugate.blocked_text() + " Заявка сохранена — "
                             "в форме доступна «Повторить отправку».",
                             THEME["danger"])
            # v65 (`keep_draft`): заявка не ушла, но выбрасывать её нельзя.
            self._pending_send_finish(psend.STATE_FAILED, reason=str(reason))
            return
        self._set_status(ugate.status_text(ugate.REASON_RELOAD), THEME["accent"])
        self._pending_send_started_at = time.monotonic()
        self._pending_send_wait_reason = ""
        try:
            self._restart_browser_for_fresh_chat()
        except Exception:
            diag.exception("upload.reload_for_retry")

    def _try_send_pending(self):
        """Ждём ФАКТИЧЕСКОЙ готовности вложений, затем отправляем заявку.

        v43.4 (сессия logs_43v). Раньше здесь было только «pdf_attached ==
        True», а этот флаг выставлял поток загрузки — и выставлял его рано:
        в логе запрос ушёл в 11:06:51.125, когда в чате было `present=0`,
        а файлы начали прикрепляться только в 11:06:51.5 и подтвердились в
        11:06:52.5. ИИ получал сообщение без .pdf и .txt.

        Теперь перед отправкой проверяется состояние страницы: все нужные
        файлы по именам, загрузка не идёт, лишних файлов нет, и после
        подтверждения прошла выдержка `chat_ready.SETTLE_SECONDS` — файлам
        нужно 1–2 секунды, чтобы прикрепиться окончательно.
        """
        record = getattr(self, "_pending_send_record_data", {}) or {}
        if not record:
            self._pending_send_stop()
            return
        if getattr(self, "_pending_send_busy", False):
            return
        page = getattr(self.worker, "page", None) if self.worker else None
        if page is None or self._closing:
            return
        waited = time.monotonic() - float(
            getattr(self, "_pending_send_started_at", 0.0) or 0.0)
        required = cread.required_names(
            getattr(self, "pdf_path", None), getattr(self, "template_path", None),
            getattr(self, "document_path", None), TEMPLATE_EXPORT_NAME,
            appeal_path=getattr(self, "appeal_path", None))
        try:
            state = check_state(page)
        except Exception:
            diag.exception("pending_send.check_state")
            state = {}
        confirmed_at = getattr(self, "_upload_confirmed_at", None)
        # v58: главный шлюз — состояние ЧИПОВ и кнопки «Отправить».
        # По дампам пользователя крестик `zXgSbc` есть и при ошибке загрузки,
        # поэтому старая проверка (`cread`) могла подтвердить незагруженный
        # файл. Здесь: ошибка в чипе → удалить только его и дать автодогрузке
        # прикрепить заново; неактивная кнопка → ждать (до 20 с); после 3
        # неудачных попыток на файл → перезагрузка браузера.
        chips = (state or {}).get("chips") or []
        send = (state or {}).get("send") or {}
        streak = self._chip_error_streak(chips)
        gate = ugate.should_send(chips, send, required, error_streak=streak,
                                 confirmed_at=confirmed_at)
        reason = str(gate.get("reason") or "")
        if reason == ugate.REASON_ERROR:
            self._handle_chip_error(page, gate.get("errors") or [])
            return
        if not gate.get("ready"):
            if reason != getattr(self, "_pending_send_wait_reason", ""):
                self._pending_send_wait_reason = reason
                diag.event("pending_send.wait", reason=reason,
                           waited=round(waited, 1), present=gate.get("present"),
                           required=len(required),
                           uploading=bool((state or {}).get("uploading")),
                           chips=[(c.get("name"), c.get("uploading"), c.get("error"))
                                  for c in chips][:6],
                           send_enabled=bool((send or {}).get("enabled")))
            self._set_status(ugate.status_text(reason, waited,
                                               getattr(self, "_chip_retry", 0)),
                             THEME["accent"])
            if ugate.button_timed_out(waited):
                # 20 секунд кнопка не активировалась — перезагружаем чат и
                # повторяем экспорт (решение пользователя).
                self._reload_for_upload_retry()
            return
        self._chip_error_streak_reset()
        self._pending_send_wait_reason = ""
        diag.event("pending_send.ready", present=gate.get("present"),
                   names=[str(n)[:60] for n in (gate.get("names") or [])][:5],
                   extra=[str(n)[:40] for n in (gate.get("extra") or [])][:4],
                   waited=round(waited, 1))
        self._pending_send_stop()
        # v50: в поле запроса печатается КОРОТКОЕ сообщение (`message_text`),
        # а не вся заявка: обращения и реквизиты ИИ читает из вложений. У
        # старых записей `message_text` пуст — тогда отправляем заявку, как
        # раньше.
        text = str(record.get("message_text") or record.get("request_text") or "")
        kind = str(record.get("kind") or "document")
        if getattr(self, "_pending_send_busy", False):
            return
        # v44: помечаем заявку отправленной ДО самого действия. Пока идёт
        # отправка, поток вложений успевает сменить состояние (false → true
        # после повторной загрузки и дедупликации) и вызвать авто-отправку —
        # так в чат уходило ВТОРОЕ сообщение с тем же текстом (сессия
        # 20261109-145359-16532-54c702: два запроса подряд, первый ИИ даже не
        # начал обрабатывать).
        self._request_sent_key = self._request_key()
        self._pending_send_busy = True
        self._pending_send_sent_at = time.monotonic()
        self._set_status("Файлы на месте — отправляем заявку ИИ…", THEME["accent"])

        def task():
            inserted = False
            try:
                page.eval(JS_FOCUS_INPUT, timeout=2)
            except Exception:
                diag.exception("pending_send.focus_input")
            time.sleep(0.15)
            try:
                page.send("Input.insertText", {"text": text}, timeout=6)
                inserted = True
            except Exception:
                diag.exception("pending_send.insert_text")
            if inserted:
                time.sleep(0.4)
                # v58: шлюз по кнопке «Отправить» — она активна только когда
                # ИИ принял вложения. Ждём до 20 секунд.
                if not wait_send_button(page).get("enabled"):
                    diag.event("pending_send.send_blocked", kind=kind,
                               reason="send-button-disabled")
                    self._pending_send_done.emit(False, kind)
                    return
                try:
                    sent = page.eval(JS_STOP_AND_SEND, timeout=4).get("value")
                    diag.event("pending_send.sent", kind=kind,
                               chars=len(text), result=str(sent)[:120])
                except Exception:
                    diag.exception("pending_send.send")
            self._pending_send_done.emit(inserted, kind)

        threading.Thread(target=task, name="PendingSend", daemon=True).start()

    @pyqtSlot(bool, str)
    def _on_pending_send_done(self, ok, kind):
        """Отправка завершилась (главный поток): закрываем заявку и ждём ответ.

        v45: ждём ответ после ЛЮБОЙ заявки, а не только после «Проверки ИИ».
        Раньше опрос включался лишь при `kind == "intake"`. Заявка на
        постановление (kind="document") уходила, ответ ИИ приходил в чат — но
        его никто не читал: PNG не печатался вовсе. Замечание пользователя:
        «Проверка ИИ прошла, обращение «Отказано», а по «Сформировать» .png не
        создаётся».
        """
        self._pending_send_busy = False
        self._pending_send_expected = False
        record = getattr(self, "_pending_send_record_data", {}) or {}
        if ok:
            self._pending_send_finish(psend.STATE_SENT, record)
            # v45: «intake» — ответ ждём на проверку обращения,
            # «document» — на постановление. Режим уже выставлен записью
            # (`_doc_request_mode`), поэтому просто включаем опрос.
            self._watch_document_answer()
            return
        # v65 (`keep_draft`): текст в поле запроса не вставился или кнопка
        # «Отправить» так и не стала активной — заявка остаётся сохранённой.
        self._pending_send_finish(psend.STATE_FAILED, record, reason="send")

    def _request_key(self) -> str:
        """Ключ заявки: по нему видно, что это ТА ЖЕ заявка (v44).

        Нужен, чтобы одна заявка уходила в чат одним сообщением. В ключ идут
        имя файла, его размер и начало текста: повторная выгрузка того же
        файла даёт тот же ключ, а другая заявка — другой.
        """
        path = getattr(self, "document_path", None)
        if not path:
            return ""
        try:
            name = Path(path).name
            size = Path(path).stat().st_size
        except Exception:
            name, size = str(path), 0
        text = str(getattr(self, "_doc_request_text", "") or "")
        return f"{name}|{size}|{text[:160]}"

    def _pending_send_stop(self):
        timer = getattr(self, "_pending_send_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass

    def _pending_send_finish(self, state, record=None, reason=""):
        """Исход отправки: `sent` / `failed` — запись остаётся, прочее — убрать.

        v65 (решение пользователя `keep_draft`): заявка хранится до разбора
        ответа ИИ. Отправленная запись переходит в состояние `sent` и
        автоматически больше не уходит (`is_fresh` → False), а не ушедшая — в
        `failed`; в обоих случаях форма предлагает «Повторить отправку».
        """
        self._pending_send_stop()
        record = record if record is not None else getattr(
            self, "_pending_send_record_data", {}) or {}
        title = psend.describe(record) or "Заявка"
        try:
            if state == psend.STATE_SENT:
                psend.mark_sent(self._documents_root(), record)
                self._set_status(f"Заявка отправлена ИИ: {title}", THEME["ok"])
                # v48: заявка ушла в чат — держать её во вложениях больше
                # незачем, иначе после обновления окна она прикрепится снова.
                self._drop_document_attachment("sent")
            elif state == psend.STATE_FAILED:
                psend.mark_failed(self._documents_root(), record, reason=reason)
                self._set_status(f"{title}: заявка не ушла в чат. Она "
                                 "сохранена — нажмите «Повторить отправку» "
                                 "в форме постановления.", "#f59e0b")
            else:
                psend.clear(self._documents_root())
                self._set_status("Отложенная заявка не отправлена — "
                                 "сформируйте документ заново", "#f59e0b")
        except Exception:
            diag.exception("main.pending_send.finish")
        self._pending_send_record_data = {}
        self._keep_attachments = False
        self._refresh_gov_resend_button()

    def _drop_document_attachment(self, reason=""):
        """Заявка отправлена — убираем её из вложений (v48).

        Замечание пользователя: «после исполнения „Проверки ИИ" и после
        получения ответа и после перезагрузки у меня помимо .pdf и Шаблон.txt
        ещё привязан файл „Проверка обращения (заявка).txt"».

        Причина: путь к заявке (`document_path`) оставался выставленным после
        отправки, и обновлённый браузер поднимался уже с тремя вложениями:
        поток загрузки сверялся с этим полем и снова вкладывал заявку. Теперь
        после отправки заявка забывается — в чате снова только промт и
        «Шаблон.txt».
        """
        had = getattr(self, "document_path", None)
        had_appeal = getattr(self, "appeal_path", None)
        self.document_path = None
        self.appeal_path = None
        self._doc_sent_path = None
        thread = getattr(self, "upload_thread", None)
        if thread is not None:
            thread.document_path = None
            thread.appeal_path = None
        diag.event("documents.attachment_dropped",
                   name=Path(had).name if had else "",
                   appeal=Path(had_appeal).name if had_appeal else "",
                   reason=str(reason)[:40])

    def _document_case_store(self):
        """Дела «Обращение №X» для формы Прокурора (v42).

        v67 (п.1 обратной связи 66v): при первом обращении к хранилищу убираем
        «фантомные» дела, которые прежние версии сохраняли при открытии формы
        (пустой `appeal_raw`, нет узлов и плана). Они занимали общие номера —
        в выгрузке «Постановление_66v.7z» дела 1, 3 и 4 были пустыми, а
        настоящее обращение получило «0002-X» вместо «0001-X». Пустые папки
        «Обращение №N» удаляются вместе с ними; папка, в которой что-то лежит
        (например «Обращение №1» с делом прежней версии `AG-1`), остаётся.
        """
        if getattr(self, "_doc_cases", None) is None:
            self._doc_cases = pcases.GovCaseStore(self._documents_root())
            try:
                purged = self._doc_cases.purge_empty()
            except Exception:
                diag.exception("gov.cases_purge")
                purged = []
            if purged:
                diag.event("gov.cases_purged", numbers=",".join(purged))
                try:
                    self._set_status(
                        "Убраны пустые обращения, созданные прежней версией: "
                        + ", ".join(f"№{number}" for number in purged), "#f59e0b")
                except Exception:
                    diag.exception("gov.cases_purge_status")
        return self._doc_cases

    def _document_gov_assets(self):
        """Герб и печать Офиса Генерального прокурора (v36)."""
        if getattr(self, "_doc_gov_assets_cache", None) is None:
            self._doc_gov_assets_cache = pgov.gov_assets(self._program_dir())
            diag.event("documents.gov_assets", **self._doc_gov_assets_cache.describe())
        return self._doc_gov_assets_cache

    def _on_document_formed(self, document, chat_txt, pngs):
        """Документ сформирован: прикладываем .txt, ждём ответ ИИ, собираем PNG."""
        # v36: бланк Прокурора и бланк IAD разбираются разными модулями.
        self._document_kind = "gov" if isinstance(document, pgov.PostanovlenieProkurora) \
            else "iad"
        # v65 (выгрузка «Обращение №1.7z»): заявку формы уже положила запись
        # отложенной отправки — по ней чат очистится и уйдёт ОДНО короткое
        # сообщение с четырьмя вложениями. Раньше здесь запись сбрасывалась и
        # начиналась выгрузка в ТЕКУЩУЮ страницу: следом срабатывала старая
        # авто-отправка `_auto_send_document_request` (6684 знака, три файла,
        # «Обращение.txt» терялся), и в чате оказывалось ДВА сообщения на одно
        # нажатие «Сформировать».
        record = self._pending_send_record()
        pending_here = bool(record) and (
            not chat_txt
            or str(record.get("source_path") or "") == str(chat_txt))
        if not pending_here:
            self._pending_send_started = False
            self._pending_send_record_data = {}
            self._pending_send_busy = False
            self._upload_confirmed_at = None
        # v44: одна заявка — одно сообщение в чате. Признак один на все пути
        # отправки (отложенная и автоматическая), чтобы не появлялось второе
        # сообщение с тем же текстом.
        self._request_sent_key = ""
        # v44: «Сформировать» — ждём ПОСТАНОВЛЕНИЕ. Раньше режим не сбрасывался,
        # и если перед этим нажимали «Проверка ИИ», ответ по постановлению
        # разбирался как проверка обращения: `_apply_gov_intake` его не узнавал
        # и возвращал False, после чего `_apply_gov_answer` не находил полей
        # (ответ ещё печатался) и ждал дальше — до «Ответ с постановлением не
        # пришёл». Теперь режим задаётся самим действием.
        self._doc_request_mode = "document"
        diag.event("documents.kind", kind=self._document_kind)
        self._document_doc = document
        self._document_pngs = list(pngs or [])
        self.document_path = Path(chat_txt) if chat_txt else None
        # v50: рядом с заявкой — «Обращение.txt» (текст обращения). Оба файла
        # уходят в чат, чтобы в поле запроса осталось короткое сообщение.
        # v65: «Обращение.txt» берём из записи заявки — иначе второе
        # вложение терялось, а сообщение всё равно на него ссылалось.
        appeal_path = str(record.get("appeal_path") or "") if pending_here else ""
        if not appeal_path:
            appeal_path = str((getattr(self, "_pending_send_record_data", {}) or {})
                              .get("appeal_path") or "")
        if not appeal_path:
            appeal_path = str((getattr(self, "_pending_formed_record", {}) or {})
                              .get("appeal_path") or "")
        self.appeal_path = Path(appeal_path) if appeal_path else None
        # v30.3: запоминаем ровно тот текст, который уходит в чат. Заявка
        # начинается словом «ПОСТАНОВЛЕНИЕ» и кончается «===КОНЕЦ ОТВЕТА===»,
        # поэтому её легко принять за ответ ИИ и собрать PNG из конструктора.
        try:
            self._doc_request_text = Path(chat_txt).read_text(encoding="utf-8")
        except Exception:
            self._doc_request_text = ""
        diag.event("documents.formed", number=document.get("doc_number"),
                   pngs=len(self._document_pngs),
                   txt=Path(chat_txt).name if chat_txt else "")
        self._set_status("Постановление сформировано — прикрепляю заявку в чат…",
                         THEME["accent"])
        # v56 (замечание п.3): «убедись, что по нажатию „Сформировать“ браузер
        # внутри сперва обновляется, а уже потом экспортируется материал в чат».
        #
        # Раньше здесь сразу начиналась выгрузка в ТЕКУЩУЮ страницу, а
        # `restart_requested` → `_on_pending_send_restart` следом гасил её и
        # открывал чистый чат: материал уходил в старую страницу, а иногда и
        # терялся вместе с перезагрузкой. Теперь, если заявка пойдёт через
        # чистый чат (`pending_send`), выгрузку НЕ начинаем: её сделает
        # `_resume_pending_send`, когда новая страница будет готова и файлы
        # будут прикреплены. Порядок «чат → файлы → сообщение» соблюдается.
        pending_mode = pending_here or bool(
            getattr(self, "_pending_send_expected", False))
        if pending_mode:
            diag.event("documents.upload_deferred", reason="fresh_chat")
        elif self.upload_thread and self.upload_thread.isRunning():
            # Третье вложение живёт в том же потоке, что PDF и Шаблон.
            self.upload_thread.document_path = self.document_path
            self.upload_thread.fails = 0
            self.upload_thread.last_upload = 0
            self.upload_thread._dedup_done = False
        else:
            self._load_prompt(force=True)
        if pending_mode:
            QMessageBox.information(
                self,
                "Заявка сохранена",
                "Чат с ИИ сейчас обновится (новый диалог), и уже затем файлы "
                "уйдут в него: заявка, «Обращение.txt», промт и «Шаблон.txt». "
                "Сообщение отправится автоматически, когда все файлы будут на "
                "месте.\n\n"
                "PNG появится ПОСЛЕ ответа ИИ: бланк печатается из ответа ИИ "
                "(ИИ-документ.txt), а не из формы.",
            )
        else:
            QMessageBox.information(
                self,
                "Заявка отправлена",
                "Заявка сохранена и прикрепляется к чату вместе с промтом и "
                "Шаблон.txt — сообщение уйдёт автоматически, как только все три файла "
                "будут на месте.\n\n"
                "PNG появится ПОСЛЕ ответа ИИ: бланк печатается из ответа ИИ "
                "(ИИ-документ.txt), а не из формы.\n\n"
                "Если ответ ИИ не пришёл — просто нажмите «Отправить» в чате: "
                "заявка уже вложена.",
            )
        self._watch_document_answer()

    @pyqtSlot()
    @stage
    def _auto_send_document_request(self):
        """Отправка заявки в чат, как только все вложения на месте (v28).

        Текст короткий и намеренно «служебный»: всю содержательную часть ИИ
        берёт из приложенного файла заявки, как требует промт.

        v28: отправляем РОВНО ОДИН раз на документ. В v27 поток вложений
        вызывал этот метод повторно (после дедупликации файлов), из-за чего в
        чате появлялось дублирующее сообщение — ровно то, что в замечаниях.
        """
        if self._closing or not self.document_path:
            return
        # v56: заявка пойдёт через чистый чат — отправляет её
        # `_try_send_pending` после обновления страницы и прикрепления файлов.
        # Здесь отправлять нельзя: сообщение уйдёт в старую страницу раньше,
        # чем браузер обновится.
        if getattr(self, "_pending_send_expected", False):
            return
        page = getattr(self.worker, "page", None) if self.worker else None
        if page is None:
            return
        if getattr(self, "_doc_sent_path", None) == str(self.document_path):
            return
        # v44: заявку уже отправил другой путь (отложенная отправка) —
        # второе сообщение в чат не нужно.
        key = self._request_key()
        if key and key == getattr(self, "_request_sent_key", ""):
            diag.event("documents.skip_duplicate_send", name=Path(self.document_path).name)
            return
        self._request_sent_key = key
        self._doc_sent_path = str(self.document_path)
        name = Path(self.document_path).name
        # v50: короткое сообщение из записи (см. `_try_send_pending`): вся
        # информация — во вложениях, в поле запроса минимум текста.
        message_text = str((getattr(self, "_pending_send_record_data", {}) or {})
                           .get("message_text") or "")
        appeal_name = Path(getattr(self, "appeal_path", "")
                           or "").name if getattr(self, "appeal_path", None) else ""
        # v30.1/v32: сообщение запрещает описывать вложения и НЕ содержит
        # литеральных маркеров ответа («===ПОСТАНОВЛЕНИЕ===»): иначе клиент
        # читал собственное сообщение как готовый ответ и обрывал ожидание.
        # v65 (выгрузка «Обращение №1.7z»): сообщение в чате — КОРОТКОЕ, вся
        # информация — во вложениях (требование пользователя: «всю информацию
        # в .txt файле, прямой текст в чате по минимуму»).
        #
        # Раньше запасным путём (когда записи отложенной отправки нет) уходила
        # простыня на 6684 знака со СТАРЫМИ требованиями промта — «этап указан
        # в заявке строкой «Этап:»», «ОБСТОЯТЕЛЬСТВА ПРОКУРОРА», «пять
        # состояний». В промте 1.35/1.36 и в заявках клиента этих заголовков
        # нет: ИИ получал два противоречащих набора правил в одном сообщении.
        # Требования к документу живут в файле заявки и в промте.
        text = str(message_text or "").strip()
        if not text:
            text = ai_request.document_message(name, appeal_name or "Обращение.txt")
        elif appeal_name:
            text += (f" Второе вложение — «{appeal_name}»: текст обращения "
                     "гражданина.")
        diag.event("documents.auto_send.short", chars=len(text),
                   appeal=appeal_name)
        self._set_status("Отправка заявки на постановление…", THEME["accent"])
        diag.event("documents.auto_send", name=name, chars=len(text))

        def do_send():
            # Поле ввода должно быть готово: иначе текст уйдёт «в никуда».
            try:
                page.eval(JS_FOCUS_INPUT, timeout=2)
            except Exception:
                diag.exception("documents.focus_input")
            time.sleep(0.15)
            try:
                page.send("Input.insertText", {"text": text}, timeout=5)
            except Exception:
                diag.exception("documents.insert_text")
            time.sleep(0.4)
            # v58: ждём активную кнопку «Отправить» (если файл ещё не принят
            # ИИ — кнопка неактивна, отправлять рано).
            if not wait_send_button(page).get("enabled"):
                diag.event("documents.send_blocked", reason="send-button-disabled")
                return
            try:
                sent = page.eval(JS_STOP_AND_SEND, timeout=3).get("value")
                diag.event("documents.auto_sent", result=str(sent)[:120])
            except Exception:
                diag.exception("documents.send")

        threading.Thread(target=do_send, name="DocAutoSend", daemon=True).start()
        # v48: заявка ушла в чат — убираем её из вложений, иначе после
        # перезагрузки окна ИИ в чате снова три файла вместо двух.
        self._drop_document_attachment("auto_send")
        # v45: включили отправку — включаем и ожидание ответа. Не полагаемся на
        # `_on_document_formed`: авто-отправка может сработать позже (после
        # догрузки вложений), когда окно уже закрыто.
        self._watch_document_answer()

    def _watch_document_answer(self):
        """Ждём ответ ИИ с триггером постановления и собираем из него PNG."""
        if getattr(self, "_doc_watch_timer", None) is None:
            self._doc_watch_timer = QTimer(self)
            self._doc_watch_timer.setInterval(2500)
            self._doc_watch_timer.timeout.connect(self._poll_document_answer)
        self._doc_last_text = None
        self._doc_settle_text = None
        self._doc_settle_count = 0
        # v66: счётчик стабильности ответа этапа 1 — тоже с нуля.
        self._intake_settle_text = None
        self._intake_settle_count = 0
        # Признак «идёт опрос» мог остаться от прошлого ожидания.
        self._doc_answer_busy = False
        # v44: запоминаем, сколько текста было в чате ДО нашей заявки. Ответ
        # принимается, только если он появился ПОСЛЕ отправки: раньше
        # «последним ответом на странице» мог оказаться наш же запрос или
        # предыдущее сообщение, и разбор шёл не по тому тексту.
        try:
            self._doc_watch_base_len = self._chat_text_length()
        except Exception:
            diag.exception("documents.watch_base")
            self._doc_watch_base_len = 0
        # v44: ожидание в две ступени. Мягкий срок — только подсказка («ИИ ещё
        # пишет»), ждать при этом не перестаём: длинное постановление ИИ
        # печатает дольше трёх минут, и раньше опрос просто выключался —
        # отсюда «Ответ с постановлением не пришёл». Жёсткий срок — когда
        # ждать уже бессмысленно.
        self._doc_watch_deadline = time.monotonic() + 180
        self._doc_watch_hard = time.monotonic() + 900
        self._doc_watch_hinted = False
        self._doc_watch_timer.start()

    def _chat_text_length(self) -> int:
        """Сколько текста сейчас в чате (для отсечения «не своего» ответа)."""
        page = getattr(self.worker, "page", None) if self.worker else None
        if page is None:
            return 0
        try:
            value = page.eval(JS_CHAT_TEXT_LENGTH, timeout=2).get("value")
            return int(value or 0)
        except Exception:
            diag.exception("documents.chat_text_length")
            return 0

    def _poll_document_answer(self):
        """Один опрос чата: прочитали последний ответ ИИ и отдали на разбор.

        v44: опрос больше НЕ глотает ответы. Раньше здесь была проверка
        «текст чата вырос», и её побочный эффект оказался разрушительным:

        * `grown` считался по замеру в ФОНОВОМ потоке; селекторы замера
          (`.markdown`, `main`) на странице ИИ включают и наше сообщение,
          поэтому величина скакала то вверх, то вниз, и настоящий ответ
          отбрасывался;
        * если замер не удавался, длина выходила 0, условие `0 > base`
          не выполнялось — и опрос глушил ЛЮБОЙ ответ, включая постановление;
        * исключение при чтении ответа тоже отдавало пустую строку.

        Итог: «Ответ с постановлением не пришёл — откройте «Документы»».
        Теперь ответ читается всегда, а «свой» текст отсекают проверки по
        содержимому (JS не считает свою заявку ответом; `is_own_request`
        срабатывает до разбора). Длину чата запоминаем только для журнала.
        """
        page = getattr(self.worker, "page", None) if self.worker else None
        if page is None:
            return
        now = time.monotonic()
        hard = getattr(self, "_doc_watch_hard", None)
        if hard is None:
            hard = getattr(self, "_doc_watch_deadline", 0)
        if now > hard:
            self._doc_watch_timer.stop()
            diag.event("documents.watch_timeout",
                       mode=getattr(self, "_doc_request_mode", ""))
            self._set_status("Ответ с постановлением не пришёл. Заявка "
                             "сохранена — нажмите «Повторить отправку» в форме "
                             "или откройте «Документы».", "#f59e0b")
            self._refresh_gov_resend_button()
            return
        if now > getattr(self, "_doc_watch_deadline", 0) and \
                not getattr(self, "_doc_watch_hinted", False):
            # Не сдаёмся: ответ ИИ часто приходит позже. Один раз сообщаем об
            # этом и продолжаем опрос.
            self._doc_watch_hinted = True
            diag.event("documents.watch_slow", mode=getattr(self, "_doc_request_mode", ""))
            self._set_status("Ответ ИИ ещё не пришёл — продолжаем ждать", THEME["accent"])
        if getattr(self, "_doc_answer_busy", False):
            return
        self._doc_answer_busy = True

        def task():
            text = ""
            length = -1
            try:
                text = str(page.eval(JS_READ_ANSWER, timeout=2).get("value") or "")
            except Exception:
                diag.exception("documents.read_answer")
            try:
                length = int(page.eval(JS_CHAT_TEXT_LENGTH, timeout=2)
                             .get("value") or 0)
            except Exception:
                pass
            base = int(getattr(self, "_doc_watch_base_len", 0) or 0)
            if length >= 0 and base and length <= base:
                # Не повод выбрасывать текст: разбор решит по содержимому.
                diag.event("documents.chat_not_grown", length=length, base=base,
                           chars=len(text))
            self._doc_answer_ready.emit(text)

        threading.Thread(target=task, name="DocAnswerPoll", daemon=True).start()

    def _documents_root(self):
        """Корень папки постановлений — РОВНО выбранная пользователем папка.

        v30.2 (замечание): «выбранная папка» — это корень, а не «папка для
        PNG внутри корня». Раньше `postanovlenie_dir()` возвращала подпапку
        `png/`, поэтому PNG уходили в `<выбранная>/png/`, а ответ ИИ — в
        `<выбранная>/<номер>/`: файлы расходились по разным местам.
        """
        try:
            return Path(postanovlenie_dir(self.cfg))
        except Exception:
            diag.exception("documents.root")
            return Path(__file__).resolve().parent / "postanovleniya"

    @pyqtSlot(str)
    def _apply_document_answer(self, text):
        """Ответ ИИ получен. Для Прокурора — свой разбор и своя проверка (v36)."""
        # v44: снимаем признак «идёт опрос» ДО любых проверок. Раньше он
        # снимался только в разборе документа, и любой ранний выход (своя
        # заявка, ответ на проверку обращения) навсегда останавливал опрос —
        # окно писало «Ответ с постановлением не пришёл».
        self._doc_answer_busy = False
        # v42: «Проверка ИИ» — отдельный вид ответа (служебный блок
        # «ПРОВЕРКА ОБРАЩЕНИЯ»); его нельзя разбирать как постановление.
        # v44: наша заявка — не ответ ИИ (проверяем до любого разбора).
        request_any = (getattr(self, "_doc_request_text", "")
                       or getattr(self, "_gov_intake_text", ""))
        if request_any and pdoc.is_own_request(text, request_any):
            diag.event("documents.skip_own_request", chars=len(text))
            return
        # v44: режим ожидания решает, что разбирать. После «Сформировать»
        # ответ на проверку обращения не принимается за постановление (и
        # наоборот): раньше проверка обращения перехватывала ответ и
        # возвращала False, а постановление после этого «не приходило».
        mode = str(getattr(self, "_doc_request_mode", "") or "")
        # v60: ждём готовое обращение в BB-коде (форма «Обращение в ОГП»).
        # Разбор идёт до остальных: у обращения маркер свой, и перепутать его
        # с постановлением нельзя.
        if mode == "appeal":
            if self._apply_appeal_ogp(text):
                return
        if mode == "intake":
            # Ждём именно служебный блок проверки. Пока его нет, ответ ИИ ещё
            # печатается или это не тот ответ — постановление не разбираем.
            self._apply_gov_intake(text)
            return
        # v64: страницу ИИ после «Сформировать» и после PNG не чистим, поэтому
        # в чате остаётся служебный блок этапа 1. Если ждём ДОКУМЕНТ и он уже
        # есть в тексте — разбираем документ, а не перечитываем проверку
        # обращения заново (иначе узел «1» перезаписывался на каждом опросе).
        if mode == "document" and pdoc.has_document_trigger(text):
            pass
        elif self._apply_gov_intake(text):
            # v45: служебный блок проверки обращения мог остаться в чате от
            # прошлого запроса. Если ждём ПОСТАНОВЛЕНИЕ, а пришёл только он —
            # это не наш ответ, продолжаем ждать документ.
            if mode != "document":
                return
            if not pdoc.has_document_trigger(text):
                return
        if getattr(self, "_document_kind", "iad") == "gov":
            return self._apply_gov_answer(text)
        return self._apply_iad_answer(text)

    @pyqtSlot(str)
    # ---------------------------------------------------------------- v42 --
    #  Проверка обращения ИИ («принято / отказано») и этапы постановления.

    @pyqtSlot(str, str)
    def _on_gov_intake_requested(self, text, case_number):
        """«Проверка ИИ»: отправляем обращение в чат и ждём служебный блок.

        Здесь повторяется путь заявки: тот же текстовый ввод и та же кнопка
        отправки, что у постановления, поэтому новый транспорт не нужен.
        """
        page = getattr(self.worker, "page", None) if self.worker else None
        self._gov_intake_case = str(case_number or "")
        self._gov_intake_text = str(text or "")
        self._gov_intake_handled = None
        # v46: новая проверка — новое обновление окна после ответа.
        self._gov_intake_reloaded = None
        # v44: теперь ответ ждём на ПРОВЕРКУ ОБРАЩЕНИЯ, а не постановление.
        self._doc_request_mode = "intake"
        # v43.4: после «Проверки ИИ» эту функцию больше не вызывают (заявка
        # идёт через чистый чат). Оставлена совместимостью, но отправку
        # дублировать нельзя — иначе в чат уйдут два запроса.
        if getattr(self, "_pending_send_record_data", None):
            diag.event("gov.intake.skip_direct_send", case=self._gov_intake_case)
            return
        if page is None:
            diag.event("gov.intake.no_page")
            self._set_status("Чат ещё не готов — проверьте обращение позже",
                             "#f59e0b")
            return
        diag.event("gov.intake.requested", case=self._gov_intake_case,
                   chars=len(self._gov_intake_text))
        self._set_status("Проверка обращения ИИ…", THEME["accent"])

        def do_send():
            try:
                page.eval(JS_FOCUS_INPUT, timeout=2)
            except Exception:
                diag.exception("gov.intake.focus_input")
            time.sleep(0.15)
            try:
                page.send("Input.insertText",
                          {"text": self._gov_intake_text}, timeout=5)
            except Exception:
                diag.exception("gov.intake.insert_text")
            time.sleep(0.4)
            # v58: та же проверка, что и везде: отправляем только по активной
            # кнопке (файлы к этому моменту должны быть приняты ИИ).
            if not wait_send_button(page).get("enabled"):
                diag.event("gov.intake.send_blocked", reason="send-button-disabled")
                return
            try:
                sent = page.eval(JS_STOP_AND_SEND, timeout=3).get("value")
                diag.event("gov.intake.sent", result=str(sent)[:120])
            except Exception:
                diag.exception("gov.intake.send")

        threading.Thread(target=do_send, name="GovIntakeSend", daemon=True).start()
        self._watch_document_answer()

    def _answer_settled(self, text) -> bool:
        """Ответ ИИ дописан? (v44: страховка от «ответ не пришёл»).

        Признаком конца ответа считается маркер `===КОНЕЦ ОТВЕТА===`. Но ИИ
        не всегда его пишет (а иногда продолжает ответ уже после документа —
        «Источники», подпись). Тогда раньше разбор ждал «неизменности» текста
        между двумя опросами и, если в ответе что-то менялось (курсор, время),
        не заканчивал ожидание никогда — окно писало «Ответ с постановлением не
        пришёл». Теперь достаточно, чтобы текст не менялся 3 опроса подряд
        (~7 секунд): это уже готовый ответ.
        """
        previous = getattr(self, "_doc_settle_text", None)
        count = int(getattr(self, "_doc_settle_count", 0) or 0)
        if previous == text:
            count += 1
        else:
            count = 1
        self._doc_settle_text = text
        self._doc_settle_count = count
        return count >= 3

    def _apply_gov_intake(self, text):
        """Ответ ИИ на проверку обращения: состояние дела + подсказка.

        Возвращает True, если ответ обработан (это был ответ на «Проверку ИИ»).

        v43: разбор терпимее к формулировкам ИИ («Отказать», «отказ в
        принятии», блок одной строкой, без «===»). Если состояние всё же не
        распознано, ответ всё равно сохраняется в дело, чтобы прокурор видел
        его в «Проверке обращения.txt», а не искал в чате.
        """
        if not pgov.has_intake_block(text):
            return False
        if getattr(self, "_gov_intake_handled", None) == text:
            return True
        if str(getattr(self, "_gov_intake_text", "")) and \
                pdoc.is_own_request(text, self._gov_intake_text):
            return False
        # v44: наша заявка — не ответ ИИ. В ней больше нет служебных маркеров,
        # но проверяем ещё раз: иначе в дело попадёт «Состояние: Принято или
        # Отказано» из описания формата (так дело 1 получило «Отказано» с
        # пустым основанием).
        if pdoc.is_own_request(text, str(getattr(self, "_gov_intake_text", "") or "")):
            diag.event("gov.intake.own_request", chars=len(text))
            return True
        result = pcases.parse_intake_answer(text)
        if not result.get("ok"):
            # Блок есть, но состояние не распознано: сохраняем ответ в дело
            # (v43) и просим проверить ещё раз.
            diag.event("gov.intake.unparsed", chars=len(text))
            store = self._document_case_store()
            case = None
            if getattr(self, "_gov_intake_case", ""):
                case = store.find(self._gov_intake_case)
            if case is None and getattr(self, "_gov_intake_text", ""):
                case = store.open_or_create(
                    getattr(self, "_gov_intake_appeal", "") or self._gov_intake_text)
            if case is not None:
                try:
                    folder = store.folder(case.number)
                    (folder / "Проверка обращения (не распознана).txt").write_text(
                        text.replace("\r\n", "\n"), encoding="utf-8")
                except Exception:
                    diag.exception("gov.intake.save_unparsed")
            self._set_status("Ответ ИИ по обращению не распознан — проверьте ещё раз",
                             "#f59e0b")
            return True
        # v66 (выгрузка `Постановление_65v.7z`): ответ этапа 1 ИИ печатает в
        # два приёма — сначала блок проверки, затем варианты цепочки этапа 2 и
        # рекомендации. Раньше опрос останавливался на ПЕРВОМ распознанном
        # состоянии: дело сохранялось с `work_chains = []`, этап 2 не
        # открывался, а дописанные позже цепочки никто не читал.
        chains = ogp_stages.split_chains(text)
        if not self._intake_answer_complete(text, result, chains):
            diag.event("gov.intake.incomplete", chars=len(text),
                       state=result.get("state"), chains=len(chains))
            return True                     # опрос продолжается
        self._gov_intake_handled = text
        self._gov_intake_watch_stop()
        # v65 (`keep_draft`): ответ этапа 1 разобран — сохранённая заявка
        # больше не нужна, «Повторить отправку» гаснет.
        self._pending_answer_received("1")
        store = self._document_case_store()
        case = store.find(self._gov_intake_case)
        if case is None:
            case = store.open_or_create(
                getattr(self, "_gov_intake_appeal", "") or self._gov_intake_text)
        case.apply_intake(result)
        case.intake_checks = int(getattr(case, "intake_checks", 0) or 0) + 1
        # v60: исход этапа 1 (пять вариантов блок-схемы) и план шагов этапа 2.
        # Разбор тот же, что в форме, — чтобы дело было одинаковым и когда
        # ответ пришёл при закрытом окне.
        outcome = {
            pgov.INTAKE_ACCEPTED: ogp_chain.OUTCOME_ACCEPT,
            pgov.INTAKE_DEFECTS: ogp_chain.OUTCOME_DEFECTS,
            pgov.INTAKE_REFUSED: ogp_chain.OUTCOME_REFUSE,
            pgov.INTAKE_REDIRECTED: ogp_chain.OUTCOME_REDIRECT,
            pgov.INTAKE_TERMINATED: ogp_chain.OUTCOME_STOP,
        }.get(result.get("state", ""))
        if outcome:
            case.set_outcome(outcome)
            # v62: этап 1 — узел цепочки. Поле 1 (что ввёл прокурор) — текст
            # обращения, поле 2 (ответ ИИ) — весь ответ: «Обстоятельства»
            # этапа 1 показывают решение по-человечески.
            state1 = ogp_stages.stage1_from_outcome(outcome)
            # v64: в поле 2 «Ответ ИИ» — только ответ, без страницы чата.
            # Сырой текст остаётся в файле дела («Проверка обращения.txt»).
            answer_text = pgov.extract_ai_answer(
                text, str(getattr(self, "_gov_intake_text", "") or ""),
                want="intake")
            case.set_work_node("1", input=str(case.appeal_raw or ""),
                               answer=answer_text or str(text or ""),
                               stale=False, done=True,
                               when=datetime.now().strftime("%d.%m.%Y %H:%M"),
                               verdict=ogp_stages.verdict_of(answer_text or text))
            if state1 == ogp_stages.STATE_ACCEPT:
                # v62: ИИ присылает варианты цепочки; старый одиночный план
                # остаётся вариантом «A», прогресс цепочек сохраняется при
                # повторном ответе.
                # v66: минимум снят (решение пользователя) — вариант может быть
                # один. Список разобран выше, до проверки завершённости ответа.
                if chains:
                    case.apply_chains(chains)
                else:
                    case.apply_plan(ogp_chain.parse_plan(text))
            else:
                case.work_plan = []
                case.work_step = 0
                case.work_chains = []
        store.save(case)
        try:
            folder = store.folder(case.number)
            (folder / "Проверка обращения.txt").write_text(
                text.replace("\r\n", "\n"), encoding="utf-8")
        except Exception:
            diag.exception("gov.intake.save_answer")
        diag.event("gov.intake.result", case=case.number, state=result["state"],
                   status=case.status)
        # Ответ пришёл при открытой форме — обновляем её состояние на месте
        # (этап и вкладка не меняются, v43).
        dialog = getattr(self, "_gov_dialog", None)
        if dialog is not None:
            try:
                dialog.refresh_case(case)
            except Exception:
                diag.exception("gov.intake.refresh_dialog")
        if result["state"] == pgov.INTAKE_ACCEPTED:
            self._set_status(
                f"Обращение №{case.number}: принято к производству", THEME["ok"])
        else:
            self._set_status(
                f"Обращение №{case.number}: {result['state']} "
                f"({result.get('basis') or 'основание в файле'})", "#f59e0b")
        # v46 (замечание пользователя): «после того как он проверил и ответ был
        # корректно получен, обнови браузер — а то он завис на „Обращение №1:
        # Отказано (…)“». Ответ разобран и записан в дело, поэтому окно ИИ и
        # список обращений перерисовываются: старое состояние больше не висит.
        self._refresh_after_intake(case)
        # v66: этап 1 завершён — автоматически запрашиваем постановление этапа 1.
        # При отказе и переадресации оно тоже выносится (критерий 5 приёмки), а
        # этапы 2 и 3 не открываются.
        self._auto_document_request(case, "1")
        self._drain_pending_queue()
        return True

    def _refresh_after_intake(self, case):
        """Обновляет окно ИИ и список дел после корректного ответа (v46)."""
        try:
            dialog = getattr(self, "_gov_cases_dialog", None)
            # Список обновляем, только если он реально открыт: закрытое окно
            # ничего не показывает, а держать на него ссылку незачем.
            if dialog is not None and dialog.isVisible():
                dialog.reload()
            elif dialog is not None:
                self._gov_cases_dialog = None
        except Exception:
            diag.exception("gov.intake.refresh_cases")
        # Перерисовка самого окна программы: без неё статус и список дел
        # остаются на прежнем состоянии, и окно выглядит зависшим.
        try:
            self.update()
            self.status_label.update()
            self.browser_placeholder.update()
            # v49: если форма ждала ответ на «Проверку ИИ», а браузер
            # перезапускался, вернём её на экран (окно не закрывается).
            if not self.native_mode:
                QTimer.singleShot(300, self._restore_gov_dialog_visibility)
        except Exception:
            diag.exception("gov.intake.repaint")
        # v63 (решение пользователя): «если кнопка называется „Этап 1“, то
        # перед отправкой ИИ выполнить мягкую очистку». Ответ этапа 1 в чате НЕ
        # трогаем: сразу за ним ИИ присылает цепочки этапа 2, и перезагрузка
        # страницы в этот момент рвёт их приём. Чистый чат уже сделан перед
        # отправкой (`_on_pending_send_restart`), а следующий нужен только по
        # кнопке «Закрыть обращение».
        self._gov_intake_reloaded = case.number
        diag.event("gov.intake.kept_in_chat", case=str(case.number))

    def _reload_chat_after_intake(self):
        """Обновление окна ИИ после корректной «Проверки ИИ» (v46).

        Пользователь: «после того как он проверил и ответ был корректно
        получен, обнови браузер. А то он завис на „Обращение №1: Отказано (…)“».

        Обновляем ровно так же, как это делает штатное восстановление страницы
        (`_recover_web`): старое CDP-соединение закрывается, окно браузера
        поднимается заново, чат открывается чистым. Тот же путь уже проверен
        на кнопке «Перезагрузить», поэтому новых состояний не появляется.
        """
        if self._closing:
            return
        # Заявка на постановление уже в очереди — её окно обновит `_start_chrome`
        # при повторной отправке, второй перезапуск только помешает.
        if getattr(self, "_pending_send_record_data", None):
            diag.event("gov.intake.reload_skipped", reason="pending_send")
            return
        timer = getattr(self, "_doc_watch_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
        diag.event("gov.intake.browser_reload", native=bool(self.native_mode))
        self._set_status("Проверка обращения получена — обновляем окно ИИ…",
                         THEME["accent"])
        try:
            self._recover_web()
        except Exception:
            diag.exception("gov.intake.browser_reload_failed")

    def _intake_settled(self, text, need: int = 3) -> bool:
        """Текст ответа этапа 1 не меняется `need` опросов подряд (v66).

        Отдельный счётчик от `_answer_settled` (тот принадлежит ожиданию
        документа): заявки этапа 1 и «Сформировать» идут друг за другом, и
        общий счётчик сбивал бы признак завершённости.
        """
        previous = getattr(self, "_intake_settle_text", None)
        count = int(getattr(self, "_intake_settle_count", 0) or 0)
        count = count + 1 if previous == text else 1
        self._intake_settle_text = text
        self._intake_settle_count = count
        return count >= max(1, int(need))

    def _intake_answer_complete(self, text: str, result: dict, chains: list) -> bool:
        """Ответ этапа 1 дописан? (v66)

        Завершённым считается ответ, в котором есть маркер конца ответа, либо
        текст перестал меняться. Для принятого обращения БЕЗ цепочек ждём
        вдвое дольше (ИИ печатает их вторым блоком) и дополнительно смотрим на
        мягкий срок ожидания `_doc_watch_deadline`: после него принимаем то,
        что есть, а форма предлагает запросить цепочки повторно — локально они
        не выдумываются.
        """
        if pdoc.has_answer_end(text):
            return True
        accepted = str(result.get("state") or "") == pgov.INTAKE_ACCEPTED
        if accepted and not chains:
            if self._intake_settled(text, need=8):
                return True
            deadline = float(getattr(self, "_doc_watch_deadline", 0) or 0)
            return bool(deadline) and time.monotonic() > deadline
        return self._intake_settled(text)

    def _gov_intake_watch_stop(self):
        timer = getattr(self, "_doc_watch_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass

    def _apply_iad_answer(self, text):
        """Ответ ИИ получен: сохраняем его и печатаем PNG ИЗ ЭТОГО ФАЙЛА.

        v31 — логика по требованию пользователя, максимально простая:

            1. дождались ответа ИИ (есть блок постановления и ответ дописан);
            2. сохранили ответ в `<выбранная папка>/<номер>/ИИ-ответ.txt`;
            3. прочитали ЭТОТ ЖЕ файл с диска;
            4. разобрали его и напечатали PNG в корень выбранной папки.

        Шаг 3 важен принципиально: PNG строится из сохранённого файла, а не из
        текста в памяти. Если файл не прочитался или в нём нет документа —
        PNG не печатается вовсе (раньше в таком случае печатались данные
        конструктора, и это выглядело как «PNG не из ответа ИИ»).
        """
        self._doc_answer_busy = False
        text = str(text or "")
        if not text.strip():
            return
        # Наша собственная заявка — не ответ ИИ.
        request_text = getattr(self, "_doc_request_text", "") or ""
        if request_text and pdoc.is_own_request(text, request_text):
            diag.event("documents.skip_own_request", chars=len(text))
            return
        # v32: РЕШЕНИЕ принимаем по наличию настоящих полей документа, а не по
        # маркеру. Наше сообщение в чате тоже содержит маркеры, и раньше этого
        # хватало, чтобы остановить ожидание и выдать «Бланк не сформирован»,
        # так и не дождавшись настоящего ответа ИИ.
        if not pdoc.looks_like_document(text):
            fields = pdoc.count_document_fields(text)
            diag.event("documents.answer_without_fields", fields=fields, chars=len(text))
            # Если ответ уже дописан, но полей нет — показываем один раз, что
            # именно сохранено. Ожидание при этом НЕ прекращаем: следующий
            # опрос может принести настоящий документ.
            unchanged = (getattr(self, "_doc_last_text", None) == text)
            self._doc_last_text = text
            if (pdoc.has_answer_end(text) or unchanged) and \
                    getattr(self, "_doc_warned_text", None) != text:
                self._doc_warned_text = text
                try:
                    folder = pdoc.doc_folder(
                        self._documents_root(),
                        (self._document_doc or pdoc.Postanovlenie()).get("doc_number"))
                    draft = folder / "ИИ-ответ.txt"
                    draft.write_text(text.replace("\r\n", "\n"), encoding="utf-8")
                    self._set_status(
                        "В ответе ИИ нет полей постановления — см. postanovleniya/",
                        "#f59e0b")
                except Exception:
                    diag.exception("documents.save_draft")
            return
        unchanged = (getattr(self, "_doc_last_text", None) == text)
        self._doc_last_text = text
        if not pdoc.has_answer_end(text) and not unchanged and \
                not self._answer_settled(text):
            diag.event("documents.answer_still_streaming", chars=len(text))
            return                      # ИИ ещё печатает — не режем документ
        if not pdoc.extract_document_block(text):
            return                      # нет блока постановления — ждём дальше
        if getattr(self, "_doc_handled_text", None) == text:
            return                      # этот ответ уже обработан
        self._doc_handled_text = text
        self._doc_watch_timer.stop()

        root = self._documents_root()
        base_doc = self._document_doc if isinstance(self._document_doc, pdoc.Postanovlenie) \
            else pdoc.Postanovlenie()

        # 2. сохраняем ответ ИИ (всегда, до всякого разбора)
        try:
            folder = pdoc.doc_folder(root, base_doc.get("doc_number"))
            raw_path = folder / "ИИ-ответ.txt"
            raw_path.write_text(text.replace("\r\n", "\n"), encoding="utf-8")
            diag.event("documents.raw_saved", path=str(raw_path), chars=len(text))
        except Exception as exc:
            diag.exception("documents.save_raw")
            self._set_status("Не удалось сохранить ответ ИИ — см. лог", THEME["danger"])
            QMessageBox.warning(
                self, "Ответ не сохранён",
                f"Не удалось записать ответ ИИ в папку:\n{root}\n\n{exc}")
            return

        # 3. читаем СОХРАНЁННЫЙ файл и только его считаем источником документа
        try:
            saved_text = raw_path.read_text(encoding="utf-8")
        except Exception:
            diag.exception("documents.read_saved_raw")
            saved_text = text

        # 4. разбор сохранённого ответа -> PNG
        doc = pdoc.parse_ai_answer(saved_text, base=self._document_doc)
        if doc is None:
            diag.event("documents.answer_not_parsed", path=str(raw_path))
            self._set_status("Ответ ИИ сохранён, но постановление из него не собрано",
                             "#f59e0b")
            QMessageBox.warning(
                self, "В ответе ИИ нет полей постановления",
                "Ответ ИИ сохранён, но в нём не нашлось полей документа, "
                "поэтому PNG не печатается.\n\n"
                f"Файл ответа:\n{raw_path}\n\n"
                "Проверьте, что ИИ прислал строки «Ключ: значение» "
                "(Ведомство, Номер, В отношении, Взыскание, Обстоятельства…) "
                "и пункты постановляющей части. Ожидание ответа продолжается: "
                "если ИИ допишет документ, PNG появится автоматически.",
            )
            return

        try:
            pages = prender.render_document(doc, self._document_assets())
            folder = pdoc.doc_folder(root, doc.get("doc_number"))
            stem = doc.get("doc_number") or "postanovlenie"
            # v54: PNG кладётся в папку документа — «Постановление №N/<номер>/»,
            # по аналогии с «Обращение №N/<AG-N>/» у Прокурора. В КОРНЕ
            # выбранной папки PNG больше не остаётся: там лежали файлы разных
            # постановлений вперемешку.
            main_paths = prender.save_pages(pages, folder, stem)
            self._document_pngs = main_paths
            saved_ai = pdoc.save_ai_answer(root, doc, saved_text)
            # v34: проверка по уставу — вилка взысканий, процессуальные нормы,
            # полномочия, чёрный список. Замечания пишем в Проверка.txt.
            issues = []
            try:
                issues = pdoc.check_document(doc, self._document_regulation())
                if issues:
                    (folder / "Проверка.txt").write_text(
                        "Замечания по уставу:\n\n" +
                        "\n".join(f"{i}. {issue}" for i, issue in enumerate(issues, 1)),
                        encoding="utf-8")
                diag.event("documents.checked", issues=len(issues))
            except Exception:
                diag.exception("documents.check")
            diag.event("documents.ai_saved", files=[p.name for p in saved_ai],
                       folder=str(folder), png=[p.name for p in main_paths])
            self._document_history().save(doc)
        except Exception as exc:
            diag.exception("documents.render_ai")
            self._set_status("Не удалось сохранить PNG постановления — см. лог",
                             THEME["danger"])
            QMessageBox.warning(
                self, "PNG не сохранён",
                f"Ответ ИИ сохранён, но PNG не записался:\n{root}\n\n{exc}")
            return
        diag.event("documents.rendered", pngs=len(self._document_pngs),
                   number=doc.get("doc_number"))
        # v56: блок «Обстоятельства» — вход для ИИ, а не текст документа.
        # После ответа он заполняется ТЕКСТОМ ИИ, чтобы в PNG и в форме было
        # одно и то же (замечание пользователя: «всё, что я пишу в
        # Обстоятельства сам и исправляю, попасть не должно»).
        dialog = getattr(self, "_iad_dialog", None)
        if dialog is not None:
            try:
                dialog.reload_document(doc)
            except Exception:
                diag.exception("documents.answer.reload_dialog")
        if issues:
            self._set_status("Постановление собрано, но есть замечания по уставу",
                             "#f59e0b")
            QMessageBox.warning(
                self, "Замечания по уставу",
                "PNG собран из ответа ИИ, но проверка по уставу нашла замечания:\n\n"
                + "\n".join(f"• {issue}" for issue in issues)
                + f"\n\nЗамечания сохранены в:\n{folder / 'Проверка.txt'}"
                  "\n\nPNG можно поправить, отредактировав ответ ИИ.",
            )
        else:
            self._set_status("Постановление собрано из ответа ИИ", THEME["ok"])
        if not issues:
            QMessageBox.information(
                self, "Постановление готово",
                "Ответ ИИ сохранён, PNG собран ИЗ НЕГО:\n\n• "
                + "\n• ".join(str(p) for p in self._document_pngs)
                + f"\n\nПапка документа: {folder}\n"
                  "В ней лежат: заявка, ответ ИИ как есть и копия PNG.\n\n"
                  "Чат с ИИ остаётся как есть: страница не перезагружается.",
            )
        # v56: приложение после PNG не перезапускается.
        # v63 (решение пользователя): страница ИИ после «Сформировать» и после
        # PNG больше НЕ обновляется — ни здесь, ни у бланка Прокурора. Чат
        # чистится только на входе и по «Закрыть обращение».
        diag.event("documents.answer.kept_in_chat")

    def _schedule_fresh_chat_after_answer(self):
        """Плановое обновление страницы ИИ (v51, v63, v67).

        v67 (п.3 обратной связи 66v, решение пользователя): «Как и до каждого
        сбора „Постановления“ так и после обновлять браузер». Поэтому метод
        снова вызывается после успешного сбора постановления — но только если
        следующей заявки нет (иначе чат очистится перед её отправкой, а лишняя
        перезагрузка откладывала выгрузку вложений).

        История: в v51 жалоба была «после „Сформировать“ браузер не
        обновляется, остаётся с ответом ИИ» — и очистка шла после каждого
        ответа. В v63 пользователь поменял решение: ответы должны оставаться,
        иначе ИИ теряет контекст этапов, и вызовы оттуда убрали. В v67 правило
        возвращено: контекст этапов ИИ получает из файла заявки («СВЕДЕНИЯ ПО
        ДЕЛУ»), а не из истории переписки. Пауза — чтобы прокурор успел
        увидеть готовый ответ и PNG.
        """
        if self._closing or not getattr(self, "_fresh_chat_after_answer", True):
            return
        self._fresh_chat_requested = True
        delay = int(FRESH_CHAT_AFTER_ANSWER_DELAY * 1000)
        diag.event("browser.fresh_chat.scheduled", delay_ms=delay)
        QTimer.singleShot(delay, self._restart_browser_for_fresh_chat)

    def _restart_after_document(self):
        """После PNG приложение НЕ перезапускается (v56).

        Оставлено как совместимая точка входа: старые вызовы и внешние
        сценарии получают мягкую перезагрузку страницы ИИ, а не
        `restart_app()`. Замечание пользователя: «после того как получил .png
        файл не перезагружай приложение, а обнови браузер внутри как при
        „Сформировать“».
        """
        if self._closing:
            return
        diag.event("documents.restart_soft", reason="post-png")
        self._schedule_fresh_chat_after_answer()

    # ------------------------------------------------------- v66: путь и автозапрос

    def _gov_answer_folder(self, root, doc_number, case_number, case=None):
        """Папка ответа ИИ по обращению.

        v66: у дел нового образца это папка ОБЩЕГО номера
        (`postanovleniya/Обращение №1/0001`), а не папка номера этапа: все
        постановления обращения лежат вместе, этапы — в своих подпапках.
        Старые дела (`AG-1`, `001`) живут по прежним правилам.
        """
        try:
            if case is None and case_number:
                case = self._document_case_store().find(str(case_number))
            if case is not None and case.new_numbering():
                base = dl.normalize_base(case.doc_base)
                if base:
                    target = dl.case_dir(root, case.number, base)
                    target.mkdir(parents=True, exist_ok=True)
                    return target
        except Exception:
            diag.exception("gov.answer_folder")
        return pdoc.doc_folder(root, doc_number, case_number)

    def _gov_raw_answer_folder(self, root, node_kind: str = "", fallback=None):
        """Папка ЭТАПА для сырого ответа ИИ (v67, находка 2).

        До разбора ответа известны только дело и узел из записи отложенной
        отправки. Папка берётся уже созданной, если она есть (`Этап 2.1 —
        истребование`), иначе создаётся по правилам `pcases.node_folder`. Для
        дел прежней нумерации и когда узел неизвестен — папка обращения
        (`fallback`), то есть прежнее поведение.
        """
        if fallback is None:
            fallback = self._gov_answer_folder(
                root, "", getattr(self, "_doc_case_number", "") or
                getattr(self, "_gov_intake_case", ""))
        case_number = (getattr(self, "_doc_case_number", "") or
                       getattr(self, "_gov_intake_case", ""))
        node = str(node_kind or "").strip()
        if not node or node == "__reorder__" or not case_number:
            return fallback
        try:
            case = self._document_case_store().find(str(case_number))
            if case is not None and case.new_numbering():
                number = ""
                base_doc = getattr(self, "_document_doc", None)
                if isinstance(base_doc, pgov.PostanovlenieProkurora):
                    number = str(base_doc.get("doc_number") or "")
                number = pcases.node_doc_number(case, node, number)
                return pcases.node_folder_guess(root, case, node,
                                                doc_number=number)
        except Exception:
            diag.exception("gov.raw_folder")
        return fallback

    def _gov_save_raw_safely(self, folder, saved_text: str):
        """Пишет сырой ответ ИИ в папку этапа, не затирая действующую версию.

        v67 (находка 2): пока в папке этапа нет напечатанного PNG, ответ
        сохраняется под обычным именем «ИИ-ответ.txt». Если действующая версия
        уже есть (повторный сбор закончился ошибкой), ответ кладётся рядом как
        «ИИ-ответ (не напечатан).txt» — комплект предыдущей версии остаётся
        целым, а в «Архив/Версия-NNN» этот файл не попадает.
        """
        folder = Path(folder)
        target = folder / "ИИ-ответ.txt"
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if target.is_file() and list(folder.glob("*.png")):
                target = folder / "ИИ-ответ (не напечатан).txt"
            target.write_text(str(saved_text or ""), encoding="utf-8")
            diag.event("gov.raw_saved", path=str(target),
                       chars=len(str(saved_text or "")))
        except Exception:
            diag.exception("gov.save_raw")
        return target

    def _auto_document_request(self, case, kind) -> bool:
        """v66: узел завершён — автоматически запрашиваем постановление ЭТОГО этапа.

        Согласовано: «после завершения каждого этапа/подэтапа — отдельный
        автоматический запрос на постановление именно этого этапа, даже если
        ответ 2.N/3 уже похож на постановление». Ответ первого запроса уже
        сохранён как ответ узла и уходит в контекст этой заявки
        (`gov_case.node_document_request` → `ogp_stages.context_block`).

        Три защиты от петель и дублей (критерий 6 приёмки):

        * признак `auto_document` в узле дела — ровно один запрос на завершение;
        * роль заявки: ответ на АВТОМАТИЧЕСКУЮ заявку нового запроса не порождает;
        * очередь `pending_send`: пересекающиеся заявки сериализуются и не
          перезаписывают единственную активную запись.

        Если цепочки этапа 2 нет, локально мы её не выдумываем: автозапрос не
        уходит, а форма предлагает ручной повтор (критерий 4 приёмки).
        """
        try:
            kind = str(kind or "").strip()
            if case is None or not kind or kind == "__reorder__":
                return False
            if not case.auto_document_due(kind):
                return False
            root = self._documents_root()
            prosecutor = str(case.keyword("author_name") or "")
            doc_type = ""
            if kind == "1":
                doc_type = str(getattr(case, "intake_doc_type", "") or "")
            elif kind.startswith("2."):
                step = int(kind.split(".")[-1] or 0)
                for item in case.current_plan() or []:
                    if int(item.get("n") or 0) == step:
                        doc_type = str(item.get("title") or item.get("kind") or "")
                        break
            folder = pcases.node_folder(root, case, kind, doc_type)
            request_text = pcases.node_document_request(case, kind, prosecutor)
            request_path = folder / "Заявка (постановление этапа).txt"
            request_path.write_text(request_text, encoding="utf-8")
            # Снимок полей рядом с заявкой: по нему main восстановит этап, номер
            # дела и вид решения, когда придёт ответ (`_load_pending_fields`).
            doc = self._document_doc if isinstance(
                self._document_doc, pgov.PostanovlenieProkurora) \
                else pgov.PostanovlenieProkurora()
            doc = pgov.PostanovlenieProkurora.from_dict(doc.to_dict())
            doc.apply_keywords(dict(getattr(case, "intake_fields", {}) or {}))
            doc.case_number = str(case.number or "")
            doc.case_stage_kind = pcases.stage_kind_for_node(kind)
            doc.doc_stage = pcases.gov_stage_for_kind(doc.case_stage_kind)
            number = pcases.node_doc_number(case, kind, doc.get("doc_number"))
            if number:
                doc.doc_number = number
            if doc_type:
                doc.doc_type = doc_type
            (folder / "Заявка-поля.json").write_text(
                json.dumps({"поля": doc.to_dict()}, ensure_ascii=False, indent=2),
                encoding="utf-8")
            appeal_path = ai_request.write_appeal_file(
                folder, str(case.appeal_raw or ""))
            record = psend.build_record(
                kind="document",
                role=psend.ROLE_AUTO_DOCUMENT,
                request_text=request_text,
                message_text=ai_request.document_message(
                    request_path.name, appeal_path.name),
                appeal_path=str(appeal_path),
                appeal_text=str(case.appeal_raw or ""),
                source_path=str(request_path),
                case_number=str(case.number),
                stage_kind=doc.case_stage_kind,
                stage_index=case.stage_number(doc.case_stage_kind),
                doc_type=doc.doc_type,
                document_kind="gov",
                node_kind=kind,
                title=f"Постановление этапа {kind} (автоматически) · "
                      f"Обращение №{case.number}")
            mode, record = psend.enqueue(root, record)
            if mode == "duplicate":
                diag.event("gov.auto_document.duplicate", node=kind)
                return False
            case.set_auto_document(kind, "requested")
            self._document_case_store().save(case)
            diag.event("gov.auto_document.queued", node=kind, mode=mode,
                       chars=len(request_text), queue=psend.queue_len(root))
            if mode == "queued":
                self._set_status(
                    f"Постановление этапа {kind}: заявка в очереди — уйдёт "
                    "сразу после текущего запроса", THEME["accent"])
                return False
            self._on_pending_send_restart(record, str(request_path))
            return True
        except Exception:
            diag.exception("gov.auto_document")
            return False

    def _drain_pending_queue(self) -> None:
        """v66: следующая заявка из очереди, когда активный слот освободился."""
        try:
            root = self._documents_root()
            if psend.is_busy(psend.load(root)) or psend.queue_len(root) <= 0:
                return
            record = psend.next_from_queue(root)
        except Exception:
            diag.exception("main.pending_send.drain")
            return
        if not record:
            return
        diag.event("pending_send.promoted", kind=record.get("kind"),
                   node=record.get("node_kind"), role=record.get("role"),
                   left=psend.queue_len(root))
        self._on_pending_send_restart(record, str(record.get("source_path") or ""))

    @pyqtSlot(str)
    def _apply_gov_answer(self, text):
        """Постановление Прокурора: ответ ИИ → ИИ-ответ.txt → PNG."""
        self._doc_answer_busy = False
        text = str(text or "")
        if not text.strip():
            return
        request_text = getattr(self, "_doc_request_text", "") or ""
        if request_text and pdoc.is_own_request(text, request_text):
            diag.event("gov.skip_own_request", chars=len(text))
            return
        has_fields = bool(pgov.parse_gov_answer(text))
        if not has_fields:
            unchanged = (getattr(self, "_doc_last_text", None) == text)
            self._doc_last_text = text
            if (pdoc.has_answer_end(text) or unchanged) and \
                    getattr(self, "_doc_warned_text", None) != text:
                self._doc_warned_text = text
                self._set_status("В ответе ИИ нет полей постановления Прокурора",
                                 "#f59e0b")
            return
        unchanged = (getattr(self, "_doc_last_text", None) == text)
        self._doc_last_text = text
        if not pdoc.has_answer_end(text) and not unchanged and \
                not self._answer_settled(text):
            return
        if getattr(self, "_doc_handled_text", None) == text:
            return
        self._doc_handled_text = text
        self._doc_watch_timer.stop()

        root = self._documents_root()
        base_doc = self._document_doc if isinstance(
            self._document_doc, pgov.PostanovlenieProkurora) else pgov.PostanovlenieProkurora()
        # v62: узел цепочки («1», «2.1», «3»). Он приходит из записи
        # отложенной отправки — форма кладёт туда `stage_kind` вида «2.1».
        node_kind = str(getattr(self, "_doc_node_kind", "") or "").strip()
        # v65 (`keep_draft`): ответ по заявке разобран — запись убираем.
        self._pending_answer_received(node_kind)

        # v53: папка документа — внутри папки обращения «Обращение №N».
        # v66: у дел нового образца это папка ОБЩЕГО номера («0001»), а не
        # папка номера этапа («0001-2»): постановления всех этапов одного
        # обращения лежат вместе, а этапы разложены по своим подпапкам.
        try:
            folder = self._gov_answer_folder(
                root, base_doc.get("doc_number"),
                getattr(self, "_doc_case_number", "") or
                getattr(self, "_gov_intake_case", ""))
        except Exception as exc:
            diag.exception("gov.save_raw")
            QMessageBox.warning(self, "Ответ не сохранён",
                                f"Не удалось записать ответ ИИ:\n{root}\n\n{exc}")
            return
        # v67 (находка 2, одобрена пользователем): сырой ответ ИИ живёт в папке
        # СВОЕГО этапа, а не в корне папки обращения. В выгрузке
        # «Постановление_66v.7z» файл `Обращение №2/0002/ИИ-ответ.txt` (13 015
        # знаков, с эхом заявки «… — ДОКУМЕНТ») был ответом ПОСЛЕДНЕГО узла, а
        # сырьё этапов 2.1–2.4 затиралось каждым следующим ответом.
        #
        # Запись здесь НЕ делаем: на успешном пути её выполняет рендер — после
        # снимка прежней версии в «Архив/Версия-NNN» (иначе в архив попал бы
        # новый ответ вместо старого). На пути ошибки ответ сохраняет
        # `_gov_save_raw_safely`, не затирая действующий комплект.
        saved_text = text.replace("\r\n", "\n")
        raw_folder = self._gov_raw_answer_folder(root, node_kind, folder)
        raw_path = raw_folder / "ИИ-ответ.txt"
        stage_dir = raw_folder

        # v64: разбираем и храним ЧИСТЫЙ ответ ИИ. Со страницы чата текст
        # приходит вместе с эхом нашей заявки, чипами вложений
        # («Memphis.pdf / PDF», «Шаблон.txt / File») и элементами интерфейса;
        # раньше этот мусор оседал в `situation` и печатался в «УСТАНОВИЛ»
        # (выгрузка `этап-1 — принятие.7z`). Сырьё остаётся в «ИИ-ответ.txt».
        #
        # v65 (выгрузка «Обращение №1.7z»): `want="document"`. Страница чата
        # хранит ВСЕ ответы диалога, и без этого признака `extract_ai_answer`
        # обрезал текст по ПЕРВОМУ якорю — блоку «ПРОВЕРКА ОБРАЩЕНИЯ» от
        # этапа 1. Постановление (в файле оно было) не разбиралось, и окно
        # писало «В ответе ИИ нет полей постановления». Теперь берётся ответ
        # на последнюю заявку, а страховкой — разбор сырого текста.
        answer_text = pgov.extract_ai_answer(
            saved_text, str(getattr(self, "_doc_request_text", "") or ""),
            want="document")
        doc = pgov.parse_gov_answer(answer_text or saved_text, base=base_doc)
        if doc is None:
            doc = pgov.parse_gov_answer(saved_text, base=base_doc)
            if doc is not None:
                diag.event("gov.answer_from_raw", node=node_kind,
                           clean_chars=len(answer_text or ""))
        if doc is None:
            raw_path = self._gov_save_raw_safely(raw_folder, saved_text)
            self._set_status("Ответ ИИ сохранён, но постановление не собрано", "#f59e0b")
            QMessageBox.warning(
                self, "В ответе ИИ нет полей постановления",
                "Ответ сохранён, но полей документа в нём не нашлось, поэтому PNG "
                "не печатается.\n\nПроверьте, что ИИ ответил на заявку "
                "«ЗАЯВКА НА ПОСТАНОВЛЕНИЕ ПО ОБРАЩЕНИЮ … — ДОКУМЕНТ» блоком "
                "постановления (поля «Ключ: значение», «УСТАНОВИЛ:», "
                "«ПОСТАНОВИЛ:»), а не служебным блоком проверки обращения.\n\n"
                f"Файл ответа:\n{raw_path}")
            return

        issues = []
        try:
            # v42: PNG этапа — в свою папку и со своим именем. Замечание:
            # «раздели итоговые файлы .png для различных этапов, чтобы файл,
            # полученный на 1 этапе, не заменялся файлами следующих этапов».
            store = self._document_case_store()
            case = None
            if doc.get("case_number"):
                case = store.load(doc.get("case_number"))
            # v45: дело берём по номеру из записи (кнопка «Сформировать»),
            # а не по «последней проверке обращения».
            case_number = (getattr(self, "_doc_case_number", "")
                           or getattr(self, "_gov_intake_case", ""))
            if case is None and case_number:
                case = store.find(case_number)
            # v51: этап берём из записи отложенной отправки (пользователь выбрал
            # его в форме), затем из документа, и только потом — из вида решения.
            # Иначе ответ этапа 2 печатался в папку «этап-1» (п.1: у AG-2 не
            # появился PNG этапа «санкция»).
            stage_kind = (doc.get("case_stage_kind")
                          or getattr(self, "_doc_stage_kind", "")
                          or (pcases.STAGE_MEASURE if doc.is_final()
                              else pcases.STAGE_INTAKE))
            # v43.2: по делу со статусом «Отказано» документ — первичное
            # решение, даже если ИИ назвал его итоговым: PNG должен попасть в
            # папку этапа 1, а не в «санкцию» (замечание пользователя).
            if case is not None and case.refused() and not case.accepted():
                stage_kind = pcases.STAGE_INTAKE
            if case is not None:
                # v43: номер этапа постоянный для его вида и совпадает с тем,
                # куда форма положила заявку (иначе PNG уходил в чужую папку).
                stage_index = case.stage_number(stage_kind)
            else:
                case = pcases.GovCase(number=doc.get("case_number")
                                      or store.next_number())
                stage_index = case.stage_number(stage_kind)
            # v66: номер постановления этапа фиксирует КЛИЕНТ («0001-2»), а не
            # ИИ: в выгрузке `Постановление_65v.7z` заявка несла «AG-1», ИИ
            # вернул «001», и комплект обращения разорвался на две папки.
            # Номер один и тот же в форме, заявке, PNG, данных дела и именах
            # файлов и папок (критерий 15 приёмки).
            new_numbering = bool(case is not None and case.new_numbering())
            node_key = str(node_kind or "").strip() or (
                "1" if stage_kind == pcases.STAGE_INTAKE else "")
            if new_numbering and node_key:
                fixed = pcases.node_doc_number(case, node_key,
                                               doc.get("doc_number"))
                if fixed and str(doc.get("doc_number") or "") != fixed:
                    diag.event("gov.number.fixed", node=node_key,
                               was=str(doc.get("doc_number") or ""), now=fixed)
                    doc.doc_number = fixed
            pages = prender.render_document(doc, self._document_gov_assets())
            # v61: у этапа 2 несколько шагов — каждый со своей папкой и своим
            # именем PNG («этап-2.3 — допрос»), иначе документы затирали друг
            # друга (замечание пользователя: на каждый подэтап — свой .png).
            step_number = 0
            if stage_kind == pcases.STAGE_MEASURE:
                step_number = int((case.current_work_step() or {}).get("n") or 0)
            if new_numbering:
                # v66: согласованная схема — «Обращение №1/0001/[Цепочка A/]
                # Этап 2.1 — истребование/0001-2 — Этап 2.1 — стр. 1.png».
                stem = pcases.node_stem(case, node_key, doc.get("doc_number"),
                                        doc.get("doc_type"))
                stage_dir = pcases.node_folder(root, case, node_key,
                                               doc.get("doc_type"),
                                               doc_number=doc.get("doc_number"))
                # Прежняя версия узла уезжает в «Архив/Версия-NNN» ЦЕЛИКОМ
                # (PNG, ответ ИИ, поля, заявка) и только затем пишется новая:
                # действующий комплект не исчезает, если запись не удалась.
                try:
                    version = dl.snapshot_current(stage_dir)
                except Exception:
                    diag.exception("gov.archive.snapshot")
                    version = None
                if version is not None:
                    diag.event("gov.archived", node=node_key,
                               version=version.name,
                               files=len(list(version.iterdir())))
            else:
                stem = pcases.stage_stem(doc.get("doc_number") or case.number,
                                         stage_index, stage_kind,
                                         doc.get("doc_type"),
                                         step_number=step_number)
                # v62: имя файла получает метку узла («эт.2.1», «эт.3»), чтобы
                # постановления разных узлов и вариантов цепочки не путались.
                if node_kind and f"эт.{node_kind}" not in stem:
                    stem = f"{stem} — эт.{node_kind}"
                stage_dir = pcases.stage_folder(
                    root, doc.get("doc_number") or case.number, stage_index,
                    stage_kind, case_number=case.number)
                # v61: у шага этапа 2 своя подпапка «этап-2.N — <вид>»: без неё
                # постановления разных подэтапов затирали друг друга.
                if step_number:
                    stage_dir = pcases.stage_folder(
                        root, doc.get("doc_number") or case.number, stage_index,
                        stage_kind, case_number=case.number,
                        step_number=step_number, doc_type=doc.get("doc_type"))
            main_paths = prender.save_pages(pages, stage_dir, stem,
                                            numbered=new_numbering)
            self._document_pngs = main_paths
            folder = self._gov_answer_folder(root, doc.get("doc_number"),
                                             case.number, case=case)
            if new_numbering:
                # v66: копии PNG в папку обращения не делаем — страницы лежат в
                # папке своего этапа и в архиве версий (иначе один и тот же
                # файл жил бы в двух местах и устаревал).
                # Страницы старой многостраничной версии не должны оставаться
                # среди новых (критерий 12 приёмки).
                for extra in dl.pages_leftover(stage_dir, len(main_paths)):
                    try:
                        extra.unlink()
                        diag.event("gov.page.removed", name=extra.name)
                    except Exception:
                        diag.exception("gov.page.remove")
            else:
                pdoc.copy_pngs_into(folder, main_paths)
            # v67 (находка 2, решение пользователя `stage_only`): сырой ответ
            # ИИ пишется в папку ЭТАПА — и для новой, и для прежней нумерации.
            # В v66 он писался ДО разбора ответа в папку ОБРАЩЕНИЯ
            # (`Обращение №2/0002/ИИ-ответ.txt`), поэтому каждый следующий
            # ответ затирал предыдущий: в выгрузке «Постановление_66v.7z» там
            # лежало 13 015 Б эха последней авто-заявки, а сырьё этапов
            # 2.1–2.4 пропало. Теперь у каждого этапа свой «ИИ-ответ.txt», и
            # при повторном сборе прежний комплект уезжает в
            # «Архив/Версия-NNN» вместе со своим ответом (`snapshot_current`).
            try:
                (stage_dir / "ИИ-ответ.txt").write_text(
                    str(saved_text or text or ""), encoding="utf-8")
            except Exception:
                diag.exception("gov.archive.answer")
            (stage_dir / "ИИ-документ.txt").write_text(
                doc.to_document_txt(), encoding="utf-8")
            (stage_dir / "ИИ-поля.json").write_text(
                json.dumps(doc.to_dict(), ensure_ascii=False, indent=2),
                encoding="utf-8")
            # v62: если ИИ прислал согласованный порядок цепочки — применяем
            # его к оставшимся подэтапам (выполненные не трогаем).
            order = ogp_stages.split_chains(saved_text)
            if order and node_kind == "__reorder__":
                applied = case.apply_new_order(order[0]["steps"])
                diag.event("gov.order.applied", steps=applied)
            issues = pgov.check_gov_document(doc)
            if issues:
                (stage_dir / "Проверка.txt").write_text(
                    "Замечания по постановлению Прокурора:\n\n" +
                    "\n".join(f"{i}. {issue}" for i, issue in enumerate(issues, 1)),
                    encoding="utf-8")
            # Дело: этап отмечен выполненным, PNG запомнен (v42).
            case.mark_stage(stage_kind, doc_number=doc.get("doc_number", ""),
                            png=str(main_paths[0]) if main_paths else "",
                            accepted=(stage_kind == pcases.STAGE_INTAKE))
            # v62: ответ ИИ записывается в узел цепочки («1», «2.N», «3»).
            # Узел хранит поле 2 (ответ ИИ, только чтение) и итог шага;
            # подэтап считается пройденным, когда пришёл ответ, а поле 1 не
            # менялось после него.
            if node_kind:
                # v64: в узел пишется чистый ответ ИИ (`answer_text` выше) —
                # его же видит прокурор в поле 2 и его же клиент отправляет ИИ
                # как память дела по следующему этапу.
                verdict = ogp_stages.verdict_of(answer_text or saved_text)
                case.set_work_node(node_kind,
                                   answer=answer_text or str(saved_text or ""),
                                   stale=False,
                                   done=True,
                                   doc_number=doc.get("doc_number", ""),
                                   png=str(main_paths[0]) if main_paths else "",
                                   when=datetime.now().strftime("%d.%m.%Y %H:%M"),
                                   verdict=verdict)
                if node_kind.startswith("2."):
                    step_number = int(node_kind.split(".")[-1] or 0)
                    case.mark_work_step(step_number,
                                        doc_number=doc.get("doc_number", ""),
                                        png=str(main_paths[0]) if main_paths else "",
                                        verdict=verdict)
            elif stage_kind == pcases.STAGE_MEASURE and step_number:
                verdict = ogp_flow.apply_verdict(case, step_number, saved_text)
                case.mark_work_step(step_number,
                                    doc_number=doc.get("doc_number", ""),
                                    png=str(main_paths[0]) if main_paths else "",
                                    verdict=verdict)
            # v66: постановление узла получено — автоматический запрос по этому
            # узлу больше не нужен (ровно один на завершение, без петель).
            # v67 (находка 1): запись отложенной отправки к этому моменту уже
            # очищена, поэтому роль берём из запомненной в
            # `_pending_answer_received` — иначе `auto_document` оставался
            # «requested» и клиент мог послать автозапрос повторно.
            role = psend.record_role(getattr(self, "_pending_send_record_data",
                                             {}) or {})
            if not role:
                role = str(getattr(self, "_pending_answer_role", "") or "")
            # v67 (п.3 `one_call` + находка 1): постановление узла напечатано —
            # автоматический запрос по нему больше не нужен. Отметка ставится
            # при ЛЮБОЙ роли заявки: авто-заявка этапа 1, единая заявка
            # «Этап N — ДОКУМЕНТ» и ручное «Сформировать» дают один результат.
            if node_key:
                case.set_auto_document(node_key, "done")
                diag.event("gov.auto_document.done", node=node_key, role=role)
            self._pending_answer_role = ""
            self._pending_answer_node = ""
            store.save(case)
            # v51 (п.4): ответ ИИ ЗАМЕНЯЕТ черновик заявки — в истории одна
            # запись на документ, а не две одинаковые строки.
            self._document_gov_history().replace(doc)
            diag.event("gov.rendered", pngs=len(main_paths), issues=len(issues),
                       stage=stage_kind, stage_index=stage_index)
        except Exception as exc:
            diag.exception("gov.render")
            # v67 (находка 2): сырой ответ сохраняется и при ошибке рендера —
            # но так, чтобы действующая версия (PNG и её «ИИ-ответ.txt»)
            # осталась нетронутой (критерии 12–13 приёмки).
            raw_path = self._gov_save_raw_safely(raw_folder, saved_text)
            QMessageBox.warning(self, "PNG не сохранён",
                                f"Ответ ИИ сохранён, но PNG не записался:\n{root}\n\n"
                                f"Ответ ИИ:\n{raw_path}\n\n{exc}")
            return

        if issues:
            self._set_status("Постановление Прокурора собрано, но есть замечания", "#f59e0b")
            QMessageBox.warning(
                self, "Замечания к постановлению",
                "PNG собран из ответа ИИ, но проверка нашла замечания:\n\n"
                + "\n".join(f"• {issue}" for issue in issues)
                + "\n\nЗамечания сохранены в:\n{stage_dir / 'Проверка.txt'}")
        else:
            self._set_status("Постановление Прокурора собрано из ответа ИИ", THEME["ok"])
        # v49 (замечание пользователя): форму «Постановление Обращение №» не
        # закрываем и не перезапускаем — обновляем её по полученному ответу
        # ИИ (реквизиты, вид решения, этап, статус).
        dialog = getattr(self, "_gov_dialog", None)
        if dialog is not None:
            try:
                # v66 (п.6 диагноза): форма получает ту же копию дела, которую
                # main только что сохранил. Раньше у формы оставалась своя
                # (устаревшая) копия, и её сохранение стирало из `case.json`
                # номер постановления, путь к PNG и ответ узла.
                dialog.adopt_case(case)
            except Exception:
                diag.exception("gov.answer.adopt_case")
            try:
                # v56: блоки «Обстоятельства» — вход для ИИ, а не текст
                # документа. После ответа они заполняются ТЕКСТОМ ИИ
                # («УСТАНОВИЛ» → «а) Что видно на видеофиксации»,
                # «ПОСТАНОВИЛ» → «г) Решение прокурора»), а всё, что прокурор
                # писал руками, в PNG не попадает вообще.
                dialog.apply_answer_texts(doc)
            except Exception:
                diag.exception("gov.answer.apply_texts")
            try:
                dialog.refresh_document(doc)
            except Exception:
                diag.exception("gov.answer.refresh_dialog")
        # v66: узел завершён — отдельным автоматическим запросом выносим
        # постановление ИМЕННО этого этапа (согласовано: даже если ответ 2.N/3
        # уже похож на постановление). Ровно один раз на узел.
        self._auto_document_request(case, node_key)
        self._drain_pending_queue()
        # v67 (п.3 обратной связи 66v): «Как и до каждого сбора „Постановления"
        # так и после обновлять браузер». ДО — очистка страницы перед каждой
        # заявкой (`restart_requested`, v65); ПОСЛЕ — здесь. Если следующая
        # заявка уже стоит (автозапрос постановления этапа 1 или очередь),
        # перезагрузку не планируем: та заявка всё равно очистит чат перед
        # отправкой, а лишняя перезагрузка сдвигала выгрузку вложений
        # (`upload_deferred reason=fresh_chat` в журнале
        # 20261128-190131-18824-02d216).
        try:
            busy = psend.is_busy(psend.load(root)) or psend.queue_len(root) > 0
        except Exception:
            diag.exception("gov.fresh_chat_check")
            busy = True
        if busy:
            diag.event("gov.fresh_chat_skipped", reason="next_request")
        else:
            self._schedule_fresh_chat_after_answer()
        if not issues:
            QMessageBox.information(
                self, "Постановление готово",
                "Ответ ИИ сохранён, PNG собран ИЗ НЕГО:\n\n• "
                + "\n• ".join(str(p) for p in self._document_pngs)
                + f"\n\nПапка документа: {folder}")
        # v63 (решение пользователя): «Страница ИИ не обновляется и не
        # очищается ни после „Сформировать“, ни после PNG».
        # v67 (п.3 обратной связи 66v) решение изменено: «Как и до каждого
        # сбора „Постановления“ так и после обновлять браузер». Перезагрузка
        # планируется выше — но только когда следующей заявки нет, поэтому
        # память дела ИИ получает из файла заявки (`node_document_request` →
        # «СВЕДЕНИЯ ПО ДЕЛУ»), а не из истории переписки.
        diag.event("gov.answer.kept_in_chat", chars=len(text or ""))

    def _open_prompts_folder(self):
        """Открывает папку «Промт» в проводнике (v26: промты лежат локально)."""
        try:
            folder = prompts_dir()
            folder.mkdir(parents=True, exist_ok=True)
            if sys.platform == "win32":
                os.startfile(str(folder))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception:
            diag.exception("main.open_prompts_folder")

    def _choose_prompt(self):
        """Выбор промта из локальной папки «Промт» (v26, без сервера)."""
        try:
            items = list_local_prompts()
            if not items:
                try:
                    prompts_dir().mkdir(parents=True, exist_ok=True)
                except Exception:
                    diag.exception("main.prompts_dir_mkdir")
                QMessageBox.information(
                    self,
                    "Промты",
                    "В локальной папке нет промтов.\n\n"
                    f"Положите туда .pdf или .txt файл:\n{prompts_dir()}",
                )
                self._open_prompts_folder()
                return

            display = [prompt_display_name(i) for i in items]
            current = self.cfg.get("selected_prompt", "")
            idx = items.index(current) if current in items else 0

            overlay_was_visible = self.overlay.isVisible()
            if overlay_was_visible:
                self.overlay.hide()

            dlg = PromptSelectionWindow(items, display, idx, self)
            dialog_result = dlg.exec()

            if dialog_result != QDialog.DialogCode.Accepted or not dlg.choice:
                if overlay_was_visible:
                    self.overlay.show()
                    self.overlay.sync_geometry()
                    force_topmost(int(self.overlay.winId()))
                return

            self.cfg["selected_prompt"] = dlg.choice
            save_config(self.cfg)
            self._update_prompt_label()
            self._reload_prompt()

        except Exception as e:
            diag.exception("main.choose_prompt")
            QMessageBox.warning(self, "Ошибка", str(e))
            if 'overlay_was_visible' in locals() and overlay_was_visible:
                self.overlay.show()

    def _reload_prompt(self):
        if not self.worker or not getattr(self.worker, "page", None):
            return

        self.pdf_attached = False
        self.pdf_was_loaded_once = False
        self._last_attached_state = None
        self._set_dot("#f59e0b")
        self._show_overlay("Синхронизация", "Обновление служебных файлов…")
        self._page_eval_async(JS_REMOVE_ALL_FILES, 3)
        QTimer.singleShot(650, lambda: self._load_prompt(force=True))

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _start_chrome(self):
        # Окно браузера — другой процесс со своей очередью ввода: отдаём ему
        # фокус по клику мыши внутри него (без хуков и перехвата клавиш).
        if getattr(self, "focus_timer", None) is None:
            self.focus_timer = QTimer(self)
            self.focus_timer.timeout.connect(self._poll_browser_focus)
            self.focus_timer.start(25)
        if self.worker is not None or self._closing:
            return
        # v18: без настоящего Chrome микрофон не работает штатно — предлагаем
        # поставить его ДО запуска. Если Chrome уже есть, вызов пустой.
        if self._offer_browser_install(self._browser_candidates()):
            return
        # Никаких миганий: до готовности страницы видна только шторка.
        self.browser_cover.show()
        self.browser_cover.raise_()
        self.overlay_state.emit("", "", False)
        self._set_status("Ожидание страницы ИИ…", THEME["muted"])

        # Штатный микрофон страницы живёт только в настоящем браузере.
        host = NativeHost(self, url=URL, profile=BROWSER_PROFILE,
                          width=W, height=H,
                          configured=(self.cfg.get("browser_path") or None),
                          lang=self.speech_lang,
                          light_theme=self.light_theme,
                          accept_languages=self.accept_languages)
        # ВАЖНО: сначала `browser_host`, потом расчёт сдвига. `_browser_inset`
        # берёт ФИЗИЧЕСКИЙ размер плейсхолдера через `browser_host.user32`;
        # без этого он уходил в резерв (413x651 вместо 453x735) и сдвиг
        # получался на 9 % меньше нужного (-9/-36 вместо -10/-40).
        self.browser_host = host
        # v17: хост поднимает шторку до показа окна браузера (п.1).
        host.cover_widget = self.browser_cover
        host.inset = self._browser_inset()
        host.ready.connect(self._on_browser_ready)
        host.failed.connect(self._on_browser_failed)
        if not host.start(self.browser_placeholder):
            self._start_embedded_fallback("no-browser")

    # ---------------------------------------------------------- v18: браузер
    def _browser_candidates(self):
        try:
            return native_browser.discover_browsers(app_dir(),
                                                    self.cfg.get("browser_path") or None)
        except Exception:
            diag.exception("main.discover")
            return []

    @staticmethod
    def _has_branded_browser(candidates) -> bool:
        """Настоящий Chrome (установленный или закреплённый) — есть?"""
        for cand in candidates or ():
            if str(getattr(cand, "kind", "") or "") in ("chrome", "portable"):
                return True
        return False

    def _offer_browser_install(self, candidates) -> bool:
        """Предложить поставить Chrome for Testing. True — запуск отложен (v18).

        Ничего не делает, если настоящий Chrome уже найден: на отлаженной
        машине поведение не меняется вообще.
        """
        if not AUTO_INSTALL_BROWSER or self._closing:
            return False
        if self._browser_install_offered or self._fetch_worker is not None:
            return False
        if self.cfg.get("browser_install_declined"):
            return False
        if self._has_branded_browser(candidates):
            return False
        self._browser_install_offered = True
        diag.event("browser.offer", candidates=[getattr(c, "kind", "?")
                                                for c in (candidates or ())][:6])
        dlg = BrowserOfferDialog(self)
        dlg.sync_position()
        dlg.exec()
        if not dlg.choice:
            try:
                self.cfg["browser_install_declined"] = True
                save_config(self.cfg)
            except Exception:
                diag.exception("main.decline_browser")
            return False
        self._start_browser_install()
        return True

    def _start_browser_install(self):
        dest = app_dir() / "browser"
        dialog = QProgressDialog("Подготовка…", "Отмена", 0, 100, self)
        dialog.setWindowTitle("Установка браузера")
        dialog.setWindowModality(Qt.WindowModality.WindowModal)
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        dialog.setAutoClose(False)
        dialog.setAutoReset(False)
        dialog.setMinimumDuration(0)
        dialog.setValue(0)
        pg = self.geometry()
        dialog.move(pg.x() - 320 - 8, pg.y())
        self._fetch_dialog = dialog
        worker = BrowserFetchWorker(dest, self)
        self._fetch_worker = worker
        worker.progress.connect(self._on_fetch_progress)
        worker.succeeded.connect(self._on_fetch_done)
        worker.failed.connect(self._on_fetch_failed)
        dialog.canceled.connect(worker.cancel)
        dialog.show()
        worker.start()
        self._set_status("Установка браузера…", THEME["muted"])

    def _on_fetch_progress(self, ratio, text):
        try:
            if self._fetch_dialog is not None:
                self._fetch_dialog.setValue(int(max(0.0, min(1.0, float(ratio))) * 100))
                self._fetch_dialog.setLabelText(str(text))
        except Exception:
            diag.exception("main.fetch_progress")

    def _close_fetch_dialog(self):
        try:
            if self._fetch_dialog is not None:
                self._fetch_dialog.close()
        except Exception:
            diag.exception("main.fetch_close")
        self._fetch_dialog = None
        self._fetch_worker = None

    @pyqtSlot(str)
    @stage
    def _on_fetch_done(self, path):
        diag.event("browser.installed", path=str(path))
        self._close_fetch_dialog()
        self._set_status("Браузер установлен — запуск…", THEME["ok"])
        if getattr(self, "web_browser", None) is not None:
            # Мы уже во встроенном движке: честнее перезапуститься целиком.
            restart_app()
            return
        QTimer.singleShot(300, self._start_chrome)

    @pyqtSlot(str)
    @stage
    def _on_fetch_failed(self, reason):
        text = str(reason)
        cancelled = "отмен" in text.lower()
        diag.event("browser.install_failed", reason=text[:200], cancelled=cancelled)
        self._close_fetch_dialog()
        if cancelled:
            self._set_status("Установка браузера отменена", THEME["muted"])
        else:
            self._set_status("Браузер не установлен — голос вводится диктовкой Windows",
                             THEME["danger"])
            QMessageBox.warning(
                self, "Браузер не установлен",
                "Не удалось скачать Chrome for Testing:\n%s\n\n"
                "Проверьте подключение к интернету, установите Google Chrome "
                "вручную или запустите tools\\fetch_chrome.bat, затем "
                "перезапустите программу." % text[:300])
        # Продолжаем тем, что есть: настоящего Chrome нет — пойдёт резерв.
        if getattr(self, "web_browser", None) is None and not self._closing:
            QTimer.singleShot(300, self._start_chrome)

    # -------------------------------------------------------- v18: «оживление»
    @diag.trace
    def _schedule_revive(self):
        if not REVIVE_AFTER_SHOW or self._closing:
            return
        # «Оживлять» нечего (резервный движок, страница ещё не готова) —
        # шторку тогда не поднимаем вообще, иначе она осталась бы навсегда.
        if not self.native_mode:
            return
        if getattr(getattr(self, "worker", None), "page", None) is None:
            return
        self._revive_settled = 0
        self._revive_last = None
        self._revive_step = 0
        self._settling = True
        # v20: до первого шага «оживления» фиксируем исходное состояние — иначе
        # в логе не будет видно, ОТКУДА браузер возвращался на место.
        btrace.mark("revive.schedule", step_ms=list(REVIVE_STEPS),
                    min_ms=int(REVIVE_MIN_MS), settle_n=int(REVIVE_SETTLE_N),
                    args=self._trace_extra())
        self._trace_landed_ms = None      # «когда встало на цель» — заново
        # v18.3: ровно тот же GUI прогрузки, что на этапе «Ожидание страницы»,
        # и тем же наивысшим приоритетом: индикатор — отдельное окно поверх
        # всех (WindowStaysOnTop + force_topmost), под ним — шторка.
        self._cover_to_top()
        self._show_overlay(REVIVE_TITLE, REVIVE_MESSAGE)
        for delay in REVIVE_STEPS:
            QTimer.singleShot(delay, self._revive_browser)
        # Страховка: GUI прогрузки не остаётся навсегда ни при каких условиях.
        QTimer.singleShot(int(REVIVE_STEPS[-1]) + 2500, self._settle_watchdog)

    def _settle_watchdog(self):
        """Снять шторку принудительно, если стабилизация не завершилась."""
        if not getattr(self, "_settling", False):
            return
        diag.event("browser.settle_watchdog")
        self._finish_settle(False)

    def _browser_sync_args(self):
        """(user32, hwnd, parent, inset) для СИНХРОННОГО переноса окна браузера.

        Всё, что зависит от Qt, берётся здесь, в ГЛАВНОМ потоке; в фоновый
        уходят только HWND и числа. None — переносить нечего.
        """
        if self._closing or not self.native_mode:
            return None
        host = getattr(self, "browser_host", None)
        if host is None or host.user32 is None or not host.hwnd:
            return None
        try:
            host.inset = self._browser_inset()
        except Exception:
            diag.exception("main.revive_inset")
        try:
            parent = int(self.browser_placeholder.winId())
        except Exception:
            diag.exception("main.revive_parent")
            parent = 0
        return host.user32, int(host.hwnd), parent, tuple(host.inset)

    def _sync_browser_now(self):
        """Поставить окно браузера на место СИНХРОННО (в фоновом потоке)."""
        args = self._browser_sync_args()
        if args is None:
            return
        user32, hwnd, parent, inset = args

        def task():
            try:
                win32_embed.sync_now(user32, hwnd, parent, inset)
            except Exception:
                diag.exception("main.sync_now")

        threading.Thread(target=task, daemon=True).start()


    def _revive_browser(self):
        """Держать GUI прогрузки, пока браузер не встанет на место (v18.3).

        Пока GUI прогрузки стоит, **окно браузера не трогаем вообще** — только
        измеряем. Это главное отличие от v18.2: каждый `SetWindowPos` /
        `ShowWindow` / `InvalidateRect` заставляет Chromium пересобрать кадр,
        а Chrome при этом поднимает своё окно — и пользователь видит мигание
        поверх шторки. Поэтому вся работа с окном делается **один раз**, в
        `_finalize_and_reveal()`, когда измерения показали, что всё устоялось.

        Снимаем GUI прогрузки только когда:
        * прошло не меньше `REVIVE_MIN_MS` (возмущение у Chromium начинается
          позже первых кадров);
        * **И** последние `REVIVE_SETTLE_N` измерения подряд одинаковы
          (`innerWidth`, `dpr`, размер окна, сдвиг);
        * либо наступил последний шаг `REVIVE_STEPS` (жёсткий предел).
        """
        if not getattr(self, "_settling", False):
            return          # уже устоялось — больше не дёргаем
        if self._closing or not self.native_mode:
            # Режим сменился или приложение закрывается — GUI снимаем, иначе
            # он остался бы навсегда.
            self._finish_settle(False)
            return
        args = self._browser_sync_args()
        if args is None:
            self._finish_settle(False)
            return
        user32, hwnd, parent, inset = args
        page = getattr(getattr(self, "worker", None), "page", None)
        step = int(getattr(self, "_revive_step", 0))
        self._revive_step = step + 1
        delay = int(REVIVE_STEPS[step]) if step < len(REVIVE_STEPS) else int(REVIVE_STEPS[-1])
        last_step = step >= len(REVIVE_STEPS) - 1
        # Шторка и индикатор — поверх (это главный поток Qt).
        self._cover_to_top()
        if page is None:
            if last_step:
                self._finish_settle(False)
            return

        def task():
            settled = 0
            try:
                # ТОЛЬКО измерение: окно не двигаем, не перерисовываем,
                # раскладку не трогаем — иначе Chrome лезет поверх шторки.
                signature = self._layout_signature(page, user32, hwnd, inset)
                if signature == self._revive_last:
                    settled = int(getattr(self, "_revive_settled", 0)) + 1
                else:
                    settled = 1
                self._revive_settled = settled
                self._revive_last = signature
                # v20: вместе с подписью — измерение ОКНА: где оно на самом
                # деле относительно цели и почему. Без этого «не встал на
                # позицию» остаётся словами.
                probe = btrace.window_probe(hwnd, parent, inset)
                diag.event("browser.revive", step=int(step), ms=int(delay),
                           settled=int(settled), inset=list(inset),
                           signature=list(signature or ()),
                           verdict=probe.get("verdict"), dx=probe.get("dx"),
                           dy=probe.get("dy"), dw=probe.get("dw"), dh=probe.get("dh"),
                           client=probe.get("client"), visible=probe.get("visible"),
                           explain=probe.get("explain"))
                if probe.get("verdict") not in (None, "on_target"):
                    btrace.mark("revive.off_target", step=int(step), ms=int(delay),
                                dx=probe.get("dx"), dy=probe.get("dy"),
                                reasons=probe.get("reasons"), client=probe.get("client"),
                                target=probe.get("target"), rect=probe.get("rect"))
                elif getattr(self, "_trace_landed_ms", None) is None:
                    # Первый замер, когда окно УЖЕ на цели: это и есть ответ на
                    # жалобу «съехало и вернулось через 2–3 секунды».
                    self._trace_landed_ms = int(delay)
                    btrace.mark("revive.on_target", step=int(step), ms=int(delay),
                                rect=probe.get("rect"), target=probe.get("target"),
                                client=probe.get("client"), scale=probe.get("scale"))
            except Exception:
                diag.exception("main.revive_measure")
            enough = (delay >= int(REVIVE_MIN_MS)
                      and settled >= int(REVIVE_SETTLE_N))
            if last_step or enough:
                self._finalize_and_reveal()

        threading.Thread(target=task, daemon=True).start()

    @diag.trace
    def _finalize_and_reveal(self):
        """ОДИН раз поставить окно и раскладку, пока GUI прогрузки ещё стоит.

        Вызывается, когда измерения показали, что браузер устоялся (или на
        жёстком пределе). Здесь и только здесь трогаем окно браузера, чтобы не
        провоцировать Chromium на перерисовку на глазах у пользователя.
        """
        args = self._browser_sync_args()
        if args is None:
            self._finish_settle(False)
            return
        user32, hwnd, parent, inset = args
        page = getattr(getattr(self, "worker", None), "page", None)

        def task():
            try:
                try:
                    win32_embed.sync_now(user32, hwnd, parent, inset)
                    win32_embed.show_window(user32, hwnd)
                    win32_embed.invalidate(user32, hwnd)
                    # v20: сразу после переноса — измерение «встало ли на цель».
                    # Именно этот замер и отвечает на вопрос пользователя.
                    probe = btrace.record_win_call("revive.reveal", True, hwnd=hwnd,
                                                   parent=parent, inset=inset,
                                                   extra={"stage": "finalize"})
                    btrace.mark("revive.reveal", verdict=(probe or {}).get("verdict"),
                                dx=(probe or {}).get("dx"), dy=(probe or {}).get("dy"),
                                dw=(probe or {}).get("dw"), dh=(probe or {}).get("dh"),
                                client=(probe or {}).get("client"),
                                reasons=(probe or {}).get("reasons"))
                except Exception:
                    diag.exception("main.revive_win32")
                if page is not None:
                    try:
                        page.send("Page.bringToFront", {}, timeout=3)
                    except Exception:
                        pass
                    try:
                        page.eval(JS_REVIVE, timeout=3)
                    except Exception:
                        pass
                    # Раскладка — ИЗМЕРЕНИЕМ и, если нужно, одним вызовом CDP.
                    ok = self._zoom_guard_once(page, reason="revive-final",
                                               pin_first=True)
                    if ok:
                        self._nudge_metrics(page)
                # Даём кадру лечь: Chromium перерисовывает не мгновенно.
                time.sleep(max(0.05, float(REVIVE_FINAL_MS) / 1000.0))
                # v19: снимаем GUI прогрузки по ЗАМЕРУ страницы, а не только
                # по таймеру: «объекты внутри браузера ещё не на своих местах»
                # — это ровно тот случай, когда страница не дорисована.
                ready = self._wait_page_complete(page, REVIVE_REVEAL_GATE_MS)
                diag.event("browser.reveal_gate", ready=ready)
                # v20: ПОКА ШТОРКА СТОИТ — держим раскладку ЗАМЕРОМ.
                # Chrome переприменяет зум профиля уже ПОСЛЕ показа окна
                # (подтверждено логом 20261004-162559-12408-c5e41c: 658/0.667 →
                # 987/0.445 и восстановление только к тику 5-секундного
                # сторожа). Одна проверка такую поломку не видит по
                # определению — её в этот момент ещё нет. Поэтому раскладка
                # проверяется по кругу, а шторка снимается только после двух
                # совпавших замеров подряд.
                if page is not None:
                    hold = self._layout_watch(page, "revive-hold", budget_ms=1200)
                    # v20 (ТЗ § 4): вердикт «раскладка в цели» ставится по
                    # ЗАМЕРУ (сколько раз чинили и чем кончилось), а не по
                    # факту вызова. В отчёте это отдельная строка проверки.
                    try:
                        ok_layout = bool((hold or {}).get("ok"))
                        btrace.selfcheck(
                            "layout", ok_layout,
                            detail="замер под шторкой: %sx%s dsf=%s, ремонтов %s, %s мс"
                                   % ((hold or {}).get("innerWidth"),
                                      "?", (hold or {}).get("dpr"),
                                      (hold or {}).get("fixed"),
                                      (hold or {}).get("ms")),
                            advice=("" if ok_layout else
                                    "переустановить переопределение в форме окна "
                                    "(`refresh_emulation`, логические px при dsf=1.0)"))
                    except Exception:
                        diag.exception("main.selfcheck_layout")
            except Exception:
                diag.exception("main.revive_final")
            self._finish_settle(True)
            # v19: после разворота страница проверяется, а не предполагается.
            self._probe_surface("restore")
            # v20: и ещё раз замером, уже после шторки: если Chrome переставит
            # зум позже, раскладка будет возвращена за ~0.1 с, а не к
            # следующему тику 5-секундного сторожа.
            if page is not None:
                self._layout_watchdog(page, "post-reveal")

        threading.Thread(target=task, daemon=True).start()

    def _layout_repair(self, page, reason):
        """Ремонт раскладки: объявить «форму окна» и проверить ЗАМЕРОМ.

        Первым шагом — `native_browser.refresh_emulation`: логические пиксели
        окна при `dsf=1.0`. Это ровно та форма, которой закончилось лечение в
        живом логе (`browser.zoom source=emulation-adaptive`, 23.303): в ней
        зум профиля не с чем складывать. Если замер говорит, что и она не
        вернула раскладку, вызывается общий сторож зума (его лестница +
        подбор по замеру). Возвращает словарь замера; исключения не выходят.
        """
        try:
            logical_w, logical_h, physical_w, physical_h = self._zoom_args()
            healed = native_browser.refresh_emulation(
                page, logical_w, logical_h, physical_w, physical_h, PAGE_ZOOM)
            diag.event("browser.layout_repair", reason=str(reason),
                       innerWidth=healed.get("innerWidth"), dpr=healed.get("dpr"),
                       restored=bool(healed.get("ok")))
            if healed.get("ok"):
                return healed
        except Exception:
            diag.exception("main.layout_repair")
            healed = {}
        try:
            self._zoom_guard_once(page, reason=reason)
        except Exception:
            diag.exception("main.layout_guard")
        return healed

    def _layout_watch(self, page, reason, budget_ms=1200, step_ms=100, need=2):
        """Держать раскладку в цели замером, пока возмущение не кончилось (v20).

        Поломка доказана замером (сессия 20261004-162559-12408-c5e41c):
        переопределение CDP с `deviceScaleFactor=0.6672` СКЛАДЫВАЕТСЯ с зумом
        профиля (0.667 x 0.667 = 0.445, innerWidth 658 → 987); первым его
        включает «толчок» метрик. Когда именно это произойдёт, заранее
        неизвестно, поэтому раскладка проверяется по кругу, а «чинит» её
        `_layout_repair` — по замеру, без догадок о том, какой механизм зума
        (профиль или эмуляция CDP) сейчас активен.

        Возвращает словарь замера; исключения не выходят наружу.
        """
        if page is None or self._closing or not self.native_mode:
            # В резервном движке (QtWebEngine) эмуляции раскладки нет — там
            # своя геометрия, и трогать её этим механизмом нельзя.
            return {"ok": False, "skipped": True}
        try:
            logical_w, logical_h, physical_w, physical_h = self._zoom_args()
        except Exception:
            diag.exception("main.layout_args")
            return {"ok": False, "skipped": True}
        try:
            return native_browser.settle_layout(
                page, logical_w, logical_h, physical_w, physical_h, zoom=PAGE_ZOOM,
                budget_ms=budget_ms, step_ms=step_ms, need=need,
                repair=lambda: self._layout_repair(page, reason),
                on_event=lambda data: diag.event("browser.layout_watch",
                                                 reason=str(reason), **data))
        except Exception:
            diag.exception("main.layout_watch")
            return {"ok": False, "error": True}

    def _final_selfchecks(self):
        """Вердикты, которые известны только в КОНЦЕ сессии (v20, ТЗ § 4).

        «Окно встало на место» и «файлы прикрепились» — утверждения о замерах
        и вердиктах, которые целиком видны лишь после остановки шкал. Поэтому
        последние проверки ставятся здесь, ДО `btrace.finish()`: так они
        попадают и в машинную сводку, и в `UNDERSTANDING.md`, и в разбор —
        человеку не нужно читать журнал построчно.

        Ничего не предполагает: любые данные могут отсутствовать.
        """
        try:
            summary = btrace.build_summary() or {}
        except Exception:
            diag.exception("main.selfcheck_summary")
            return
        worst = None
        for tag, data in (summary.get("watchers") or {}).items():
            deviations = int(data.get("deviations") or 0)
            if deviations and (worst is None or deviations > worst[1]):
                worst = (tag, deviations, data.get("settle_ms"),
                         data.get("max_offset_px"), data.get("final_verdict"))
        if worst:
            btrace.selfcheck(
                "window_position", False,
                detail="шкала «%s»: расхождений %d, макс. уход %s px, устой %s мс"
                       % (worst[0], worst[1], worst[3], worst[2]),
                advice="смотреть `win32.call` и шкалу в `browser-trace.txt`: "
                       "искать причину (dpi_scale/parent_moved), а не снимать сдвиг")
        else:
            btrace.selfcheck("window_position", True,
                             detail="во всех шкалах окно стояло на цели")
        verdicts = {}
        for key, value in (summary.get("counters") or {}).items():
            name = str(key)
            if name.startswith("export.verdict."):
                verdicts[name.split(".", 2)[-1]] = int(value or 0)
        if verdicts:
            good = ("confirmed_attached", "attached_unnamed")
            bad = {k: v for k, v in verdicts.items() if k not in good}
            detail = ", ".join("%s×%s" % kv for kv in sorted(verdicts.items()))
            btrace.selfcheck(
                "export", not bad, detail=detail,
                advice=("" if not bad else
                        "смотреть раздел «Экспорт файлов» в разборе: какой "
                        "вердикт и что было в `input[type=file]`/чипах чата"))
        try:
            blockers = [name for name, data in (summary.get("selfcheck") or {}).items()
                        if not data.get("ok") and name != "native_browser"]
            diag.event("selfcheck.summary", checks=len(summary.get("selfcheck") or {}),
                       failed=blockers)
        except Exception:
            diag.exception("main.selfcheck_summary_event")

    def _layout_watchdog(self, page, reason="post-reveal", budget_ms=2000, step_ms=120):
        """Тот же замер, но фоном и уже после снятия шторки (v20).

        Нужен на случай, когда Chrome ставит свой зум с задержкой больше
        удержания под шторкой: тогда раскладка вернётся за ~0.1 с вместо
        ожидания следующего тика сторожа (5 с).
        """
        if page is None or self._closing or not self.native_mode:
            return None
        try:
            threading.Thread(target=self._layout_watch,
                             args=(page, reason, budget_ms, step_ms),
                             name="LayoutWatchdog", daemon=True).start()
        except Exception:
            diag.exception("main.layout_watchdog")
        return None

    def _probe_surface(self, when="timer"):
        """Проверить, что открыто в браузере, и записать это в лог (v19).

        Отдельным потоком: CDP-запрос не должен задерживать поток GUI ни при
        развороте окна, ни при показе страницы.
        """

        def task():
            try:
                page = self._current_page()
                if page is None:
                    return
                surface = probe_page_surface(page, timeout=3)
                verdict = str(surface.get("verdict") or "unknown")
                diag.state("page.verdict", verdict)
                if verdict != getattr(self, "_surface_verdict", None):
                    previous = str(getattr(self, "_surface_verdict", "") or "")
                    self._surface_verdict = verdict
                    diag.event("page.surface_changed", verdict=verdict,
                               previous=previous, when=str(when))
                    # v20: поверхность сменилась — снимаем её структуру и «код».
                    # Это ровно тот случай, когда страница отдала НЕ тот чат, и
                    # по снимку видно, чем она на самом деле оказалась.
                    shots = int(getattr(self, "_trace_surface_shots", 0) or 0)
                    if shots < 4:
                        self._trace_surface_shots = shots + 1
                        btrace.capture_page(page, reason="surface-%s" % verdict, full=True)
                        btrace.mark("page.surface_captured", verdict=verdict,
                                    previous=previous, shot=shots + 1)
                diag.event("page.surface_after_%s" % re.sub(r"\W+", "", str(when)),
                           **{k: surface.get(k) for k in
                              ("verdict", "ready", "composer", "files", "chips",
                               "dark", "bg", "account", "pending", "host")})
            except Exception:
                diag.exception("main.probe_surface")

        threading.Thread(target=task, name="SurfaceProbe",
                         daemon=True).start()

    def _wait_page_complete(self, page, limit_ms):
        """Дождаться `readyState == "complete"`, но не дольше `limit_ms` (v19).

        Возвращает True (дождались), False (предел) или None (страницы/соединения
        нет). GUI прогрузки снимается в любом случае: залипший индикатор хуже,
        чем недодержанный.
        """
        if page is None:
            return None
        deadline = time.monotonic() + max(0.0, float(limit_ms) / 1000.0)
        while True:
            try:
                if probe_page_surface(page, timeout=2).get("ready") == "complete":
                    return True
            except Exception:
                diag.exception("main.reveal_gate")
                return None
            if time.monotonic() >= deadline:
                return False
            time.sleep(0.1)

    def _layout_signature(self, page, user32, hwnd, inset):
        """Подпись текущего состояния: (innerWidth, dpr, размер окна, сдвиг).

        Пока Chromium «устаивается», подпись меняется — по ней и определяется
        момент, когда браузер действительно встал на место.
        """
        try:
            metrics = native_browser.page_metrics(page)
            inner = int((metrics or {}).get("innerWidth") or 0)
            dpr = round(float((metrics or {}).get("dpr") or 0.0), 3)
        except Exception:
            diag.exception("main.revive_metrics")
            inner, dpr = 0, 0.0
        try:
            client = tuple(int(v) for v in win32_embed.client_size(user32, hwnd))
        except Exception:
            diag.exception("main.revive_client")
            client = (0, 0)
        return (inner, dpr, client[0], client[1], tuple(int(v) for v in inset))

    def _finish_settle(self, stable):
        """Снять шторку (сигнал уходит в главный поток Qt)."""
        if not getattr(self, "_settling", False):
            return
        try:
            self.revive_settled.emit(bool(stable))
        except Exception:
            diag.exception("main.revive_signal")
            self._settling = False
            try:
                self._hide_overlay()
            except Exception:
                diag.exception("main.revive_reveal_fallback")

    def _nudge_metrics(self, page):
        """На 1 px изменить ЛОГИЧЕСКУЮ ширину и вернуть: Chromium рисует новый кадр.

        Толчок — единственная причина, по которой приложению вообще нужно
        переопределение: заставить Chromium отрисовать новый кадр. ФОРМА
        объявления здесь принципиальна и взята из живого лога (сессия
        20261004-162559-12408-c5e41c): dsf-масштаб (`658 css @ dsf 0.6672`)
        СКЛАДЫВАЕТСЯ с зумом профиля — 0.667 x 0.667 = 0.445, innerWidth
        658 → 987. Именно так «съезжали объекты». Поэтому объявляем логические
        пиксели окна с `dsf=1.0`, а конец толчка — ИЗМЕРЯЕМОЕ восстановление.

        Делается только когда раскладка и так верна по замеру — иначе это была
        бы не «встряска кадра», а изменение раскладки.
        """
        try:
            metrics = native_browser.page_metrics(page)
        except Exception:
            diag.exception("main.nudge_metrics")
            return
        inner = int((metrics or {}).get("innerWidth") or 0)
        logical_w, logical_h, physical_w, physical_h = self._zoom_args()
        css_w, css_h, _dsf = native_browser.target_css(
            logical_w, logical_h, physical_w, physical_h, PAGE_ZOOM)
        if not inner or abs(inner - css_w) > 2:
            return
        try:
            # «Форма окна»: логическая ширина, dsf=1.0 — складывать нечего.
            native_browser.apply_viewport_raw(page, int(round(logical_w)) + 1,
                                              int(round(logical_h)), 1.0)
            time.sleep(0.06)
            healed = native_browser.refresh_emulation(
                page, logical_w, logical_h, physical_w, physical_h, PAGE_ZOOM)
            diag.event("browser.metrics_nudged", css=(int(css_w), int(css_h)),
                       window=(int(round(logical_w)), int(round(logical_h))),
                       innerWidth=healed.get("innerWidth"),
                       dpr=healed.get("dpr"), restored=bool(healed.get("ok")))
        except Exception:
            diag.exception("main.metrics_nudge")

    @pyqtSlot(int)
    @stage
    @diag.trace
    def _on_browser_ready(self, port):
        if self._closing:
            return
        self.native_mode = True
        self.cdp_port = int(port)
        self.chrome_hwnd = int(self.browser_host.hwnd or 0)
        diag.event("browser.ready", port=self.cdp_port, hwnd=self.chrome_hwnd)
        # v20 (ТЗ § 3): ПАСПОРТ МАШИНЫ. Пишется один раз на запуск и объясняет
        # дефекты «у другого пользователя, но не у меня»: масштаб экрана,
        # число мониторов, RDP, тёмная тема, права, сборка Windows. Сравнение
        # двух машин идёт по этим числам, а не по догадкам.
        try:
            facts = btrace.env_fingerprint(
                reason="browser_ready",
                extra={"engine": "external_chrome", "port": self.cdp_port,
                       "target": [X, Y, W, H],
                       "insets": [self.side_inset, self.top_inset,
                                  self.side_inset, self.bottom_inset],
                       "zoom": PAGE_ZOOM},
                screens=mp.qt_screens())
            session = (facts or {}).get("session") or {}
            admin = session.get("admin")
            btrace.selfcheck(
                "engine", True,
                detail="внешний Chrome, порт %d" % self.cdp_port)
            # Проверка «браузер настоящий» ставится ВСЕГДА (ок/не ок): иначе по
            # логу нельзя отличить «всё хорошо» от «сбор просто не пишет».
            btrace.selfcheck("native_browser", True,
                             detail="страница в настоящем Chrome")
            btrace.selfcheck(
                "admin_free", admin is not True,
                detail="права администратора: %s" % ("есть" if admin else "нет"),
                advice=("путь обычного пользователя не проверен: запуск был "
                        "с правами" if admin else ""))
        except Exception:
            diag.exception("main.env_fingerprint")
        # v19: чем именно показывается страница. Это первое, что нужно знать по
        # логу: настоящий Chrome (штатный микрофон страницы) или встроенный
        # движок. Раньше в логе этого не было вообще.
        try:
            exe = getattr(getattr(self.browser_host, "native", None), "exe", None)
            kind = getattr(getattr(self.browser_host, "native", None), "kind", None)
        except Exception:
            exe, kind = None, None
        diag.event("browser.mode", engine="external_chrome" if self.native_mode
                   else "qtwebengine", exe=str(exe or ""), kind=str(kind or ""),
                   port=self.cdp_port, hwnd=self.chrome_hwnd,
                   zoom=float(PAGE_ZOOM), inset=list(self._browser_inset()),
                   dx=int(BROWSER_DX), dy=int(BROWSER_DY),
                   light_theme=bool(self.light_theme), lang=str(self.speech_lang),
                   placeholder=[self.browser_placeholder.width(),
                                self.browser_placeholder.height()],
                   dpr=float(self.devicePixelRatioF()),
                   screens=len(QApplication.screens()), url=str(URL))
        diag.state("browser.mode", "external_chrome" if self.native_mode
                   else "qtwebengine")
        self._set_status("Подключение к странице ИИ…", THEME["muted"])
        # Окно браузера только что стало дочерним: шторка снова сверху, поэтому
        # сырой браузер не виден ни на одной машине.
        self._cover_to_top()
        # v17: Chrome поднимает окна и меняет z-порядок не сразу — первые
        # секунды повторяем подъём шторки с той же частотой, что и скрытие
        # кнопки в панели задач.
        for delay in (300, 800, 1500, 2500, 4000):
            QTimer.singleShot(delay, self._hold_cover_if_needed)
        self._start_web_automation()
        # Окно дочернего процесса подстраивается под плейсхолдер не сразу.
        QTimer.singleShot(500, self._sync_chrome_geometry)
        QTimer.singleShot(1500, self._sync_chrome_geometry)
        # Реальный физический размер окна браузера — от него считается зум.
        self.browser_physical = self._placeholder_physical_size()
        self.browser_logical = self._placeholder_logical_size()
        # Точка отсчёта для отслеживания переезда на другой масштаб (v16).
        try:
            self._last_dpr = float(self.devicePixelRatioF())
        except Exception:
            self._last_dpr = 0.0
        # v16: поздние окна браузера (рендерер, утилиты) поднимаются уже ПОСЛЕ
        # `ready` — убираем их с запасом, чтобы ни на экране, ни в Alt+Tab не
        # появился «сырой» браузер с неудалёнными элементами.
        QTimer.singleShot(0, self._hide_strays_once)
        QTimer.singleShot(1500, self._hide_strays_once)
        QTimer.singleShot(3000, self._hide_strays_once)
        # Масштаб держится намертво: если страница перезагрузилась или сменила
        # таргет, метрики возвращаются к «широкой» раскладке — следим.
        if getattr(self, "zoom_timer", None) is None:
            self.zoom_timer = QTimer(self)
            self.zoom_timer.timeout.connect(self._ensure_zoom)
        self.zoom_timer.start(5000)
        # Сдвиг пересчитывается по настоящему плейсхолдеру: при `_start_chrome`
        # окно Qt ещё могло быть без корректного HWND.
        try:
            host = getattr(self, "browser_host", None)
            if host is not None:
                host.inset = self._browser_inset()
                host.sync()
        except Exception:
            diag.exception("main.reinset")
        # v15: Chrome сам возвращает кнопку в панель задач — проверяем раз в 5 с.
        self.taskbar_timer.start(5000)
        # Сдвиги страницы из блока настроек — один раз, когда страница уже есть.
        if page_tuning_needed():
            QTimer.singleShot(1500, self._apply_page_tuning)

    @pyqtSlot(str)
    @stage
    def _on_browser_failed(self, reason):
        if self._closing:
            return
        diag.event("browser.host_failed", reason=str(reason))
        self._start_embedded_fallback(str(reason))

    @stage
    def _start_embedded_fallback(self, reason):
        """Резерв: встроенный QtWebEngine.

        Используется только если настоящий браузер не найден или не запустился.
        Штатного микрофона страницы здесь нет (движок без ключа Google), поэтому
        запись голоса идёт через Windows-диктовку — пользователь видит об этом
        честный статус.
        """
        if self._closing or getattr(self, "web_browser", None) is not None:
            return
        diag.event("browser.fallback_embedded", reason=str(reason))
        # v18: встроенный движок — значит запись пойдёт диктовкой Windows,
        # которой у большинства пользователей Win11 просто нет. Предлагаем
        # настоящий Chrome: это и есть лечение, а не косметика.
        if self._offer_browser_install(self._browser_candidates()):
            return
        self.native_mode = False
        # v20 (ТЗ § 3): и в резервном режиме паспорт машины и вердикт движка
        # обязательны — иначе чужая сессия выглядит одинаково и «всё ок», а
        # на деле работает QtWebEngine (другая диктовка, другая раскладка).
        try:
            btrace.env_fingerprint(
                reason="fallback_embedded",
                extra={"engine": "qtwebengine", "target": [X, Y, W, H],
                       "insets": [self.side_inset, self.top_inset,
                                  self.side_inset, self.bottom_inset],
                       "zoom": PAGE_ZOOM},
                screens=mp.qt_screens())
            btrace.selfcheck("engine", True, detail="резервный движок QtWebEngine")
            btrace.selfcheck(
                "native_browser", False,
                detail="страница показывается встроенным движком, не Chrome",
                advice="проверить `browser.no_candidate`/`browser.offer`: "
                       "предложить пользователю установку Chrome")
        except Exception:
            diag.exception("main.env_fingerprint_fallback")
        self.cdp_port = DEBUG_PORT
        self.web_browser = BrowserPane(PROFILE, self.browser_placeholder)
        self.web_browser.setGeometry(self.side_inset, self.top_inset,
            W - 2 * self.side_inset, H - self.top_inset - self.bottom_inset)
        self.web_browser.show()
        self.web_browser.view.loadFinished.connect(self._web_load_finished)
        self._hook_speech_feedback()
        self.browser_cover.show()
        self.browser_cover.raise_()
        if str(reason) == "no-browser":
            self._set_status("Браузер со штатным микрофоном не найден — "
                             "диктовка Windows (на Win11 её обычно нет)",
                             THEME["danger"])
        else:
            self._set_status("Браузер не запустился — диктовка Windows "
                             "(на Win11 её обычно нет)", THEME["danger"])
        self._start_web_automation()
        self.web_browser.open_home()

    def _poll_browser_focus(self):
        """Внепроцессное окно имеет свою очередь ввода: отдаём фокус по клику."""
        host = getattr(self, "browser_host", None)
        if host is None:
            return
        # v51: хост остановлен — его окно и процессы уже убиты, Win32-вызов по
        # мёртвому hwnd не нужен (п.2, падение на «Сформировать»).
        if getattr(host, "stopped", False):
            return
        # v17: сторож работает с САМОГО СТАРТА браузера, а не только после
        # `ready` (раньше он требовал `native_mode`, тот включался уже в
        # `_on_browser_ready` — то есть весь этап «Ожидание страницы» шторку
        # никто не держал, и неудалённые элементы промелькивали). Теперь
        # шторка держится, пока чат не готов ИЛИ пока не выбран промт.
        self._hold_cover_if_needed()
        if not self.native_mode:
            return
        try:
            host.poll_focus(int(self.winId()), self.isActiveWindow())
        except Exception:
            diag.exception("main.focus_timer")

    # Диагностика диктовки: понятные русские тексты вместо кодов DOMException.
    # v18: у каждой проблемы с распознаванием Windows есть ОДНА настоящая
    # причина — нет браузера со штатным микрофоном. Поэтому каждая подсказка
    # говорит не только про Windows, но и про то, что лечит причину.
    MIC_ERROR_MESSAGES = {
        "not-allowed": "Нет доступа к микрофону — разрешите его в Параметрах Windows",
        "audio-capture": "Микрофон не найден — проверьте устройство записи",
        "language-not-supported": "Нет русского распознавателя речи — установите речевой пакет Windows",
        "no-speech": "Речь не распознана — повторите (F3)",
        "service-not-allowed": "Диктовка Windows недоступна — установите Google Chrome со штатным микрофоном",
        "network": "Сбой диктовки — повторите (F3)",
        "aborted": "Запись прервана",
    }

    # Куда ведёт «вылечить причину»: штатный микрофон страницы.
    BROWSER_HINT = (" Голосовой ввода штатно работает в Chrome: перезапустите "
                    "программу и согласитесь на установку браузера.")

    def _mic_reset_state(self):
        """Снять «активную запись»: следующее нажатие снова НАЧИНАЕТ запись."""
        self.mic_active = False
        self._mic_got_text = False
        try:
            self.chip_mic.set_active(False)
        except Exception:
            pass

    def _mic_cancel(self, reason):
        """Повторное нажатие без распознанного текста: НИКОГДА не отправляем
        пустой запрос в чат ИИ (реальный дефект v6)."""
        self._mic_reset_state()
        self._page_eval_async(JS_MIC_STOP, timeout=3)
        self._set_status(reason, THEME["muted"])
        diag.event("mic.cancelled_no_text")

    def _on_speech_error(self, code):
        detail = ""
        try:
            engine = self.web_browser.speech_bridge.engine
            detail = str((getattr(engine, "last_error", None) or {}).get("msg") or "")[:200]
        except Exception:
            detail = ""
        text = self.MIC_ERROR_MESSAGES.get(code) or ("Ошибка диктовки: %s" % code)
        low = detail.lower()
        if code == "service-not-allowed" and ("recognizer" in low or "speech" in low):
            # v18: самое частое сообщение у пользователей Windows 11. Его
            # причина — не «сломанная Windows», а отсутствие браузера со
            # штатным микрофоном страницы. Говорим об этом прямо.
            text = ("В Windows нет распознавателя речи — на Windows 11 оно не "
                    "ставится по умолчанию." + self.BROWSER_HINT)
        elif code == "language-not-supported" and "recognizer" in low:
            text = ("Нет распознавателя для этого языка — установите русский "
                    "речевой пакет (Параметры → Время и язык → Речь)."
                    + self.BROWSER_HINT)
        # Любая «мёртвая» диктовка снимает активную запись: иначе следующее
        # нажатие ушло бы в ветку «стоп + отправка» и отправило пустой запрос.
        if code in ("service-not-allowed", "language-not-supported",
                    "audio-capture", "not-allowed"):
            self._mic_reset_state()
        elif self.mic_active and not self._mic_got_text:
            self._mic_reset_state()
        self._set_status(text, THEME["danger"])
        diag.event("mic.speech_error", code=code, detail=detail[:200])
        # v18: лечим ПРИЧИНУ в момент отказа, а не только при запуске. Если
        # настоящего Chrome нет — сразу предлагаем его поставить (после
        # установки приложение перезапустится и микрофон станет штатным).
        if code in ("service-not-allowed", "language-not-supported"):
            try:
                if self._offer_browser_install(self._browser_candidates()):
                    text = ("Ставлю браузер со штатным микрофоном — после "
                            "установки программа перезапустится")
                    self._set_status(text, THEME["muted"])
            except Exception:
                diag.exception("main.speech_error_offer")

    def _hook_speech_feedback(self):
        """Видимая обратная связь диктовки: слушаю / распознано / ошибка.

        Сигналы приходят из потока чтения PowerShell-хоста; Qt доставляет их в
        главный поток автоматически (queued connection). v7: любое завершение
        хоста без текста снимает «активную запись», чтобы повторное нажатие
        микрофона снова начало запись, а не отправило пустой запрос.
        """
        if getattr(self, "_speech_hooked", False):
            return
        bridge = getattr(self.web_browser, "speech_bridge", None)
        if bridge is None:
            return
        self._speech_hooked = True

        def on_started():
            notice = None
            try:
                notice = self.web_browser.speech_bridge.engine.last_notice
            except Exception:
                notice = None
            if notice and notice[0] == "fallback":
                # Распознаватель запрошенного языка не установлен — хост
                # взял тот, что есть. Честно говорим об этом пользователю
                # (v18: и сразу объясняем, как получить русский).
                self._set_status(
                    "Слушаю… (распознаватель %s, а не %s — установите русский "
                    "речевой пакет или браузер со штатным микрофоном)"
                    % (str(notice[1]), self.speech_lang), THEME["muted"])
                diag.event("mic.lang_fallback_shown", lang=str(notice[1]),
                           wanted=str(self.speech_lang))
            else:
                self._set_status("Слушаю… говорите", THEME["ok"])

        def on_hypothesis(text):
            if str(text or "").strip():
                self._mic_got_text = True

        def on_result(text, _confidence):
            if str(text or "").strip():
                self._mic_got_text = True
            self._set_status("Распознано: %s" % (str(text or "")[:48] or "—"), THEME["ok"])

        def on_error(code):
            self._on_speech_error(str(code))

        def on_ended():
            if self.mic_active and not self._mic_got_text:
                self._mic_reset_state()
                self._set_status("Речь не распознана — нажмите «Микрофон» ещё раз",
                                 THEME["muted"])
                diag.event("mic.no_text_on_end")

        try:
            bridge.started.connect(on_started)
            bridge.hypothesis.connect(on_hypothesis)
            bridge.result.connect(on_result)
            bridge.error.connect(on_error)
            bridge.ended.connect(on_ended)
        except Exception:
            diag.exception("main.speech_feedback")

    def _start_web_automation(self):
        previous = self.worker
        if previous and previous.isRunning():
            return
        if previous:
            previous.close_connections()
        self._chat_ready = False
        # v44: новый диалог — состояние ожидания ответа начинается с чистого
        # листа. Опрос предыдущего ответа мог оставить признак «идёт запрос»
        # (`_doc_answer_busy`) или старое окно ожидания — после этого новый
        # ответ молча пропускался, и окно писало «Ответ не пришёл».
        self._doc_answer_busy = False
        self._doc_watch_hinted = False
        self._doc_settle_text = None
        self._doc_settle_count = 0
        self.worker = ChromeWorker(self, port=getattr(self, "cdp_port", DEBUG_PORT),
                                  native=self.native_mode, size=self._zoom_size(),
                                  lang=self.speech_lang, light=self.light_theme)
        self.worker.hwnd_ready.connect(self._on_hwnd)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    def _web_load_finished(self, ok):
        if self._closing:
            return
        if not ok:
            # Падение рендер-процесса (например, из-за запроса микрофона на
            # движке без WebRTC) не оставляет пользователя с пустой страницей:
            # шторка + статус + автоматическая перезагрузка (до 3 раз).
            crashed = bool(getattr(self.web_browser, "crashed", False))
            if crashed and self._crash_recoveries < 3:
                self._crash_recoveries += 1
                try:
                    self.web_browser.crashed = False
                except Exception:
                    diag.exception("main.crash_flag")
                self._chat_ready = False
                self.mic_active = False
                self.chip_mic.set_active(False)
                self._set_status("Восстановление страницы…", THEME["muted"])
                self._show_overlay("Восстановление", "Страница ИИ перезагружается…")
                QTimer.singleShot(700, self._recover_web)
                diag.event("webengine.crash_recovery", attempt=self._crash_recoveries)
                return
            self._set_status("Страница не загружена — Ctrl+R", THEME["danger"])
            self._hide_overlay()
        else:
            # Страница загружена: зачистка уже внедрена при создании документа,
            # даём ей гарантированный проход и лишь затем открываем шторку.
            QTimer.singleShot(250, self._reveal_page)
            if self.worker and not self.worker.isRunning():
                self._set_status("Проверка готовности чата…", THEME["muted"])
                self._start_web_automation()

    def _reveal_page(self):
        if self._closing:
            return
        self._hide_overlay()

    def _recover_web(self):
        if self._closing:
            return
        # Зависшие потоки работают с мёртвым CDP-соединением — останавливаем,
        # чтобы не спамить ошибками; после готовности промт загрузится заново.
        try:
            if self.upload_thread and self.upload_thread.isRunning():
                self.upload_thread.stop()
                self.upload_thread.wait(500)
        except Exception:
            diag.exception("main.recover_upload_stop")
        if self.native_mode and getattr(self, "browser_host", None) is not None:
            # Настоящий браузер: перезапускаем хост целиком (свежий профиль /
            # без GPU / следующий браузер — по счётчику попыток).
            self.browser_host.stop()
            self.worker = None
            self._start_chrome()
            return
        self._start_web_automation()
        self.web_browser.open_home()

    @stage
    @diag.trace
    def _on_hwnd(self, hwnd):
        try:
            if not hwnd:
                self._on_failed()
                return

            self.mic_active = False
            self.chip_mic.set_active(False)
            self._chat_ready = True
            # v19: что именно открылось — чат, режим ИИ в поиске или вход.
            surface = getattr(self.worker, "surface", None) or {}
            self._surface_verdict = str(surface.get("verdict") or "unknown")
            self._surface_blocked = str(surface.get("blocked") or "")
            if self._surface_blocked in ("login", "consent"):
                self._set_status("Войдите в аккаунт Google в окне чата",
                                 THEME["danger"])
            elif self._surface_blocked:
                self._set_status("Страница не распознана — обновите её (Ctrl+R)",
                                 THEME["danger"])

            self.browser_placeholder.update()

            if self.native_mode:
                # Окончательная подгонка окна браузера под плейсхолдер и
                # раскрытие страницы (loadFinished здесь не приходит — браузер
                # внешний, поэтому шторку снимаем сами).
                QTimer.singleShot(200, self._sync_chrome_geometry)
                if not self._check_speech_surface():
                    return
                QTimer.singleShot(250, self._reveal_page)
                QTimer.singleShot(600, self._sync_chrome_geometry)
                # v49: форма «Постановление Обращение №» возвращается на экран
                # после смены браузера — она не должна закрываться по
                # «Проверке ИИ» и «Сформировать».
                QTimer.singleShot(650, self._restore_gov_dialog_visibility)

            force_topmost(int(self.winId()))
            self._set_status("Готов к работе", THEME["ok"])

            # v20: чат готов — фиксируем это событие и снимаем структуру страницы
            # («код» один раз). По снимку видно, та ли поверхность открылась и
            # где именно стоит поле ввода.
            btrace.mark("chat.ready", verdict=self._surface_verdict,
                        blocked=self._surface_blocked, args=self._trace_extra())
            if not getattr(self, "_trace_chat_captured", False):
                self._trace_chat_captured = True
                self._trace_page("chat-ready", full=True)

            # v43.4: заявка, ждущая чистого чата, сначала готовит вложения
            # (заявку и промт) и только потом запускает обычную загрузку.
            # Иначе промт выгружался бы без заявки, а отправка ждала файл,
            # которого нет в очереди.
            if not self._resume_pending_send():
                self._load_prompt()

        except Exception:
            diag.exception("main.py:3369")
            self._on_failed()

    def _check_speech_surface(self):
        """Проверяем, умеет ли этот браузер штатный голосовой ввод страницы.

        QtWebEngine/vanilla Chromium/Edge отдают объект, который либо падает,
        либо молчит. Если ни Web Speech, ни getUserMedia недоступны — пробуем
        следующий браузер из списка (у пользователя может быть и Chrome, и Edge).
        """
        if not self.native_mode or self.worker is None or self.worker.page is None:
            return True
        try:
            surface = speech_surface(self.worker.page)
        except Exception:
            diag.exception("main.speech_surface")
            return True
        if surface.get("sr") or surface.get("gum"):
            return True
        if self._browser_demoted or self.browser_host is None:
            self._set_status(
                "В этом браузере нет голосового ввода — установите Google Chrome",
                THEME["danger"])
            return False
        self._browser_demoted = True
        diag.event("browser.demote", reason="no-speech-surface")
        self._set_status("Голосовой ввод недоступен — пробуем другой браузер…",
                         THEME["muted"])
        QTimer.singleShot(400, self._restart_browser_next)
        return False

    def _restart_browser_next(self):
        if self._closing or self.browser_host is None:
            return
        host = self.browser_host
        try:
            if self.worker is not None:
                self.worker.close_connections()
        except Exception:
            diag.exception("main.demote_close")
        self.worker = None
        self._chat_ready = False
        self.browser_cover.show()
        self.browser_cover.raise_()
        if not host.restart_next():
            self._set_status("Голосовой ввод недоступен — установите Google Chrome",
                             THEME["danger"])
            self._hide_overlay()

    def _auto_select_local_prompt(self) -> bool:
        """Берёт единственный промт из локальной папки автоматически (v26).

        Первый запуск должен идти без вопросов: если в папке «Промт» лежит
        ровно один файл, он и становится рабочим. Если файлов несколько —
        откроется обычный диалог выбора (как и раньше).
        """
        try:
            if self._auto_prompt_tried:
                return False
            self._auto_prompt_tried = True
            items = list_local_prompts()
            if len(items) != 1:
                return False
            self.cfg["selected_prompt"] = items[0]
            save_config(self.cfg)
            self._update_prompt_label()
            diag.event("prompt.auto_selected", filename=items[0])
            return True
        except Exception:
            diag.exception("main.auto_select_prompt")
            return False

    def _load_prompt(self, force=False) -> bool:
        sel = self.cfg.get("selected_prompt", "")
        if not sel and self._auto_select_local_prompt():
            sel = self.cfg.get("selected_prompt", "")
        if not sel:
            # v16: первый запуск на чистой машине (нет %APPDATA%\Legalyze).
            # Раньше здесь просто вставала красная шторка: браузер открывался,
            # GUI был ею закрыт, экспорт .pdf/.txt НЕ начинался — пока
            # пользователь сам не догадается нажать «Промт». Теперь открывается
            # тот же самый диалог выбора, что и по кнопке. Рабочий сценарий
            # (промт уже выбран) не меняется вообще.
            if not getattr(self, "_prompt_picker_shown", False):
                self._prompt_picker_shown = True
                diag.event("prompt.picker_auto", reason="no-selection")
                QTimer.singleShot(0, self._choose_prompt)
            self._show_overlay(
                "Выберите промт",
                "Сейчас откроется список промтов из локальной папки — выберите "
                "файл. Без него отправка запросов заблокирована.",
            )
            return False

        if self.prompt_loader and self.prompt_loader.isRunning():
            return True

        self._last_attached_state = None
        self._show_overlay("Подготовка промта", "Чтение локальной папки «Промт»…")
        self._set_dot("#f59e0b")

        # v26: сервера нет — файлы готовятся из локальной папки «Промт»
        # (сигнатура воркера без token).
        self.prompt_loader = PromptLoaderWorker(self.cfg, force=force)
        self.prompt_loader.progress.connect(lambda m: self.overlay.set_message(m))
        self.prompt_loader.loaded.connect(self._on_prompt_loaded)
        self.prompt_loader.start()
        return True

    def _on_prompt_loaded(self, success, payload):
        if self._closing:
            return
        diag.event("prompt.prepared", success=bool(success))
        if success and isinstance(payload, dict):
            self.pdf_path = Path(payload.get("pdf", ""))
            self.template_path = Path(payload.get("template", "") or str(TEMPLATE_FILE))
            self.overlay.set_message(
                f"Экспорт «{self.pdf_path.name}» + «{TEMPLATE_EXPORT_NAME}» в чат…"
            )
            self._start_upload_thread()
        else:
            self.pdf_attached = False
            self._set_dot(THEME["danger"])
            self._show_overlay("Промт недоступен", str(payload), error=True)
            QTimer.singleShot(8000, lambda: self._load_prompt(force=True))

    def _start_upload_thread(self):
        if not self.worker or not getattr(self.worker, "page", None):
            return

        if not self.pdf_path or not Path(self.pdf_path).exists():
            self._load_prompt(force=True)
            return
        if not self.template_path or not Path(self.template_path).exists():
            self._load_prompt(force=True)
            return

        if self.upload_thread:
            # Актуальное CDP-соединение (после перезагрузки страницы старое
            # мертво) — иначе поток остаётся с мёртвым page навсегда.
            self.upload_thread.page = self.worker.page
            self.upload_thread.page_provider = self._current_page
        if self.upload_thread and self.upload_thread.isRunning() and self.upload_thread._stop:
            self._show_overlay("Предыдущая загрузка останавливается", "Перезапустите клиент перед повторной загрузкой.", error=True)
            return
        self._upload_failed = False
        self.upload_deadline_timer.start(120000)
        if self.upload_thread and self.upload_thread.isRunning():
            self.upload_thread.wait_started = time.monotonic()
            self.upload_thread.pdf_path = self.pdf_path
            self.upload_thread.template_path = self.template_path
            self.upload_thread.document_path = getattr(self, "document_path", None)
            self.upload_thread.appeal_path = getattr(self, "appeal_path", None)
            self.upload_thread.fails = 0
            self.upload_thread.last_upload = 0
            self.upload_thread.end_check_counter = 0
            self.upload_thread.files_loaded = False
            self.upload_thread._dedup_done = False
            return

        if self.upload_thread:
            try:
                self.upload_thread.wait(100)
            except Exception:
                diag.exception("main.py:3435")
                pass

        # v26: token в потоке остаётся только как позиционный параметр.
        self.upload_thread = UploadThread(
            self.worker.page, self.pdf_path, self.template_path, self.token,
            page_provider=self._current_page,
            document_path=getattr(self, "document_path", None),
            appeal_path=getattr(self, "appeal_path", None),
        )
        self.upload_thread.decrement_signal.connect(self._on_decrement)
        self.upload_thread.attached.connect(self._on_files_attached)
        self.upload_thread.failed.connect(self._on_upload_failed)
        self.upload_thread.blocked.connect(self._on_upload_blocked)
        self.upload_thread.start()

    @pyqtSlot(str)
    def _on_upload_blocked(self, verdict):
        """Вложение не работает: сообщаем об этом, НЕ меняя адрес (v55).

        Раньше здесь был автопереход на ВТОРОЙ адрес (чат Gemini), если на
        стартовой странице сервис не давал прикрепить файлы. Замечание
        пользователя: «нужно чтобы ты всегда и только всегда использовал ссылку,
        которая используется при первичном запуске, никаких вторичных если
        первичная не работает».

        Поэтому адрес не подменяется никогда: приложение работает ровно на
        `config.CHAT_URL` (тот же адрес, что и при первичном запуске), а о
        невозможности прикрепить файл пользователь узнаёт из статуса и лога.
        """
        verdict = str(verdict or "unknown")
        diag.state("upload.blocked_verdict", verdict)
        diag.event("upload.blocked_no_fallback", verdict=verdict,
                   url=URL, host=str(getattr(self, "_surface_verdict", "")))
        self._set_status(
            "На этой странице не удалось прикрепить файлы — проверьте лог "
            "и прикрепите вложение вручную", "#f59e0b")

    def _restart_automation(self, reason=""):
        """Перезапустить автоматизацию страницы (v19): ворота пройдут заново."""
        diag.event("automation.restart", reason=str(reason))
        try:
            if self.worker is not None:
                self.worker.requestInterruption()
                self.worker.close_connections()
        except Exception:
            diag.exception("main.restart_automation_close")
        self.worker = None
        self._chat_ready = False
        try:
            if self.upload_thread and self.upload_thread.isRunning():
                self.upload_thread.stop()
        except Exception:
            diag.exception("main.restart_automation_upload")
        QTimer.singleShot(700, self._start_web_automation)

    def _current_page(self):
        """Актуальный CDP page воркера (None, если воркера/соединения нет)."""
        try:
            if self.worker and not self._closing:
                return self.worker.page
        except Exception:
            diag.exception("main.current_page")
        return None

    @pyqtSlot()
    def _upload_wait_expired(self):
        self._on_upload_failed("attachment_deadline")

    @pyqtSlot(str)
    def _on_upload_failed(self, reason):
        if self._closing or self._upload_failed:
            return
        self._upload_failed = True
        self.upload_deadline_timer.stop()
        if self.upload_thread:
            self.upload_thread.stop()
        self.pdf_attached = False
        diag.event("upload.failed", reason=reason)
        self._hide_overlay()
        QMessageBox.warning(self, "Файлы не прикреплены", "Ожидание остановлено. Проверьте вход в Google и доступность чата. "
                           "Закройте сообщение и проверьте страницу (Ctrl+R — обновить). Логи: " + str(diag.LOG_DIR))

    def _on_files_attached(self, attached: bool):
        if self._closing or self._upload_failed:
            return
        attached = bool(attached)
        if attached:
            self.upload_deadline_timer.stop()
        elif not self.upload_deadline_timer.isActive():
            self.upload_deadline_timer.start(120000)
        diag.event("upload.attachments_confirmed", complete=attached)
        if attached == self._last_attached_state:
            return
        self._last_attached_state = attached
        self.pdf_attached = attached

        if attached:
            self.pdf_was_loaded_once = True
            # v43.4: момент подтверждения вложений. Выдержка перед отправкой
            # считается от него — файлам нужно 1–2 с, чтобы прикрепиться.
            self._upload_confirmed_at = time.monotonic()
            self._set_dot(THEME["ok"])
            self._set_status("Готов к работе", THEME["ok"])
            self._hide_overlay()
            # v27: все три файла в чате (промт + Шаблон + заявка на
            # постановление) — отправляем сообщение автоматически, чтобы
            # пользователю не нужно было нажимать ничего вручную.
            # v43.2: заявка после перезапуска отправляется своим путём
            # (`_try_send_pending`) — иначе в чат ушло бы два сообщения.
            if self.document_path and not getattr(
                    self, "_pending_send_record_data", None):
                self._auto_send_document_request()
        else:
            self._set_dot("#f59e0b")
            if not self.pdf_was_loaded_once:
                if self.pdf_path and Path(self.pdf_path).exists():
                    self._show_overlay(
                        "Синхронизация данных",
                        f"Подключение конфигурации и шаблона «{TEMPLATE_EXPORT_NAME}»…",
                    )
            else:
                self._set_status("Синхронизация…", "#f59e0b")

    def _refresh_balance(self):
        """Баланса больше нет (v26): запросов на сервер не уходит."""
        return

    @stage
    def _on_balance(self, ok, remaining, unlimited, unlimited_until):
        """Пустой обработчик совместимости (v26)."""
        return

    def _on_decrement(self):
        """Счётчик запросов удалён (v26): списывать нечего."""
        return

    def _check_response_end_from_ui(self):
        if self._closing or self._response_poll_busy or not self.pdf_attached:
            return
        page = getattr(self.worker, "page", None) if self.worker else None
        if not page:
            return
        self._response_poll_busy = True
        def task():
            value = None
            try:
                value = int(page.eval(JS_CHECK_END, timeout=1).get("value") or 0)
            except Exception:
                diag.exception("response.poll")
            finally:
                self.response_poll_finished.emit(value)
        threading.Thread(target=task, name="ResponsePoll", daemon=True).start()

    @pyqtSlot(object)
    def _apply_response_poll(self, current_markers_count):
        """Ответ ИИ отслеживается только для индикатора — без списаний (v26)."""
        self._response_poll_busy = False
        return

    def _on_decrement_finished(self, ok, remaining):
        """Списанных запросов больше нет (v26)."""
        return

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _on_failed(self):
        if self._closing:
            return
        diag.event("webengine.not_ready", **getattr(self.worker, "failure", {}))
        self._hide_overlay()
        if self.native_mode and self._crash_recoveries < 2:
            # Страница не стала чатом (согласие/вход/сеть): перезапускаем
            # браузер целиком — это то, чего не хватало прежней сборке.
            self._crash_recoveries += 1
            self._set_status("Перезапуск браузера…", THEME["muted"])
            self.browser_cover.show()
            self.browser_cover.raise_()
            try:
                if self.browser_host is not None:
                    self.browser_host.stop()
            except Exception:
                diag.exception("main.host_stop")
            self.worker = None
            diag.event("browser.restart", attempt=self._crash_recoveries)
            QTimer.singleShot(800, self._start_chrome)
            return
        self._set_status("Войдите в Google; Ctrl+R — повтор", THEME["danger"])

    @stage
    def _cleanup(self):
        if self._cleaned:
            return

        self._cleaned = True
        self.upload_deadline_timer.stop()
        self.response_end_timer.stop()
        self.topmost_timer.stop()
        if getattr(self, "zoom_timer", None) is not None:
            self.zoom_timer.stop()
        if getattr(self, "taskbar_timer", None) is not None:
            self.taskbar_timer.stop()
        self.chrome_hwnd = None

        try:
            self.overlay.finish()
            self.overlay.deleteLater()
        except Exception:
            diag.exception("main.py:3560")
            pass

        try:
            if getattr(self, "browser_host", None) is not None:
                self.browser_host.stop()
        except Exception:
            diag.exception("main.py:host_cleanup")
            pass
        # Браузер снят вместе со всем деревом — журнал можно очистить.
        try:
            _pid_journal_write([])
        except Exception:
            diag.exception("main.pid_journal_clear")

        try:
            if self.upload_thread:
                self.upload_thread.stop()
                self.upload_thread.wait(1500)
        except Exception:
            diag.exception("main.py:3568")
            pass

        try:
            if self.prompt_loader and self.prompt_loader.isRunning():
                self.prompt_loader.wait(1000)
        except Exception:
            diag.exception("main.py:3575")
            pass

        worker = self.worker
        if worker:
            worker.requestInterruption()
            worker.close_connections()
        # Let bounded network tasks finish before QObject/profile destruction.
        for task in (worker, self.upload_thread, self.prompt_loader):
            if task and task.isRunning():
                task.wait()
        if worker:
            worker.close_connections()
        if hasattr(self, "web_browser"):
            self.web_browser.shutdown()
        self._unregister_hotkeys()
        try:
            self.hotkeys.stop()
        except Exception:
            diag.exception("main.hotkeys_stop")

        try:
            if self.pdf_path and WORKSPACE.path in Path(self.pdf_path).parents:
                shred_file(self.pdf_path)
        except Exception:
            diag.exception("main.py:3623")
            pass

        try:
            WORKSPACE.dispose()
            purge_plaintext_artifacts(DATA_DIR)
        except Exception:
            diag.exception("main.py:3630")
            pass

        # v20: закрыть приборную панель браузера ПОСЛЕ остановки браузера и
        # рабочих потоков: здесь дописываются итог (`UNDERSTANDING.md`),
        # машинная сводка и сбрасываются на диск все файлы сбора. Без этого
        # последние строки оставались в буфере и пользователь копировал
        # неполную сессию (проверено: `browser-trace.txt` выходил 0 байт).
        try:
            self._final_selfchecks()
        except Exception:
            diag.exception("main.final_selfchecks")
        try:
            btrace.stop_watchers()
            btrace.finish()
        except Exception:
            diag.exception("main.trace_finish")

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _close_app(self):
        if self._closing:
            return

        self._closing = True
        self._cleanup()

        try:
            QApplication.instance().quit()
        except Exception:
            diag.exception("main.py:3644")
            pass

        diag.event("session.qt_exit", reason="close or restart")
        QApplication.instance().quit()

    @pyqtSlot()  # Explicit zero-argument Qt slot: clicked(bool) must not reach @stage.
    @stage
    def _restart(self):
        if self._closing:
            return

        self._closing = True
        self._cleanup()
        restart_app()
        diag.event("session.qt_exit", reason="close or restart")
        QApplication.instance().quit()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if event.position().y() <= self.top_inset:
                self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and not self.drag_position.isNull():
            self.move(event.globalPosition().toPoint() - self.drag_position)
            if self.overlay.isVisible():
                self.overlay.sync_geometry()
            event.accept()

    def mouseReleaseEvent(self, event):
        self.drag_position = QPoint()
        event.accept()

    def closeEvent(self, event):
        self._close_app()
        event.accept()


def _pid_journal_read() -> list:
    """pid браузера, который запускал ПРОШЛЫЙ экземпляр приложения."""
    try:
        data = json.loads(BROWSER_PIDS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return [int(p) for p in data if str(p).lstrip("-").isdigit()]
    except Exception:
        pass
    return []


def _pid_journal_write(pids) -> None:
    try:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        BROWSER_PIDS_FILE.write_text(
            json.dumps(sorted({int(p) for p in pids})[:200]), encoding="utf-8")
    except Exception:
        diag.exception("main.pid_journal_write")


def _kill_leftover_browsers() -> None:
    """Добить браузер, оставшийся от прошлого запуска (только СВОЙ).

    Прошлый запуск мог упасть или быть убит: тогда его Chrome остаётся висеть
    в панели задач и держит профиль (синглтон), из-за чего новый процесс
    молча выходит. Имя процесса проверяется, чтобы никогда не снять чужой.
    """
    pids = _pid_journal_read()
    _pid_journal_write([])
    if not pids:
        return
    names = win32_embed.process_names()
    stale = [p for p in pids
             if str(names.get(p, "")).lower() in win32_embed.BROWSER_EXE_NAMES]
    if not stale:
        return
    user32 = ctypes.WinDLL("user32", use_last_error=True) if sys.platform == "win32" else None
    if user32 is not None:
        win32_embed.configure(user32)
    try:
        win32_embed.hide_stray_windows(user32, stale)
        win32_embed.kill_tree(stale)
    except Exception:
        diag.exception("main.leftover_kill")
    diag.event("browser.leftover_killed", pids=stale, known=len(pids))


def _migrate_config_secrets(cfg: dict) -> dict:
    """Совместимость со старыми конфигами (v26).

    Логина и пароля в приложении больше нет, поэтому единственное, что нужно
    сделать со старым config.json, — стереть сохранённые учётные данные:
    незачем хранить то, что больше не используется.
    """
    try:
        if cfg.get("password") or cfg.get("login") or cfg.get("token"):
            cfg["password"] = ""
            cfg["login"] = ""
            cfg["token"] = ""
            cfg["remember"] = False
            save_config(cfg)
    except Exception:
        diag.exception("main.migrate_config_secrets")
        pass
    return cfg


def purge_stray_sources(app_dir, data_dir) -> int:
    r"""Удалить .py/.pyc, если они всё-таки оказались в хранилище (v16).

    Клиент НИКОГДА не записывает исходники в %APPDATA%\Legalyze. Проверено по
    всему коду: единственные записи в эту папку — config.json, Шаблон.txt,
    data/DejaVuSans.ttf, data/prompt_cache.json, data/prompts/*,
    browser-pids.json, логи и профиль браузера. Значит .py могут попасть туда
    только извне: из старой папки при миграции, от ручного запуска из исходников
    или если пользователь сам скопировал. Удаляем их и пишем в лог, чтобы в
    папке оставалось только то, что создаёт сама программа.
    """
    removed = 0
    for root in (app_dir, data_dir):
        try:
            d = Path(root)
            if not d.exists() or not d.is_dir():
                continue
            for pattern in ("*.py", "*.pyc", "*.pyo", "*.pyw", "*.spec"):
                for f in d.glob(pattern):
                    try:
                        if f.is_file():
                            f.unlink()
                            removed += 1
                    except Exception:
                        diag.exception("main.purge_stray_sources")
            cache = d / "__pycache__"
            if cache.is_dir():
                shutil.rmtree(cache, ignore_errors=True)
                removed += 1
        except Exception:
            diag.exception("main.purge_stray_sources_root")
    if removed:
        diag.event("storage.stray_py", removed=int(removed))
    return removed


@stage
def main():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("legalyze.desktop.app")
        except Exception:
            diag.exception("main.appusermodelid")

    APP_DIR.mkdir(parents=True, exist_ok=True)
    instance_lock = QLockFile(str(APP_DIR / "diagnostic-client.lock"))
    instance_lock.setStaleLockTime(0)
    if not instance_lock.tryLock(100):
        diag.event("instance.already_running")
        return
    legacy_locks = []
    try:
        locked_roots = set()
        for label, old_root in storage_paths.legacy_roots():
            if old_root.exists() and old_root not in locked_roots:
                locked_roots.add(old_root)
                old_lock = QLockFile(str(old_root / "diagnostic-client.lock"))
                old_lock.setStaleLockTime(0)
                if not old_lock.tryLock(100):
                    raise RuntimeError("Old diagnostic client is still running")
                legacy_locks.append(old_lock)
        # Release lock file handles before directory rename (mandatory on Windows).
        # The old clients must be closed; browser-process preflight runs in migrator.
        for old_lock in legacy_locks:
            old_lock.unlock()
        for migration in storage_paths.migrate_legacy(APP_DIR, storage_paths.legacy_roots()):
            diag.event("storage.migrated", **migration)
    except Exception:
        diag.exception("storage.migration")
        if user32:
            user32.MessageBoxW(None,
                "Не удалось безопасно перенести старые данные. Закройте старые версии Legalyze и их Chromium, затем повторите запуск. "
                "Данные не удалялись принудительно. Логи: " + str(diag.LOG_DIR), "Legalyze — перенос данных", 0x30)
        return
    finally:
        for old_lock in legacy_locks:
            old_lock.unlock()
    diag.event("storage.paths", app_dir=str(APP_DIR), data_dir=str(DATA_DIR), profile=str(PROFILE), logs=str(diag.LOG_DIR))
    cfg = load_config()
    cfg = _migrate_config_secrets(cfg)
    try:
        ensure_template_file(cfg.get("template", {}))
    except Exception:
        diag.exception("main.py:3711")
        pass
    purge_plaintext_artifacts(DATA_DIR)
    # v16: в хранилище данных лежат только данные — исходники там не место.
    purge_stray_sources(APP_DIR, DATA_DIR)
    # v15: перед запуском своего браузера убираем окна прошлого запуска.
    _kill_leftover_browsers()

    app = QApplication(sys.argv)
    diag.install_qt(app)
    app.setApplicationName("Legalyze")
    app.setApplicationDisplayName("Legalyze")
    if ICON_FILE.exists():
        app.setWindowIcon(QIcon(str(ICON_FILE)))
    app.setQuitOnLastWindowClosed(False)
    app.setStyleSheet(BASE_QSS)

    # ── v26: АВТОРИЗАЦИИ НЕТ ────────────────────────────────────────────────
    # Раньше здесь открывалось окно «Вход в аккаунт» (логин/пароль/HWID) и
    # блокировало запуск. Теперь приложение стартует сразу с работы.
    # Если Шаблон не заполнен — первым открывается окно «Шаблон» (как и
    # просили), после него работа продолжается без лишних вопросов.
    token = ""
    user_data = {}

    if not get_template_filled(cfg):
        diag.event("template.required", filled=False)
        try:
            tpl_win = TemplateWindow(cfg, parent=None)
            if tpl_win.exec() == QDialog.DialogCode.Accepted:
                save_template(cfg, tpl_win.get_template())
            else:
                diag.event("template.dismissed")
        except Exception:
            diag.exception("main.template_window")

    # Промт на первом запуске выбирается уже в рабочем окне: кнопка «Промт»
    # и автоматический выбор из локальной папки (см. `_load_prompt`).

    diag.event("startup.ready", template_filled=bool(get_template_filled(cfg)),
               prompt_selected=bool(str(cfg.get("selected_prompt", "") or "").strip()))

    window = MainWindow(cfg, token, user_data)
    diag.place_window(window, app)
    window.show()
    window.raise_()
    window.activateWindow()
    diag.monitor_window(window)
    diag.event("main.shown", visible=window.isVisible(), geometry=window.geometry().getRect())
    force_topmost(int(window.winId()))

    sys.exit(app.exec())


@stage
def _enforce_latest_version(token: str = ""):
    """Проверки версии на сервере больше нет (v26).

    Функция оставлена, потому что её имя встречается в тестах и в истории:
    локальному клиенту не у кого спрашивать версию, и закрывать себя из-за
    неё он тоже не должен.
    """
    return


if __name__ == "__main__":
    main()
